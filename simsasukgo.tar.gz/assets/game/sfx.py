"""효과음 재생. assets/sounds/<이름>.wav|.ogg 가 있으면 재생하고, 없으면 조용히 넘어간다.

사운드 파일은 tools/make_sfx.py 로 생성한다.
이름: click, pop, boing, paper, stamp, correct, wrong, bell, fanfare, blip_<low|mid|high>_<1~5>
"""
import os
import random

import pygame

from .config import ASSET_DIR

_cache: dict[str, "pygame.mixer.Sound | None"] = {}
_ok: bool | None = None
muted = False          # M 키로 전체 소리 끄기/켜기
master = 1.0           # 설정의 효과음 크기 (0~1)


def _ready() -> bool:
    global _ok
    if _ok is None:
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.set_num_channels(24)
            _ok = True
        except Exception:
            _ok = False
    return _ok


def play(name: str, volume: float = 0.6):
    if muted or not _ready():
        return
    if name not in _cache:
        _cache[name] = None
        for ext in (".wav", ".ogg"):
            path = os.path.join(ASSET_DIR, "sounds", name + ext)
            if os.path.exists(path):
                try:
                    _cache[name] = pygame.mixer.Sound(path)
                except Exception:
                    pass
                break
    snd = _cache[name]
    if snd:
        snd.set_volume(volume * master)
        snd.play()


_last_blip = 0


def blip(voice: str, volume: float = 0.32):
    """말소리 한 톨. 5음계 중 직전과 다른 음을 골라 재잘재잘 멜로디처럼 들리게."""
    global _last_blip
    k = random.choice([i for i in range(1, 6) if i != _last_blip])
    _last_blip = k
    play(f"blip_{voice}_{k}", volume)
