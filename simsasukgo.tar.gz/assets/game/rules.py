"""규정 검증 엔진 — 게임의 '정답'을 판정한다.

규칙 문구/도입일은 data/rules.json, 실제 판정 로직은 여기.
새 규정 추가: rules.json 에 항목 추가 → CHECKS 에 함수 등록 → generator.INJECTORS 에 위반 생성 함수 등록.
"""
from dataclasses import dataclass

from .config import GUARANTEE_RATE
from .models import Bid, Notice


@dataclass
class Context:
    notice: Notice
    debarred_biz_nos: set[str]


def _r01(bid: Bid, ctx: Context) -> bool:
    return "registration" in bid.docs


def _r02(bid: Bid, ctx: Context) -> bool:
    reg = bid.docs.get("registration")
    return reg is None or reg["사업자번호"] == bid.form["사업자번호"]


def _r03(bid: Bid, ctx: Context) -> bool:
    return bid.form["제출시각"] <= ctx.notice.deadline


def _r04(bid: Bid, ctx: Context) -> bool:
    return bid.form["사업자번호"] not in ctx.debarred_biz_nos


def _r05(bid: Bid, ctx: Context) -> bool:
    g = bid.docs.get("guarantee")
    if g is None:
        return False
    return g["보증금액"] >= bid.price * GUARANTEE_RATE and g["보증만료일"] >= ctx.notice.today


def _r06(bid: Bid, ctx: Context) -> bool:
    return bid.price <= ctx.notice.est_price


def _r07(bid: Bid, ctx: Context) -> bool:
    if not ctx.notice.sme_only:
        return True
    dp = bid.docs.get("direct_production")
    if dp is None:
        return False
    return dp["확인품목"] == ctx.notice.item and dp["유효기간"] >= ctx.notice.today


def _r08(bid: Bid, ctx: Context) -> bool:
    doc = bid.docs.get("integrity")
    return doc is not None and doc["서명"] is True


def _r09(bid: Bid, ctx: Context) -> bool:
    name = bid.company
    return all(d.get("상호", name) == name for d in bid.docs.values())


CHECKS = {
    "R01": _r01, "R02": _r02, "R03": _r03, "R04": _r04, "R05": _r05,
    "R06": _r06, "R07": _r07, "R08": _r08, "R09": _r09,
}


def evaluate(bid: Bid, ctx: Context, active_rule_ids) -> list[str]:
    """위반한 규정 ID 목록. 빈 리스트 = 승인이 정답."""
    return [rid for rid in active_rule_ids if not CHECKS[rid](bid, ctx)]


# 판정 결과
CORRECT = "correct"          # 정답
PARTIAL = "partial"          # 반려는 맞지만 사유가 틀림
WRONG = "wrong"              # 오판


def judge(violations: list[str], approved: bool, reason: str | None) -> str:
    if approved:
        return CORRECT if not violations else WRONG
    if not violations:
        return WRONG
    return CORRECT if reason in violations else PARTIAL
