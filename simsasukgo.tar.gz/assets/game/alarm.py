"""마감 임박 알림 — 세 편(심사숙GO·납품하GO·요청하GO)이 같이 쓴다.

제한시간이 warn 초 아래로 내려가는 순간:  '띠링띠링' 경고음 + 화면 위쪽에 "마감 임박!" 딱지가 잠깐 뜬다.
그 뒤로는 화면 가장자리가 붉게 숨 쉬듯 깜빡이고, 마지막 last 초 동안은 초마다 '똑' 소리가 난다.

    self.alarm = Alarm()
    self.alarm.update(dt, 남은 초, 시계가 가고 있는가, warn=30)      # update 에서
    self.alarm.draw(surf)                                         # draw 의 맨 끝에서
"""
import math

import pygame

from . import sfx, ui
from .config import WIDTH

RED = (226, 64, 56)
_edge: dict = {}


def _vignette(size) -> pygame.Surface:
    """가장자리만 붉은 테두리 (가운데는 비어 있어 놀이를 가리지 않는다)."""
    if size not in _edge:
        w, h = size
        s = pygame.Surface(size, pygame.SRCALPHA)
        band = 46
        for i in range(band):
            a = int(150 * (1 - i / band) ** 2)
            pygame.draw.rect(s, (*RED, a), (i, i, w - i * 2, h - i * 2), 1)
        _edge[size] = s
    return _edge[size]


class Alarm:
    def __init__(self, last=10):
        self.last = last
        self.on = False          # 지금 임박 상태인가
        self.left = 0.0
        self.t = 0.0             # 임박 상태가 된 뒤 흐른 시간
        self.sec = None          # 마지막으로 '똑' 소리를 낸 초
        self.label = "마감 임박!"
        self.paused = False

    def reset(self):
        self.on, self.t, self.sec = False, 0.0, None

    def update(self, dt, left, active=True, warn=30.0, label="마감 임박!"):
        """left = 남은 초. active = 시계가 가는 중인가 (멈춰 있으면 알림도 쉰다)."""
        if not 0 < left <= warn:                                # 여유가 있거나 이미 끝났다
            self.on = False
            return
        self.paused = not active                                 # 시계가 멈춘 동안은 조용히 기다린다 (다시 울리지 않는다)
        if self.paused:
            return
        self.left, self.label = left, label
        if not self.on:                                          # 막 임박해졌다
            self.on, self.t, self.sec = True, 0.0, None
            sfx.play("alarm", 0.6)
        self.t += dt
        sec = math.ceil(left)
        if sec <= self.last and sec != self.sec and self.t > 0.9:      # 마지막 몇 초: 초마다 똑
            sfx.play("tick", 0.5 if sec > 3 else 0.7)
        self.sec = sec

    def draw(self, surf):
        if not self.on or self.paused:
            return
        fast = self.left <= self.last
        pulse = (math.sin(self.t * (9 if fast else 4.5)) + 1) / 2
        edge = _vignette(surf.get_size())
        edge.set_alpha(int((120 if fast else 70) + 135 * pulse))
        surf.blit(edge, (0, 0))
        if self.t < 2.4:                                         # 처음 잠깐: 딱지가 통 하고 내려온다
            k = min(1.0, self.t / 0.18)
            out = max(0.0, (self.t - 2.0) / 0.4)
            y = int(-50 + 150 * (1 - (1 - k) ** 3) - 120 * out)
            text = self.label
            w = ui.fonts.get(26, "heavy").size(text)[0] + 60
            r = pygame.Rect((WIDTH - w) // 2, y, w, 54)
            r.x += int(math.sin(self.t * 40) * 5 * max(0.0, 1 - self.t / 0.7))
            pygame.draw.rect(surf, (120, 30, 26), r.move(4, 5), border_radius=27)
            pygame.draw.rect(surf, RED, r, border_radius=27)
            pygame.draw.rect(surf, (255, 240, 220), r, 3, border_radius=27)
            ui.draw_text(surf, text, r.center, 26, (255, 250, 236), "heavy", center=True)
