import math

import pygame

from . import fonts, sfx, sticker
from .anim import ease_out_back
from .config import (C_DESK, C_DESK_EDGE, C_DESK_GRAIN, C_INK, C_PANEL, C_PAPER, C_PAPER_EDGE,
                     C_WHITE, HEIGHT, WIDTH)


# ------------------------------------------------------------------ 텍스트
def won(n) -> str:
    """금액을 읽기 쉽게: 15000000 → '1,500만원', 120000000 → '1억 2,000만원' (0 을 줄줄이 세지 않게)."""
    n = int(n)
    sign, n = ("-" if n < 0 else ""), abs(n)
    eok, rest = divmod(n, 10 ** 8)
    man, one = divmod(rest, 10 ** 4)
    parts = ([f"{eok:,}억"] if eok else []) + ([f"{man:,}만"] if man else []) + ([f"{one:,}"] if one or not n else [])
    return sign + " ".join(parts) + "원"


_text_cache: dict = {}
_wrap_cache: dict = {}
CACHE_MAX = 1500          # 글자 그림을 기억해 둔다 (같은 글자를 매 프레임 다시 그리지 않게 — 웹에서 특히 느림)


def text_image(text, size=18, color=C_INK, bold=False):
    key = (str(text), size, tuple(color), bold)
    img = _text_cache.get(key)
    if img is None:
        if len(_text_cache) >= CACHE_MAX:
            _text_cache.clear()
        img = _text_cache[key] = fonts.get(size, bold).render(key[0], True, color)
    return img


def draw_text(surf, text, pos, size=18, color=C_INK, bold=False, center=False, anchor=None):
    img = text_image(text, size, color, bold)
    rect = img.get_rect()
    if center:
        rect.center = pos
    elif anchor:
        setattr(rect, anchor, pos)
    else:
        rect.topleft = pos
    surf.blit(img, rect)
    return rect


def wrap(text, size, max_width, bold=False):
    """단어 단위로 줄바꿈하고, 한 단어가 너무 길면 글자 단위로 자른다."""
    key = (str(text), size, max_width, bold)
    if key in _wrap_cache:
        return _wrap_cache[key]
    if len(_wrap_cache) >= CACHE_MAX:
        _wrap_cache.clear()
    font = fonts.get(size, bold)
    lines = _wrap_cache[key] = []
    for para in str(text).split("\n"):
        line = ""
        for word in para.split(" "):
            cand = f"{line} {word}" if line else word
            if font.size(cand)[0] <= max_width:
                line = cand
                continue
            if line:
                lines.append(line)
            line = ""
            for ch in word:
                if font.size(line + ch)[0] > max_width and line:
                    lines.append(line)
                    line = ch
                else:
                    line += ch
        lines.append(line)
    return lines


def draw_wrapped(surf, text, rect, size=16, color=C_INK, bold=False, line_gap=2):
    x, y = rect[0], rect[1]
    h = fonts.get(size, bold).get_linesize() + line_gap
    for line in wrap(text, size, rect[2], bold):
        draw_text(surf, line, (x, y), size, color, bold)
        y += h
    return y


_logo_cache: dict = {}


def pps_logo(surf, topleft, height=40):
    """조달청 로고 (공모전 제공 자료, 비율·색 그대로). 흰 바탕 판 위에 올린다."""
    import os

    from .config import ASSET_DIR
    if height not in _logo_cache:
        path = os.path.join(ASSET_DIR, "images", "pps_logo.png")
        img = pygame.image.load(path).convert() if os.path.exists(path) else None
        if img:
            img = pygame.transform.smoothscale(img, (int(height * img.get_width() / img.get_height()), height))
        _logo_cache[height] = img
    img = _logo_cache[height]
    if img is None:
        return
    plate = img.get_rect(topleft=topleft).inflate(16, 8)
    pygame.draw.rect(surf, (255, 255, 255), plate, border_radius=8)
    pygame.draw.rect(surf, (214, 196, 170), plate, 2, border_radius=8)
    surf.blit(img, topleft)


# ------------------------------------------------------------------ 도형
_shadow_cache: dict = {}


def shadow(surf, rect, radius=14, alpha=45, offset=(5, 6)):
    """카툰풍: 흐리지 않고 또렷한 그림자를 오른쪽 아래로."""
    rect = pygame.Rect(rect)
    key = (rect.size, radius, alpha)
    if key not in _shadow_cache:
        s = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(s, (60, 35, 20, min(255, alpha + 12)), s.get_rect(), border_radius=radius)
        _shadow_cache[key] = s
    surf.blit(_shadow_cache[key], (rect.x + offset[0], rect.y + offset[1]))


def panel(surf, rect, color=C_PANEL, radius=16, border=None, shadow_alpha=0, border_w=3):
    if shadow_alpha:
        shadow(surf, rect, radius, shadow_alpha)
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border:
        pygame.draw.rect(surf, border, rect, border_w, border_radius=radius)


def paper(surf, rect, lift=0):
    """외곽선이 있는 종이 한 장."""
    rect = pygame.Rect(rect).move(0, -lift)
    shadow(surf, rect, 8, 44, (5 + lift // 2, 6 + lift))
    pygame.draw.rect(surf, C_PAPER, rect, border_radius=8)
    pygame.draw.rect(surf, C_PAPER_EDGE, (rect.x + 3, rect.bottom - 18, rect.w - 6, 15),
                     border_bottom_left_radius=8, border_bottom_right_radius=8)
    pygame.draw.rect(surf, C_INK, rect, 3, border_radius=8)
    return rect


def pill(surf, rect, text, color=C_WHITE, text_color=C_INK, size=18, bold=True):
    r = pygame.Rect(rect)
    shadow(surf, r, r.h // 2, 40, (3, 4))
    pygame.draw.rect(surf, color, r, border_radius=r.h // 2)
    pygame.draw.rect(surf, C_INK, r, 3, border_radius=r.h // 2)
    draw_text(surf, text, r.center, size, text_color, bold, center=True)


def desk_background(surf, y0=0):
    surf.fill(C_DESK, (0, y0, WIDTH, HEIGHT - y0))
    for i, y in enumerate(range(y0 + 30, HEIGHT, 46)):
        x = (i * 173) % 400
        pygame.draw.line(surf, C_DESK_GRAIN, (0, y), (WIDTH, y + (i % 3) - 1), 3)
        pygame.draw.ellipse(surf, C_DESK_GRAIN, (x + 200, y - 8, 120, 16), 2)
    pygame.draw.line(surf, C_DESK_EDGE, (0, y0), (WIDTH, y0), 4)


# ------------------------------------------------------------------ 풍선 버튼
def _shade(c, k):
    """k>0 밝게, k<0 어둡게."""
    return tuple(max(0, min(255, int(v + (255 - v) * k if k > 0 else v * (1 + k)))) for v in c)


_balloon_cache: dict = {}


def _balloon(w, h, color, parts, size):
    """반짝이는 풍선 몸통 + 아래 매듭 + 스티커 글씨. (크기·색·글씨별 캐시)"""
    key = (w, h, color, tuple(parts), size)
    if key in _balloon_cache:
        return _balloon_cache[key]
    pad, knot_h = 8, 14
    s = pygame.Surface((w + pad * 2, h + pad * 2 + knot_h), pygame.SRCALPHA)
    body = pygame.Rect(pad, pad, w, h)
    r = h // 2
    light, dark = _shade(color, 0.45), _shade(color, -0.28)

    # 매듭 (몸통 뒤)
    kx, ky = body.centerx, body.bottom
    knot = [(kx - 10, ky - 6), (kx + 10, ky - 6), (kx + 6, ky + knot_h - 2), (kx - 6, ky + knot_h - 2)]
    pygame.draw.polygon(s, dark, knot)
    pygame.draw.polygon(s, sticker.INK, knot, 3)

    # 테두리 + 위→아래 그라데이션 몸통
    pygame.draw.rect(s, sticker.INK, body.inflate(8, 8), border_radius=r + 4)
    grad = pygame.Surface(body.size, pygame.SRCALPHA)
    for y in range(h):
        t = y / max(1, h - 1)
        c = tuple(int(light[i] + (color[i] - light[i]) * min(1.0, t * 2.2)) for i in range(3))
        if t > 0.72:
            c = tuple(int(c[i] + (dark[i] - c[i]) * (t - 0.72) / 0.28) for i in range(3))
        pygame.draw.line(grad, c, (0, y), (w, y))
    mask = pygame.Surface(body.size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=r)
    grad.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(grad, body.topleft)

    # 광택: 왼쪽 위 길쭉한 하이라이트 + 오른쪽 위 반짝 점
    gloss = pygame.Surface(body.size, pygame.SRCALPHA)
    pygame.draw.ellipse(gloss, (255, 255, 255, 120), (int(r * 0.5), int(h * 0.11), int(w * 0.42), int(h * 0.28)))
    pygame.draw.circle(gloss, (255, 255, 255, 190), (int(w - r * 0.75), int(h * 0.3)), max(3, h // 13))
    s.blit(gloss, body.topleft)

    # 스티커 글씨
    label = sticker.fit(sticker.sticker_line(parts, size), int(w - r * 0.8), h - 8)
    s.blit(label, label.get_rect(center=(body.centerx, body.centery + 1)))
    _balloon_cache[key] = s
    return s


class Button:
    """풍선 버튼 — 둥실 떠 있고, 마우스를 올리면 부풀고, 누르면 말랑하게 눌린다.

    label 대신 parts=[("적격 ", sticker.WHITE), ("GO!", sticker.YELLOW)] 로 색 조각을 줄 수 있다.
    """

    def __init__(self, rect, label, color, text_color=None, size=22, parts=None, float_amp=3.0):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.color = color
        self.parts = parts or [(label, sticker.WHITE)]
        self.size = size + 4
        self.enabled = True
        self.pulse = False            # True 면 '눌러줘!' 하고 통통 (예: 반려 사유 기다릴 때)
        self.float_amp = float_amp
        self.hover_t = 0.0
        self.press_t = 0.0
        self.t = (self.rect.x * 0.013) % 6.28   # 버튼마다 둥실 박자를 다르게

    def hovered(self):
        return self.enabled and self.rect.collidepoint(pygame.mouse.get_pos())

    def clicked(self, event):
        hit = (self.enabled and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
               and self.rect.collidepoint(event.pos))
        if hit:
            self.press()
            sfx.play("click", 0.4)
        return hit

    def press(self):
        self.press_t = 0.32

    def update(self, dt):
        self.t += dt
        target = 1.0 if self.hovered() else 0.0
        self.hover_t += (target - self.hover_t) * min(1.0, dt * 12)
        self.press_t = max(0.0, self.press_t - dt)

    def draw(self, surf):
        img = _balloon(self.rect.w, self.rect.h, self.color, self.parts, self.size)
        bob = math.sin(self.t * 2.3) * self.float_amp if self.enabled else 0.0
        grow = 1 + 0.07 * self.hover_t
        if self.pulse:
            grow += 0.05 * abs(math.sin(self.t * 7))
        sx = sy = grow
        if self.press_t > 0:                                  # 말랑 스쿼시 → 튕김
            k = self.press_t / 0.32
            wob = math.sin((1 - k) * math.pi * 2.5) * k
            sx, sy = grow * (1 + 0.14 * wob), grow * (1 - 0.14 * wob)
        w, h = int(img.get_width() * sx), int(img.get_height() * sy)
        if (w, h) != img.get_size():
            img = pygame.transform.smoothscale(img, (w, h))
        if not self.enabled:
            img = img.copy()
            img.set_alpha(130)

        # 바닥 그림자 (떠오르면 작아짐)
        sw = int(self.rect.w * (0.8 - bob * 0.01))
        sh_surf = pygame.Surface((sw, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(sh_surf, (90, 50, 20, 45 if self.enabled else 20), sh_surf.get_rect())
        surf.blit(sh_surf, sh_surf.get_rect(center=(self.rect.centerx, self.rect.bottom + 16)))

        cy = self.rect.centery - bob - 3 * self.hover_t + 7       # +7: 매듭 높이 보정
        surf.blit(img, img.get_rect(center=(self.rect.centerx, int(cy))))


# ------------------------------------------------------------------ 말풍선
class Typewriter:
    def __init__(self, text: str = "", cps: float = 42, voice: str | None = None):
        self.voice = voice          # 'low' | 'mid' | 'high' → 글자가 찍힐 때 말소리
        self.set(text, cps)

    def set(self, text: str, cps: float = 42):
        self.text = text
        self.cps = cps
        self.pos = 0.0
        self.age = 0.0

    @property
    def done(self):
        return self.pos >= len(self.text)

    @property
    def shown(self):
        return self.text[: int(self.pos)]

    def skip(self):
        self.pos = len(self.text)

    def update(self, dt):
        self.age += dt
        if not self.done:
            before = int(self.pos)
            self.pos = min(len(self.text), self.pos + self.cps * dt)
            after = int(self.pos)
            if self.voice and after > before:
                # 두 글자마다 한 번, 공백·문장부호는 건너뜀
                for i in range(before, after):
                    if i % 2 == 0 and self.text[i].strip() and self.text[i] not in ".,!?…~()":
                        sfx.blip(self.voice)
                        break


def speech_bubble(surf, rect, tw: Typewriter, tail=None, name=None, size=17):
    """만화 말풍선. tail=(x, y) 꼬리 끝 — 말풍선의 어느 쪽에 있든 그쪽으로 꼬리가 난다."""
    if not tw.text:
        return
    k = ease_out_back(tw.age / 0.25)
    rect = pygame.Rect(rect)
    if k < 1:
        rect = rect.inflate(-rect.w * (1 - k) * 0.3, -rect.h * (1 - k) * 0.3)
    shadow(surf, rect, 24, 44)
    base = None
    if tail:
        tx, ty = tail
        if ty > rect.bottom or ty < rect.y:
            bx = max(rect.x + 44, min(rect.right - 44, tx))
            edge = rect.bottom - 3 if ty > rect.bottom else rect.y + 3
            base = [(bx - 17, edge), (bx + 17, edge)]
        else:
            by = max(rect.y + 34, min(rect.bottom - 34, ty))
            edge = rect.x + 3 if tx < rect.x else rect.right - 3
            base = [(edge, by - 15), (edge, by + 15)]
        pygame.draw.polygon(surf, C_WHITE, [base[0], tail, base[1]])
        pygame.draw.lines(surf, C_INK, False, [base[0], tail, base[1]], 3)
    pygame.draw.rect(surf, C_WHITE, rect, border_radius=24)
    pygame.draw.rect(surf, C_INK, rect, 3, border_radius=24)
    if base:                                              # 꼬리와 몸통 사이 외곽선 지우기
        inset = 4
        (x1, y1), (x2, y2) = base
        if x1 == x2:
            dx = inset if x1 < rect.centerx else -inset
            pygame.draw.line(surf, C_WHITE, (x1 + dx, y1 + 3), (x2 + dx, y2 - 3), 7)
        else:
            dy = -inset if y1 > rect.centery else inset
            pygame.draw.line(surf, C_WHITE, (x1 + 3, y1 + dy), (x2 - 3, y2 + dy), 7)
    y = rect.y + 13
    if name:
        draw_text(surf, name, (rect.x + 20, y), 14, (214, 110, 70), bold=True)
        y += 22
    draw_wrapped(surf, tw.shown, (rect.x + 20, y, rect.w - 40, rect.h), size)
