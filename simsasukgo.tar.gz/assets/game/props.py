"""현장 소품 — 창구 벽, 창문, 시계, 일력, 게시판, 카운터, 클립보드, 노트…

카툰 렌더링 규칙 (캐릭터와 통일):
  1) 모든 물건에 진갈색 굵은 외곽선(INK)
  2) 그림자는 흐리지 않고 또렷하게, 오른쪽 아래로 살짝 (hard_shadow)
  3) 면은 단색 + 아래쪽에 한 단계 어두운 띠(셀 셰이딩)
"""
import math
import random

import pygame

from . import fonts, sfx, ui
from .anim import clamp01, ease_in_out_sine
from .config import HEIGHT, WIDTH

INK = (74, 52, 40)
INK_SOFT = (150, 120, 100)
SHADOW = (60, 35, 20)
RED = (226, 76, 76)

_cache: dict = {}


def lerp_c(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# ------------------------------------------------------------------ 기본기
def hard_shadow(surf, rect, radius=8, offset=(5, 6), alpha=55):
    r = pygame.Rect(rect)
    key = ("hs", r.size, radius, alpha)
    if key not in _cache:
        sh = pygame.Surface(r.size, pygame.SRCALPHA)
        pygame.draw.rect(sh, (*SHADOW, alpha), sh.get_rect(), border_radius=radius)
        _cache[key] = sh
    surf.blit(_cache[key], (r.x + offset[0], r.y + offset[1]))


def box(surf, rect, fill, radius=8, w=3, shadow=True, shade=None, offset=(5, 6)):
    """외곽선 + 또렷한 그림자 + (선택) 아래쪽 셀 셰이딩 띠가 있는 상자."""
    r = pygame.Rect(rect)
    if shadow:
        hard_shadow(surf, r, radius, offset)
    pygame.draw.rect(surf, fill, r, border_radius=radius)
    if shade:
        h = max(4, int(r.h * 0.22))
        pygame.draw.rect(surf, shade, (r.x, r.bottom - h, r.w, h),
                         border_bottom_left_radius=radius, border_bottom_right_radius=radius)
    pygame.draw.rect(surf, INK, r, w, border_radius=radius)
    return r


def silhouette_shadow(img: pygame.Surface, alpha=60) -> pygame.Surface:
    """회전한 종이처럼 네모가 아닌 그림의 모양 그대로 그림자를 만든다."""
    return pygame.mask.from_surface(img, 40).to_surface(setcolor=(*SHADOW, alpha), unsetcolor=(0, 0, 0, 0))


def tape(surf, center, angle=0, w=58, h=20):
    key = ("tape", w, h, angle)
    if key not in _cache:
        t = pygame.Surface((w, h), pygame.SRCALPHA)
        t.fill((250, 236, 190, 215))
        pygame.draw.rect(t, (214, 190, 140, 230), t.get_rect(), 2)
        _cache[key] = pygame.transform.rotozoom(t, angle, 1.0)
    img = _cache[key]
    surf.blit(img, img.get_rect(center=center))


def pin(surf, pos, color=RED):
    pygame.draw.circle(surf, SHADOW, (pos[0] + 2, pos[1] + 3), 7)
    pygame.draw.circle(surf, color, pos, 7)
    pygame.draw.circle(surf, INK, pos, 7, 2)
    pygame.draw.circle(surf, (255, 255, 255), (pos[0] - 2, pos[1] - 2), 2)


def pen_circle(surf, rect, progress=1.0, color=RED, width=3):
    """빨간 펜으로 슥 그린 동그라미 (살짝 삐뚤, 끝이 겹침)."""
    r = pygame.Rect(rect)
    cx, cy = r.center
    rx, ry = r.w / 2 + 5, r.h / 2 + 3
    n = int(44 * clamp01(progress))
    pts = []
    for i in range(n + 1):
        a = -2.5 + i / 44 * (2 * math.pi * 1.07)
        wob = 1 + 0.035 * math.sin(a * 3 + 1)
        pts.append((cx + math.cos(a) * rx * wob, cy + math.sin(a) * ry * wob))
    if len(pts) > 1:
        pygame.draw.lines(surf, color, False, pts, width)


# ------------------------------------------------------------------ 창구 풍경
def draw_wall(surf, h, t=0.0, ratio=0.0):
    """벽 + 허리 몰딩 + 창에서 드는 햇살. ratio(0~1)가 커지면 노을빛."""
    pygame.draw.rect(surf, (255, 236, 208), (0, 0, WIDTH, h))
    wy = h - 84
    pygame.draw.rect(surf, (246, 216, 180), (0, wy, WIDTH, 84))
    for x in range(40, WIDTH, 96):
        pygame.draw.line(surf, (236, 202, 162), (x, wy + 12), (x, h - 6), 3)
    pygame.draw.line(surf, (255, 246, 228), (0, wy + 5), (WIDTH, wy + 5), 3)
    pygame.draw.line(surf, INK, (0, wy), (WIDTH, wy), 3)

    key = ("shaft", h)
    if key not in _cache:
        sf = pygame.Surface((WIDTH, h), pygame.SRCALPHA)
        pygame.draw.polygon(sf, (255, 255, 255, 36), [(250, 0), (430, 0), (290, h), (110, h)])
        pygame.draw.polygon(sf, (255, 255, 255, 24), [(470, 0), (530, 0), (390, h), (330, h)])
        _cache[key] = sf
    surf.blit(_cache[key], (0, 0))

    late = clamp01((ratio - 0.6) / 0.4)
    if late > 0:
        key = ("warm", h)
        if key not in _cache:
            warm = pygame.Surface((WIDTH, h))
            warm.fill((255, 150, 70))
            _cache[key] = warm
        _cache[key].set_alpha(int(44 * late))
        surf.blit(_cache[key], (0, 0))


def draw_window(surf, rect, t=0.0, ratio=0.0):
    r = pygame.Rect(rect)
    late = clamp01((ratio - 0.5) / 0.5)
    sky = lerp_c((158, 212, 250), (255, 186, 128), late)
    pygame.draw.rect(surf, (214, 180, 140), r.move(5, 6).inflate(16, 16), border_radius=8)   # 그림자
    pygame.draw.rect(surf, sky, r)
    clip = surf.get_clip()
    surf.set_clip(r)
    sun = (r.right - 46, int(r.y + 30 + late * (r.h - 50)))
    pygame.draw.circle(surf, lerp_c((255, 246, 190), (255, 120, 80), late), sun, 20)
    for i, (speed, cy, cw) in enumerate(((9, 0.26, 70), (5, 0.5, 96), (13, 0.38, 54))):
        x = r.x + ((t * speed + i * 110) % (r.w + 160)) - 120
        y = r.y + int(r.h * cy)
        col = lerp_c((255, 255, 255), (255, 226, 200), late)
        pygame.draw.ellipse(surf, col, (x, y, cw, 24))
        pygame.draw.ellipse(surf, col, (x + cw * 0.2, y - 12, cw * 0.5, 28))
    pygame.draw.ellipse(surf, lerp_c((150, 206, 130), (170, 150, 110), late), (r.x - 30, r.bottom - 34, r.w * 0.8, 80))
    pygame.draw.ellipse(surf, lerp_c((120, 186, 112), (140, 126, 96), late), (r.centerx - 20, r.bottom - 24, r.w * 0.8, 70))
    surf.set_clip(clip)
    pygame.draw.line(surf, (255, 252, 244), (r.centerx, r.y), (r.centerx, r.bottom), 7)
    pygame.draw.line(surf, (255, 252, 244), (r.x, r.centery), (r.right, r.centery), 7)
    pygame.draw.rect(surf, (255, 252, 244), r.inflate(14, 14), 9, border_radius=8)
    pygame.draw.rect(surf, INK, r.inflate(16, 16), 3, border_radius=9)
    pygame.draw.rect(surf, INK, r, 2)
    sill = pygame.Rect(r.x - 18, r.bottom + 8, r.w + 36, 12)
    pygame.draw.rect(surf, (255, 252, 244), sill, border_radius=4)
    pygame.draw.rect(surf, INK, sill, 3, border_radius=4)


def draw_clock(surf, center, r, minutes, alarm=0.0, t=0.0):
    """벽시계. minutes = 하루 중 분(540=09:00). alarm(0~1)이 크면 다급하게 떨린다."""
    cx = center[0] + (math.sin(t * 46) * 3 * alarm)
    cy = center[1]
    pygame.draw.circle(surf, (214, 180, 140), (cx + 5, cy + 6), r)
    pygame.draw.circle(surf, lerp_c((255, 253, 247), (255, 214, 204), alarm), (cx, cy), r)
    # 18시(퇴근) 방향 빨간 표시
    pygame.draw.circle(surf, RED, (cx, cy + r - 9), 5)
    for i in range(12):
        a = i / 12 * math.tau
        p1 = (cx + math.sin(a) * (r - 6), cy - math.cos(a) * (r - 6))
        p2 = (cx + math.sin(a) * (r - (13 if i % 3 == 0 else 10)), cy - math.cos(a) * (r - (13 if i % 3 == 0 else 10)))
        pygame.draw.line(surf, INK, p1, p2, 3 if i % 3 == 0 else 2)
    ha = (minutes / 60 % 12) / 12 * math.tau
    ma = (minutes % 60) / 60 * math.tau
    pygame.draw.line(surf, INK, (cx, cy), (cx + math.sin(ha) * r * 0.5, cy - math.cos(ha) * r * 0.5), 6)
    pygame.draw.line(surf, RED if alarm > 0 else INK, (cx, cy),
                     (cx + math.sin(ma) * r * 0.74, cy - math.cos(ma) * r * 0.74), 4)
    pygame.draw.circle(surf, INK, (cx, cy), 5)
    pygame.draw.circle(surf, INK, (cx, cy), r, 4)


def draw_calendar(surf, rect, month, day, label):
    r = box(surf, rect, (255, 253, 247), radius=6, offset=(4, 5))
    head = pygame.Rect(r.x, r.y, r.w, int(r.h * 0.28))
    pygame.draw.rect(surf, RED, head, border_top_left_radius=6, border_top_right_radius=6)
    pygame.draw.line(surf, INK, (r.x, head.bottom), (r.right, head.bottom), 3)
    for dx in (0.28, 0.72):                                 # 스프링 고리
        pygame.draw.circle(surf, INK, (int(r.x + r.w * dx), r.y), 5)
    ui.draw_text(surf, f"{month}월", head.center, max(12, int(r.h * 0.17)), (255, 255, 255), True, center=True)
    ui.draw_text(surf, str(day), (r.centerx, r.y + int(r.h * 0.52)), int(r.h * 0.38), INK, "heavy", center=True)
    ui.draw_text(surf, label, (r.centerx, r.bottom - int(r.h * 0.13)), max(11, int(r.h * 0.15)), RED, True, center=True)
    pygame.draw.rect(surf, INK, r, 3, border_radius=6)


def draw_corkboard(surf, rect, lines, warnings):
    """실적 메모가 꽂힌 코르크 게시판. lines = [(글, 색, 굵게)]"""
    r = box(surf, rect, (196, 146, 96), radius=8, offset=(5, 6))
    inner = r.inflate(-16, -16)
    pygame.draw.rect(surf, (226, 190, 140), inner, border_radius=4)
    key = ("cork", inner.size)
    if key not in _cache:
        rng = random.Random(7)
        sp = pygame.Surface(inner.size, pygame.SRCALPHA)
        for _ in range(90):
            pygame.draw.circle(sp, (200, 160, 110), (rng.randint(4, inner.w - 4), rng.randint(4, inner.h - 4)), rng.choice((1, 2)))
        _cache[key] = sp
    surf.blit(_cache[key], inner.topleft)
    pygame.draw.rect(surf, INK, inner, 2, border_radius=4)

    note = pygame.Rect(inner.x + 10, inner.y + 14, inner.w - 20, 22 + len(lines) * 20)
    hard_shadow(surf, note, 2, (3, 4), 50)
    pygame.draw.rect(surf, (255, 240, 150), note)
    pygame.draw.polygon(surf, (236, 214, 110), [(note.right - 14, note.bottom), (note.right, note.bottom - 14), (note.right, note.bottom)])
    pygame.draw.rect(surf, INK, note, 2)
    pin(surf, (note.centerx, note.y + 2))
    y = note.y + 13
    for text, color, bold in lines:
        ui.draw_text(surf, text, (note.x + 12, y), 14, color, bold)
        y += 20
    ui.draw_text(surf, "감사 경고", (inner.x + 12, note.bottom + 9), 13, (120, 80, 50), True)
    for i in range(5):
        c = (inner.x + 22 + i * 30, note.bottom + 40)
        on = i < warnings
        pygame.draw.circle(surf, RED if on else (206, 168, 120), c, 10)
        pygame.draw.circle(surf, INK, c, 10, 2)
        if on:
            ui.draw_text(surf, "!", c, 14, (255, 255, 255), True, center=True)


def draw_counter(surf, y):
    """창구 카운터(내 책상의 먼 쪽 턱). 반환: 카운터 아래 y."""
    pygame.draw.rect(surf, (250, 216, 164), (0, y, WIDTH, 20))
    pygame.draw.line(surf, (255, 236, 200), (0, y + 6), (WIDTH, y + 6), 4)
    pygame.draw.rect(surf, (212, 160, 106), (0, y + 20, WIDTH, 14))
    for yy in (y, y + 20, y + 34):
        pygame.draw.line(surf, INK, (0, yy), (WIDTH, yy), 3)
    return y + 34


def draw_desk(surf, y0):
    ui.desk_background(surf, y0)
    key = ("deskshade",)
    if key not in _cache:
        sh = pygame.Surface((WIDTH, 14), pygame.SRCALPHA)
        sh.fill((*SHADOW, 46))
        _cache[key] = sh
    surf.blit(_cache[key], (0, y0 + 2))


def draw_plant(surf, x, base_y, t=0.0):
    sway = math.sin(t * 1.3) * 3
    for dx, dy, w, h, col in ((-22, -70, 30, 52, (112, 180, 104)), (14, -78, 30, 58, (132, 200, 116)),
                              (-6, -92, 30, 62, (150, 212, 126))):
        r = pygame.Rect(x + dx + sway * (abs(dy) / 90), base_y + dy, w, h)
        pygame.draw.ellipse(surf, INK, r.inflate(6, 6))
        pygame.draw.ellipse(surf, col, r)
        pygame.draw.line(surf, lerp_c(col, (60, 110, 60), 0.5), (r.centerx, r.y + 8), (r.centerx, r.bottom - 6), 2)
    pot = [(x - 26, base_y - 34), (x + 26, base_y - 34), (x + 19, base_y + 4), (x - 19, base_y + 4)]
    pygame.draw.polygon(surf, (226, 130, 90), pot)
    pygame.draw.polygon(surf, (196, 104, 70), [(x - 22, base_y - 12), (x + 22, base_y - 12), (x + 19, base_y + 4), (x - 19, base_y + 4)])
    pygame.draw.polygon(surf, INK, pot, 3)
    rim = pygame.Rect(x - 30, base_y - 42, 60, 12)
    pygame.draw.rect(surf, (240, 150, 106), rim, border_radius=4)
    pygame.draw.rect(surf, INK, rim, 3, border_radius=4)


def draw_mug(surf, center, t=0.0):
    cx, cy = center
    pygame.draw.circle(surf, (196, 150, 100), (cx + 5, cy + 6), 30)
    pygame.draw.ellipse(surf, INK, (cx + 18, cy - 14, 30, 28), 6)
    pygame.draw.circle(surf, (255, 253, 247), (cx, cy), 30)
    pygame.draw.circle(surf, (150, 96, 60), (cx, cy), 22)
    pygame.draw.circle(surf, (176, 118, 76), (cx - 6, cy - 6), 8)
    pygame.draw.circle(surf, INK, (cx, cy), 30, 3)
    pygame.draw.circle(surf, INK, (cx, cy), 22, 2)
    for i in range(2):                                         # 김
        pts = [(cx - 8 + i * 16 + math.sin(t * 2 + k * 0.9 + i) * 4, cy - 34 - k * 7) for k in range(5)]
        pygame.draw.lines(surf, (255, 255, 255), False, pts, 3)


def draw_pen(surf, pos, angle=-24):
    key = ("pen", angle)
    if key not in _cache:
        p = pygame.Surface((120, 18), pygame.SRCALPHA)
        pygame.draw.rect(p, (70, 110, 200), (10, 3, 86, 12), border_radius=5)
        pygame.draw.rect(p, (50, 84, 160), (10, 10, 86, 5), border_bottom_left_radius=5, border_bottom_right_radius=5)
        pygame.draw.polygon(p, (240, 220, 180), [(96, 3), (116, 9), (96, 15)])
        pygame.draw.polygon(p, INK, [(110, 7), (116, 9), (110, 11)])
        pygame.draw.rect(p, INK, (10, 3, 86, 12), 2, border_radius=5)
        pygame.draw.polygon(p, INK, [(96, 3), (116, 9), (96, 15)], 2)
        _cache[key] = pygame.transform.rotozoom(p, angle, 1.0)
    img = _cache[key]
    sh = _cache.setdefault(("pensh", angle), silhouette_shadow(img, 50))
    r = img.get_rect(center=pos)
    surf.blit(sh, r.move(4, 5))
    surf.blit(img, r)


def draw_stamp_tool(surf, base_center, color, squash=1.0):
    """나무 손잡이 도장. base_center = 도장 바닥 한가운데."""
    cx, cy = int(base_center[0]), int(base_center[1])
    bh = int(34 * squash)
    base = pygame.Rect(cx - 58, cy - bh, 116, bh)
    neck = pygame.Rect(cx - 17, base.y - 52, 34, 58)
    pygame.draw.rect(surf, (176, 118, 70), neck, border_radius=10)
    pygame.draw.rect(surf, INK, neck, 3, border_radius=10)
    pygame.draw.circle(surf, (204, 144, 90), (cx, neck.y - 8), 28)
    pygame.draw.circle(surf, (232, 180, 124), (cx - 9, neck.y - 16), 9)
    pygame.draw.circle(surf, INK, (cx, neck.y - 8), 28, 3)
    pygame.draw.rect(surf, color, base, border_radius=10)
    pygame.draw.rect(surf, tuple(max(0, c - 50) for c in color), (base.x, base.bottom - 10, base.w, 10),
                     border_bottom_left_radius=10, border_bottom_right_radius=10)
    pygame.draw.rect(surf, INK, base, 3, border_radius=10)


def draw_notebook(surf, rect, title, highlight=None):
    """스프링 노트 한 장 (줄 공책 + 빨간 여백선). 내용은 호출한 쪽에서 그린다."""
    r = pygame.Rect(rect)
    hard_shadow(surf, r, 6, (5, 6))
    pygame.draw.rect(surf, (236, 226, 204), r.move(3, 3), border_radius=6)          # 아래 깔린 장
    pygame.draw.rect(surf, INK, r.move(3, 3), 2, border_radius=6)
    pygame.draw.rect(surf, (255, 252, 240), r, border_radius=6)
    for y in range(r.y + 52, r.bottom - 6, 26):
        pygame.draw.line(surf, (196, 220, 240), (r.x + 26, y + 22), (r.right - 8, y + 22), 2)
    pygame.draw.line(surf, (244, 170, 170), (r.x + 30, r.y + 44), (r.x + 30, r.bottom - 6), 2)
    pygame.draw.rect(surf, highlight or INK, r, 4 if highlight else 3, border_radius=6)
    for y in range(r.y + 16, r.bottom - 10, 22):                                   # 스프링
        pygame.draw.circle(surf, (120, 100, 90), (r.x + 12, y), 4)
        pygame.draw.arc(surf, INK, (r.x - 8, y - 7, 22, 14), 0.4, math.pi * 1.6, 3)
    label = pygame.Rect(r.x + 40, r.y + 8, r.w - 54, 30)
    pygame.draw.rect(surf, (255, 214, 120), label, border_radius=6)
    pygame.draw.rect(surf, INK, label, 2, border_radius=6)
    ui.draw_text(surf, title, label.center, 15, INK, True, center=True)


# ------------------------------------------------------------------ 클립보드 (종이 넘기기)
class Clipboard:
    """집게 달린 클립보드. 여러 장이 끼워져 있고, 색인 탭이나 종이를 눌러 넘긴다.

    pages = [(탭 글자, 종이 Surface, 탭 색)]
    넘길 때: 위쪽 집게를 축으로 종이가 들려 올라가며 뒤로 넘어간다.
    """
    FLIP_SEC = 0.42

    def __init__(self, rect, pages):
        self.rect = pygame.Rect(rect)
        self.pages = pages
        self.idx = 0
        self.flip = None                 # [from, to, t]
        pw, ph = pages[0][1].get_size()
        self.page = pygame.Rect(self.rect.x + 12, self.rect.y + 42, pw, ph)

    def tab_rect(self, i):
        return pygame.Rect(self.page.right - 3, self.page.y + 18 + i * 62, 30, 54)

    def goto(self, i):
        if self.flip or i == self.idx or not (0 <= i < len(self.pages)):
            return
        self.flip = [self.idx, i, 0.0]
        sfx.play("paper", 0.6)

    def click(self, pos) -> bool:
        for i in range(len(self.pages)):
            if self.tab_rect(i).collidepoint(pos):
                self.goto(i)
                return True
        if self.page.collidepoint(pos) and len(self.pages) > 1:
            self.goto((self.idx + 1) % len(self.pages))
            return True
        return self.rect.collidepoint(pos)

    def update(self, dt):
        if self.flip:
            self.flip[2] += dt
            if self.flip[2] >= self.FLIP_SEC:
                self.idx = self.flip[1]
                self.flip = None

    def _draw_tabs(self, surf, front):
        for i, (label, _, color) in enumerate(self.pages):
            if (i == front) != (self._pass == "front"):
                continue
            tr = self.tab_rect(i)
            if i == front:
                tr = tr.inflate(6, 0).move(3, 0)
            pygame.draw.rect(surf, color, tr, border_top_right_radius=9, border_bottom_right_radius=9)
            pygame.draw.rect(surf, INK, tr, 3, border_top_right_radius=9, border_bottom_right_radius=9)
            for k, ch in enumerate(label[:2]):
                ui.draw_text(surf, ch, (tr.centerx + 1, tr.y + 15 + k * 22), 15, INK, True, center=True)

    def _blit_page(self, surf, i, frac=1.0, shade=0.0):
        img = self.pages[i][1]
        p = self.page
        if frac < 1.0:
            h = max(2, int(p.h * frac))
            img = pygame.transform.smoothscale(img, (p.w, h))
            if shade > 0:
                dark = pygame.Surface(img.get_size(), pygame.SRCALPHA)
                dark.fill((*SHADOW, int(110 * shade)))
                img.blit(dark, (0, 0))
            surf.blit(img, p.topleft)
            pygame.draw.rect(surf, INK, (p.x, p.y, p.w, h), 3)
            # 들린 종이의 아래 끝: 뒷면이 살짝 말려 보임
            curl = pygame.Rect(p.x - 2, p.y + h - 5, p.w + 4, 9)
            pygame.draw.rect(surf, (255, 255, 255), curl, border_radius=4)
            pygame.draw.rect(surf, INK, curl, 2, border_radius=4)
        else:
            surf.blit(img, p.topleft)
            pygame.draw.rect(surf, INK, p, 3)

    def draw(self, surf):
        r = self.rect
        box(surf, r, (176, 124, 78), radius=14, offset=(6, 7))
        pygame.draw.rect(surf, (152, 102, 62), (r.x + 3, r.bottom - 26, r.w - 6, 23),
                         border_bottom_left_radius=12, border_bottom_right_radius=12)
        p = self.page
        for k in (2, 1):                                        # 겹쳐 끼운 종이 가장자리
            pygame.draw.rect(surf, (238, 230, 212), p.move(k * 3, k * 3))
            pygame.draw.rect(surf, INK, p.move(k * 3, k * 3), 2)

        front = self.idx
        self._pass = "back"
        self._draw_tabs(surf, front if not self.flip else self.flip[1])
        if self.flip:
            a, b, t = self.flip
            k = ease_in_out_sine(t / self.FLIP_SEC)
            if b > a:                                           # 앞으로 넘기기: a 가 위로 들려 사라짐
                self._blit_page(surf, b)
                self._blit_page(surf, a, 1 - k, k)
            else:                                               # 되넘기기: b 가 위에서 내려와 덮음
                self._blit_page(surf, a)
                self._blit_page(surf, b, k, 1 - k)
            front = b
        else:
            self._blit_page(surf, front)
        self._pass = "front"
        self._draw_tabs(surf, front)

        # 집게
        clip = pygame.Rect(0, 0, 112, 34)
        clip.midtop = (p.centerx, r.y + 14)
        pygame.draw.rect(surf, (130, 88, 54), clip.move(3, 4), border_radius=9)
        pygame.draw.rect(surf, (196, 200, 210), clip, border_radius=9)
        pygame.draw.rect(surf, (156, 162, 176), (clip.x, clip.bottom - 11, clip.w, 11),
                         border_bottom_left_radius=9, border_bottom_right_radius=9)
        pygame.draw.rect(surf, INK, clip, 3, border_radius=9)
        ring = pygame.Rect(0, 0, 44, 26)
        ring.midbottom = (clip.centerx, clip.y + 9)
        pygame.draw.rect(surf, (196, 200, 210), ring, border_radius=11)
        pygame.draw.rect(surf, INK, ring, 3, border_radius=11)
        pygame.draw.circle(surf, (176, 124, 78), ring.center, 6)
        pygame.draw.circle(surf, INK, ring.center, 6, 2)
        if len(self.pages) > 1 and not self.flip:
            ui.draw_text(surf, f"{self.idx + 1} / {len(self.pages)}  ·  눌러서 넘기기", (p.centerx, r.bottom - 14),
                         12, (255, 240, 220), True, center=True)


def draw_bell(surf, center, pressed=False):
    """책상 호출 벨 (정리 담당을 부른다)."""
    cx, cy = center
    base = pygame.Rect(cx - 30, cy + 8, 60, 12)
    pygame.draw.ellipse(surf, (196, 150, 100), base.move(4, 5))
    pts = [(cx + math.cos(a) * 26, cy + 10 - math.sin(a) * 26) for a in [i * math.pi / 14 for i in range(15)]]
    pygame.draw.polygon(surf, (250, 208, 90), pts)
    pygame.draw.polygon(surf, (226, 176, 60), [(cx + math.cos(a) * 26, cy + 10 - math.sin(a) * 26)
                                              for a in [i * math.pi / 14 for i in range(5)]] + [(cx + 6, cy + 10)])
    pygame.draw.polygon(surf, INK, pts, 3)
    pygame.draw.rect(surf, (150, 110, 70), base, border_radius=5)
    pygame.draw.rect(surf, INK, base, 3, border_radius=5)
    knob = pygame.Rect(cx - 6, cy - 26 + (5 if pressed else 0), 12, 10)
    pygame.draw.rect(surf, (236, 96, 96), knob, border_radius=4)
    pygame.draw.rect(surf, INK, knob, 2, border_radius=4)
    pygame.draw.arc(surf, (255, 240, 180), (cx - 18, cy - 10, 20, 20), 1.8, 2.9, 3)
