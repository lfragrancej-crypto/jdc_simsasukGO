"""서류 꾸리기 책상 위의 종이들 — 종류마다 생김새가 다르다.

같은 종류(예: 입찰보증서 세 장)는 같은 틀이라 아래 글씨를 읽어야 구별되고, 다른 종류는 한눈에 다른 종이로 보인다.
  cert    입찰참가자격 등록증     초록 겹테두리 + 붉은 도장 (증서)
  bond    입찰보증서            파란 머리띠 + 큰 금액 + 바코드 (금융 서류)
  prod    직접생산확인증명서      갈색 겹테두리 + 품목 표 + 네모 직인 (증명서)
  pledge  청렴계약 이행서약서     줄글 + 아래 서명란 (서약서)
그 밖의 종이(영수증·전단지·사진·달력…)는 입찰과 상관없는 잡동사니.
"""
import math

import pygame

from .. import ui

INK = (74, 52, 40)
SOFT = (130, 116, 104)
SIZES = {"cert": (124, 156), "bond": (124, 156), "prod": (124, 156), "pledge": (124, 156),
         "receipt": (96, 150), "flyer": (128, 150), "photo": (124, 132), "calendar": (128, 128), "lotto": (140, 86),
         "card": (130, 96), "manual": (114, 150), "member": (140, 86), "invite": (130, 110), "namecard": (136, 80)}
JUNK_KIND = {"점심 영수증": "receipt", "주차 영수증": "receipt", "세탁소 영수증": "receipt", "헬스장 회원권": "member",
             "동창회 초대장": "invite", "공장 고양이 사진": "photo", "배달 전단지": "flyer", "작년 달력": "calendar",
             "로또 용지": "lotto", "직원 생일 카드": "card", "기계 설명서": "manual", "명함 한 뭉치": "namecard"}
RULE_KIND = {"R01": "cert", "R05": "bond", "R07": "prod", "R08": "pledge"}


def kind_of(rule, name) -> str:
    return RULE_KIND.get(rule) or JUNK_KIND.get(name, "receipt")


def _fit(text, width, size, bold="heavy", least=9):
    while size > least and ui.fonts.get(size, bold).size(text)[0] > width:
        size -= 1
    return size


def _center(s, text, y, size, color=INK, bold="heavy", width=None):
    w = s.get_width()
    size = _fit(text, (width or w) - 12, size, bold)
    ui.draw_text(s, text, (w // 2, y), size, color, bold, center=True)
    return size


def _lines(s, text, x, y, width, size, color=SOFT, center=False, gap=3, most=3):
    for line in ui.wrap(text, size, width, True)[:most]:
        if center:
            ui.draw_text(s, line, (s.get_width() // 2, y + size // 2), size, color, True, center=True)
        else:
            ui.draw_text(s, line, (x, y), size, color, True)
        y += size + gap
    return y


def _split_title(name):
    """긴 서류 이름은 두 줄로 (띄어쓰기가 있으면 거기서, 없으면 가운데서)."""
    if " " in name:
        a, b = name.split(" ", 1)
        return [a, b]
    if len(name) > 7:
        return [name[:-3], name[-3:]]                              # '직접생산확인' / '증명서'
    return [name]


def render(dc) -> pygame.Surface:
    kind = dc["kind"]
    w, h = SIZES[kind]
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    r = s.get_rect()
    name, sub = dc["name"], dc["sub"]

    if kind == "cert":                                             # 등록증: 증서
        pygame.draw.rect(s, (255, 250, 234), r, border_radius=4)
        pygame.draw.rect(s, (62, 140, 92), r.inflate(-6, -6), 3, border_radius=3)
        pygame.draw.rect(s, (62, 140, 92), r.inflate(-16, -16), 1)
        for cx, cy in ((12, 12), (w - 12, 12), (12, h - 12), (w - 12, h - 12)):
            pygame.draw.circle(s, (62, 140, 92), (cx, cy), 4)
        y = 26
        for line in _split_title(name):
            _center(s, line, y, 14, (40, 96, 62), width=w - 16)
            y += 18
        pygame.draw.line(s, (62, 140, 92), (22, y + 2), (w - 22, y + 2), 2)
        _lines(s, sub.replace(" · ", "\n").split("\n")[0], 0, y + 12, w - 28, 12, INK, center=True, most=2)
        rest = sub.split(" · ")
        if len(rest) > 1:
            _lines(s, rest[1], 0, y + 32, w - 28, 12, INK, center=True, most=2)
        pygame.draw.circle(s, (226, 76, 76), (w - 28, h - 28), 13, 3)
        ui.draw_text(s, "인", (w - 28, h - 29), 12, (226, 76, 76), "heavy", center=True)
    elif kind == "bond":                                           # 보증서: 금융 서류
        pygame.draw.rect(s, (252, 253, 255), r, border_radius=4)
        pygame.draw.rect(s, (52, 104, 190), (0, 0, w, 32), border_top_left_radius=4, border_top_right_radius=4)
        _center(s, name, 16, 15, (255, 255, 255))
        ui.draw_text(s, "보증금액", (12, 42), 10, SOFT, True)
        parts = sub.split(" · ")
        box = pygame.Rect(10, 56, w - 20, 34)
        pygame.draw.rect(s, (232, 240, 252), box, border_radius=4)
        pygame.draw.rect(s, (52, 104, 190), box, 2, border_radius=4)
        ui.draw_text(s, parts[0], box.center, _fit(parts[0], box.w - 8, 16), INK, "heavy", center=True)
        ui.draw_text(s, "보증기간", (12, 98), 10, SOFT, True)
        ui.draw_text(s, parts[1] if len(parts) > 1 else "", (12, 112), 12, INK, True)
        x = 12
        for k in range(26):                                        # 바코드
            bw = 1 + (k * 7 % 3)
            pygame.draw.rect(s, INK, (x, h - 24, bw, 14))
            x += bw + 2
            if x > w - 14:
                break
    elif kind == "prod":                                           # 직접생산확인증명서: 증명서
        pygame.draw.rect(s, (252, 244, 228), r, border_radius=4)
        pygame.draw.rect(s, (160, 108, 60), r.inflate(-6, -6), 3)
        pygame.draw.rect(s, (160, 108, 60), r.inflate(-14, -14), 1)
        y = 26
        for line in _split_title(name):
            _center(s, line, y, 14, (120, 76, 36), width=w - 16)
            y += 18
        table = pygame.Rect(14, y + 6, w - 28, 50)
        pygame.draw.rect(s, (255, 252, 244), table)
        pygame.draw.rect(s, (160, 108, 60), table, 2)
        pygame.draw.line(s, (160, 108, 60), (table.x, table.y + 18), (table.right, table.y + 18), 2)
        ui.draw_text(s, "확인 품목", (table.centerx, table.y + 9), 10, (120, 76, 36), True, center=True)
        item = sub.replace("품목: ", "")
        ui.draw_text(s, item, (table.centerx, table.y + 34), _fit(item, table.w - 8, 13, True), INK, True, center=True)
        st = pygame.Rect(w - 44, h - 42, 28, 28)
        pygame.draw.rect(s, (226, 76, 76), st, 3)
        ui.draw_text(s, "확인", st.center, 10, (226, 76, 76), "heavy", center=True)
    elif kind == "pledge":                                         # 서약서: 줄글 + 서명란
        pygame.draw.rect(s, (255, 255, 255), r, border_radius=3)
        y = 20
        for line in _split_title(name):
            _center(s, line, y, 14, INK, width=w - 12)
            y += 18
        for k in range(4):
            pygame.draw.line(s, (206, 206, 212), (14, y + 8 + k * 11), (w - 14 - (30 if k == 3 else 0), y + 8 + k * 11), 2)
        sign = pygame.Rect(14, h - 54, w - 28, 30)
        ui.draw_text(s, "대표자 서명", (14, h - 68), 10, SOFT, True)
        if "완료" in sub:
            pygame.draw.rect(s, (255, 252, 240), sign)
            pygame.draw.rect(s, INK, sign, 2)
            pts = [(sign.x + 10 + i * 6, sign.centery + math.sin(i * 1.7) * 8 - (4 if i % 3 == 0 else 0)) for i in range(14)]
            pygame.draw.lines(s, (40, 60, 140), False, pts, 3)
        else:
            pygame.draw.rect(s, (250, 250, 250), sign)
            for x in range(sign.x, sign.right, 8):                 # 빈 서명란 (점선)
                pygame.draw.line(s, (170, 170, 176), (x, sign.y), (x + 4, sign.y), 2)
                pygame.draw.line(s, (170, 170, 176), (x, sign.bottom), (x + 4, sign.bottom), 2)
        _lines(s, sub, 0, h - 20, w - 12, 10, INK, center=True, most=1)
    elif kind == "receipt":
        pts = [(0, 0), (w, 0), (w, h - 8)] + [(w - i * 8, h - (0 if i % 2 else 8)) for i in range(1, w // 8 + 1)] + [(0, h - 8)]
        pygame.draw.polygon(s, (250, 250, 248), pts)
        pygame.draw.polygon(s, INK, pts, 2)
        _center(s, name, 18, 12, INK)
        for y in (32, 36):
            for x in range(8, w - 8, 6):
                pygame.draw.line(s, (150, 150, 150), (x, y), (x + 3, y), 1)
        yy = _lines(s, sub, 10, 46, w - 20, 11, INK)
        for k in range(3):
            pygame.draw.line(s, (200, 200, 200), (10, yy + 10 + k * 12), (w - 10 - k * 14, yy + 10 + k * 12), 2)
        ui.draw_text(s, "합계", (10, h - 34), 11, INK, "heavy")
    elif kind == "flyer":
        pygame.draw.rect(s, (255, 220, 60), r)
        pygame.draw.rect(s, INK, r, 3)
        pts = [(w // 2 + math.cos(i * math.pi / 8) * (46 if i % 2 else 30), 52 + math.sin(i * math.pi / 8) * (46 if i % 2 else 30)) for i in range(16)]
        pygame.draw.polygon(s, (236, 60, 50), pts)
        ui.draw_text(s, "할인!", (w // 2, 52), 18, (255, 255, 255), "heavy", center=True)
        _center(s, name, 110, 14, (200, 40, 30))
        _lines(s, sub, 0, 124, w - 12, 10, INK, center=True, most=2)
    elif kind == "photo":
        pygame.draw.rect(s, (255, 255, 255), r)
        pygame.draw.rect(s, INK, r, 3)
        pic = pygame.Rect(10, 10, w - 20, h - 46)
        pygame.draw.rect(s, (170, 214, 240), pic)
        cx, cy = pic.centerx, pic.centery + 8                      # 고양이
        pygame.draw.polygon(s, (240, 170, 90), [(cx - 26, cy - 12), (cx - 18, cy - 38), (cx - 4, cy - 20)])
        pygame.draw.polygon(s, (240, 170, 90), [(cx + 26, cy - 12), (cx + 18, cy - 38), (cx + 4, cy - 20)])
        pygame.draw.circle(s, (240, 170, 90), (cx, cy), 28)
        for dx in (-10, 10):
            pygame.draw.circle(s, INK, (cx + dx, cy - 4), 3)
        pygame.draw.line(s, INK, (cx - 5, cy + 8), (cx + 5, cy + 8), 2)
        pygame.draw.rect(s, INK, pic, 2)
        _center(s, sub, h - 18, 11, INK, True)
    elif kind == "calendar":
        pygame.draw.rect(s, (255, 255, 255), r)
        pygame.draw.rect(s, (226, 76, 76), (0, 0, w, 30))
        pygame.draw.rect(s, INK, r, 3)
        _center(s, sub, 15, 12, (255, 255, 255))
        for i in range(5):
            for j in range(7):
                c = pygame.Rect(8 + j * 16, 38 + i * 16, 14, 14)
                pygame.draw.rect(s, (236, 236, 240), c, 1)
        _center(s, name, h - 10, 10, SOFT, True)
    elif kind == "lotto":
        pygame.draw.rect(s, (255, 214, 226), r, border_radius=6)
        pygame.draw.rect(s, INK, r, 3, border_radius=6)
        ui.draw_text(s, name, (10, 8), 13, (200, 50, 90), "heavy")
        for i, n in enumerate((3, 12, 19, 27, 34, 41)):
            c = (18 + i * 21, 46)
            pygame.draw.circle(s, (255, 255, 255), c, 9)
            pygame.draw.circle(s, INK, c, 9, 2)
            ui.draw_text(s, str(n), c, 9, INK, True, center=True)
        ui.draw_text(s, sub, (10, h - 22), 11, INK, True)
    elif kind == "card":
        pygame.draw.rect(s, (255, 236, 240), r, border_radius=8)
        pygame.draw.rect(s, INK, r, 3, border_radius=8)
        cx, cy = w - 30, 34
        pygame.draw.circle(s, (236, 96, 120), (cx - 7, cy), 9)
        pygame.draw.circle(s, (236, 96, 120), (cx + 7, cy), 9)
        pygame.draw.polygon(s, (236, 96, 120), [(cx - 15, cy + 4), (cx + 15, cy + 4), (cx, cy + 22)])
        ui.draw_text(s, name, (10, 12), _fit(name, w - 56, 13), (200, 60, 90), "heavy")
        ui.draw_text(s, sub, (10, h - 26), 12, INK, True)
    elif kind == "manual":
        pygame.draw.rect(s, (226, 230, 236), r)
        pygame.draw.rect(s, INK, r, 3)
        pygame.draw.circle(s, (120, 130, 146), (w // 2, 52), 24, 8)
        for i in range(8):
            a = i * math.pi / 4
            pygame.draw.circle(s, (120, 130, 146), (int(w / 2 + math.cos(a) * 28), int(52 + math.sin(a) * 28)), 6)
        _center(s, name, 100, 13, INK)
        _lines(s, sub, 0, 114, w - 12, 10, SOFT, center=True, most=2)
    elif kind == "member":
        pygame.draw.rect(s, (40, 52, 84), r, border_radius=10)
        pygame.draw.rect(s, (250, 196, 60), (0, 22, w, 12))
        pygame.draw.rect(s, INK, r, 3, border_radius=10)
        ui.draw_text(s, name, (12, 42), _fit(name, w - 24, 14), (255, 255, 255), "heavy")
        ui.draw_text(s, sub, (12, 62), 11, (200, 210, 230), True)
    elif kind == "invite":
        pygame.draw.rect(s, (236, 226, 250), r, border_radius=4)
        pygame.draw.rect(s, (140, 110, 190), r.inflate(-8, -8), 2, border_radius=3)
        pygame.draw.rect(s, INK, r, 3, border_radius=4)
        _center(s, "초대합니다", 26, 11, (140, 110, 190), True)
        _center(s, name, 52, 14, INK)
        _lines(s, sub, 0, 70, w - 20, 11, INK, center=True, most=2)
    else:                                                          # namecard
        pygame.draw.rect(s, (200, 204, 210), r.move(4, 4))
        pygame.draw.rect(s, (255, 255, 255), (0, 0, w - 4, h - 4))
        pygame.draw.rect(s, (72, 170, 196), (0, 0, 14, h - 4))
        pygame.draw.rect(s, INK, (0, 0, w - 4, h - 4), 2)
        ui.draw_text(s, name, (22, 14), _fit(name, w - 34, 13), INK, "heavy")
        ui.draw_text(s, sub, (22, 40), _fit(sub, w - 34, 11, True), SOFT, True)

    if kind in ("cert", "bond", "prod", "pledge", "manual", "calendar", "flyer", "photo"):
        pygame.draw.rect(s, INK, r, 2, border_radius=4)             # 종이 가장자리
    if dc.get("mark"):                                             # 형광펜: 꼭 챙길 서류
        hl = pygame.Surface((w, 22), pygame.SRCALPHA)
        hl.fill((255, 236, 60, 120))
        s.blit(hl, (0, 14))
        pygame.draw.circle(s, (250, 140, 70), (16, h - 16), 12)
        pygame.draw.circle(s, INK, (16, h - 16), 12, 2)
        ui.draw_text(s, "꼭", (16, h - 17), 12, (255, 255, 255), "heavy", center=True)
    return s
