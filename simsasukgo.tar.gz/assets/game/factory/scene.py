"""납품하GO! 우리 공장 — 제조업체 사장이 되어 공공 입찰에 도전한다.

심사숙GO(공무원 편)와 같은 닷새, 같은 공고(data/world.json)를 창구 반대편에서 겪는다.
하루의 흐름:
  공고 고르기 → 투찰가 정하기 → 서류 꾸리기(마감 시계가 돈다) → 창구 접수 → 개찰
    → (낙찰) 생산 → 납품 → 장부        (낙찰 실패·반려) 일반 거래처 납품 → 장부
서류 규칙은 심사숙GO의 규정(data/rules.json)을 그대로 뒤집어 쓴다. 그날까지 배운 규정만 직접 챙긴다.
"""
import json
import math
import random

import pygame

from .. import bgm, cg as C
from .. import props, sfx, storage, ui
from ..character import Character
from ..config import HEIGHT, WIDTH
from ..scenes.base import Scene
from . import cgs as fcg
from . import iso, papers, staff as staffmod
from .iso import BLUE, BOXCOL, GREEN, INK, ORANGE, PAPER, RED, SOFT, TEAL, YELLOW, Btn, View, card, chip, shade

EVENT, BOARD, PRICE, DOCS, WINDOW, OPEN, PRODUCE, RESULT, LEDGER, END = (
    "event", "board", "price", "docs", "window", "open", "produce", "result", "ledger", "end")
PANEL = pygame.Rect(640, 96, 612, 604)
FORM = pygame.Rect(24, 100, 306, 440)                             # 서류 꾸리기: 왼쪽 입찰서
DESK_AREA = pygame.Rect(346, 150, 610, 548)                       # 서류가 흩어져 있는 책상
ENVELOPE = pygame.Rect(986, 176, 266, 170)                        # 서류를 끌어다 넣는 봉투
PAPER_W, PAPER_H = 150, 92
LIFE_CARD = pygame.Rect((WIDTH - 700) // 2, 110, 700, 500)      # 일하는 중간에 끼어드는 생활 사건
ORIGIN = (560, 176)
BG_TOP, BG_BOT = (224, 238, 240), (196, 220, 226)
BELT_Y, BELT_X0, BELT_X1 = 4.85, 1.3, 10.0
MACHINES = ((2.6, TEAL, "재단"), (5.0, ORANGE, "포장"), (7.4, GREEN, "검사"))
# 출하 검수장(리듬 놀이)의 작업대 12곳 — 상자가 여기저기서 튀어나온다
SPOTS = [(gx, gy) for gy in (2.2, 4.4, 6.6) for gx in (1.4, 3.7, 6.0, 8.3)]
PAD = 1.3
SPOT_KEYS = "QWERASDFZXCV"            # 작업대 12곳의 단축키 — 자판의 세 줄(QWER / ASDF / ZXCV)이 작업대 세 줄과 같다


SAVE_NAME = "factory_save.json"
_BG: dict = {}


def load_save(app) -> dict | None:
    """이어하기 기록 (하루를 시작할 때마다 자동 저장된다)."""
    try:
        data = json.loads(storage.read(app.profile.dir, SAVE_NAME) or "")
        level = next(lv for lv in app.data.factory["levels"] if lv["id"] == data["level"])
        if not 0 <= data["day_i"] < len(app.data.world["cases"]):
            return None
        return dict(data, level=level)
    except Exception:
        return None


def delete_save(app):
    storage.delete(app.profile.dir, SAVE_NAME)


def record(app) -> dict:
    """꺼도 남는 납품하GO! 기록 (도감의 '우리 공장' 탭이 읽는다)."""
    rec = app.profile.data.setdefault("factory", {})
    for key, blank in (("levels", {}), ("delivered", {}), ("rejects", {}), ("staff", {})):
        if not isinstance(rec.get(key), dict):
            rec[key] = blank
    for key in ("wins", "perfect", "best"):
        rec.setdefault(key, 0)
    return rec


def clients(data) -> list[dict]:
    """우리 공장이 납품할 수 있는 곳 전부 (공통 공고 + 일반 공고). 도감의 납품처 도장판."""
    can = data.factory["company"]["can_make"]
    out = [{"agency": c["agency"], "item": c["item"], "officer": c["officer"], "thanks": c["thanks"], "day": c["day"]}
           for c in data.world["cases"] if c["item"] in can]
    out += [{"agency": s["agency"], "item": s["item"], "officer": None, "thanks": "", "day": 0}
            for s in data.factory["side_notices"] if s["item"] in can]
    for c in out:
        c["key"] = f"{c['agency']}|{c['item']}"
    return out


def _man(n) -> int:
    """만원 단위로 반올림."""
    return int(round(n / 10000.0)) * 10000


def workshop_background():
    """작업장 전경 — 심사숙GO와 같은 손그림풍이지만 창구가 아니라 공장이다. (움직이는 것은 장면이 따로 그린다)"""
    if "shop" not in _BG:
        s = pygame.Surface((WIDTH, HEIGHT))
        s.fill((222, 238, 236))                                          # 민트색 철판 벽
        for y in range(0, 520, 40):
            pygame.draw.line(s, (204, 226, 224), (0, y), (WIDTH, y), 3)
        for x in range(0, WIDTH, 213):                                   # 벽 기둥
            pygame.draw.rect(s, (188, 214, 214), (x, 0, 16, 520))
            pygame.draw.line(s, C.INK, (x, 0), (x, 520), 3)
            pygame.draw.line(s, C.INK, (x + 16, 0), (x + 16, 520), 3)
        pygame.draw.rect(s, (96, 124, 136), (0, 0, WIDTH, 22))               # 천장 보
        pygame.draw.line(s, C.INK, (0, 22), (WIDTH, 22), 4)
        for x in (40, 700, 1010):
            props.draw_window(s, (x, 118, 172, 132), 4.0, 0.0)
        for x in (126, 452, 786, 1096):
            C.lamp(s, x, 84, (255, 214, 120))
        C.banner(s, (246, 104, 348, 54), "(주)한바퀴제작소", TEAL, 26)
        board = pygame.Rect(262, 176, 316, 104)                          # 사훈 판
        props.box(s, board, (255, 253, 247), radius=8, offset=(5, 6))
        ui.draw_text(s, "우리 공장 약속", (board.centerx, board.y + 24), 17, (226, 76, 76), "heavy", center=True)
        ui.draw_text(s, "정직하게 쓰고 · 반듯하게 만들고", (board.centerx, board.y + 54), 15, C.INK, True, center=True)
        ui.draw_text(s, "약속한 날에 납품한다", (board.centerx, board.y + 78), 15, C.INK, True, center=True)
        for i in range(3):                                               # 오른쪽 벽의 자재 선반
            y = 300 + i * 70
            pygame.draw.rect(s, (150, 104, 66), (890, y + 56, 330, 12))
            pygame.draw.rect(s, C.INK, (890, y + 56, 330, 12), 3)
            for k in range(4 - i % 2):
                r = pygame.Rect(904 + k * 80, y + 8, 64, 48)
                pygame.draw.rect(s, (214, 170, 110), r)
                pygame.draw.rect(s, C.INK, r, 3)
        C._ground(s, 520, (238, 228, 208))                                # 바닥
        for y in (570, 630, 690):
            pygame.draw.line(s, (226, 214, 190), (0, y), (WIDTH, y), 3)
        pygame.draw.rect(s, (250, 196, 60), (0, 532, WIDTH, 10))            # 안전선
        for x in range(0, WIDTH, 60):
            pygame.draw.polygon(s, (60, 60, 66), [(x, 532), (x + 20, 532), (x + 10, 542), (x - 10, 542)])
        _BG["shop"] = s.convert()
    return _BG["shop"]


def stage_background():
    """출하 검수장 전경 (생산 = 리듬 놀이의 무대). 한 번만 그려 둔다."""
    if "stage" not in _BG:
        S = 2
        big = pygame.Surface((WIDTH * S, HEIGHT * S))
        g = pygame.Surface((1, 2))
        g.set_at((0, 0), (214, 232, 244))
        g.set_at((0, 1), (186, 208, 226))
        big.blit(pygame.transform.smoothscale(g, big.get_size()), (0, 0))
        v = View(ORIGIN, S)
        sh = pygame.Surface(big.get_size(), pygame.SRCALPHA)
        pts = [v.pt(-0.4, 9.3, -1.3), v.pt(11.3, 9.3, -1.3), v.pt(11.3, -0.4, -1.3), v.pt(12.2, 0.6, -2), v.pt(0.6, 10.2, -2)]
        pygame.draw.polygon(sh, (50, 70, 100, 60), pts)
        big.blit(sh, (0, 0))
        v.cube(big, 0, 0, 11, 9, 0.5, (70, 86, 110), -0.5)               # 짙은 바닥: 상자와 고리가 잘 보이게
        for gx in range(11):
            for gy in range(9):
                if (gx + gy) % 2 == 0:
                    v.tile(big, gx, gy, (78, 95, 120))
        v.cube(big, 0, -0.4, 11, 0.4, 2.8, (120, 150, 190))             # 뒷벽
        v.cube(big, -0.4, 0, 0.4, 9, 2.8, (140, 168, 204))
        for i in range(5):                                              # 뒷벽의 줄무늬 띠 (박자 등은 위에 따로 그린다)
            x0 = 0.6 + i * 2.1
            v.poly(big, (96, 124, 164), [v.pt(x0, 0, 2.3), v.pt(x0 + 1.5, 0, 2.3), v.pt(x0 + 1.5, 0, 1.9), v.pt(x0, 0, 1.9)])
        v.cube(big, 0.2, 0.3, 10.6, 0.8, 0.45, (60, 70, 88))              # 뒤쪽 컨베이어 (장식)
        v.cube(big, 0.2, 0.4, 10.6, 0.6, 0.07, (40, 48, 62), 0.45)
        for gx, gy in SPOTS:                                            # 작업대 12곳
            v.cube(big, gx - 0.08, gy - 0.08, PAD + 0.16, PAD + 0.16, 0.10, (250, 196, 60))
            v.cube(big, gx, gy, PAD, PAD, 0.14, (236, 240, 244))
        v.cube(big, 10.0, 1.6, 0.9, 2.2, 0.12, (150, 160, 176))            # 출하 팔레트 (오른쪽 뒤)
        _BG["stage"] = pygame.transform.smoothscale(big, (WIDTH, HEIGHT)).convert()
    return _BG["stage"]


def background():
    """공장 전경 (한 번만 그려 둔다). (전경, 옆으로 밀었을 때 채울 바탕) 을 돌려준다."""
    if "bg" not in _BG:
        S = 2
        big = pygame.Surface((WIDTH * S, HEIGHT * S))
        g = pygame.Surface((1, 2))
        g.set_at((0, 0), BG_TOP)
        g.set_at((0, 1), BG_BOT)
        big.blit(pygame.transform.smoothscale(g, big.get_size()), (0, 0))
        v = View(ORIGIN, S)
        sh = pygame.Surface(big.get_size(), pygame.SRCALPHA)
        pts = [v.pt(-0.4, 9.3, -1.3), v.pt(11.3, 9.3, -1.3), v.pt(11.3, -0.4, -1.3), v.pt(12.2, 0.6, -2), v.pt(0.6, 10.2, -2)]
        pygame.draw.polygon(sh, (60, 90, 100, 60), pts)
        big.blit(sh, (0, 0))
        v.cube(big, 0, 0, 11, 9, 0.5, (236, 232, 222), -0.5)
        for gx in range(11):
            for gy in range(9):
                if (gx + gy) % 2 == 0:
                    v.tile(big, gx, gy, (228, 223, 211))
        pygame.draw.lines(big, YELLOW, True, [v.pt(1.0, 2.2), v.pt(10.4, 2.2), v.pt(10.4, 6.0), v.pt(1.0, 6.0)], 3 * S)
        v.cube(big, 0, -0.4, 11, 0.4, 2.6, (150, 196, 206))            # 뒷벽
        v.cube(big, -0.4, 0, 0.4, 9, 2.6, (170, 210, 218))
        for i in range(4):
            x0 = 1.2 + i * 2.5
            v.poly(big, (240, 250, 252), [v.pt(x0, 0, 2.0), v.pt(x0 + 1.5, 0, 2.0), v.pt(x0 + 1.5, 0, 0.9), v.pt(x0, 0, 0.9)])
        for i, c in enumerate(((240, 240, 236), (240, 240, 236), (222, 206, 170))):   # 원자재
            v.cube(big, 0.5, 0.6 + i * 0.95, 1.1, 0.8, 0.9, c)
            v.cube(big, 0.5, 0.6 + i * 0.95, 1.1, 0.8, 0.9, c, 0.9)
        for gx, col, _ in MACHINES:                                              # 기계 (벨트 뒤쪽)
            v.cube(big, gx, 2.9, 1.5, 1.5, 1.5, col)
            v.cube(big, gx + 0.2, 3.1, 1.1, 1.1, 0.25, shade(col, 0.8), 1.5)
            v.cube(big, gx + 0.6, 3.5, 0.3, 0.3, 0.7, (240, 240, 236), 1.75)
            v.cube(big, gx + 0.35, 4.4, 0.8, 0.5, 0.25, shade(col, 0.9), 1.0)    # 벨트 위로 내민 덮개
        v.cube(big, BELT_X0 - 0.1, 4.6, BELT_X1 - BELT_X0 + 0.7, 0.9, 0.55, (86, 98, 112))     # 컨베이어
        v.cube(big, BELT_X0 - 0.1, 4.7, BELT_X1 - BELT_X0 + 0.7, 0.7, 0.08, (52, 60, 72), 0.55)
        v.cube(big, 4.6, 7.0, 2.6, 1.3, 1.5, (250, 250, 248), 0.3)               # 납품 트럭
        v.cube(big, 3.6, 7.0, 1.0, 1.3, 1.1, BLUE, 0.3)
        for gx in (3.9, 5.4, 6.6):
            x, y = v.pt(gx, 8.3, 0.25)
            pygame.draw.ellipse(big, (50, 56, 66), (x - 13 * S, y - 10 * S, 26 * S, 20 * S))
        for i in range(2):                                                       # 출하장 상자
            for j in range(2):
                v.cube(big, 9.0 + j * 0.75, 6.6 + i * 0.75, 0.62, 0.62, 0.55, BOXCOL)
        v.cube(big, 9.0, 6.6, 0.62, 0.62, 0.55, shade(BOXCOL, 1.05), 0.55)
        v.cube(big, 10.0, 0.4, 0.6, 0.6, 0.5, (220, 150, 110))                   # 화분
        x, y = v.pt(10.3, 0.7, 1.6)
        pygame.draw.circle(big, (96, 180, 120), (int(x), int(y)), 22 * S)
        _BG["bg"] = pygame.transform.smoothscale(big, (WIDTH, HEIGHT)).convert()
        _BG["plain"] = pygame.transform.smoothscale(g, (300, HEIGHT)).convert()
    return _BG["bg"], _BG["plain"]


class FactoryScene(Scene):
    BGM = "factory"
    HOME = "factory_title"

    def __init__(self, app, level=None, saved=None, seed=None):
        super().__init__(app)
        self.cfg = app.data.factory
        self.co = self.cfg["company"]
        self.level = level or self.cfg["levels"][1]         # 난이도
        self.boss = Character(self.level["look"])           # 난이도마다 다른 사장
        self.boss.expression = "happy"
        self.boss_x, self.boss_dir, self.boss_wait = 300.0, 1, 0.0       # 사장은 작업장을 왔다 갔다 한다
        self.crew, self.crew_ids = [], ()                    # 작업장에 서 있는 직원들 (그림)
        self.tutorial = bool(self.level.get("tutorial")) and saved is None
        self.guide = Character(app.data.dialogue["mascots"]["narmi"]["look"])     # 튜토리얼 안내: AI 도우미 나르미
        self.guide.expression = "happy"
        self.guide.set_pose("point")
        self.rng = random.Random(seed)
        self.money = self.cfg["start_money"]
        self.trust = self.cfg["start_trust"]
        self.day_i = 0
        self.days = len(app.data.world["cases"])
        self.history = []                # 날마다의 결과 (dict)
        self.refused = False             # 담합 제안을 거절했는가
        self.staff = []                  # 함께 일하는 직원 (채용 봉투에서 온다, 최대 3명)
        self.run_cgs = []                # 이번 판에서 본 CG
        self.life = None                 # 지금 끼어든 생활 사건 (없으면 None)
        self.life_enabled = True
        self.life_done = True            # 오늘 사건이 이미 나왔는가
        self.life_hook = "bid"           # 오늘 일이 끼어드는 때: bid(값·서류를 챙기는 중) / produce(생산 도중)
        self.pending = None              # 어제 보류한 일 (오늘 다시 찾아온다)
        self.life_log = {"solved": 0, "deferred": 0, "burst": 0}
        self.life_seen = []
        self.buffs = {}                  # 생활 사건이 남긴 효과 (data/factory.json life 참고)
        self.life_btns = []
        self.life_ok = Btn((LIFE_CARD.right - 290, LIFE_CARD.bottom - 78, 260, 54), "하던 일로 돌아가기", ORANGE, 17)
        self.cg_wait = []                # 곧 보여 줄 CG (장면이 자리를 잡은 뒤 update 에서 띄운다)
        self.perks = {}
        self.bad = False                 # 담합에 가담 → BAD 엔딩
        self.t = 0.0
        self.phase_t = 0.0
        self.toast = None                # (글, 남은 시간)
        self.view = View(ORIGIN)
        self._bg = None
        self.clerk = Character(app.data.dialogue["hero"]["look"])      # 창구의 심사관 = 심사숙GO의 주인공
        self.officer = None
        self.next_btn = Btn((PANEL.right - 250, PANEL.bottom - 76, 226, 56), "다음")
        self.alt_btn = Btn((PANEL.x + 24, PANEL.bottom - 76, 290, 56), "", TEAL)
        self.speed_btns = []
        self.seq = []                    # 생산(리듬 놀이)의 상자들
        self.opt_btns = []
        if saved:                                                # 이어하기: 그날 아침부터
            self.money, self.trust, self.day_i = saved["money"], saved["trust"], saved["day_i"]
            self.history, self.refused = list(saved["history"]), saved["refused"]
            self.staff = list(saved.get("staff", []))
            self.run_cgs = list(saved.get("cgs", []))
            self.life_seen, self.buffs = list(saved.get("life", [])), dict(saved.get("buffs", {}))
            self.pending = saved.get("pending")
            self.life_log.update(saved.get("life_log", {}))
        self._start_day()

    def _save(self):
        storage.write(self.app.profile.dir, SAVE_NAME, json.dumps(
            {"level": self.level["id"], "day_i": self.day_i, "money": self.money, "trust": self.trust,
             "history": self.history, "refused": self.refused, "staff": self.staff, "cgs": self.run_cgs,
             "life": self.life_seen, "buffs": self.buffs, "pending": self.pending, "life_log": self.life_log},
            ensure_ascii=False))

    # ================================================================ 하루 준비
    @property
    def day(self) -> int:
        return self.day_i + 1

    def _go(self, phase):
        self.phase, self.phase_t = phase, 0.0

    def _notice(self, item_name, agency, scale, no, shared=None):
        item = self.app.data.item_by_name(item_name)
        est = _man(item["qty"] * item["unit_price"] * scale)
        return {"no": no, "item": item_name, "agency": agency, "qty": max(1, int(item["qty"] * scale)), "unit": item["unit"],
                "est": est, "sme": item["sme_only"], "can": item_name in self.co["can_make"], "shared": shared,
                "cost": _man(est * self.rng.uniform(*self.cfg["cost_rate"]))}

    def _start_day(self):
        data, cfg = self.app.data, self.cfg
        tut = self.tutorial
        self.perks = {} if tut else staffmod.perks(self.staff)
        if not tut:
            if self.day_i == 0 and "f_open" not in self.run_cgs:    # 첫날 아침: 공장 문을 여는 CG
                self.cg_wait.append(("f_open", None))
            self._save()                                         # 하루를 시작할 때마다 자동 저장
        case = data.case_of(self.day)
        self.case = case
        self.active = {"R01", "R02"} if tut else {r["id"] for r in data.active_rules(self.day)}
        if tut:
            notices = [self._notice("복사용지(A4)", "연습 공고", 0.2, "R26BK00000000")]
        else:
            notices = [self._notice(case["item"], case["agency"], 1.0, case["notice_no"], shared=case)]
        pool = [s for s in cfg["side_notices"] if s["item"] != case["item"]]
        self.rng.shuffle(pool)
        can = [s for s in pool if s["item"] in self.co["can_make"]]
        picks = can[:1 if notices[0]["can"] else 2]              # 만들 수 있는 공고가 날마다 두 건은 있게
        if tut:
            picks = [next(s for s in pool if s["item"] not in self.co["can_make"])]
        picks += [s for s in pool if s not in picks][:2 - len(picks)]
        for i, s in enumerate(picks):
            notices.append(self._notice(s["item"], s["agency"], s["scale"], f"R26BK{self.rng.randint(30000000, 99999999)}"))
        self.notices = notices
        self.pick = None
        self.price = 0
        self.rivals = []
        self.deadline = float(cfg["deadline_sec"]) * self.level["deadline"]
        self.deadline_total = self.deadline
        self.retries = 99 if tut else self.level["retries"]
        self.life_done = tut
        self.life_hook = self.rng.choice(("bid", "produce"))
        if not tut:                                              # 어제의 생활 사건이 남긴 효과
            self.deadline = max(25.0, self.deadline + self.buffs.pop("deadline", 0))
            self.deadline_total = self.deadline
        self.cost_cut = 0
        self.fields, self.answers = [], {}
        self.violation = None
        self.today = {"day": self.day, "won": False, "rejected": None, "paid": 0, "cost": 0, "penalty": 0, "leak": 0,
                      "late": False, "side": 0, "item": "", "agency": ""}
        if not tut:
            self.history.append(self.today)
        col = cfg["collusion"]
        if self.day == col["day"] and not tut:
            self.event = col
            self.event_result = None
            self.opt_btns = [Btn((PANEL.x + 30, PANEL.y + 330, PANEL.w - 60, 58), col["refuse"]["label"], GREEN),
                             Btn((PANEL.x + 30, PANEL.y + 402, PANEL.w - 60, 58), col["accept"]["label"], (150, 140, 150))]
            self._go(EVENT)
        else:
            self._go(BOARD)
            if self.refused and self.day == col["day"] + 1 and not tut:
                self.toast = (col["news"], 7.0)
        sfx.play("pop", 0.5)

    # ================================================================ 선택과 진행 (화면 없이도 불러 쓸 수 있다)
    def choose_event(self, accept: bool):
        if self.phase != EVENT or self.event_result:
            return
        if accept:
            self.bad = True
            self.event_result = self.event["accept"]["result"]
            sfx.play("wrong", 0.6)
        else:
            self.refused = True
            record(self.app)["refused"] = True
            self.app.profile.save()
            self.trust = min(100, self.trust + self.event["refuse"]["trust"])
            self.event_result = self.event["refuse"]["result"]
            sfx.play("correct", 0.6)
        self.phase_t = 0.0

    def pick_notice(self, i: int):
        if self.phase != BOARD or not self.notices[i]["can"]:
            if self.phase == BOARD:
                self.toast = ("우리 공장이 직접 만들 수 없는 품목이에요. 직접 만드는 업체만 응찰할 수 있어요.", 3.0)
                sfx.play("wrong", 0.4)
            return
        n = self.pick = self.notices[i]
        lo, hi = self.cfg["price_range"]
        self.p_min = _man(n["est"] * lo)
        self.p_max = _man(n["est"] * (hi if "R06" in self.active else 1.0))    # 예정가격 규정을 배우기 전에는 넘겨 쓸 수 없다
        self.floor = _man(n["est"] * self.cfg["floor_rate"])
        self.price = _man(n["est"] * 0.97)
        cut = (self.perks["account"][1]["cut"] if "account" in self.perks else 0) + self.cost_cut
        if cut and "cost0" not in n:                              # 살림꾼·미리 사 둔 원자재: 원가 절감
            n["cost0"] = n["cost"]
            n["cost"] = _man(n["cost"] * (1 - cut))
        names = [c["name"] for c in self.app.data.clean_companies]
        self.rng.shuffle(names)
        lo, hi = self.cfg["floor_rate"] - 0.03, self.level["rival_hi"]
        if self.tutorial:
            lo, hi = 0.985, 1.0                                  # 연습: 경쟁 업체는 비싸게 쓴다
        self.rivals = [(nm, _man(n["est"] * self.rng.uniform(lo, hi))) for nm in names[:3]]
        self.intel = self.rivals[:self.perks["sales"][1]["n"]] if "sales" in self.perks else []   # 영업 담당이 알아 온 값
        self.today["item"], self.today["agency"] = n["item"], n["agency"]
        sub = self.cfg["subway"]
        if self.day == sub["day"] and not self.tutorial:
            self.deadline -= sub["lose_sec"]
            self.toast = (sub["text"], 6.0)
        self._go(PRICE)
        sfx.play("paper", 0.5)

    def set_price(self, v):
        self.price = max(self.p_min, min(self.p_max, _man(v)))

    def submit_price(self):
        if self.phase == PRICE:
            self._build_fields()
            self._go(DOCS)
            sfx.play("paper", 0.5)

    def _build_fields(self):
        """서류 꾸리기 — 그날까지 배운 규정만 직접 챙긴다.
        fields: 입찰서에 적어 넣는 칸 (id, 이름, 보기들, 정답 번호들)
        docs:   서류 더미. 봉투에 넣을 서류를 모두 고른다. 같은 이름이라도 조건이 안 맞는 서류(기간 만료·금액 부족·
                다른 품목·서명 없음)와 입찰과 아무 상관 없는 종이가 섞여 있다."""
        co, rng, n = self.co, self.rng, self.pick
        f = []
        if "R09" in self.active:
            opts = [co["name"], co["old_name"]]
            rng.shuffle(opts)
            f.append(("R09", "입찰서 상호", opts, {opts.index(co["name"])}))
        if "R02" in self.active:
            b = co["biz_no"]
            opts = [b, b[:-1] + str((int(b[-1]) + 6) % 10), b[:4] + b[5] + b[4] + b[6:]]
            rng.shuffle(opts)
            f.append(("R02", "입찰서 사업자번호", opts, {opts.index(b)}))
        self.fields = f
        self.answers = {fid: None for fid, *_ in f}

        def doc(rule, ok, name, sub):
            kind = papers.kind_of(rule, name)
            return {"rule": rule, "ok": ok, "name": name, "sub": sub, "picked": False, "mark": False, "kind": kind,
                    "w": papers.SIZES[kind][0], "h": papers.SIZES[kind][1]}

        def amount(rate):
            return ui.won(math.ceil(self.price * rate / 10000) * 10000)
        docs = []
        if "R01" in self.active:
            docs += [doc("R01", True, "입찰참가자격 등록증", "유효 · 2026년 발급"), doc("R01", False, "입찰참가자격 등록증", "기간 만료 · 2023년 발급")]
        if "R05" in self.active:
            docs += [doc("R05", True, "입찰보증서", f"{amount(rng.choice((0.05, 0.06)))} · 유효"),
                     doc("R05", False, "입찰보증서", f"{amount(0.03)} · 유효"),
                     doc("R05", False, "입찰보증서", f"{amount(0.07)} · 지난달 만료")]
        if "R07" in self.active:
            other = rng.choice([i["name"] for i in self.app.data.items if i["name"] != n["item"]])
            docs += [doc("R07", True, "직접생산확인증명서", f"품목: {n['item']}"), doc("R07", False, "직접생산확인증명서", f"품목: {other}")]
        if "R08" in self.active:
            docs += [doc("R08", True, "청렴계약 이행서약서", "대표자 서명 완료"), doc("R08", False, "청렴계약 이행서약서", "서명 칸이 비어 있음")]
        junk = list(self.cfg["junk_docs"])
        rng.shuffle(junk)
        for name, sub_ in junk[:max(2, min(4, 12 - len(docs)))]:      # 입찰과 아무 상관 없는 종이
            docs.append(doc(None, False, name, sub_))
        rng.shuffle(docs)
        self.docs = docs
        self.crossed = {}
        # 책상 위에 서너 무더기로 아무렇게나 쌓여 있다
        piles = [(DESK_AREA.x + 150, DESK_AREA.y + 140), (DESK_AREA.right - 170, DESK_AREA.y + 170),
                 (DESK_AREA.x + 230, DESK_AREA.bottom - 160), (DESK_AREA.right - 150, DESK_AREA.bottom - 140)]
        for k, dc in enumerate(docs):
            cx, cy = piles[k % len(piles)]
            dc.update(x=cx + rng.uniform(-60, 60), y=cy + rng.uniform(-40, 40), rot=rng.uniform(-14, 14), tx=None, ty=None, img=None)
        self.doc_order = list(range(len(docs)))                  # 겹친 순서 (뒤가 위)
        self.drag = None                                         # 끌고 있는 서류 (번호, 잡은 자리 x, y)
        self.check_left = 1                                      # 꼼꼼 확인: 하루 한 번
        self.tidy_at = float(self.perks["tidy"][1]["delay"]) if "tidy" in self.perks else None      # 서류 정리까지 남은 시간
        if "mark" in self.perks:                                 # 형광펜: 꼭 챙길 서류에 표시
            must = [dc for dc in docs if dc["ok"] and self.doc_required(dc["rule"])]
            for dc in must[:self.perks["mark"][1]["n"]]:
                dc["mark"] = True

    def tidy_docs(self):
        """책상에 남은 서류를 겹치지 않게 가지런히 펼친다 (서류 정리 기술)."""
        rest = [i for i in self.doc_order if not self.docs[i]["picked"]]
        for k, i in enumerate(sorted(rest, key=lambda i: (self.docs[i]["rule"] is None, self.docs[i]["name"], self.docs[i]["sub"]))):
            dc = self.docs[i]
            dc["tx"] = DESK_AREA.x + 78 + (k % 4) * 151
            dc["ty"] = DESK_AREA.y + 92 + (k // 4) * 180
            if dc["rot"]:
                dc["rot"], dc["img"] = 0.0, None

    def doc_required(self, rule) -> bool:
        """이 규정의 서류를 오늘 공고에 꼭 넣어야 하는가 (직접생산확인증명서는 중소기업자간 경쟁제품일 때만)."""
        return rule != "R07" or self.pick["sme"]

    def toggle_doc(self, i: int):
        """서류를 봉투에 넣거나(책상 → 봉투) 도로 꺼낸다."""
        dc = self.docs[i]
        if self.phase != DOCS:
            return
        dc["picked"] = not dc["picked"]
        if not dc["picked"]:                                     # 꺼낸 서류는 봉투 옆 책상에 놓인다
            dc["x"], dc["y"] = DESK_AREA.right - 110 + self.rng.uniform(-30, 20), DESK_AREA.y + 120 + self.rng.uniform(0, 240)
            dc["tx"] = dc["ty"] = None
            self.doc_order.remove(i)
            self.doc_order.append(i)
        sfx.play("paper", 0.4)

    def _check_docs(self):
        """봉투에 든 서류를 본다 → (걸린 규정 또는 None, 상관없는 종이 수)."""
        picked = [dc for dc in self.docs if dc["picked"]]
        for rule in ("R01", "R05", "R07", "R08"):
            mine = [dc for dc in self.docs if dc["rule"] == rule]
            if not mine or not self.doc_required(rule):
                continue
            got = [dc for dc in mine if dc["picked"]]
            if not any(dc["ok"] for dc in got) or any(not dc["ok"] for dc in got):   # 빠졌거나, 조건이 안 맞는 서류가 섞였다
                return rule, 0
        junk = sum(1 for dc in picked if dc["rule"] is None or (not self.doc_required(dc["rule"]) and not dc["ok"]))
        return None, junk

    def choose(self, fid: str, idx: int):
        if self.phase == DOCS and fid in self.answers and self.crossed.get(fid) != idx:
            self.answers[fid] = idx
            sfx.play("click", 0.4)

    def docs_ready(self) -> bool:
        return all(v is not None for v in self.answers.values())

    def submit_docs(self, late=False):
        """창구에 낸다. 틀린 곳이 있으면 심사숙GO의 그 규정으로 반려된다."""
        if self.phase not in (DOCS, PRICE) or (not late and not self.docs_ready()):
            return
        if not late and self.phase == DOCS and "check" in self.perks and self.check_left > 0:
            missing = next((dc for dc in self.docs if dc["ok"] and not dc["picked"] and self.doc_required(dc["rule"])), None)
            if missing:
                self.check_left -= 1
                if self.rng.random() < self.perks["check"][1]["chance"]:
                    who = self.perks["check"][2]
                    self.toast = (f"{who['nick']}: “{who['say']['check']} ‘{missing['name']}’가 빠졌어요.”", 5.0)
                    sfx.play("bell", 0.5)
                    return
        self.drag = None
        self.violation = None
        if late:
            self.violation = "R03"
        elif self.price > self.pick["est"]:
            self.violation = "R06"
        else:
            for fid, _, _, ok in self.fields:
                if self.answers[fid] not in ok:
                    self.violation = fid
                    break
            self.junk = 0
            if not self.violation:
                self.violation, self.junk = self._check_docs()
                if self.junk and not self.tutorial:                  # 상관없는 종이를 넣으면 반려는 아니지만 인상이 깎인다
                    self.trust = max(0, self.trust - min(3, self.junk))
        self.clerk.expression = "happy" if not self.violation else "nervous"
        self.clerk.set_pose("cheer" if not self.violation else "shrug")
        can_retry = bool(self.violation) and not late and self.retries > 0 and self.deadline > self.cfg["retry_cost_sec"]
        self.alt_btn.label = f"고쳐서 다시 낸다 (-{self.cfg['retry_cost_sec']}초)"
        self.alt_btn.enabled = can_retry
        self.next_btn.label = "개찰 보러 가기" if not self.violation else "오늘은 돌아간다"
        if self.tutorial and self.violation:
            self.alt_btn.enabled, self.alt_btn.label = True, "고쳐서 다시 낸다"
        sfx.play("stamp", 0.7)
        sfx.play("correct" if not self.violation else "wrong", 0.5)
        self._go(WINDOW)

    def retry_docs(self):
        if self.phase == WINDOW and self.alt_btn.enabled:
            self.retries -= 1
            if not self.tutorial:
                self.deadline -= self.cfg["retry_cost_sec"]
            if self.violation == "R06":
                self._go(PRICE)
            else:
                self._go(DOCS)

    def _open_bids(self):
        n = self.pick
        rows = [(self.co["name"], self.price, True)] + [(nm, p, False) for nm, p in self.rivals]
        valid = [r for r in rows if self.floor <= r[1] <= n["est"]]
        self.winner = min(valid, key=lambda r: (r[1], not r[2])) if valid else None
        self.bid_rows = sorted(rows, key=lambda r: r[1])
        self.today["won"] = bool(self.winner and self.winner[2])
        self.next_btn.label = "공장 가동!" if self.today["won"] else "다시 써 보기" if self.tutorial else "다음"
        self._go(OPEN)

    def _start_production(self):
        """생산 = 출하 검수 리듬 놀이. 작업대 여기저기서 상자가 박자에 맞춰 튀어나온다.
        멀쩡한 상자는 고리가 딱 맞을 때 누르고(출하), 찌그러진 상자는 누르지 않는다(걸러냄)."""
        p, rng = self.cfg["produce"], self.rng
        rh = dict(self.level["rhythm"])
        if self.tutorial:
            rh.update(tracks=["line_a"], step=2, rest=0.0, lead=2.0, window=0.42, multi=0.0, half=0.0)
        self.target = 6 if self.tutorial else p["boxes"][min(self.day_i, len(p["boxes"]) - 1)]
        self.track = rh["tracks"][self.day_i % len(rh["tracks"])]
        self.bpm = p["tracks"][self.track]
        spb = self.spb = 60.0 / self.bpm
        wide = 1 + self.perks["craft"][1]["wide"] if "craft" in self.perks else 1.0       # 숙련공: 판정이 넉넉해진다
        self.window = rh["window"] * wide
        self.lead = rh["lead"] * spb
        defect = min(0.6, rh["defect"] * self.buffs.get("defect", 1.0))                  # 생활 이슈의 효과 포함
        need = math.ceil(self.target * p["extra"])
        fixed = [False, True, False, False, True, False, False, False, False]           # 연습: 정해진 순서
        seq, busy, beat, normal = [], {}, 4.0, 0                                          # 처음 네 박은 준비
        while normal < need and len(seq) < 240:
            count = 0 if rng.random() < rh["rest"] else 2 if rng.random() < rh["multi"] else 1
            b = beat + (0.5 if rng.random() < rh["half"] else 0.0)
            for _ in range(count):
                free = [i for i in range(len(SPOTS)) if busy.get(i, -99.0) <= b - rh["lead"] - 0.3]
                if not free or normal >= need:
                    break
                spot = rng.choice(free)
                bad = fixed[len(seq) % len(fixed)] if self.tutorial else rng.random() < defect
                busy[spot] = b + 1.0
                seq.append({"spot": spot, "bad": bad, "hit": b * spb, "state": "wait", "t": 0.0, "judge": ""})
                normal += not bad
            beat += rh["step"]
        self.seq = self.boxes = seq
        self.clock = 0.0
        self.length = max(b["hit"] for b in seq) + self.window + 1.0
        self.shipped = self.leaked = self.pulled = self.missed = self.auto_pulled = 0
        self.perfect = self.good = self.off = self.combo = self.max_combo = 0
        self.judge = None                # 방금 판정 (글, 색, 남은 시간)
        self._go(PRODUCE)
        bgm.restart(self.track)          # 곡을 처음부터 — 박자를 맞춘다
        sfx.play("bell", 0.5)

    def tap_box(self, box):
        """나와 있는 상자를 누른다. 멀쩡한 상자 = 출하(박자에 맞을수록 좋다), 찌그러진 상자 = 불량을 내보낸 것."""
        if box["state"] != "live":
            return
        box["t"] = 0.0
        if box["bad"]:
            if "qc" in self.perks and self.rng.random() < self.perks["qc"][1]["chance"]:   # 검사 고수가 대신 걸러 준다
                who = self.perks["qc"][2]
                box["state"], box["judge"] = "saved", f"{who['nick']}: {who['say']['qc']}"
                self.pulled += 1
                self.auto_pulled += 1
                sfx.play("correct", 0.4)
                return
            box["state"], box["judge"] = "oops", "불량 출하!"
            self.leaked += 1
            self.combo = 0
            self.judge = ("불량 출하!", RED, 0.7)
            sfx.play("wrong", 0.5)
            return
        gap = self.clock - box["hit"]
        self.shipped += 1
        if abs(gap) <= self.window * 0.45:
            box["judge"], col = "딱!", ORANGE
            self.perfect += 1
            self.combo += 1
        elif abs(gap) <= self.window:
            box["judge"], col = "좋아요", GREEN
            self.good += 1
            self.combo += 1
        else:
            box["judge"], col = ("빨라요" if gap < 0 else "늦었어요"), SOFT
            self.off += 1
            self.combo = 0
        self.max_combo = max(self.max_combo, self.combo)
        box["state"] = "hit"
        self.judge = (box["judge"], col, 0.6)
        sfx.play("pop" if col != SOFT else "click", 0.5)

    def _finish_production(self, late=False):
        n, t, p = self.pick, self.today, self.cfg["produce"]
        done = self.shipped + self.leaked
        bgm.play("factory")                                      # 리듬 곡을 끄고 공장 음악으로
        total = max(1, self.perfect + self.good + self.off + self.missed)
        t.update(perfect=self.perfect, good=self.good, missed=self.missed, combo=self.max_combo)
        on_beat = (self.perfect + self.good) / total >= 0.85
        self.buffs.pop("defect", None)                           # 불량 효과는 이번 생산까지
        t["late"], t["leak"] = late, self.leaked
        ratio = min(1.0, done / self.target)
        t["paid"] = _man(self.price * ratio)
        t["cost"] = n["cost"]
        over = max(0, self.leaked - p["leak_ok"])
        t["penalty"] = _man(self.price * (p["leak_penalty"] * over + (0.10 if late else 0)))
        if not self.tutorial:
            self.trust = max(0, min(100, self.trust + (8 if not late and not over else 0) - 6 * over - (12 if late else 0)
                                    + (2 if on_beat and not late and not over else 0)))      # 박자를 잘 맞추면 덤
        case = n["shared"]
        look = case["officer"]["look"] if case else {"body": "#D8E6F0", "shape": "bean", "ears": "none", "acc": ["idcard"]}
        self.officer = Character(look)
        good = not late and not over
        self.hire = False
        if not self.tutorial:                                    # 도감 기록: 납품 횟수, 완벽하게 납품한 곳
            rec = record(self.app)
            rec["wins"] += 1
            if good:
                rec["perfect"] += 1
                self.hire = len(self.staff) < staffmod.MAX_STAFF     # 완벽 납품 → 채용 봉투 (최대 3명)
                key = f"{n['agency']}|{n['item']}"
                rec["delivered"][key] = rec["delivered"].get(key, 0) + 1
            self.app.profile.save()
        self.officer.expression = "happy" if good else "nervous"
        self.officer.set_pose("cheer" if good else "shrug")
        self.next_btn.label = "진짜 입찰 시작!" if self.tutorial else "채용 봉투 열기!" if self.hire else "다음"
        self._go(RESULT)
        sfx.play("fanfare" if good else "pop", 0.5)

    def _to_ledger(self):
        self._life_pop()                                         # 오늘 사건이 아직 안 나왔으면 정산 전에
        t = self.today
        if not t["won"]:
            t["side"] = self.cfg["side_income"]                  # 낙찰은 못 했지만 일반 거래처 주문으로 버틴다
        self.fixed_rows = [(name, _man(v * self.level["fixed"])) for name, v in self.cfg["fixed"]]
        self.fixed = sum(v for _, v in self.fixed_rows)
        t["net"] = t["paid"] + t["side"] - t["cost"] - t["penalty"] - self.fixed
        self.money_before = self.money
        self.money += t["net"]
        self.next_btn.label = "결과 보기" if self.day_i >= self.days - 1 else "다음 날로"
        self._go(LEDGER)
        sfx.play("paper", 0.5)

    def _finish(self):
        grade = next(g for g in self.cfg["grades"] if self.money >= g[0] and self.trust >= g[1])
        self.grade = ("BAD", "입찰참가자격 제한") if self.bad else (grade[2], grade[3])
        delete_save(self.app)                                    # 끝까지 왔으면 이어하기 기록은 지운다
        if not self.bad:
            rec = record(self.app)
            rec["clear"] = True
            order = "CBAS"                                       # 난이도마다 가장 좋았던 등급을 남긴다
            old = rec["levels"].get(self.level["id"], "C")
            rec["levels"][self.level["id"]] = max(old, self.grade[0], key=order.index)
            rec["best"] = max(rec.get("best", 0), self.money)
            rec["grade"] = self.grade[0]
            self.app.profile.save()
        self.next_btn.label = "처음 화면으로"
        self.boss.expression = "sad" if self.bad else "happy"
        self.boss.set_pose("slump" if self.bad else "cheer")
        self._go(END)
        sfx.play("wrong" if self.bad else "fanfare", 0.6)

    # ---------------------------------------------------------------- 이벤트 CG
    def show_cg(self, cg_id, then=None):
        """CG 한 장을 보여 주고 이 장면으로 돌아온다. then: CG 를 넘길 때 할 일."""
        from ..scenes.cgscene import CGScene
        if cg_id not in self.run_cgs:
            self.run_cgs.append(cg_id)

        def done():
            if then:
                then()
            self.app.change(lambda: self)
        chief = {"look": self.app.data.dialogue["hero"]["look"], "name": "조달청 심사관", "difficulty": self.level["name"]}
        looks = [m["look"] for m in self.staff]
        self.app.change(lambda: CGScene(self.app, cg_id, chief=chief, mates=looks, on_done=done, hero_look=self.level["look"]))

    def _day_cg(self):
        """하루를 마칠 때 보여 줄 CG: 처음 겪은 일(첫 낙찰·새 식구·거절)이 먼저, 없으면 일상 CG 하나."""
        t = self.today
        firsts = (("f_firstwin", t["won"]), ("f_hire", bool(self.staff)),
                  ("f_refuse", self.refused and self.day == self.cfg["collusion"]["day"]))
        for cg_id, ok in firsts:
            if ok and cg_id not in self.run_cgs:
                return cg_id
        return fcg.pick_random(self.run_cgs, self.app.profile.data["cgs"], self.rng)

    # ---------------------------------------------------------------- 일하는 중간에 끼어드는 생활 이슈
    def _life_pop(self):
        """하루 한 번, 일하는 도중에 가족·지인의 일이 끼어든다. 바로 해결할지, 일단 보류할지 고른다.
        어제 보류한 일이 있으면 그 일이 다시 찾아온다 (또 미루면 터진다)."""
        if not self.life_enabled or self.life_done or self.tutorial or self.bad or self.life:
            return
        self.life_done = True
        events = self.cfg["life"]["events"]
        again = self.pending is not None
        if again:
            ev = next(e for e in events if e["id"] == self.pending)
        else:
            pool = [e for e in events if e["id"] not in self.life_seen] or events
            ev = self.rng.choice(pool)
            self.life_seen.append(ev["id"])
        self.life = {"ev": ev, "chosen": None, "t": 0.0, "again": again}
        r = LIFE_CARD
        self.life_btns = [Btn((r.x + 30, r.bottom - 184, r.w - 60, 54), ev["solve"]["label"], TEAL, 18),
                          Btn((r.x + 30, r.bottom - 96, r.w - 60, 54), "또 미룬다" if again else "일단 보류한다", (150, 160, 166), 18)]
        sfx.play("bell", 0.5)

    def _life_time(self) -> str:
        """지금 쓰게 되는 시간이 어디서 깎이는지: bid(서류 마감) / produce(납기) / tomorrow(내일 마감)."""
        return "bid" if self.phase in (PRICE, DOCS) else "produce" if self.phase == PRODUCE else "tomorrow"

    def choose_life(self, i: int):
        """0 = 바로 해결, 1 = 일단 보류."""
        lf = self.life
        if not lf or lf["chosen"] is not None:
            return
        ev = lf["ev"]
        if i == 0:
            o = ev["solve"]
            sec = int(o["time"] * (1.5 if lf["again"] else 1))       # 미뤘던 일은 품이 더 든다
            where = self._life_time()
            if where == "bid":
                self.deadline = max(5.0, self.deadline - sec)
            elif where == "produce":                              # 자리를 비운 사이 곧 나올 상자를 놓친다
                left = self._life_lost(sec)
                for box in self.seq:
                    if left and box["state"] == "wait" and not box["bad"]:
                        box["state"] = "gone"
                        self.missed += 1
                        left -= 1
            else:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) - sec
            self.money += o["money"]
            self.trust = max(0, min(100, self.trust + o["trust"]))
            if o["tomorrow"]:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) + o["tomorrow"]
            lf["result"], lf["effect"] = o["result"], self.life_effect(ev, "solve", sec, where)
            self.pending = None
            self.life_log["solved"] += 1
            sfx.play("correct", 0.5)
        elif lf["again"]:                                            # 두 번 미뤘다 → 터진다
            o = ev["burst"]
            self.money += o["money"]
            self.trust = max(0, min(100, self.trust + o["trust"]))
            if o["tomorrow"]:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) + o["tomorrow"]
            if o["defect"]:
                self.buffs["defect"] = self.buffs.get("defect", 1.0) * (1 + o["defect"])
            lf["result"], lf["effect"] = o["result"], self.life_effect(ev, "burst")
            self.pending = None
            self.life_log["burst"] += 1
            sfx.play("wrong", 0.6)
        else:
            lf["result"], lf["effect"] = ev["defer"]["result"], "내일 다시 찾아옵니다 (또 미루면 일이 커져요)"
            self.pending = ev["id"]
            self.life_log["deferred"] += 1
            sfx.play("pop", 0.4)
        lf["chosen"], lf["t"] = i, 0.0

    @staticmethod
    def _life_lost(sec) -> int:
        return min(2, max(1, sec // 5))

    def close_life(self):
        if self.life and self.life["chosen"] is not None:
            self.life = None
            bgm.pause(False)
            sfx.play("paper", 0.4)

    def life_effect(self, ev, kind, sec=0, where="bid") -> str:
        o = ev[kind]
        parts = []
        if kind == "solve":
            parts.append({"bid": f"서류 마감 -{sec}초", "produce": f"곧 나올 상자 {self._life_lost(sec)}개 놓침", "tomorrow": f"내일 마감 -{sec}초"}[where])
        if o["money"]:
            parts.append(f"통장 {'+' if o['money'] > 0 else '-'}{ui.won(abs(o['money']))}")
        if o["trust"]:
            parts.append(f"신뢰도 {o['trust']:+d}")
        if o["tomorrow"]:
            parts.append(f"내일 마감 {o['tomorrow']:+d}초")
        if o.get("defect"):
            parts.append(f"다음 생산 불량 +{int(o['defect'] * 100)}%")
        return " · ".join(parts)

    def _draw_life(self, surf):
        lf = self.life
        ev = lf["ev"]
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((30, 44, 54, min(150, int(lf["t"] * 700)) if lf["chosen"] is None else 150))
        surf.blit(veil, (0, 0))
        r = LIFE_CARD
        card(surf, r, 24)
        head = RED if lf["again"] else YELLOW
        pygame.draw.rect(surf, head, (r.x, r.y, r.w, 54), border_top_left_radius=24, border_top_right_radius=24)
        ui.draw_text(surf, "어제 미뤄 둔 일이 다시…" if lf["again"] else "잠깐! 일하는 중에…", (r.x + 28, r.y + 27), 17,
                     PAPER if lf["again"] else INK, "heavy", anchor="midleft")
        ui.draw_text(surf, ev["who"], (r.right - 28, r.y + 27), 14, PAPER if lf["again"] else INK, True, anchor="midright")
        ui.draw_text(surf, ev["title"], (r.x + 30, r.y + 72), 27, INK, "heavy")
        y = ui.draw_wrapped(surf, ev["text"], (r.x + 30, r.y + 118, r.w - 60, 90), 17, INK)
        if lf["chosen"] is None:
            sec = int(ev["solve"]["time"] * (1.5 if lf["again"] else 1))
            hints = (self.life_effect(ev, "solve", sec, self._life_time()),
                     "지금은 하던 일에 집중 · " + ("더 미루면 일이 커져요!" if lf["again"] else "내일 다시 찾아와요"))
            for b, hint in zip(self.life_btns, hints):
                b.draw(surf)
                ui.draw_text(surf, hint, (b.rect.right - 8, b.rect.bottom + 10), 12, SOFT, True, anchor="topright")
        else:
            box = pygame.Rect(r.x + 26, y + 16, r.w - 52, 140)
            burst = lf["chosen"] == 1 and lf["again"]
            pygame.draw.rect(surf, (255, 236, 230) if burst else (240, 247, 248), box, border_radius=14)
            label = self.life_btns[lf["chosen"]].label
            ui.draw_text(surf, f"→ {label}", (box.x + 16, box.y + 12), 14, RED if burst else TEAL, True)
            ui.draw_wrapped(surf, lf["result"], (box.x + 16, box.y + 38, box.w - 32, 70), 16, INK, True)
            ui.draw_text(surf, lf["effect"], (box.right - 16, box.bottom - 26), 13, RED if burst else ORANGE, True, anchor="topright")
            self.life_ok.draw(surf)

    def hire_staff(self):
        """채용 봉투(심사숙GO의 인사 발령 봉투와 같은 연출)를 열고, 끝나면 이 장면으로 돌아와 장부를 본다."""
        from ..scenes.gacha import GachaScene

        def done():
            self.perks = staffmod.perks(self.staff)
            self._to_ledger()
            self.app.change(lambda: self)
        self.app.change(lambda: GachaScene(self.app, 1, staffmod.kit(self.app, self, done)))

    def advance(self):
        """'다음' 버튼."""
        if self.life:
            return
        ph = self.phase
        if ph == EVENT and self.event_result:
            if self.bad:
                self.show_cg("f_bad", self._finish)            # 닫힌 셔터 → BAD 엔딩
            else:
                self._go(BOARD)
        elif ph == WINDOW:
            if self.violation and self.tutorial:
                self.retry_docs()
            elif self.violation:
                rec = record(self.app)                           # 도감 기록: 어떤 규정으로 반려당했는가
                rec["rejects"][self.violation] = rec["rejects"].get(self.violation, 0) + 1
                self.app.profile.save()
                self.today["rejected"] = self.violation
                self.trust = max(0, self.trust - 4)
                self._to_ledger()
            else:
                self._open_bids()
        elif ph == OPEN and self.phase_t > 1.6:
            if self.today["won"]:
                self._start_production()
            elif self.tutorial:
                self._go(PRICE)                                  # 연습: 값을 다시 써 본다
            else:
                self._to_ledger()
        elif ph == RESULT:
            if self.tutorial:                                    # 연습 끝 → 진짜 1일차
                self.tutorial = False
                self._start_day()
            elif self.hire:                                      # 채용 봉투 열기 → 돌아와서 장부
                self.hire = False
                self.hire_staff()
            else:
                self._to_ledger()
        elif ph == LEDGER:
            def next_day():
                self.day_i += 1
                self._start_day()
            if self.day_i >= self.days - 1:
                self.show_cg("f_finale", self._finish)
            else:
                cg_id = self._day_cg()
                self.show_cg(cg_id, next_day) if cg_id else next_day()
        elif ph == END:
            self.app.to_factory()

    # ================================================================ 입력
    def _slider(self):
        return pygame.Rect(PANEL.x + 40, PANEL.y + 372, PANEL.w - 80, 16)

    def _notice_rect(self, i):
        return pygame.Rect(PANEL.x + 20, PANEL.y + 146 + i * 140, PANEL.w - 40, 130)

    def _doc_rect(self, i):
        dc = self.docs[i]
        r = pygame.Rect(0, 0, dc["w"], dc["h"])
        r.center = (int(dc["x"]), int(dc["y"]))
        return r

    def _env_chip(self, k):
        return pygame.Rect(ENVELOPE.x, ENVELOPE.bottom + 34 + k * 30, ENVELOPE.w, 26)

    def _field_opts(self, row, n_opts):
        y = FORM.y + 150
        for _, _, opts, _ in self.fields[:row]:
            y += 34 + len(opts) * 40
        return [pygame.Rect(FORM.x + 16, y + 26 + k * 40, FORM.w - 32, 34) for k in range(n_opts)]

    def _box_pos(self, box):
        gx, gy = SPOTS[box["spot"]]
        x, y = self.view.pt(gx + PAD / 2, gy + PAD / 2, 0.5)
        return int(x), int(y)

    def handle_event(self, event):
        if self.life:                                            # 생활 사건이 떠 있는 동안은 그것부터
            if self.life["chosen"] is None:
                for i, b in enumerate(self.life_btns):
                    num = event.type == pygame.KEYDOWN and event.key == pygame.K_1 + i
                    if self.life["t"] > 0.4 and (b.clicked(event) or num):
                        self.choose_life(i)
                        break
            elif self.life["t"] > 0.4 and (self.life_ok.clicked(event) or (
                    event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE))):
                self.close_life()
            return
        ph = self.phase
        down = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        key = event.key if event.type == pygame.KEYDOWN else None
        go = key in (pygame.K_RETURN, pygame.K_SPACE)
        if ph == EVENT:
            if self.event_result is None:
                for i, b in enumerate(self.opt_btns):
                    if b.clicked(event):
                        self.choose_event(i == 1)
            elif self.phase_t > 0.4 and (self.next_btn.clicked(event) or go):
                self.advance()
        elif ph == BOARD:
            if down:
                for i in range(len(self.notices)):
                    if self._notice_rect(i).collidepoint(event.pos):
                        self.pick_notice(i)
                        break
        elif ph == PRICE:
            sl = self._slider()
            drag = (down and sl.inflate(30, 60).collidepoint(event.pos)) or (
                event.type == pygame.MOUSEMOTION and event.buttons[0] and sl.inflate(60, 160).collidepoint(event.pos))
            if drag:
                k = (event.pos[0] - sl.x) / sl.w
                self.set_price(self.p_min + (self.p_max - self.p_min) * max(0.0, min(1.0, k)))
            elif key in (pygame.K_LEFT, pygame.K_RIGHT):
                self.set_price(self.price + (-100000 if key == pygame.K_LEFT else 100000))
            elif self.next_btn.clicked(event) or go:
                self.submit_price()
        elif ph == DOCS:
            if down:
                for row, (fid, _, opts, _) in enumerate(self.fields):
                    for k, r in enumerate(self._field_opts(row, len(opts))):
                        if r.collidepoint(event.pos):
                            self.choose(fid, k)
                            return
                inside = [i for i in self.doc_order if self.docs[i]["picked"]]
                for k, i in enumerate(inside):                       # 봉투 안의 서류를 누르면 도로 꺼낸다
                    if self._env_chip(k).collidepoint(event.pos):
                        self.toggle_doc(i)
                        return
                for i in reversed(self.doc_order):                   # 맨 위에 놓인 서류부터 잡힌다
                    dc = self.docs[i]
                    if not dc["picked"] and self._doc_rect(i).collidepoint(event.pos):
                        self.drag = (i, dc["x"] - event.pos[0], dc["y"] - event.pos[1])
                        dc["tx"] = dc["ty"] = None
                        self.doc_order.remove(i)
                        self.doc_order.append(i)
                        sfx.play("paper", 0.3)
                        return
            elif event.type == pygame.MOUSEMOTION and self.drag:
                i, ox, oy = self.drag
                self.docs[i]["x"], self.docs[i]["y"] = event.pos[0] + ox, event.pos[1] + oy
                return
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag:
                i, ox, oy = self.drag
                self.drag = None
                dc = self.docs[i]
                dc["x"], dc["y"] = event.pos[0] + ox, event.pos[1] + oy
                if ENVELOPE.inflate(50, 60).collidepoint(dc["x"], dc["y"]) or ENVELOPE.inflate(20, 20).collidepoint(event.pos):
                    dc["picked"] = True                              # 봉투에 쏙
                    sfx.play("pop", 0.5)
                else:
                    dc["x"] = max(DESK_AREA.x + 40, min(DESK_AREA.right - 40, dc["x"]))
                    dc["y"] = max(DESK_AREA.y + 30, min(DESK_AREA.bottom - 30, dc["y"]))
                return
            if self.docs_ready() and (self.next_btn.clicked(event) or go):
                self.submit_docs()
        elif ph == WINDOW:
            if self.phase_t < 0.5:
                return
            if self.alt_btn.clicked(event):
                self.retry_docs()
            elif self.next_btn.clicked(event) or go:
                self.advance()
        elif ph == PRODUCE:
            if key is not None and pygame.K_a <= key <= pygame.K_z:      # 단축키: 그 작업대에 나와 있는 상자를 누른다
                spot = SPOT_KEYS.find(chr(key).upper())
                box = next((b for b in self.seq if b["spot"] == spot and b["state"] == "live"), None) if spot >= 0 else None
                if box:
                    self.tap_box(box)
                return
            if down:                                             # 누른 자리에서 가장 가까운, 나와 있는 상자
                best, far = None, 62
                for box in self.seq:
                    if box["state"] == "live":
                        x, y = self._box_pos(box)
                        dist = math.hypot(event.pos[0] - x, (event.pos[1] - y) * 1.5)
                        if dist < far:
                            best, far = box, dist
                if best:
                    self.tap_box(best)
        elif ph in (OPEN, RESULT, LEDGER, END):
            if self.phase_t > 0.5 and (self.next_btn.clicked(event) or go):
                self.advance()

    # ================================================================ 갱신
    def update(self, dt):
        self.t += dt
        self.phase_t += dt
        self.clerk.update(dt)
        if self.officer:
            self.officer.update(dt)
        for b in [self.next_btn, self.alt_btn] + self.speed_btns + self.opt_btns:
            b.update(dt)
        if self.toast:
            self.toast = (self.toast[0], self.toast[1] - dt) if self.toast[1] > dt else None
        self.guide.update(dt)
        self.boss.update(dt)
        if self.boss_wait > 0:                                   # 사장: 걷다가 가끔 멈춰 서서 둘러본다
            self.boss_wait -= dt
        else:
            self.boss_x += self.boss_dir * 70 * dt
            if not 70 <= self.boss_x <= 570 or self.rng.random() < dt * 0.25:
                self.boss_x = max(70.0, min(570.0, self.boss_x))
                self.boss_dir = -self.boss_dir if not 70 < self.boss_x < 570 or self.rng.random() < 0.5 else self.boss_dir
                self.boss_wait = 0.8 + self.rng.random() * 1.6
        for ch in self.crew:
            ch.update(dt)
        if self.life:                                            # 사건이 떠 있으면 시계도 라인도 멈춘다
            self.life["t"] += dt
            for b in self.life_btns + [self.life_ok]:
                b.update(dt)
            return
        if self.cg_wait and self.app.fade_next is None and self.app.scene is self:
            self.show_cg(*self.cg_wait.pop(0))
            return
        if self.phase in (PRICE, DOCS) and not self.tutorial:
            self.deadline -= dt
            if self.life_hook == "bid" and self.deadline_total - self.deadline > 7:     # 값과 서류를 챙기는 도중에
                self._life_pop()
                if self.life:
                    self.drag = None
            if self.deadline <= 0:                               # 마감을 넘겼다 → 접수 불가 (R03)
                self.deadline = 0.0
                self.submit_docs(late=True)
        elif self.phase == PRODUCE:
            self._update_production(dt)
        if self.phase == DOCS:                                   # 서류 정리 기술 · 정리되는 서류의 움직임
            if self.tidy_at is not None:
                self.tidy_at -= dt
                if self.tidy_at <= 0:
                    self.tidy_at = None
                    self.tidy_docs()
                    who = self.perks["tidy"][2]
                    self.toast = (f"{who['nick']}: “{who['say']['tidy']}”", 2.6)
                    sfx.play("paper", 0.6)
            for dc in self.docs:
                if dc.get("tx") is not None:
                    k = min(1.0, dt * 10)
                    dc["x"] += (dc["tx"] - dc["x"]) * k
                    dc["y"] += (dc["ty"] - dc["y"]) * k

    def _update_production(self, dt):
        self.clock += dt
        now = self.clock
        if self.judge:
            self.judge = (self.judge[0], self.judge[1], self.judge[2] - dt) if self.judge[2] > dt else None
        for box in self.seq:
            st = box["state"]
            if st == "wait":
                if now >= box["hit"] - self.lead:
                    box["state"], box["t"] = "live", 0.0
            elif st == "live":
                box["t"] += dt
                if now > box["hit"] + self.window:                # 누르지 않고 지나갔다
                    box["t"] = 0.0
                    if box["bad"]:
                        box["state"], box["judge"] = "pass", "걸러냄"
                        self.pulled += 1
                        self.combo += 1
                        self.max_combo = max(self.max_combo, self.combo)
                    else:
                        box["state"], box["judge"] = "miss", "놓침"
                        self.missed += 1
                        self.combo = 0
            elif st != "gone":
                box["t"] += dt
                if box["t"] > 0.55:
                    box["state"] = "gone"
        if self.life_hook == "produce" and now >= self.length * 0.5:     # 생산이 한창일 때 생활 이슈가 끼어든다
            self._life_pop()
            if self.life:
                bgm.pause(True)
        if now >= self.length:
            self._finish_production(late=self.shipped + self.leaked < self.target)

    # ================================================================ 그리기: 공장
    def _background(self):
        self._bg, self._plain = background()
        return self._bg

    def _tut_text(self):
        tut, ph = self.cfg["tutorial"], self.phase
        if ph == WINDOW:
            return tut["window_ng" if self.violation else "window_ok"]
        if ph == OPEN:
            return tut["open_ok" if self.today["won"] else "open_ng"] if self.phase_t > 1.6 else ""
        return tut.get(ph, "")

    def _draw_tutorial(self, surf):
        """나르미의 안내 말풍선 + 오래 걸리면 정답 쪽을 반짝여 준다."""
        ph = self.phase
        pulse = 3 + int(abs(math.sin(self.t * 5)) * 3)
        if ph == BOARD and self.phase_t > 8:
            pygame.draw.rect(surf, ORANGE, self._notice_rect(0).inflate(8, 8), pulse, border_radius=18)
        elif ph == PRICE and self.phase_t > 8:
            sl = self._slider()
            k0 = (self.floor - self.p_min) / (self.p_max - self.p_min)
            k1 = (self.pick["est"] - self.p_min) / (self.p_max - self.p_min)
            pygame.draw.rect(surf, ORANGE, (sl.x + int(sl.w * k0) - 4, sl.y - 8, int(sl.w * (k1 - k0)) + 8, sl.h + 16), pulse,
                             border_radius=10)
        elif ph == DOCS and self.phase_t > 12:
            for row, (fid, _, opts, ok) in enumerate(self.fields):
                if self.answers[fid] not in ok:
                    pygame.draw.rect(surf, ORANGE, self._field_opts(row, len(opts))[max(ok)].inflate(8, 8), pulse, border_radius=14)
            for i, dc in enumerate(self.docs):                       # 넣어야 하는데 아직 안 넣은 서류
                if dc["ok"] and not dc["picked"] and self.doc_required(dc["rule"]):
                    pygame.draw.rect(surf, ORANGE, self._doc_rect(i).inflate(14, 14), pulse, border_radius=12)
        text = self._tut_text()
        if not text:
            return
        r = pygame.Rect(440, 150, 400, 96) if ph == PRODUCE else pygame.Rect(16, HEIGHT - 142, 606, 126)
        card(surf, r, 18)
        clip = surf.get_clip()
        surf.set_clip(pygame.Rect(r.x + 6, r.y + 6, 96, r.h - 12))
        self.guide.draw(surf, (r.x + 54, r.y + 12), scale=0.36)
        surf.set_clip(clip)
        chip(surf, (r.x + 108, r.y + 12, 84, 24), "튜토리얼", ORANGE, size=12)
        ui.draw_text(surf, "AI 도우미 나르미", (r.x + 200, r.y + 17), 12, SOFT, True)
        ui.draw_wrapped(surf, text, (r.x + 108, r.y + 44, r.w - 124, r.h - 50), 15, INK, True)


    def _draw_factory(self, surf, dx=0):
        """작업장: 컨베이어가 돌고, 뽑은 직원들이 자리를 지키고, 사장이 왔다 갔다 한다. (오른쪽은 서류판이 덮는다)"""
        surf.blit(workshop_background(), (0, 0))
        t = self.t
        xs = [int((k * 236 + t * 46) % 1420) - 70 for k in range(6)]
        fcg.conveyor(surf, 396, xs)
        m = pygame.Rect(292, 286, 150, 112)                           # 포장기
        props.box(surf, m, TEAL, radius=12, shade=shade(TEAL, 0.72), offset=(5, 6))
        pygame.draw.rect(surf, (214, 238, 244), (m.x + 18, m.y + 18, 114, 40), border_radius=8)
        pygame.draw.rect(surf, C.INK, (m.x + 18, m.y + 18, 114, 40), 3, border_radius=8)
        on = math.sin(t * 6) > 0
        pygame.draw.circle(surf, (255, 226, 110) if on else (120, 150, 160), (m.centerx, m.y - 12), 11)
        pygame.draw.circle(surf, C.INK, (m.centerx, m.y - 12), 11, 3)
        ui.draw_text(surf, "포장", (m.centerx, m.y + 82), 17, PAPER, "heavy", center=True)
        ids = tuple(p["id"] for p in self.staff)
        if ids != self.crew_ids:                                      # 직원이 바뀌면 그림도 새로
            self.crew_ids = ids
            self.crew = [Character(p["look"]) for p in self.staff]
            for ch, pose in zip(self.crew, ("point", "clap", "hi")):
                ch.expression = "happy"
                ch.set_pose(pose)
        spots = (150, 356, 540)
        for i, x in enumerate(spots):
            if i < len(self.crew):
                sh = pygame.Surface((90, 20), pygame.SRCALPHA)
                pygame.draw.ellipse(sh, (60, 35, 20, 70), sh.get_rect())
                surf.blit(sh, sh.get_rect(center=(x, 566)))
                self.crew[i].draw(surf, (x, 562 - C.FOOT * 0.5), scale=0.5, full=True)
                nick = self.staff[i]["nick"]
                w = ui.fonts.get(12, True).size(nick)[0] + 20
                ui.pill(surf, (x - w // 2, 574, w, 22), nick, PAPER, INK, 12)
            elif not self.tutorial and i == len(self.crew):          # 빈자리: 직원 모집 팻말
                post = pygame.Rect(x - 46, 470, 92, 62)
                pygame.draw.line(surf, C.INK, (x, 532), (x, 566), 6)
                props.box(surf, post, (255, 253, 247), radius=6, offset=(3, 4))
                ui.draw_text(surf, "직원", (x, post.y + 20), 15, INK, "heavy", center=True)
                ui.draw_text(surf, "모집 중", (x, post.y + 42), 13, (226, 76, 76), True, center=True)
        walking = self.boss_wait <= 0 and self.phase != END
        step = int(t * 7) % 4
        self.boss.legs = ((-12, 12), (0, 0), (12, -12), (0, 0))[step] if walking else (0, 0)
        if self.phase != END:
            hurry = self.phase in (PRICE, DOCS) and not self.tutorial and self.deadline < 20
            self.boss.expression = "nervous" if hurry else "happy" if self.phase in (RESULT, OPEN) and self.today["won"] else "neutral"
            self.boss.set_pose("shock" if hurry else "idle" if walking else "hip")
            sh = pygame.Surface((110, 24), pygame.SRCALPHA)
            pygame.draw.ellipse(sh, (60, 35, 20, 70), sh.get_rect())
            surf.blit(sh, sh.get_rect(center=(self.boss_x, 676)))
            self.boss.draw(surf, (self.boss_x, 672 - C.FOOT * 0.62), scale=0.62, flip=self.boss_dir < 0, full=True)

    def _draw_stage(self, surf):
        """출하 검수장 — 박자에 맞춰 상자가 작업대 여기저기서 튀어나온다."""
        surf.blit(stage_background(), (0, 0))
        v = self.view
        v.ox = ORIGIN[0]
        now = self.clock
        phase = (now / self.spb) % 1.0
        pulse = max(0.0, 1 - phase * 3)                              # 박마다 번쩍
        beat_i = int(now / self.spb)
        for i in range(4):                                           # 뒷벽의 박자 등 네 개
            x, y = v.pt(2.2 + i * 2.2, 0, 2.1)
            on = beat_i % 4 == i
            r = 15 + (6 * pulse if on else 0)
            pygame.draw.circle(surf, (255, 226, 110) if on else (84, 104, 138), (int(x), int(y)), int(r))
            pygame.draw.circle(surf, (40, 52, 72), (int(x), int(y)), int(r), 3)
        for k in range(min(self.shipped, 18)):                       # 출하 팔레트에 쌓이는 상자
            v.cube(surf, 10.05 + (k % 2) * 0.42, 1.7 + (k // 2 % 5) * 0.42, 0.38, 0.38, 0.3, BOXCOL, 0.12 + (k // 10) * 0.3)
        if not self.app.device["touch"]:                         # 자판이 있는 기기: 작업대마다 단축키를 작게 적어 둔다
            live = {b["spot"] for b in self.seq if b["state"] == "live"}
            for i, (gx, gy) in enumerate(SPOTS):
                x, y = v.pt(gx + PAD / 2, gy + PAD + 0.05, 0.16)
                on = i in live
                r = pygame.Rect(0, 0, 22, 20)
                r.center = (int(x), int(y) - 2)
                pygame.draw.rect(surf, (255, 226, 110) if on else (52, 66, 90), r, border_radius=6)
                ui.draw_text(surf, SPOT_KEYS[i], r.center, 12, (40, 52, 72) if on else (150, 166, 190), "heavy", center=True)
        marks = self.tutorial or self.day_i < self.level["mark_days"]
        for box in sorted(self.seq, key=lambda b: (SPOTS[b["spot"]][1], SPOTS[b["spot"]][0])):
            st = box["state"]
            if st in ("wait", "gone"):
                continue
            gx, gy = SPOTS[box["spot"]]
            cx, cy = gx + PAD / 2, gy + PAD / 2
            t = box["t"]
            if st == "live":
                k = min(1.0, t / 0.16)                               # 쑥 올라온다
                left = (box["hit"] - now) / self.lead                # 1 → 0 : 고리가 줄어든다
                ring = PAD / 2 * (1 + 1.5 * max(0.0, left))
                near = abs(now - box["hit"]) <= self.window
                col = PAPER if near else (150, 220, 240)
                pts = [v.pt(cx - ring, cy - ring, 0.16), v.pt(cx + ring, cy - ring, 0.16), v.pt(cx + ring, cy + ring, 0.16),
                       v.pt(cx - ring, cy + ring, 0.16)]
                pygame.draw.lines(surf, col, True, pts, 6 if near else 3)
                self._draw_box(surf, cx, cy, 0.14, 0.86 * k, box["bad"], marks)
            elif st == "hit":                                        # 출하: 위로 날아간다
                self._draw_box(surf, cx, cy, 0.14 + t * 7, 0.86 * max(0.2, 1 - t * 1.4), False, False)
            elif st in ("oops", "saved"):
                self._draw_box(surf, cx, cy, 0.14, 0.86, True, False)
                if st == "oops":
                    x, y = v.pt(cx, cy, 0.9)
                    pygame.draw.line(surf, RED, (x - 22, y - 22), (x + 22, y + 22), 8)
                    pygame.draw.line(surf, RED, (x + 22, y - 22), (x - 22, y + 22), 8)
            else:                                                    # pass / miss: 가라앉는다
                self._draw_box(surf, cx, cy, 0.14, 0.86 * max(0.05, 1 - t * 2.2), box["bad"], False)
            if box["judge"] and st != "live":
                x, y = v.pt(cx, cy, 1.2)
                col = {"hit": ORANGE if box["judge"] == "딱!" else GREEN if box["judge"] == "좋아요" else PAPER,
                       "oops": RED, "saved": YELLOW, "pass": (150, 230, 170), "miss": (190, 200, 214)}[st]
                ui.draw_text(surf, box["judge"], (x + 1, y - t * 46 + 2), 19, (30, 40, 56), "heavy", center=True)
                ui.draw_text(surf, box["judge"], (x, y - t * 46), 19, col, "heavy", center=True)

    def _draw_box(self, surf, cx, cy, z, size, bad, mark):
        v = self.view
        col = (168, 128, 88) if bad else BOXCOL
        h = size * 0.7
        v.cube(surf, cx - size / 2, cy - size / 2, size, size, h, col, z)
        x, y = v.pt(cx, cy, z + h)
        k = size / 0.86
        if bad:                                                      # 찌그러진 상자: 윗면이 터져 있다
            pygame.draw.line(surf, (84, 56, 36), (x - 18 * k, y - 6 * k), (x + 16 * k, y + 7 * k), max(2, int(5 * k)))
            pygame.draw.line(surf, (84, 56, 36), (x + 4 * k, y - 11 * k), (x - 8 * k, y + 9 * k), max(2, int(4 * k)))
            if mark:
                by = y - 40 + math.sin(self.t * 8) * 3
                pygame.draw.circle(surf, RED, (int(x), int(by)), 13)
                ui.draw_text(surf, "!", (x, by - 1), 17, PAPER, "heavy", center=True)
        else:                                                        # 멀쩡한 상자: 반듯한 테이프
            pygame.draw.line(surf, (244, 232, 200), (x - 22 * k, y + 1), (x + 22 * k, y - 1), max(2, int(6 * k)))

    # ================================================================ 그리기: 화면 부품
    def _hud(self, surf):
        card(surf, (24, 20, 400, 62), 16)
        ui.draw_text(surf, "납품하GO! 우리 공장", (42, 30), 13, ORANGE, True)
        ui.draw_text(surf, ("튜토리얼" if self.tutorial else f"{self.day}일차") + f" · {self.co['name']}", (42, 48), 17, INK, "heavy")
        chip(surf, (300, 28, 108, 22), self.level["name"], tuple(self.level["color"]), size=11)
        card(surf, (440, 20, 190, 62), 16)
        ui.draw_text(surf, "통장", (456, 30), 12, SOFT, True)
        ui.draw_text(surf, ui.won(self.money), (456, 46), 18, RED if self.money < 0 else INK, "heavy")
        card(surf, (646, 20, 190, 62), 16)
        ui.draw_text(surf, f"신뢰도 {self.trust}", (662, 30), 12, SOFT, True)
        iso.bar(surf, (662, 54, 158, 12), self.trust / 100, GREEN if self.trust >= 40 else RED)
        if self.staff and self.phase != PRODUCE:                 # 함께 일하는 직원
            w = 26 + len(self.staff) * 96
            card(surf, (852, 20, w, 62), 16)
            for i, m in enumerate(self.staff):
                x = 866 + i * 96
                pygame.draw.circle(surf, pygame.Color(m["look"]["body"]), (x + 14, 51), 14)
                pygame.draw.circle(surf, INK, (x + 14, 51), 14, 2)
                ui.draw_text(surf, m["nick"], (x + 34, 34), 13, INK, True)
                ui.draw_text(surf, staffmod.SKILLS[m["skills"][0]["type"]]["name"], (x + 34, 52), 10, SOFT, True)

    def _panel(self, surf, title, tag=None, tag_color=TEAL):
        card(surf, PANEL, 22)
        x, y = PANEL.x + 28, PANEL.y + 22
        if tag:
            w = ui.fonts.get(13, True).size(tag)[0] + 24
            chip(surf, (x, y, w, 26), tag, tag_color)
            y += 36
        ui.draw_text(surf, title, (x, y), 27, INK, "heavy")
        return y + 46

    def _deadline_bar(self, surf):
        r = pygame.Rect(PANEL.right - 236, PANEL.y + 24, 208, 40)
        hot = self.deadline < 20
        pygame.draw.rect(surf, (255, 232, 226) if hot else (236, 244, 246), r, border_radius=12)
        ui.draw_text(surf, "입찰 마감까지", (r.x + 12, r.y + 5), 11, RED if hot else SOFT, True)
        ui.draw_text(surf, "연습: 제한 없음" if self.tutorial else f"{int(self.deadline)}초", (r.right - 12, r.y + 3), 15,
                     RED if hot else INK, "heavy", anchor="topright")
        iso.bar(surf, (r.x + 12, r.y + 26, r.w - 24, 8), self.deadline / self.deadline_total, RED if hot else TEAL, (214, 226, 230))

    def _notice_line(self, surf, y):
        n = self.pick
        box = pygame.Rect(PANEL.x + 24, y, PANEL.w - 48, 56)
        pygame.draw.rect(surf, (240, 247, 248), box, border_radius=12)
        ui.draw_text(surf, f"{n['agency']} · {n['item']} {n['qty']:,}{n['unit']}", (box.x + 16, box.y + 8), 17, INK, "heavy")
        ui.draw_text(surf, f"공고 {n['no']}   예정가격 {ui.won(n['est'])}", (box.x + 16, box.y + 32), 13, SOFT, True)
        return box.bottom + 14

    def _draw_event(self, surf):
        ev = self.event
        y = self._panel(surf, "수상한 제안", f"{ev['who']} 사장", (150, 140, 150))
        y = ui.draw_wrapped(surf, ev["text"], (PANEL.x + 30, y + 6, PANEL.w - 60, 200), 19, INK)
        if self.event_result is None:
            ui.draw_text(surf, "어떻게 할까요?", (PANEL.x + 30, PANEL.y + 296), 14, SOFT, True)
            for b in self.opt_btns:
                b.draw(surf)
        else:
            box = pygame.Rect(PANEL.x + 24, y + 20, PANEL.w - 48, 150)
            pygame.draw.rect(surf, (255, 236, 230) if self.bad else (232, 246, 236), box, border_radius=14)
            ui.draw_wrapped(surf, self.event_result, (box.x + 18, box.y + 16, box.w - 36, 100), 17, INK, True)
            ui.draw_text(surf, "입찰참가자격 제한!" if self.bad else f"신뢰도 +{ev['refuse']['trust']}",
                         (box.x + 18, box.bottom - 34), 16, RED if self.bad else GREEN, "heavy")
            self.next_btn.draw(surf)

    def _draw_board(self, surf):
        y = self._panel(surf, "오늘의 입찰 공고", "나라장터")
        case = self.case
        ui.draw_wrapped(surf, f"{case['agency']} {case['officer']['name']} {case['officer']['role']}: “{case['need']}”",
                        (PANEL.x + 28, y - 4, PANEL.w - 56, 44), 14, SOFT, True)
        mouse = pygame.mouse.get_pos()
        for i, n in enumerate(self.notices):
            r = self._notice_rect(i)
            hot = n["can"] and r.collidepoint(mouse)
            pygame.draw.rect(surf, (236, 247, 250) if hot else (246, 249, 250) if n["can"] else (240, 240, 240), r, border_radius=14)
            pygame.draw.rect(surf, TEAL if hot else (220, 230, 234), r, 3 if hot else 2, border_radius=14)
            ink = INK if n["can"] else (160, 166, 170)
            x = r.x + 18
            if n["shared"]:
                x = chip(surf, (x, r.y + 14, 108, 24), "오늘의 공통 공고", ORANGE, size=12).right + 8
            if n["sme"]:
                chip(surf, (x, r.y + 14, 132, 24), "중소기업자간 경쟁제품", BLUE if n["can"] else (170, 176, 180), size=12)
            ui.draw_text(surf, f"{n['agency']}  ·  {n['item']} {n['qty']:,}{n['unit']}", (r.x + 18, r.y + 44), 20, ink, "heavy")
            ui.draw_text(surf, f"공고 {n['no']}", (r.x + 18, r.y + 74), 13, SOFT, True)
            ui.draw_text(surf, f"예정가격 {ui.won(n['est'])}", (r.x + 18, r.y + 96), 16, ink, True)
            if n["can"]:
                chip(surf, (r.right - 112, r.bottom - 46, 94, 32), "응찰하기", TEAL, size=14)
            else:
                ui.draw_text(surf, "우리 공장이 직접 만들지 못하는 품목", (r.right - 16, r.bottom - 32), 13, (170, 120, 110), True,
                             anchor="topright")
        ui.draw_text(surf, f"우리 공장이 만드는 것: {' · '.join(self.co['can_make'])}", (PANEL.x + 28, PANEL.bottom - 32), 13, SOFT, True)

    def _draw_price(self, surf):
        n = self.pick
        y = self._panel(surf, "얼마에 써낼까?", "투찰가 정하기")
        self._deadline_bar(surf)
        y = self._notice_line(surf, y)
        parts = (("재료비", 0.62), ("인건비", 0.26), ("운송·기타", 0.12))
        for i, (name, k) in enumerate(parts):
            ui.draw_text(surf, name, (PANEL.x + 40, y + i * 26), 15, SOFT, True)
            ui.draw_text(surf, ui.won(_man(n["cost"] * k)), (PANEL.x + 300, y + i * 26), 15, INK, True, anchor="topright")
        ui.draw_text(surf, "원가 합계" + ("  (살림꾼이 아낌)" if "cost0" in n else ""), (PANEL.x + 340, y + 4), 13,
                     GREEN if "cost0" in n else SOFT, True)
        ui.draw_text(surf, ui.won(n["cost"]), (PANEL.x + 340, y + 24), 24, INK, "heavy")
        sl = self._slider()
        span = self.p_max - self.p_min

        def px(v):
            return sl.x + int(sl.w * (v - self.p_min) / span)
        pygame.draw.rect(surf, (226, 234, 238), sl, border_radius=8)
        ok = pygame.Rect(px(self.floor), sl.y, px(n["est"]) - px(self.floor), sl.h)
        pygame.draw.rect(surf, (190, 232, 204), ok)
        for v, name, col in ((self.floor, "낙찰 하한선", TEAL), (n["est"], "예정가격", RED)):
            pygame.draw.line(surf, col, (px(v), sl.y - 22), (px(v), sl.bottom + 6), 3)
            ui.draw_text(surf, name, (px(v), sl.y - 40), 12, col, True, anchor="midtop")
        pygame.draw.line(surf, (150, 120, 90), (px(n["cost"]), sl.y - 8), (px(n["cost"]), sl.bottom + 8), 3)
        ui.draw_text(surf, "원가", (px(n["cost"]), sl.bottom + 10), 12, (150, 120, 90), True, anchor="midtop")
        for nm, v in self.intel:                                 # 영업 담당이 알아 온 경쟁 업체 값
            if self.p_min <= v <= self.p_max:
                pygame.draw.polygon(surf, BLUE, [(px(v), sl.y - 4), (px(v) - 7, sl.y - 16), (px(v) + 7, sl.y - 16)])
        if self.intel:
            who = self.perks["sales"][2]["nick"]
            ui.draw_text(surf, f"▼ {who}의 정보: " + ", ".join(f"{nm} {ui.won(v)}" for nm, v in self.intel[:2])
                         + (" …" if len(self.intel) > 2 else ""), (PANEL.x + 40, sl.y - 66), 12, BLUE, True)
        kx = px(self.price)
        pygame.draw.circle(surf, shade(ORANGE, 0.7), (kx, sl.centery + 3), 17)
        pygame.draw.circle(surf, ORANGE, (kx, sl.centery), 17)
        pygame.draw.circle(surf, PAPER, (kx, sl.centery), 7)
        y2 = sl.bottom + 44
        ui.draw_text(surf, "내 투찰가", (PANEL.x + 40, y2), 14, SOFT, True)
        ui.draw_text(surf, ui.won(self.price), (PANEL.x + 40, y2 + 20), 32, INK, "heavy")
        profit = self.price - n["cost"]
        ui.draw_text(surf, "낙찰되면 남는 돈", (PANEL.x + 340, y2), 14, SOFT, True)
        ui.draw_text(surf, ("+" if profit >= 0 else "") + ui.won(profit), (PANEL.x + 340, y2 + 22), 26, GREEN if profit >= 0 else RED, "heavy")
        if self.price > n["est"]:
            msg, col = "예정가격을 넘으면 접수조차 안 돼요!", RED
        elif self.price < self.floor:
            msg, col = "낙찰 하한선보다 낮으면 탈락이에요.", RED
        elif profit < 0:
            msg, col = "원가보다 낮아요. 따내도 손해!", RED
        else:
            msg, col = "하한선과 예정가격 사이에서 가장 낮게 쓴 업체가 낙찰돼요.", SOFT
        ui.draw_text(surf, msg, (PANEL.x + 40, y2 + 70), 14, col, True)
        ui.draw_text(surf, "막대를 끌거나 ← → 키로 조절", (PANEL.x + 28, PANEL.bottom - 52), 12, SOFT, True)
        self.next_btn.label = "이 가격으로 투찰"
        self.next_btn.draw(surf)

    def _paper_img(self, dc):
        """서류 한 장 (살짝 돌아간 종이). 한 번 그려 두고 쓴다."""
        key = (dc["mark"],)
        if dc.get("img") is None or dc.get("img_key") != key:
            img = papers.render(dc)                                  # 종류마다 다른 생김새 (game/factory/papers.py)
            dc["img"] = pygame.transform.rotozoom(img, dc["rot"], 1.0) if dc["rot"] else img
            dc["img_key"] = key
        return dc["img"]

    def _draw_docs(self, surf):
        """서류 꾸리기: 왼쪽 입찰서를 채우고, 책상에 흩어진 서류 중 넣을 것만 오른쪽 봉투로 끌어다 넣는다."""
        props.draw_desk(surf, 0)
        co, n = self.co, self.pick
        rules = self.app.data.rules_by_id
        # ---- 왼쪽: 입찰서
        card(surf, FORM, 18)
        ui.draw_text(surf, "입찰서", (FORM.x + 18, FORM.y + 14), 22, INK, "heavy")
        ui.draw_text(surf, f"투찰가 {ui.won(self.price)}", (FORM.right - 18, FORM.y + 20), 13, TEAL, True, anchor="topright")
        ref = pygame.Rect(FORM.x + 14, FORM.y + 52, FORM.w - 28, 84)
        pygame.draw.rect(surf, (236, 247, 240), ref, border_radius=10)
        pygame.draw.rect(surf, GREEN, ref, 2, border_radius=10)
        ui.draw_text(surf, "사업자등록증 (이것과 똑같이!)", (ref.x + 12, ref.y + 8), 12, shade(GREEN, 0.7), True)
        ui.draw_text(surf, co["name"], (ref.x + 12, ref.y + 28), 17, INK, "heavy")
        ui.draw_text(surf, co["biz_no"], (ref.x + 12, ref.y + 54), 17, INK, "heavy")
        for row, (fid, name, opts, _) in enumerate(self.fields):
            rects = self._field_opts(row, len(opts))
            ui.draw_text(surf, name, (FORM.x + 18, rects[0].y - 24), 15, INK, "heavy")
            for k, r in enumerate(rects):
                on = self.answers[fid] == k
                pygame.draw.rect(surf, TEAL if on else (240, 246, 248), r, border_radius=10)
                pygame.draw.rect(surf, shade(TEAL, 0.8) if on else (214, 226, 230), r, 2, border_radius=10)
                ui.draw_text(surf, opts[k], r.center, 15, PAPER if on else INK, True, center=True)
        if not self.fields:
            ui.draw_wrapped(surf, "오늘은 적어 넣을 칸이 없어요. 서류만 챙기면 돼요.", (FORM.x + 18, FORM.y + 156, FORM.w - 36, 60), 14, SOFT, True)
        # ---- 가운데: 안내
        chip(surf, (DESK_AREA.x + 4, 100, 330, 34), "넣을 서류만 봉투로 끌어다 넣으세요", INK, size=15)
        hint = "보증금은 투찰가의 5% 이상" if "R05" in self.active else "같은 이름이라도 아래 글씨를 읽어요"
        if "R07" in self.active:
            hint += " · 이번 공고: " + ("중소기업자간 경쟁제품" if n["sme"] else "일반 경쟁")
        memo = pygame.Rect(FORM.x, FORM.bottom + 14, FORM.w, 132)             # 입찰서 아래의 메모지
        props.box(surf, memo, (255, 238, 150), radius=6, offset=(4, 5))
        ui.draw_text(surf, "오늘 챙길 것", (memo.x + 14, memo.y + 10), 14, C.INK, "heavy")
        yy = memo.y + 36
        for line in hint.split(" · "):
            yy = ui.draw_wrapped(surf, "· " + line, (memo.x + 14, yy, memo.w - 28, 60), 13, C.INK, True) + 2
        # ---- 오른쪽: 마감 시계 · 봉투 · 봉투 안 서류 · 제출
        self._deadline_bar(surf)
        drag_dc = self.docs[self.drag[0]] if self.drag else None
        over = bool(drag_dc) and ENVELOPE.inflate(50, 60).collidepoint(drag_dc["x"], drag_dc["y"])
        env = ENVELOPE.inflate(10, 10) if over else ENVELOPE
        props.box(surf, env, (240, 206, 140) if not over else (255, 226, 150), radius=10, shade=(214, 176, 110), offset=(6, 7))
        pygame.draw.lines(surf, C.INK, False, [(env.x + 4, env.y + 6), (env.centerx, env.y + env.h * 0.52), (env.right - 4, env.y + 6)], 4)
        ui.draw_text(surf, "입찰 봉투", (env.centerx, env.bottom - 52), 22, C.INK, "heavy", center=True)
        ui.draw_text(surf, "여기에 끌어다 놓기", (env.centerx, env.bottom - 24), 13, (120, 86, 60), True, center=True)
        inside = [i for i in self.doc_order if self.docs[i]["picked"]]
        ui.draw_text(surf, f"봉투 안 {len(inside)}장  (누르면 도로 꺼내요)", (ENVELOPE.x + 2, ENVELOPE.bottom + 12), 12, (120, 86, 60), True)
        for k, i in enumerate(inside):
            dc, r = self.docs[i], self._env_chip(k)
            pygame.draw.rect(surf, (255, 253, 247), r, border_radius=8)
            pygame.draw.rect(surf, C.INK, r, 2, border_radius=8)
            text = f"{dc['name']} · {dc['sub']}"
            while ui.fonts.get(11, True).size(text)[0] > r.w - 16:
                text = text[:-2] + "…"
            ui.draw_text(surf, text, (r.x + 8, r.centery), 11, INK, True, anchor="midleft")
        self.next_btn.rect = pygame.Rect(ENVELOPE.x, HEIGHT - 82, ENVELOPE.w, 56)
        self.next_btn.label = "창구에 제출"
        self.next_btn.enabled = self.docs_ready()
        self.next_btn.draw(surf)
        self.next_btn.enabled = True
        if not self.docs_ready():
            ui.draw_text(surf, "입찰서의 빈칸부터 골라요", (self.next_btn.rect.centerx, self.next_btn.rect.y - 16), 12, RED, True, center=True)
        # ---- 책상 위의 서류 (겹친 순서대로, 끌고 있는 서류가 맨 위)
        for i in self.doc_order:
            dc = self.docs[i]
            if dc["picked"]:
                continue
            img = self._paper_img(dc)
            held = self.drag is not None and self.drag[0] == i
            pos = img.get_rect(center=(int(dc["x"]), int(dc["y"]) - (6 if held else 0)))
            surf.blit(props.silhouette_shadow(img, 70), pos.move(4 + (5 if held else 0), 5 + (8 if held else 0)))
            surf.blit(img, pos)

    def _draw_window(self, surf):
        ok = not self.violation
        y = self._panel(surf, "접수 완료!" if ok else "반려되었습니다", "조달청 계약심사과 창구", GREEN if ok else RED)
        clip = surf.get_clip()
        area = pygame.Rect(PANEL.x + 24, y, 190, 190)
        pygame.draw.rect(surf, (255, 240, 214), area, border_radius=16)
        surf.set_clip(area)
        self.clerk.draw(surf, (area.centerx, area.y + 22), scale=0.62)
        surf.set_clip(clip)
        ui.draw_text(surf, "조달청 심사관", (area.x, area.bottom + 8), 11, SOFT, True)
        tx = area.right + 20
        tw = PANEL.right - 28 - tx
        if ok:
            line = "“서류 이상 없습니다. 꼼꼼하게 챙겨 오셨네요! 개찰 결과는 곧 나옵니다.”"
            if getattr(self, "junk", 0):
                line = f"“필요한 서류는 다 있네요. 그런데… 입찰과 상관없는 종이 {self.junk}장은 도로 가져가세요.”"
            yy = ui.draw_wrapped(surf, line, (tx, y + 10, tw, 120), 18, INK, True)
            if getattr(self, "junk", 0) and not self.tutorial:
                ui.draw_text(surf, f"신뢰도 -{min(3, self.junk)}", (tx, yy + 8), 14, RED, True)
        else:
            r = self.app.data.rules_by_id[self.violation]
            chip(surf, (tx, y + 4, 60, 26), "반려", RED)
            ui.draw_text(surf, r["short"], (tx + 70, y + 5), 18, RED, "heavy")
            yy = ui.draw_wrapped(surf, r["text"], (tx, y + 42, tw, 60), 15, INK, True)
            ui.draw_wrapped(surf, r["explain"], (tx, yy + 8, tw, 90), 14, SOFT, True)
            if self.alt_btn.enabled:
                self.alt_btn.draw(surf)
        self.next_btn.draw(surf)

    def _draw_open(self, surf):
        n = self.pick
        y = self._panel(surf, "개찰 결과", "투찰함을 엽니다")
        y = self._notice_line(surf, y)
        x0, w = PANEL.x + 200, PANEL.w - 250
        lo, hi = self.p_min * 0.98, n["est"] * 1.04

        def px(v):
            return x0 + int(w * (v - lo) / (hi - lo))
        shown = min(len(self.bid_rows), int(self.phase_t / 0.35))
        for i, (name, price, mine) in enumerate(self.bid_rows):
            ry = y + 24 + i * 58
            ui.draw_text(surf, name, (PANEL.x + 28, ry + 4), 14, ORANGE if mine else INK, True)
            if i < shown:
                valid = self.floor <= price <= n["est"]
                win = self.winner and (name, price, mine) == self.winner and self.phase_t > 1.6
                col = (ORANGE if mine else TEAL) if valid else (190, 196, 200)
                pygame.draw.rect(surf, col, (x0, ry, max(8, px(price) - x0), 26), border_radius=8)
                ui.draw_text(surf, ui.won(price), (PANEL.x + 28, ry + 24), 13, SOFT, True)
                if not valid:
                    ui.draw_text(surf, "하한선 미달" if price < self.floor else "예정가격 초과", (px(price) + 8, ry + 4), 12, RED, True)
                elif win:
                    chip(surf, (px(price) + 8, ry, 54, 26), "낙찰", RED)
        for v, name, col in ((self.floor, "하한선", TEAL), (n["est"], "예정가격", RED)):
            pygame.draw.line(surf, col, (px(v), y + 14), (px(v), y + 250), 2)
            ui.draw_text(surf, name, (px(v), y - 2), 11, col, True, anchor="midtop")
        if self.phase_t > 1.6:
            won = self.today["won"]
            msg = "낙찰! 이제 납기 안에 만들어 내야 해요." if won else (
                "이번엔 놓쳤어요. 일반 거래처 주문으로 오늘을 채웁니다." if self.winner else "유효한 입찰이 없어 유찰됐어요.")
            ui.draw_text(surf, msg, (PANEL.x + 28, y + 276), 18, GREEN if won else INK, "heavy")
            ui.draw_text(surf, "※ 실제 낙찰 방식은 더 복잡해요. 게임에서는 단순하게 줄였습니다.", (PANEL.x + 28, y + 308), 12, SOFT, True)
            self.next_btn.draw(surf)

    def _draw_produce_ui(self, surf):
        n = self.pick
        card(surf, (WIDTH - 330, 20, 306, 124), 18)
        ui.draw_text(surf, f"{n['agency']} 납품", (WIDTH - 312, 30), 13, ORANGE, True)
        ui.draw_text(surf, f"{n['item']}", (WIDTH - 312, 48), 18, INK, "heavy")
        done = self.shipped + self.leaked
        ui.draw_text(surf, f"출하 {done} / {self.target}", (WIDTH - 312, 80), 14, GREEN if done >= self.target else INK, True)
        ui.draw_text(surf, f"{self.bpm} BPM", (WIDTH - 42, 80), 13, SOFT, True, anchor="topright")
        iso.bar(surf, (WIDTH - 312, 102, 270, 12), done / self.target, GREEN if done >= self.target else TEAL)
        iso.bar(surf, (WIDTH - 312, 120, 270, 8), self.clock / self.length, ORANGE)       # 곡이 얼마나 지났는가
        card(surf, (16, HEIGHT - 132, 330, 116), 18)
        ui.draw_text(surf, "콤보", (34, HEIGHT - 120), 13, SOFT, True)
        ui.draw_text(surf, str(self.combo), (34, HEIGHT - 104), 40, ORANGE if self.combo >= 5 else INK, "heavy")
        ui.draw_text(surf, f"딱! {self.perfect}   좋아요 {self.good}   놓침 {self.missed}", (120, HEIGHT - 112), 14, INK, True)
        ui.draw_text(surf, f"걸러낸 불량 {self.pulled}" + (f" (직원 {self.auto_pulled})" if self.auto_pulled else ""),
                     (120, HEIGHT - 86), 13, GREEN, True)
        ui.draw_text(surf, f"내보낸 불량 {self.leaked}", (120, HEIGHT - 64), 13, RED if self.leaked else SOFT, True)
        if self.judge:
            ui.draw_text(surf, self.judge[0], (WIDTH // 2 + 2, 124), 44, (30, 40, 56), "heavy", center=True)
            ui.draw_text(surf, self.judge[0], (WIDTH // 2, 122), 44, self.judge[1], "heavy", center=True)
        if self.clock < 4 * self.spb:                                # 준비 박자
            left = 4 - int(self.clock / self.spb)
            ui.draw_text(surf, "준비!" if left > 3 else str(left), (WIDTH // 2, HEIGHT // 2 - 30), 96, PAPER, "heavy", center=True)
        tip = "멀쩡한 상자는 고리가 맞을 때 누르고, 찌그러진 상자는 누르지 마세요!"
        if not self.app.device["touch"]:
            tip += "   (자판: QWER · ASDF · ZXCV)"
        w = ui.fonts.get(14, True).size(tip)[0] + 40
        chip(surf, (max(356, WIDTH // 2 - w // 2), HEIGHT - 52, w, 36), tip, INK, size=14)

    def _draw_result(self, surf):
        t, n = self.today, self.pick
        over = max(0, t["leak"] - self.cfg["produce"]["leak_ok"])
        good = not t["late"] and not over
        y = self._panel(surf, "납품 완료!" if good else "납품은 했지만…", f"{n['agency']} 검수", GREEN if good else ORANGE)
        area = pygame.Rect(PANEL.x + 24, y, 190, 190)
        pygame.draw.rect(surf, (232, 244, 246), area, border_radius=16)
        clip = surf.get_clip()
        surf.set_clip(area)
        self.officer.draw(surf, (area.centerx, area.y + 22), scale=0.62)
        surf.set_clip(clip)
        case = n["shared"]
        who = f"{case['officer']['name']} {case['officer']['role']}" if case else "검수 담당자"
        ui.draw_text(surf, who, (area.x, area.bottom + 8), 12, SOFT, True)
        if good:
            line = case["thanks"] if case else "수량도 품질도 계약서 그대로네요. 수고하셨습니다!"
        elif t["late"]:
            line = "약속한 수량이 모자라네요… 지체상금이 붙습니다."
        else:
            line = f"상자 {t['leak']}개가 찌그러져 있어요. 그만큼 대금에서 깎겠습니다."
        tx = area.right + 20
        ui.draw_wrapped(surf, f"“{line}”", (tx, y + 8, PANEL.right - 28 - tx, 120), 18, INK, True)
        rows = [("박자", f"딱! {t.get('perfect', 0)} · 좋아요 {t.get('good', 0)} · 최고 콤보 {t.get('combo', 0)}", ORANGE),
                ("납기", "물량 부족" if t["late"] else "준수", RED if t["late"] else GREEN),
                ("내보낸 불량", f"{t['leak']}개", RED if over else GREEN),
                ("계약 대금", ui.won(t["paid"]), INK),
                ("감액·지체상금", "-" + ui.won(t["penalty"]) if t["penalty"] else "없음", RED if t["penalty"] else GREEN)]
        for i, (a, b, col) in enumerate(rows):
            ry = y + 240 + i * 34
            ui.draw_text(surf, a, (PANEL.x + 40, ry), 16, SOFT, True)
            ui.draw_text(surf, b, (PANEL.right - 40, ry - 2), 18, col, "heavy", anchor="topright")
        self.next_btn.draw(surf)

    def _draw_ledger(self, surf):
        t = self.today
        y = self._panel(surf, f"{self.day}일차 회사 장부", "오늘의 정산")
        if t["rejected"]:
            note = f"서류 반려({self.app.data.rules_by_id[t['rejected']]['short']})로 입찰에 참여하지 못했어요."
        elif not t["won"]:
            note = "낙찰받지 못한 날. 일반 거래처 주문으로 공장을 돌렸어요."
        else:
            note = f"{t['agency']}에 {t['item']} 납품!"
        ui.draw_wrapped(surf, note, (PANEL.x + 28, y, PANEL.w - 56, 40), 15, TEAL, True)
        rows = []
        if t["paid"]:
            rows.append(("계약 대금", t["paid"]))
        if t["side"]:
            rows.append(("일반 거래처 매출", t["side"]))
        if t["cost"]:
            rows.append(("원가 (재료·인건·운송)", -t["cost"]))
        if t["penalty"]:
            rows.append(("감액·지체상금", -t["penalty"]))
        rows += [(name, -v) for name, v in self.fixed_rows]
        yy = y + 50
        for name, v in rows:
            ui.draw_text(surf, name, (PANEL.x + 40, yy), 16, INK, True)
            ui.draw_text(surf, ("+" if v > 0 else "-") + ui.won(abs(v)), (PANEL.right - 40, yy - 1), 17, GREEN if v > 0 else RED, True,
                         anchor="topright")
            yy += 34
        pygame.draw.line(surf, (220, 230, 234), (PANEL.x + 40, yy + 4), (PANEL.right - 40, yy + 4), 3)
        ui.draw_text(surf, "오늘의 손익", (PANEL.x + 40, yy + 18), 18, INK, "heavy")
        ui.draw_text(surf, ("+" if t["net"] >= 0 else "-") + ui.won(abs(t["net"])), (PANEL.right - 40, yy + 12), 26,
                     GREEN if t["net"] >= 0 else RED, "heavy", anchor="topright")
        ui.draw_text(surf, f"통장  {ui.won(self.money_before)} → {ui.won(self.money)}", (PANEL.right - 40, yy + 54), 14, SOFT, True,
                     anchor="topright")
        self.next_btn.draw(surf)

    def _draw_end(self, surf):
        card(surf, (240, 70, 800, 590), 26)
        g, name = self.grade
        ui.draw_text(surf, f"납품하GO! 우리 공장 · {self.level['name']}", (WIDTH // 2, 100), 16, ORANGE, True, center=True)
        ui.draw_text(surf, "닷새의 결산" if not self.bad else "문 닫은 공장", (WIDTH // 2, 144), 38, INK, "heavy", center=True)
        pygame.draw.circle(surf, RED if self.bad else TEAL, (WIDTH // 2, 256), 64)
        ui.draw_text(surf, g, (WIDTH // 2, 254), 44 if self.bad else 64, PAPER, "heavy", center=True)
        ui.draw_text(surf, name, (WIDTH // 2, 346), 24, INK, "heavy", center=True)
        self.boss.draw(surf, (WIDTH // 2 - 250, 176), scale=0.5)          # 이 난이도의 사장
        wins = sum(1 for h in self.history if h["won"])
        rows = [("통장", ui.won(self.money)), ("신뢰도", str(self.trust)), ("공공 납품", f"{wins}건")]
        for i, (a, b) in enumerate(rows):
            x = WIDTH // 2 - 240 + i * 240
            ui.draw_text(surf, a, (x, 396), 14, SOFT, True, center=True)
            ui.draw_text(surf, b, (x, 426), 24, INK, "heavy", center=True)
        msg = ("담합은 함께 망하는 지름길입니다. 공정한 경쟁만이 공장을 지킵니다." if self.bad else
               "서류 한 장, 가격 한 줄, 상자 하나까지 — 정직하게 만든 물건이 세금을 값지게 씁니다.")
        ui.draw_wrapped(surf, msg, (WIDTH // 2 - 320, 478, 640, 60), 17, INK, True)
        lg = self.life_log
        ui.draw_text(surf, f"일하는 틈에 챙긴 일 {lg['solved']}건 · 미루다 터진 일 {lg['burst']}건", (WIDTH // 2, 534), 13,
                     RED if lg["burst"] else SOFT, True, center=True)
        ui.draw_text(surf, "창구 건너편 이야기는 ‘심사숙GO! 조달청’에서 이어집니다.", (WIDTH // 2, 556), 14, TEAL, True, center=True)
        self.next_btn.rect.center = (WIDTH // 2, 616)
        self.next_btn.draw(surf)

    def draw(self, surf):
        ph = self.phase
        if ph == END:
            self._draw_factory(surf, 0)
            veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            veil.fill((224, 238, 240, 150))
            surf.blit(veil, (0, 0))
            self._draw_end(surf)
            return
        if ph == PRODUCE:
            self._draw_stage(surf)
            self._draw_produce_ui(surf)
        elif ph == DOCS:
            self._draw_docs(surf)
        else:
            self._draw_factory(surf)
            self.next_btn.rect.topleft = (PANEL.right - 250, PANEL.bottom - 76)
            {EVENT: self._draw_event, BOARD: self._draw_board, PRICE: self._draw_price,
             WINDOW: self._draw_window, OPEN: self._draw_open, RESULT: self._draw_result, LEDGER: self._draw_ledger}[ph](surf)
        self._hud(surf)
        if self.tutorial:
            self._draw_tutorial(surf)
        if self.toast:
            w = min(WIDTH - 80, ui.fonts.get(15, True).size(self.toast[0])[0] + 44)
            chip(surf, ((WIDTH - w) // 2, 92 if ph == PRODUCE else HEIGHT - 44, w, 34), self.toast[0], INK, size=15)
        if self.life:
            self._draw_life(surf)
