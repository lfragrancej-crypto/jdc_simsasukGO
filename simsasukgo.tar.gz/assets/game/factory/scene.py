"""납품하GO! 우리 공장 — 제조업체 사장이 되어 공공 입찰에 도전한다.

심사숙GO(공무원 편)와 같은 닷새, 같은 공고(data/world.json)를 창구 반대편에서 겪는다.
하루의 흐름:
  공고 고르기 → 투찰가 정하기 → 서류 꾸리기(마감 시계가 돈다) → 창구 접수 → 개찰
    → (낙찰) 생산 → 납품 → 장부        (낙찰 실패·반려) 일반 거래처 납품 → 장부
서류 규칙은 심사숙GO의 규정(data/rules.json)을 그대로 뒤집어 쓴다. 그날까지 배운 규정만 직접 챙긴다.
"""
import json
import math
import random

import pygame

from .. import sfx, storage, ui
from ..character import Character
from ..config import HEIGHT, WIDTH
from ..scenes.base import Scene
from . import cgs as fcg
from . import iso, staff as staffmod
from .iso import BLUE, BOXCOL, GREEN, INK, ORANGE, PAPER, RED, SOFT, TEAL, YELLOW, Btn, View, card, chip, shade

EVENT, BOARD, PRICE, DOCS, WINDOW, OPEN, PRODUCE, RESULT, LEDGER, END = (
    "event", "board", "price", "docs", "window", "open", "produce", "result", "ledger", "end")
PANEL = pygame.Rect(640, 96, 612, 604)
LIFE_CARD = pygame.Rect((WIDTH - 700) // 2, 110, 700, 500)      # 일하는 중간에 끼어드는 생활 사건
ORIGIN = (560, 176)
BG_TOP, BG_BOT = (224, 238, 240), (196, 220, 226)
BELT_Y, BELT_X0, BELT_X1 = 4.85, 1.3, 10.0
MACHINES = ((2.6, TEAL, "재단"), (5.0, ORANGE, "포장"), (7.4, GREEN, "검사"))


SAVE_NAME = "factory_save.json"
_BG: dict = {}


def load_save(app) -> dict | None:
    """이어하기 기록 (하루를 시작할 때마다 자동 저장된다)."""
    try:
        data = json.loads(storage.read(app.profile.dir, SAVE_NAME) or "")
        level = next(lv for lv in app.data.factory["levels"] if lv["id"] == data["level"])
        if not 0 <= data["day_i"] < len(app.data.world["cases"]):
            return None
        return dict(data, level=level)
    except Exception:
        return None


def delete_save(app):
    storage.delete(app.profile.dir, SAVE_NAME)


def record(app) -> dict:
    """꺼도 남는 납품하GO! 기록 (도감의 '우리 공장' 탭이 읽는다)."""
    rec = app.profile.data.setdefault("factory", {})
    for key, blank in (("levels", {}), ("delivered", {}), ("rejects", {}), ("staff", {})):
        if not isinstance(rec.get(key), dict):
            rec[key] = blank
    for key in ("wins", "perfect", "best"):
        rec.setdefault(key, 0)
    return rec


def clients(data) -> list[dict]:
    """우리 공장이 납품할 수 있는 곳 전부 (공통 공고 + 일반 공고). 도감의 납품처 도장판."""
    can = data.factory["company"]["can_make"]
    out = [{"agency": c["agency"], "item": c["item"], "officer": c["officer"], "thanks": c["thanks"], "day": c["day"]}
           for c in data.world["cases"] if c["item"] in can]
    out += [{"agency": s["agency"], "item": s["item"], "officer": None, "thanks": "", "day": 0}
            for s in data.factory["side_notices"] if s["item"] in can]
    for c in out:
        c["key"] = f"{c['agency']}|{c['item']}"
    return out


def _man(n) -> int:
    """만원 단위로 반올림."""
    return int(round(n / 10000.0)) * 10000


def background():
    """공장 전경 (한 번만 그려 둔다). (전경, 옆으로 밀었을 때 채울 바탕) 을 돌려준다."""
    if "bg" not in _BG:
        S = 2
        big = pygame.Surface((WIDTH * S, HEIGHT * S))
        g = pygame.Surface((1, 2))
        g.set_at((0, 0), BG_TOP)
        g.set_at((0, 1), BG_BOT)
        big.blit(pygame.transform.smoothscale(g, big.get_size()), (0, 0))
        v = View(ORIGIN, S)
        sh = pygame.Surface(big.get_size(), pygame.SRCALPHA)
        pts = [v.pt(-0.4, 9.3, -1.3), v.pt(11.3, 9.3, -1.3), v.pt(11.3, -0.4, -1.3), v.pt(12.2, 0.6, -2), v.pt(0.6, 10.2, -2)]
        pygame.draw.polygon(sh, (60, 90, 100, 60), pts)
        big.blit(sh, (0, 0))
        v.cube(big, 0, 0, 11, 9, 0.5, (236, 232, 222), -0.5)
        for gx in range(11):
            for gy in range(9):
                if (gx + gy) % 2 == 0:
                    v.tile(big, gx, gy, (228, 223, 211))
        pygame.draw.lines(big, YELLOW, True, [v.pt(1.0, 2.2), v.pt(10.4, 2.2), v.pt(10.4, 6.0), v.pt(1.0, 6.0)], 3 * S)
        v.cube(big, 0, -0.4, 11, 0.4, 2.6, (150, 196, 206))            # 뒷벽
        v.cube(big, -0.4, 0, 0.4, 9, 2.6, (170, 210, 218))
        for i in range(4):
            x0 = 1.2 + i * 2.5
            v.poly(big, (240, 250, 252), [v.pt(x0, 0, 2.0), v.pt(x0 + 1.5, 0, 2.0), v.pt(x0 + 1.5, 0, 0.9), v.pt(x0, 0, 0.9)])
        for i, c in enumerate(((240, 240, 236), (240, 240, 236), (222, 206, 170))):   # 원자재
            v.cube(big, 0.5, 0.6 + i * 0.95, 1.1, 0.8, 0.9, c)
            v.cube(big, 0.5, 0.6 + i * 0.95, 1.1, 0.8, 0.9, c, 0.9)
        for gx, col, _ in MACHINES:                                              # 기계 (벨트 뒤쪽)
            v.cube(big, gx, 2.9, 1.5, 1.5, 1.5, col)
            v.cube(big, gx + 0.2, 3.1, 1.1, 1.1, 0.25, shade(col, 0.8), 1.5)
            v.cube(big, gx + 0.6, 3.5, 0.3, 0.3, 0.7, (240, 240, 236), 1.75)
            v.cube(big, gx + 0.35, 4.4, 0.8, 0.5, 0.25, shade(col, 0.9), 1.0)    # 벨트 위로 내민 덮개
        v.cube(big, BELT_X0 - 0.1, 4.6, BELT_X1 - BELT_X0 + 0.7, 0.9, 0.55, (86, 98, 112))     # 컨베이어
        v.cube(big, BELT_X0 - 0.1, 4.7, BELT_X1 - BELT_X0 + 0.7, 0.7, 0.08, (52, 60, 72), 0.55)
        v.cube(big, 4.6, 7.0, 2.6, 1.3, 1.5, (250, 250, 248), 0.3)               # 납품 트럭
        v.cube(big, 3.6, 7.0, 1.0, 1.3, 1.1, BLUE, 0.3)
        for gx in (3.9, 5.4, 6.6):
            x, y = v.pt(gx, 8.3, 0.25)
            pygame.draw.ellipse(big, (50, 56, 66), (x - 13 * S, y - 10 * S, 26 * S, 20 * S))
        for i in range(2):                                                       # 출하장 상자
            for j in range(2):
                v.cube(big, 9.0 + j * 0.75, 6.6 + i * 0.75, 0.62, 0.62, 0.55, BOXCOL)
        v.cube(big, 9.0, 6.6, 0.62, 0.62, 0.55, shade(BOXCOL, 1.05), 0.55)
        v.cube(big, 10.0, 0.4, 0.6, 0.6, 0.5, (220, 150, 110))                   # 화분
        x, y = v.pt(10.3, 0.7, 1.6)
        pygame.draw.circle(big, (96, 180, 120), (int(x), int(y)), 22 * S)
        _BG["bg"] = pygame.transform.smoothscale(big, (WIDTH, HEIGHT)).convert()
        _BG["plain"] = pygame.transform.smoothscale(g, (300, HEIGHT)).convert()
    return _BG["bg"], _BG["plain"]


class FactoryScene(Scene):
    BGM = "factory"
    HOME = "factory_title"

    def __init__(self, app, level=None, saved=None, seed=None):
        super().__init__(app)
        self.cfg = app.data.factory
        self.co = self.cfg["company"]
        self.level = level or self.cfg["levels"][1]         # 난이도
        self.boss = Character(self.level["look"])           # 난이도마다 다른 사장
        self.boss.expression = "happy"
        self.tutorial = bool(self.level.get("tutorial")) and saved is None
        self.guide = Character(app.data.dialogue["mascots"]["narmi"]["look"])     # 튜토리얼 안내: AI 도우미 나르미
        self.guide.expression = "happy"
        self.guide.set_pose("point")
        self.rng = random.Random(seed)
        self.money = self.cfg["start_money"]
        self.trust = self.cfg["start_trust"]
        self.day_i = 0
        self.days = len(app.data.world["cases"])
        self.history = []                # 날마다의 결과 (dict)
        self.refused = False             # 담합 제안을 거절했는가
        self.staff = []                  # 함께 일하는 직원 (채용 봉투에서 온다, 최대 3명)
        self.run_cgs = []                # 이번 판에서 본 CG
        self.life = None                 # 지금 끼어든 생활 사건 (없으면 None)
        self.life_enabled = True
        self.life_done = True            # 오늘 사건이 이미 나왔는가
        self.life_hook = "bid"           # 오늘 일이 끼어드는 때: bid(값·서류를 챙기는 중) / produce(생산 도중)
        self.pending = None              # 어제 보류한 일 (오늘 다시 찾아온다)
        self.life_log = {"solved": 0, "deferred": 0, "burst": 0}
        self.life_seen = []
        self.buffs = {}                  # 생활 사건이 남긴 효과 (data/factory.json life 참고)
        self.life_btns = []
        self.life_ok = Btn((LIFE_CARD.right - 290, LIFE_CARD.bottom - 78, 260, 54), "하던 일로 돌아가기", ORANGE, 17)
        self.cg_wait = []                # 곧 보여 줄 CG (장면이 자리를 잡은 뒤 update 에서 띄운다)
        self.perks = {}
        self.bad = False                 # 담합에 가담 → BAD 엔딩
        self.t = 0.0
        self.phase_t = 0.0
        self.toast = None                # (글, 남은 시간)
        self.view = View(ORIGIN)
        self._bg = None
        self.clerk = Character(app.data.dialogue["hero"]["look"])      # 창구의 심사관 = 심사숙GO의 주인공
        self.officer = None
        self.next_btn = Btn((PANEL.right - 250, PANEL.bottom - 76, 226, 56), "다음")
        self.alt_btn = Btn((PANEL.x + 24, PANEL.bottom - 76, 290, 56), "", TEAL)
        self.speed_btns = [Btn((28 + i * 124, HEIGHT - 86, 114, 54), s["name"], (TEAL, GREEN, ORANGE)[i], 17)
                           for i, s in enumerate(self.cfg["produce"]["speeds"])]
        self.opt_btns = []
        if saved:                                                # 이어하기: 그날 아침부터
            self.money, self.trust, self.day_i = saved["money"], saved["trust"], saved["day_i"]
            self.history, self.refused = list(saved["history"]), saved["refused"]
            self.staff = list(saved.get("staff", []))
            self.run_cgs = list(saved.get("cgs", []))
            self.life_seen, self.buffs = list(saved.get("life", [])), dict(saved.get("buffs", {}))
            self.pending = saved.get("pending")
            self.life_log.update(saved.get("life_log", {}))
        self._start_day()

    def _save(self):
        storage.write(self.app.profile.dir, SAVE_NAME, json.dumps(
            {"level": self.level["id"], "day_i": self.day_i, "money": self.money, "trust": self.trust,
             "history": self.history, "refused": self.refused, "staff": self.staff, "cgs": self.run_cgs,
             "life": self.life_seen, "buffs": self.buffs, "pending": self.pending, "life_log": self.life_log},
            ensure_ascii=False))

    # ================================================================ 하루 준비
    @property
    def day(self) -> int:
        return self.day_i + 1

    def _go(self, phase):
        self.phase, self.phase_t = phase, 0.0

    def _notice(self, item_name, agency, scale, no, shared=None):
        item = self.app.data.item_by_name(item_name)
        est = _man(item["qty"] * item["unit_price"] * scale)
        return {"no": no, "item": item_name, "agency": agency, "qty": max(1, int(item["qty"] * scale)), "unit": item["unit"],
                "est": est, "sme": item["sme_only"], "can": item_name in self.co["can_make"], "shared": shared,
                "cost": _man(est * self.rng.uniform(*self.cfg["cost_rate"]))}

    def _start_day(self):
        data, cfg = self.app.data, self.cfg
        tut = self.tutorial
        self.perks = {} if tut else staffmod.perks(self.staff)
        if not tut:
            if self.day_i == 0 and "f_open" not in self.run_cgs:    # 첫날 아침: 공장 문을 여는 CG
                self.cg_wait.append(("f_open", None))
            self._save()                                         # 하루를 시작할 때마다 자동 저장
        case = data.case_of(self.day)
        self.case = case
        self.active = {"R01", "R02"} if tut else {r["id"] for r in data.active_rules(self.day)}
        if tut:
            notices = [self._notice("복사용지(A4)", "연습 공고", 0.2, "R26BK00000000")]
        else:
            notices = [self._notice(case["item"], case["agency"], 1.0, case["notice_no"], shared=case)]
        pool = [s for s in cfg["side_notices"] if s["item"] != case["item"]]
        self.rng.shuffle(pool)
        can = [s for s in pool if s["item"] in self.co["can_make"]]
        picks = can[:1 if notices[0]["can"] else 2]              # 만들 수 있는 공고가 날마다 두 건은 있게
        if tut:
            picks = [next(s for s in pool if s["item"] not in self.co["can_make"])]
        picks += [s for s in pool if s not in picks][:2 - len(picks)]
        for i, s in enumerate(picks):
            notices.append(self._notice(s["item"], s["agency"], s["scale"], f"R26BK{self.rng.randint(30000000, 99999999)}"))
        self.notices = notices
        self.pick = None
        self.price = 0
        self.rivals = []
        self.deadline = float(cfg["deadline_sec"]) * self.level["deadline"]
        self.deadline_total = self.deadline
        self.retries = 99 if tut else self.level["retries"]
        self.life_done = tut
        self.life_hook = self.rng.choice(("bid", "produce"))
        if not tut:                                              # 어제의 생활 사건이 남긴 효과
            self.deadline = max(25.0, self.deadline + self.buffs.pop("deadline", 0))
            self.deadline_total = self.deadline
        self.cost_cut = 0
        self.fields, self.answers = [], {}
        self.violation = None
        self.today = {"day": self.day, "won": False, "rejected": None, "paid": 0, "cost": 0, "penalty": 0, "leak": 0,
                      "late": False, "side": 0, "item": "", "agency": ""}
        if not tut:
            self.history.append(self.today)
        col = cfg["collusion"]
        if self.day == col["day"] and not tut:
            self.event = col
            self.event_result = None
            self.opt_btns = [Btn((PANEL.x + 30, PANEL.y + 330, PANEL.w - 60, 58), col["refuse"]["label"], GREEN),
                             Btn((PANEL.x + 30, PANEL.y + 402, PANEL.w - 60, 58), col["accept"]["label"], (150, 140, 150))]
            self._go(EVENT)
        else:
            self._go(BOARD)
            if self.refused and self.day == col["day"] + 1 and not tut:
                self.toast = (col["news"], 7.0)
        sfx.play("pop", 0.5)

    # ================================================================ 선택과 진행 (화면 없이도 불러 쓸 수 있다)
    def choose_event(self, accept: bool):
        if self.phase != EVENT or self.event_result:
            return
        if accept:
            self.bad = True
            self.event_result = self.event["accept"]["result"]
            sfx.play("wrong", 0.6)
        else:
            self.refused = True
            record(self.app)["refused"] = True
            self.app.profile.save()
            self.trust = min(100, self.trust + self.event["refuse"]["trust"])
            self.event_result = self.event["refuse"]["result"]
            sfx.play("correct", 0.6)
        self.phase_t = 0.0

    def pick_notice(self, i: int):
        if self.phase != BOARD or not self.notices[i]["can"]:
            if self.phase == BOARD:
                self.toast = ("우리 공장이 직접 만들 수 없는 품목이에요. 직접 만드는 업체만 응찰할 수 있어요.", 3.0)
                sfx.play("wrong", 0.4)
            return
        n = self.pick = self.notices[i]
        lo, hi = self.cfg["price_range"]
        self.p_min = _man(n["est"] * lo)
        self.p_max = _man(n["est"] * (hi if "R06" in self.active else 1.0))    # 예정가격 규정을 배우기 전에는 넘겨 쓸 수 없다
        self.floor = _man(n["est"] * self.cfg["floor_rate"])
        self.price = _man(n["est"] * 0.97)
        cut = (self.perks["account"][1]["cut"] if "account" in self.perks else 0) + self.cost_cut
        if cut and "cost0" not in n:                              # 살림꾼·미리 사 둔 원자재: 원가 절감
            n["cost0"] = n["cost"]
            n["cost"] = _man(n["cost"] * (1 - cut))
        names = [c["name"] for c in self.app.data.clean_companies]
        self.rng.shuffle(names)
        lo, hi = self.cfg["floor_rate"] - 0.03, self.level["rival_hi"]
        if self.tutorial:
            lo, hi = 0.985, 1.0                                  # 연습: 경쟁 업체는 비싸게 쓴다
        self.rivals = [(nm, _man(n["est"] * self.rng.uniform(lo, hi))) for nm in names[:3]]
        self.intel = self.rivals[:self.perks["sales"][1]["n"]] if "sales" in self.perks else []   # 영업 담당이 알아 온 값
        self.today["item"], self.today["agency"] = n["item"], n["agency"]
        sub = self.cfg["subway"]
        if self.day == sub["day"] and not self.tutorial:
            self.deadline -= sub["lose_sec"]
            self.toast = (sub["text"], 6.0)
        self._go(PRICE)
        sfx.play("paper", 0.5)

    def set_price(self, v):
        self.price = max(self.p_min, min(self.p_max, _man(v)))

    def submit_price(self):
        if self.phase == PRICE:
            self._build_fields()
            self._go(DOCS)
            sfx.play("paper", 0.5)

    def _build_fields(self):
        """서류 꾸리기 항목 — 그날까지 배운 규정만 직접 챙긴다. (id, 이름, 보기들, 정답 번호들)"""
        co, rng, n = self.co, self.rng, self.pick
        f = []
        if "R09" in self.active:
            opts = [co["name"], co["old_name"]]
            rng.shuffle(opts)
            f.append(("R09", "입찰서 상호", opts, {opts.index(co["name"])}))
        if "R02" in self.active:
            b = co["biz_no"]
            opts = [b, b[:-1] + str((int(b[-1]) + 6) % 10), b[:4] + b[5] + b[4] + b[6:]]
            rng.shuffle(opts)
            f.append(("R02", "입찰서 사업자번호", opts, {opts.index(b)}))
        if "R05" in self.active:
            rates = [0.03, 0.05, 0.07]
            rng.shuffle(rates)
            opts = [ui.won(math.ceil(self.price * r / 10000) * 10000) for r in rates]
            f.append(("R05", "입찰보증금", opts, {i for i, r in enumerate(rates) if r >= 0.05}))
        if "R01" in self.active:
            f.append(("R01", "입찰참가자격 등록증", ["넣지 않음", "봉투에 넣기"], {1}))
        if "R07" in self.active:
            f.append(("R07", "직접생산확인증명서", ["넣지 않음", "봉투에 넣기"], {1} if n["sme"] else {0, 1}))
        if "R08" in self.active:
            f.append(("R08", "청렴계약 서약서", ["서명 안 함", "서명하기"], {1}))
        self.fields = f
        self.answers = {fid: (0 if fid in ("R01", "R07", "R08") else None) for fid, *_ in f}
        self.crossed = {}                                        # 서류 달인이 미리 지워 준 틀린 보기 {항목: 보기 번호}
        if "docs" in self.perks:
            for fid, _, opts, ok in f:
                wrong = [i for i in range(len(opts)) if i not in ok]
                if wrong and rng.random() < self.perks["docs"][1]["chance"]:
                    self.crossed[fid] = rng.choice(wrong)
                    if self.answers[fid] == self.crossed[fid]:   # 기본값이 틀린 쪽이면 바른 쪽으로 바꿔 둔다
                        self.answers[fid] = max(ok)

    def choose(self, fid: str, idx: int):
        if self.phase == DOCS and fid in self.answers and self.crossed.get(fid) != idx:
            self.answers[fid] = idx
            sfx.play("click", 0.4)

    def docs_ready(self) -> bool:
        return all(v is not None for v in self.answers.values())

    def submit_docs(self, late=False):
        """창구에 낸다. 틀린 곳이 있으면 심사숙GO의 그 규정으로 반려된다."""
        if self.phase not in (DOCS, PRICE) or (not late and not self.docs_ready()):
            return
        self.violation = None
        if late:
            self.violation = "R03"
        elif self.price > self.pick["est"]:
            self.violation = "R06"
        else:
            for fid, _, _, ok in self.fields:
                if self.answers[fid] not in ok:
                    self.violation = fid
                    break
        self.clerk.expression = "happy" if not self.violation else "nervous"
        self.clerk.set_pose("cheer" if not self.violation else "shrug")
        can_retry = bool(self.violation) and not late and self.retries > 0 and self.deadline > self.cfg["retry_cost_sec"]
        self.alt_btn.label = f"고쳐서 다시 낸다 (-{self.cfg['retry_cost_sec']}초)"
        self.alt_btn.enabled = can_retry
        self.next_btn.label = "개찰 보러 가기" if not self.violation else "오늘은 돌아간다"
        if self.tutorial and self.violation:
            self.alt_btn.enabled, self.alt_btn.label = True, "고쳐서 다시 낸다"
        sfx.play("stamp", 0.7)
        sfx.play("correct" if not self.violation else "wrong", 0.5)
        self._go(WINDOW)

    def retry_docs(self):
        if self.phase == WINDOW and self.alt_btn.enabled:
            self.retries -= 1
            if not self.tutorial:
                self.deadline -= self.cfg["retry_cost_sec"]
            if self.violation == "R06":
                self._go(PRICE)
            else:
                self._go(DOCS)

    def _open_bids(self):
        n = self.pick
        rows = [(self.co["name"], self.price, True)] + [(nm, p, False) for nm, p in self.rivals]
        valid = [r for r in rows if self.floor <= r[1] <= n["est"]]
        self.winner = min(valid, key=lambda r: (r[1], not r[2])) if valid else None
        self.bid_rows = sorted(rows, key=lambda r: r[1])
        self.today["won"] = bool(self.winner and self.winner[2])
        self.next_btn.label = "공장 가동!" if self.today["won"] else "다시 써 보기" if self.tutorial else "다음"
        self._go(OPEN)

    def _start_production(self):
        p = self.cfg["produce"]
        self.target = 6 if self.tutorial else p["boxes"][min(self.day_i, len(p["boxes"]) - 1)]
        self.prod_total = self.prod_left = 999.0 if self.tutorial else float(p["time"][min(self.day_i, len(p["time"]) - 1)])
        self.speed = 1
        self.boxes = []                  # [gx, 불량인가, 사라지는 중 시간, 검사 고수가 봤는가]
        self.auto_pulled = 0
        self.spawn_t = 0.6
        self.made = self.shipped = self.leaked = self.pulled = self.wasted = 0
        self._go(PRODUCE)
        sfx.play("bell", 0.5)

    def pull_box(self, box):
        """상자를 라인에서 빼낸다 (불량이면 잘한 것, 멀쩡하면 낭비)."""
        if box[2] > 0:
            return
        box[2] = 0.001
        if box[1]:
            self.pulled += 1
            sfx.play("correct", 0.5)
        else:
            self.wasted += 1
            self.toast = ("멀쩡한 상자를 뺐어요! 찌그러진 상자만 빼내요.", 2.2)
            sfx.play("wrong", 0.4)

    def _finish_production(self, late=False):
        n, t, p = self.pick, self.today, self.cfg["produce"]
        done = self.shipped + self.leaked
        self.buffs.pop("defect", None)                           # 불량 효과는 이번 생산까지
        t["late"], t["leak"] = late, self.leaked
        ratio = min(1.0, done / self.target)
        t["paid"] = _man(self.price * ratio)
        t["cost"] = n["cost"]
        over = max(0, self.leaked - p["leak_ok"])
        t["penalty"] = _man(self.price * (p["leak_penalty"] * over + (0.10 if late else 0)))
        if not self.tutorial:
            self.trust = max(0, min(100, self.trust + (8 if not late and not over else 0) - 6 * over - (12 if late else 0)))
        case = n["shared"]
        look = case["officer"]["look"] if case else {"body": "#D8E6F0", "shape": "bean", "ears": "none", "acc": ["idcard"]}
        self.officer = Character(look)
        good = not late and not over
        self.hire = False
        if not self.tutorial:                                    # 도감 기록: 납품 횟수, 완벽하게 납품한 곳
            rec = record(self.app)
            rec["wins"] += 1
            if good:
                rec["perfect"] += 1
                self.hire = len(self.staff) < staffmod.MAX_STAFF     # 완벽 납품 → 채용 봉투 (최대 3명)
                key = f"{n['agency']}|{n['item']}"
                rec["delivered"][key] = rec["delivered"].get(key, 0) + 1
            self.app.profile.save()
        self.officer.expression = "happy" if good else "nervous"
        self.officer.set_pose("cheer" if good else "shrug")
        self.next_btn.label = "진짜 입찰 시작!" if self.tutorial else "채용 봉투 열기!" if self.hire else "다음"
        self._go(RESULT)
        sfx.play("fanfare" if good else "pop", 0.5)

    def _to_ledger(self):
        self._life_pop()                                         # 오늘 사건이 아직 안 나왔으면 정산 전에
        t = self.today
        if not t["won"]:
            t["side"] = self.cfg["side_income"]                  # 낙찰은 못 했지만 일반 거래처 주문으로 버틴다
        self.fixed_rows = [(name, _man(v * self.level["fixed"])) for name, v in self.cfg["fixed"]]
        self.fixed = sum(v for _, v in self.fixed_rows)
        t["net"] = t["paid"] + t["side"] - t["cost"] - t["penalty"] - self.fixed
        self.money_before = self.money
        self.money += t["net"]
        self.next_btn.label = "결과 보기" if self.day_i >= self.days - 1 else "다음 날로"
        self._go(LEDGER)
        sfx.play("paper", 0.5)

    def _finish(self):
        grade = next(g for g in self.cfg["grades"] if self.money >= g[0] and self.trust >= g[1])
        self.grade = ("BAD", "입찰참가자격 제한") if self.bad else (grade[2], grade[3])
        delete_save(self.app)                                    # 끝까지 왔으면 이어하기 기록은 지운다
        if not self.bad:
            rec = record(self.app)
            rec["clear"] = True
            order = "CBAS"                                       # 난이도마다 가장 좋았던 등급을 남긴다
            old = rec["levels"].get(self.level["id"], "C")
            rec["levels"][self.level["id"]] = max(old, self.grade[0], key=order.index)
            rec["best"] = max(rec.get("best", 0), self.money)
            rec["grade"] = self.grade[0]
            self.app.profile.save()
        self.next_btn.label = "처음 화면으로"
        self.boss.expression = "sad" if self.bad else "happy"
        self.boss.set_pose("slump" if self.bad else "cheer")
        self._go(END)
        sfx.play("wrong" if self.bad else "fanfare", 0.6)

    # ---------------------------------------------------------------- 이벤트 CG
    def show_cg(self, cg_id, then=None):
        """CG 한 장을 보여 주고 이 장면으로 돌아온다. then: CG 를 넘길 때 할 일."""
        from ..scenes.cgscene import CGScene
        if cg_id not in self.run_cgs:
            self.run_cgs.append(cg_id)

        def done():
            if then:
                then()
            self.app.change(lambda: self)
        chief = {"look": self.app.data.dialogue["hero"]["look"], "name": "조달청 심사관", "difficulty": self.level["name"]}
        looks = [m["look"] for m in self.staff]
        self.app.change(lambda: CGScene(self.app, cg_id, chief=chief, mates=looks, on_done=done, hero_look=self.level["look"]))

    def _day_cg(self):
        """하루를 마칠 때 보여 줄 CG: 처음 겪은 일(첫 낙찰·새 식구·거절)이 먼저, 없으면 일상 CG 하나."""
        t = self.today
        firsts = (("f_firstwin", t["won"]), ("f_hire", bool(self.staff)),
                  ("f_refuse", self.refused and self.day == self.cfg["collusion"]["day"]))
        for cg_id, ok in firsts:
            if ok and cg_id not in self.run_cgs:
                return cg_id
        return fcg.pick_random(self.run_cgs, self.app.profile.data["cgs"], self.rng)

    # ---------------------------------------------------------------- 일하는 중간에 끼어드는 생활 이슈
    def _life_pop(self):
        """하루 한 번, 일하는 도중에 가족·지인의 일이 끼어든다. 바로 해결할지, 일단 보류할지 고른다.
        어제 보류한 일이 있으면 그 일이 다시 찾아온다 (또 미루면 터진다)."""
        if not self.life_enabled or self.life_done or self.tutorial or self.bad or self.life:
            return
        self.life_done = True
        events = self.cfg["life"]["events"]
        again = self.pending is not None
        if again:
            ev = next(e for e in events if e["id"] == self.pending)
        else:
            pool = [e for e in events if e["id"] not in self.life_seen] or events
            ev = self.rng.choice(pool)
            self.life_seen.append(ev["id"])
        self.life = {"ev": ev, "chosen": None, "t": 0.0, "again": again}
        r = LIFE_CARD
        self.life_btns = [Btn((r.x + 30, r.bottom - 184, r.w - 60, 54), ev["solve"]["label"], TEAL, 18),
                          Btn((r.x + 30, r.bottom - 96, r.w - 60, 54), "또 미룬다" if again else "일단 보류한다", (150, 160, 166), 18)]
        sfx.play("bell", 0.5)

    def _life_time(self) -> str:
        """지금 쓰게 되는 시간이 어디서 깎이는지: bid(서류 마감) / produce(납기) / tomorrow(내일 마감)."""
        return "bid" if self.phase in (PRICE, DOCS) else "produce" if self.phase == PRODUCE else "tomorrow"

    def choose_life(self, i: int):
        """0 = 바로 해결, 1 = 일단 보류."""
        lf = self.life
        if not lf or lf["chosen"] is not None:
            return
        ev = lf["ev"]
        if i == 0:
            o = ev["solve"]
            sec = int(o["time"] * (1.5 if lf["again"] else 1))       # 미뤘던 일은 품이 더 든다
            where = self._life_time()
            if where == "bid":
                self.deadline = max(5.0, self.deadline - sec)
            elif where == "produce":
                self.prod_left = max(5.0, self.prod_left - sec)
            else:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) - sec
            self.money += o["money"]
            self.trust = max(0, min(100, self.trust + o["trust"]))
            if o["tomorrow"]:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) + o["tomorrow"]
            lf["result"], lf["effect"] = o["result"], self.life_effect(ev, "solve", sec, where)
            self.pending = None
            self.life_log["solved"] += 1
            sfx.play("correct", 0.5)
        elif lf["again"]:                                            # 두 번 미뤘다 → 터진다
            o = ev["burst"]
            self.money += o["money"]
            self.trust = max(0, min(100, self.trust + o["trust"]))
            if o["tomorrow"]:
                self.buffs["deadline"] = self.buffs.get("deadline", 0) + o["tomorrow"]
            if o["defect"]:
                self.buffs["defect"] = self.buffs.get("defect", 1.0) * (1 + o["defect"])
            lf["result"], lf["effect"] = o["result"], self.life_effect(ev, "burst")
            self.pending = None
            self.life_log["burst"] += 1
            sfx.play("wrong", 0.6)
        else:
            lf["result"], lf["effect"] = ev["defer"]["result"], "내일 다시 찾아옵니다 (또 미루면 일이 커져요)"
            self.pending = ev["id"]
            self.life_log["deferred"] += 1
            sfx.play("pop", 0.4)
        lf["chosen"], lf["t"] = i, 0.0

    def close_life(self):
        if self.life and self.life["chosen"] is not None:
            self.life = None
            sfx.play("paper", 0.4)

    def life_effect(self, ev, kind, sec=0, where="bid") -> str:
        o = ev[kind]
        parts = []
        if kind == "solve":
            parts.append({"bid": f"서류 마감 -{sec}초", "produce": f"납기 -{sec}초", "tomorrow": f"내일 마감 -{sec}초"}[where])
        if o["money"]:
            parts.append(f"통장 {'+' if o['money'] > 0 else '-'}{ui.won(abs(o['money']))}")
        if o["trust"]:
            parts.append(f"신뢰도 {o['trust']:+d}")
        if o["tomorrow"]:
            parts.append(f"내일 마감 {o['tomorrow']:+d}초")
        if o.get("defect"):
            parts.append(f"다음 생산 불량 +{int(o['defect'] * 100)}%")
        return " · ".join(parts)

    def _draw_life(self, surf):
        lf = self.life
        ev = lf["ev"]
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((30, 44, 54, min(150, int(lf["t"] * 700)) if lf["chosen"] is None else 150))
        surf.blit(veil, (0, 0))
        r = LIFE_CARD
        card(surf, r, 24)
        head = RED if lf["again"] else YELLOW
        pygame.draw.rect(surf, head, (r.x, r.y, r.w, 54), border_top_left_radius=24, border_top_right_radius=24)
        ui.draw_text(surf, "어제 미뤄 둔 일이 다시…" if lf["again"] else "잠깐! 일하는 중에…", (r.x + 28, r.y + 27), 17,
                     PAPER if lf["again"] else INK, "heavy", anchor="midleft")
        ui.draw_text(surf, ev["who"], (r.right - 28, r.y + 27), 14, PAPER if lf["again"] else INK, True, anchor="midright")
        ui.draw_text(surf, ev["title"], (r.x + 30, r.y + 72), 27, INK, "heavy")
        y = ui.draw_wrapped(surf, ev["text"], (r.x + 30, r.y + 118, r.w - 60, 90), 17, INK)
        if lf["chosen"] is None:
            sec = int(ev["solve"]["time"] * (1.5 if lf["again"] else 1))
            hints = (self.life_effect(ev, "solve", sec, self._life_time()),
                     "지금은 하던 일에 집중 · " + ("더 미루면 일이 커져요!" if lf["again"] else "내일 다시 찾아와요"))
            for b, hint in zip(self.life_btns, hints):
                b.draw(surf)
                ui.draw_text(surf, hint, (b.rect.right - 8, b.rect.bottom + 10), 12, SOFT, True, anchor="topright")
        else:
            box = pygame.Rect(r.x + 26, y + 16, r.w - 52, 140)
            burst = lf["chosen"] == 1 and lf["again"]
            pygame.draw.rect(surf, (255, 236, 230) if burst else (240, 247, 248), box, border_radius=14)
            label = self.life_btns[lf["chosen"]].label
            ui.draw_text(surf, f"→ {label}", (box.x + 16, box.y + 12), 14, RED if burst else TEAL, True)
            ui.draw_wrapped(surf, lf["result"], (box.x + 16, box.y + 38, box.w - 32, 70), 16, INK, True)
            ui.draw_text(surf, lf["effect"], (box.right - 16, box.bottom - 26), 13, RED if burst else ORANGE, True, anchor="topright")
            self.life_ok.draw(surf)

    def hire_staff(self):
        """채용 봉투(심사숙GO의 인사 발령 봉투와 같은 연출)를 열고, 끝나면 이 장면으로 돌아와 장부를 본다."""
        from ..scenes.gacha import GachaScene

        def done():
            self.perks = staffmod.perks(self.staff)
            self._to_ledger()
            self.app.change(lambda: self)
        self.app.change(lambda: GachaScene(self.app, 1, staffmod.kit(self.app, self, done)))

    def advance(self):
        """'다음' 버튼."""
        if self.life:
            return
        ph = self.phase
        if ph == EVENT and self.event_result:
            if self.bad:
                self.show_cg("f_bad", self._finish)            # 닫힌 셔터 → BAD 엔딩
            else:
                self._go(BOARD)
        elif ph == WINDOW:
            if self.violation and self.tutorial:
                self.retry_docs()
            elif self.violation:
                rec = record(self.app)                           # 도감 기록: 어떤 규정으로 반려당했는가
                rec["rejects"][self.violation] = rec["rejects"].get(self.violation, 0) + 1
                self.app.profile.save()
                self.today["rejected"] = self.violation
                self.trust = max(0, self.trust - 4)
                self._to_ledger()
            else:
                self._open_bids()
        elif ph == OPEN and self.phase_t > 1.6:
            if self.today["won"]:
                self._start_production()
            elif self.tutorial:
                self._go(PRICE)                                  # 연습: 값을 다시 써 본다
            else:
                self._to_ledger()
        elif ph == RESULT:
            if self.tutorial:                                    # 연습 끝 → 진짜 1일차
                self.tutorial = False
                self._start_day()
            elif self.hire:                                      # 채용 봉투 열기 → 돌아와서 장부
                self.hire = False
                self.hire_staff()
            else:
                self._to_ledger()
        elif ph == LEDGER:
            def next_day():
                self.day_i += 1
                self._start_day()
            if self.day_i >= self.days - 1:
                self.show_cg("f_finale", self._finish)
            else:
                cg_id = self._day_cg()
                self.show_cg(cg_id, next_day) if cg_id else next_day()
        elif ph == END:
            self.app.to_factory()

    # ================================================================ 입력
    def _slider(self):
        return pygame.Rect(PANEL.x + 40, PANEL.y + 372, PANEL.w - 80, 16)

    def _notice_rect(self, i):
        return pygame.Rect(PANEL.x + 20, PANEL.y + 150 + i * 148, PANEL.w - 40, 136)

    def _field_opts(self, row, n_opts):
        y = PANEL.y + 150 + row * 62
        w = (PANEL.w - 250) // n_opts
        return [pygame.Rect(PANEL.x + 222 + k * w, y, w - 8, 44) for k in range(n_opts)]

    def _box_pos(self, gx):
        x, y = self.view.pt(gx + 0.25, BELT_Y + 0.25, 0.63 + 0.42)
        return int(x), int(y)

    def handle_event(self, event):
        if self.life:                                            # 생활 사건이 떠 있는 동안은 그것부터
            if self.life["chosen"] is None:
                for i, b in enumerate(self.life_btns):
                    num = event.type == pygame.KEYDOWN and event.key == pygame.K_1 + i
                    if self.life["t"] > 0.4 and (b.clicked(event) or num):
                        self.choose_life(i)
                        break
            elif self.life["t"] > 0.4 and (self.life_ok.clicked(event) or (
                    event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE))):
                self.close_life()
            return
        ph = self.phase
        down = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        key = event.key if event.type == pygame.KEYDOWN else None
        go = key in (pygame.K_RETURN, pygame.K_SPACE)
        if ph == EVENT:
            if self.event_result is None:
                for i, b in enumerate(self.opt_btns):
                    if b.clicked(event):
                        self.choose_event(i == 1)
            elif self.phase_t > 0.4 and (self.next_btn.clicked(event) or go):
                self.advance()
        elif ph == BOARD:
            if down:
                for i in range(len(self.notices)):
                    if self._notice_rect(i).collidepoint(event.pos):
                        self.pick_notice(i)
                        break
        elif ph == PRICE:
            sl = self._slider()
            drag = (down and sl.inflate(30, 60).collidepoint(event.pos)) or (
                event.type == pygame.MOUSEMOTION and event.buttons[0] and sl.inflate(60, 160).collidepoint(event.pos))
            if drag:
                k = (event.pos[0] - sl.x) / sl.w
                self.set_price(self.p_min + (self.p_max - self.p_min) * max(0.0, min(1.0, k)))
            elif key in (pygame.K_LEFT, pygame.K_RIGHT):
                self.set_price(self.price + (-100000 if key == pygame.K_LEFT else 100000))
            elif self.next_btn.clicked(event) or go:
                self.submit_price()
        elif ph == DOCS:
            if down:
                for row, (fid, _, opts, _) in enumerate(self.fields):
                    for k, r in enumerate(self._field_opts(row, len(opts))):
                        if r.collidepoint(event.pos):
                            self.choose(fid, k)
                            return
            if self.docs_ready() and (self.next_btn.clicked(event) or go):
                self.submit_docs()
        elif ph == WINDOW:
            if self.phase_t < 0.5:
                return
            if self.alt_btn.clicked(event):
                self.retry_docs()
            elif self.next_btn.clicked(event) or go:
                self.advance()
        elif ph == PRODUCE:
            for i, b in enumerate(self.speed_btns):
                if b.clicked(event) or key == pygame.K_1 + i:
                    self.speed = i
                    return
            if down:
                for box in sorted(self.boxes, key=lambda b: -b[0]):
                    x, y = self._box_pos(box[0])
                    if box[2] == 0 and abs(event.pos[0] - x) < 34 and abs(event.pos[1] - y) < 34:
                        self.pull_box(box)
                        break
        elif ph in (OPEN, RESULT, LEDGER, END):
            if self.phase_t > 0.5 and (self.next_btn.clicked(event) or go):
                self.advance()

    # ================================================================ 갱신
    def update(self, dt):
        self.t += dt
        self.phase_t += dt
        self.clerk.update(dt)
        if self.officer:
            self.officer.update(dt)
        for b in [self.next_btn, self.alt_btn] + self.speed_btns + self.opt_btns:
            b.update(dt)
        if self.toast:
            self.toast = (self.toast[0], self.toast[1] - dt) if self.toast[1] > dt else None
        self.guide.update(dt)
        self.boss.update(dt)
        if self.life:                                            # 사건이 떠 있으면 시계도 라인도 멈춘다
            self.life["t"] += dt
            for b in self.life_btns + [self.life_ok]:
                b.update(dt)
            return
        if self.cg_wait and self.app.fade_next is None and self.app.scene is self:
            self.show_cg(*self.cg_wait.pop(0))
            return
        if self.phase in (PRICE, DOCS) and not self.tutorial:
            self.deadline -= dt
            if self.life_hook == "bid" and self.deadline_total - self.deadline > 7:     # 값과 서류를 챙기는 도중에
                self._life_pop()
            if self.deadline <= 0:                               # 마감을 넘겼다 → 접수 불가 (R03)
                self.deadline = 0.0
                self.submit_docs(late=True)
        elif self.phase == PRODUCE:
            self._update_production(dt)

    def _update_production(self, dt):
        sp = self.cfg["produce"]["speeds"][self.speed]
        if not self.tutorial:
            self.prod_left -= dt
        self.spawn_t -= dt
        if self.spawn_t <= 0 and self.made < self.target + self.pulled + self.wasted:
            self.spawn_t = sp["gap"]
            self.made += 1
            craft = 1 - self.perks["craft"][1]["cut"] if "craft" in self.perks else 1.0      # 숙련공: 불량 감소
            craft *= self.buffs.get("defect", 1.0)                 # 생활 사건의 효과 (회식·정비 등)
            self.boxes.append([BELT_X0, self.rng.random() < sp["defect"] * self.level["defect"] * craft, 0.0, False])
        for box in self.boxes:
            if box[2] > 0:
                box[2] += dt
            else:
                box[0] += sp["move"] * dt
                if box[1] and not box[3] and box[0] >= 8.4 and "qc" in self.perks:    # 검사 고수: 검사대를 지난 불량을 대신 빼낸다
                    box[3] = True
                    if self.rng.random() < self.perks["qc"][1]["chance"]:
                        box[2] = 0.001
                        self.pulled += 1
                        self.auto_pulled += 1
                        who = self.perks["qc"][2]
                        self.toast = (f"{who['nick']}: “{who['say']['qc']}”", 1.6)
                        sfx.play("correct", 0.35)
                        continue
                if box[0] >= BELT_X1:
                    box[2] = -1.0
                    if box[1]:
                        self.leaked += 1
                        sfx.play("wrong", 0.3)
                    else:
                        self.shipped += 1
                        sfx.play("pop", 0.3)
        self.boxes = [b for b in self.boxes if 0 <= b[2] < 0.3]
        if self.life_hook == "produce" and self.shipped + self.leaked >= self.target // 2:    # 생산이 한창일 때
            self._life_pop()
        if self.shipped + self.leaked >= self.target:
            self._finish_production()
        elif self.prod_left <= 0:
            self._finish_production(late=True)

    # ================================================================ 그리기: 공장
    def _background(self):
        self._bg, self._plain = background()
        return self._bg

    def _tut_text(self):
        tut, ph = self.cfg["tutorial"], self.phase
        if ph == WINDOW:
            return tut["window_ng" if self.violation else "window_ok"]
        if ph == OPEN:
            return tut["open_ok" if self.today["won"] else "open_ng"] if self.phase_t > 1.6 else ""
        return tut.get(ph, "")

    def _draw_tutorial(self, surf):
        """나르미의 안내 말풍선 + 오래 걸리면 정답 쪽을 반짝여 준다."""
        ph = self.phase
        pulse = 3 + int(abs(math.sin(self.t * 5)) * 3)
        if ph == BOARD and self.phase_t > 8:
            pygame.draw.rect(surf, ORANGE, self._notice_rect(0).inflate(8, 8), pulse, border_radius=18)
        elif ph == PRICE and self.phase_t > 8:
            sl = self._slider()
            k0 = (self.floor - self.p_min) / (self.p_max - self.p_min)
            k1 = (self.pick["est"] - self.p_min) / (self.p_max - self.p_min)
            pygame.draw.rect(surf, ORANGE, (sl.x + int(sl.w * k0) - 4, sl.y - 8, int(sl.w * (k1 - k0)) + 8, sl.h + 16), pulse,
                             border_radius=10)
        elif ph == DOCS and self.phase_t > 12:
            for row, (fid, _, opts, ok) in enumerate(self.fields):
                if self.answers[fid] not in ok:
                    pygame.draw.rect(surf, ORANGE, self._field_opts(row, len(opts))[max(ok)].inflate(8, 8), pulse, border_radius=14)
        text = self._tut_text()
        if not text:
            return
        r = pygame.Rect(440, 150, 400, 96) if ph == PRODUCE else pygame.Rect(16, HEIGHT - 142, 606, 126)
        card(surf, r, 18)
        clip = surf.get_clip()
        surf.set_clip(pygame.Rect(r.x + 6, r.y + 6, 96, r.h - 12))
        self.guide.draw(surf, (r.x + 54, r.y + 12), scale=0.36)
        surf.set_clip(clip)
        chip(surf, (r.x + 108, r.y + 12, 84, 24), "튜토리얼", ORANGE, size=12)
        ui.draw_text(surf, "AI 도우미 나르미", (r.x + 200, r.y + 17), 12, SOFT, True)
        ui.draw_wrapped(surf, text, (r.x + 108, r.y + 44, r.w - 124, r.h - 50), 15, INK, True)


    def _draw_factory(self, surf, dx=0):
        bg = self._background()
        if dx:                                                    # 옆으로 민 만큼 드러나는 자리는 같은 바탕으로 채운다
            surf.blit(self._plain, (WIDTH + dx, 0))
        surf.blit(bg, (dx, 0))
        v = self.view
        v.ox = ORIGIN[0] + dx
        running = self.phase == PRODUCE
        for i, (gx, col, name) in enumerate(MACHINES):
            x, y = v.pt(gx + 0.75, 3.65, 3.2)
            on = running and math.sin(self.t * 6 + i * 2) > 0
            pygame.draw.circle(surf, (255, 240, 150) if on else shade(col, 0.6), (int(x), int(y + 22)), 6)
            r = pygame.Rect(0, 0, 58, 24)
            r.center = (x, y - 4)
            pygame.draw.rect(surf, PAPER, r, border_radius=12)
            pygame.draw.rect(surf, shade(col, 0.8), r, 2, border_radius=12)
            ui.draw_text(surf, name, r.center, 13, shade(col, 0.6), True, center=True)
        if running:
            for box in self.boxes:
                self._draw_box(surf, box)
        for i, (gx, gy, col) in enumerate(((3.3, 6.3, ORANGE), (5.9, 6.4, TEAL), (8.3, 6.2, GREEN), (1.6, 7.6, BLUE))):
            v.worker(surf, gx, gy, col, abs(math.sin(self.t * 4 + i)) * 3 if running else 0)

    def _draw_box(self, surf, box):
        gx, bad, gone = box[:3]
        v = self.view
        z = 0.63 + (gone * 4.0 if gone > 0 else 0)
        col = (176, 138, 96) if bad else BOXCOL
        v.cube(surf, gx, BELT_Y, 0.5, 0.5, 0.42, col, z)
        x, y = v.pt(gx + 0.25, BELT_Y + 0.25, z + 0.42)
        if bad:                                                   # 찌그러진 상자: 윗면이 터져 있다
            pygame.draw.line(surf, (96, 66, 44), (x - 12, y - 4), (x + 10, y + 5), 4)
            pygame.draw.line(surf, (96, 66, 44), (x + 2, y - 7), (x - 5, y + 6), 3)
            if (self.tutorial or self.day_i < self.level["mark_days"]) and gone == 0:    # 난이도에 따라 표시를 붙여 준다
                pygame.draw.circle(surf, RED, (int(x), int(y - 30 + math.sin(self.t * 8) * 3)), 11)
                ui.draw_text(surf, "!", (x, y - 31 + math.sin(self.t * 8) * 3), 15, PAPER, "heavy", center=True)
        else:
            pygame.draw.line(surf, (240, 226, 190), (x - 14, y + 1), (x + 14, y - 1), 4)

    # ================================================================ 그리기: 화면 부품
    def _hud(self, surf):
        card(surf, (24, 20, 400, 62), 16)
        ui.draw_text(surf, "납품하GO! 우리 공장", (42, 30), 13, ORANGE, True)
        ui.draw_text(surf, ("튜토리얼" if self.tutorial else f"{self.day}일차") + f" · {self.co['name']}", (42, 48), 17, INK, "heavy")
        chip(surf, (300, 28, 108, 22), self.level["name"], tuple(self.level["color"]), size=11)
        card(surf, (440, 20, 190, 62), 16)
        ui.draw_text(surf, "통장", (456, 30), 12, SOFT, True)
        ui.draw_text(surf, ui.won(self.money), (456, 46), 18, RED if self.money < 0 else INK, "heavy")
        card(surf, (646, 20, 190, 62), 16)
        ui.draw_text(surf, f"신뢰도 {self.trust}", (662, 30), 12, SOFT, True)
        iso.bar(surf, (662, 54, 158, 12), self.trust / 100, GREEN if self.trust >= 40 else RED)
        if self.staff and self.phase != PRODUCE:                 # 함께 일하는 직원
            w = 26 + len(self.staff) * 96
            card(surf, (852, 20, w, 62), 16)
            for i, m in enumerate(self.staff):
                x = 866 + i * 96
                pygame.draw.circle(surf, pygame.Color(m["look"]["body"]), (x + 14, 51), 14)
                pygame.draw.circle(surf, INK, (x + 14, 51), 14, 2)
                ui.draw_text(surf, m["nick"], (x + 34, 34), 13, INK, True)
                ui.draw_text(surf, staffmod.SKILLS[m["skills"][0]["type"]]["name"], (x + 34, 52), 10, SOFT, True)

    def _panel(self, surf, title, tag=None, tag_color=TEAL):
        card(surf, PANEL, 22)
        x, y = PANEL.x + 28, PANEL.y + 22
        if tag:
            w = ui.fonts.get(13, True).size(tag)[0] + 24
            chip(surf, (x, y, w, 26), tag, tag_color)
            y += 36
        ui.draw_text(surf, title, (x, y), 27, INK, "heavy")
        return y + 46

    def _deadline_bar(self, surf):
        r = pygame.Rect(PANEL.right - 236, PANEL.y + 24, 208, 40)
        hot = self.deadline < 20
        pygame.draw.rect(surf, (255, 232, 226) if hot else (236, 244, 246), r, border_radius=12)
        ui.draw_text(surf, "입찰 마감까지", (r.x + 12, r.y + 5), 11, RED if hot else SOFT, True)
        ui.draw_text(surf, "연습: 제한 없음" if self.tutorial else f"{int(self.deadline)}초", (r.right - 12, r.y + 3), 15,
                     RED if hot else INK, "heavy", anchor="topright")
        iso.bar(surf, (r.x + 12, r.y + 26, r.w - 24, 8), self.deadline / self.deadline_total, RED if hot else TEAL, (214, 226, 230))

    def _notice_line(self, surf, y):
        n = self.pick
        box = pygame.Rect(PANEL.x + 24, y, PANEL.w - 48, 56)
        pygame.draw.rect(surf, (240, 247, 248), box, border_radius=12)
        ui.draw_text(surf, f"{n['agency']} · {n['item']} {n['qty']:,}{n['unit']}", (box.x + 16, box.y + 8), 17, INK, "heavy")
        ui.draw_text(surf, f"공고 {n['no']}   예정가격 {ui.won(n['est'])}", (box.x + 16, box.y + 32), 13, SOFT, True)
        return box.bottom + 14

    def _draw_event(self, surf):
        ev = self.event
        y = self._panel(surf, "수상한 제안", f"{ev['who']} 사장", (150, 140, 150))
        y = ui.draw_wrapped(surf, ev["text"], (PANEL.x + 30, y + 6, PANEL.w - 60, 200), 19, INK)
        if self.event_result is None:
            ui.draw_text(surf, "어떻게 할까요?", (PANEL.x + 30, PANEL.y + 296), 14, SOFT, True)
            for b in self.opt_btns:
                b.draw(surf)
        else:
            box = pygame.Rect(PANEL.x + 24, y + 20, PANEL.w - 48, 150)
            pygame.draw.rect(surf, (255, 236, 230) if self.bad else (232, 246, 236), box, border_radius=14)
            ui.draw_wrapped(surf, self.event_result, (box.x + 18, box.y + 16, box.w - 36, 100), 17, INK, True)
            ui.draw_text(surf, "입찰참가자격 제한!" if self.bad else f"신뢰도 +{ev['refuse']['trust']}",
                         (box.x + 18, box.bottom - 34), 16, RED if self.bad else GREEN, "heavy")
            self.next_btn.draw(surf)

    def _draw_board(self, surf):
        y = self._panel(surf, "오늘의 입찰 공고", "나라장터")
        case = self.case
        ui.draw_wrapped(surf, f"{case['agency']} {case['officer']['name']} {case['officer']['role']}: “{case['need']}”",
                        (PANEL.x + 28, y - 4, PANEL.w - 56, 44), 14, SOFT, True)
        mouse = pygame.mouse.get_pos()
        for i, n in enumerate(self.notices):
            r = self._notice_rect(i)
            hot = n["can"] and r.collidepoint(mouse)
            pygame.draw.rect(surf, (236, 247, 250) if hot else (246, 249, 250) if n["can"] else (240, 240, 240), r, border_radius=14)
            pygame.draw.rect(surf, TEAL if hot else (220, 230, 234), r, 3 if hot else 2, border_radius=14)
            ink = INK if n["can"] else (160, 166, 170)
            x = r.x + 18
            if n["shared"]:
                x = chip(surf, (x, r.y + 14, 108, 24), "오늘의 공통 공고", ORANGE, size=12).right + 8
            if n["sme"]:
                chip(surf, (x, r.y + 14, 132, 24), "중소기업자간 경쟁제품", BLUE if n["can"] else (170, 176, 180), size=12)
            ui.draw_text(surf, f"{n['agency']}  ·  {n['item']} {n['qty']:,}{n['unit']}", (r.x + 18, r.y + 46), 20, ink, "heavy")
            ui.draw_text(surf, f"공고 {n['no']}", (r.x + 18, r.y + 78), 13, SOFT, True)
            ui.draw_text(surf, f"예정가격 {ui.won(n['est'])}", (r.x + 18, r.y + 100), 16, ink, True)
            if n["can"]:
                chip(surf, (r.right - 112, r.bottom - 46, 94, 32), "응찰하기", TEAL, size=14)
            else:
                ui.draw_text(surf, "우리 공장이 직접 만들지 못하는 품목", (r.right - 16, r.bottom - 32), 13, (170, 120, 110), True,
                             anchor="topright")
        ui.draw_text(surf, f"우리 공장이 만드는 것: {' · '.join(self.co['can_make'])}", (PANEL.x + 28, PANEL.bottom - 28), 13, SOFT, True)

    def _draw_price(self, surf):
        n = self.pick
        y = self._panel(surf, "얼마에 써낼까?", "투찰가 정하기")
        self._deadline_bar(surf)
        y = self._notice_line(surf, y)
        parts = (("재료비", 0.62), ("인건비", 0.26), ("운송·기타", 0.12))
        for i, (name, k) in enumerate(parts):
            ui.draw_text(surf, name, (PANEL.x + 40, y + i * 26), 15, SOFT, True)
            ui.draw_text(surf, ui.won(_man(n["cost"] * k)), (PANEL.x + 300, y + i * 26), 15, INK, True, anchor="topright")
        ui.draw_text(surf, "원가 합계" + ("  (살림꾼이 아낌)" if "cost0" in n else ""), (PANEL.x + 340, y + 4), 13,
                     GREEN if "cost0" in n else SOFT, True)
        ui.draw_text(surf, ui.won(n["cost"]), (PANEL.x + 340, y + 24), 24, INK, "heavy")
        sl = self._slider()
        span = self.p_max - self.p_min

        def px(v):
            return sl.x + int(sl.w * (v - self.p_min) / span)
        pygame.draw.rect(surf, (226, 234, 238), sl, border_radius=8)
        ok = pygame.Rect(px(self.floor), sl.y, px(n["est"]) - px(self.floor), sl.h)
        pygame.draw.rect(surf, (190, 232, 204), ok)
        for v, name, col in ((self.floor, "낙찰 하한선", TEAL), (n["est"], "예정가격", RED)):
            pygame.draw.line(surf, col, (px(v), sl.y - 22), (px(v), sl.bottom + 6), 3)
            ui.draw_text(surf, name, (px(v), sl.y - 40), 12, col, True, anchor="midtop")
        pygame.draw.line(surf, (150, 120, 90), (px(n["cost"]), sl.y - 8), (px(n["cost"]), sl.bottom + 8), 3)
        ui.draw_text(surf, "원가", (px(n["cost"]), sl.bottom + 10), 12, (150, 120, 90), True, anchor="midtop")
        for nm, v in self.intel:                                 # 영업 담당이 알아 온 경쟁 업체 값
            if self.p_min <= v <= self.p_max:
                pygame.draw.polygon(surf, BLUE, [(px(v), sl.y - 4), (px(v) - 7, sl.y - 16), (px(v) + 7, sl.y - 16)])
        if self.intel:
            who = self.perks["sales"][2]["nick"]
            ui.draw_text(surf, f"▼ {who}의 정보: " + ", ".join(f"{nm} {ui.won(v)}" for nm, v in self.intel[:2])
                         + (" …" if len(self.intel) > 2 else ""), (PANEL.x + 40, sl.y - 66), 12, BLUE, True)
        kx = px(self.price)
        pygame.draw.circle(surf, shade(ORANGE, 0.7), (kx, sl.centery + 3), 17)
        pygame.draw.circle(surf, ORANGE, (kx, sl.centery), 17)
        pygame.draw.circle(surf, PAPER, (kx, sl.centery), 7)
        y2 = sl.bottom + 44
        ui.draw_text(surf, "내 투찰가", (PANEL.x + 40, y2), 14, SOFT, True)
        ui.draw_text(surf, ui.won(self.price), (PANEL.x + 40, y2 + 20), 32, INK, "heavy")
        profit = self.price - n["cost"]
        ui.draw_text(surf, "낙찰되면 남는 돈", (PANEL.x + 340, y2), 14, SOFT, True)
        ui.draw_text(surf, ("+" if profit >= 0 else "") + ui.won(profit), (PANEL.x + 340, y2 + 22), 26, GREEN if profit >= 0 else RED, "heavy")
        if self.price > n["est"]:
            msg, col = "예정가격을 넘으면 접수조차 안 돼요!", RED
        elif self.price < self.floor:
            msg, col = "낙찰 하한선보다 낮으면 탈락이에요.", RED
        elif profit < 0:
            msg, col = "원가보다 낮아요. 따내도 손해!", RED
        else:
            msg, col = "하한선과 예정가격 사이에서 가장 낮게 쓴 업체가 낙찰돼요.", SOFT
        ui.draw_text(surf, msg, (PANEL.x + 40, y2 + 70), 14, col, True)
        ui.draw_text(surf, "막대를 끌거나 ← → 키로 조절", (PANEL.x + 28, PANEL.bottom - 52), 12, SOFT, True)
        self.next_btn.label = "이 가격으로 투찰"
        self.next_btn.draw(surf)

    def _draw_docs(self, surf):
        y = self._panel(surf, "서류 꾸리기", "입찰 봉투")
        self._deadline_bar(surf)
        co = self.co
        ui.draw_text(surf, f"사업자등록증: {co['name']}  {co['biz_no']}    투찰가 {ui.won(self.price)}",
                     (PANEL.x + 28, y - 2), 14, TEAL, True)
        rules = self.app.data.rules_by_id
        for row, (fid, name, opts, _) in enumerate(self.fields):
            ry = PANEL.y + 150 + row * 62
            ui.draw_text(surf, name, (PANEL.x + 28, ry + 4), 16, INK, "heavy")
            ui.draw_text(surf, rules[fid]["short"], (PANEL.x + 28, ry + 26), 11, SOFT, True)
            for k, r in enumerate(self._field_opts(row, len(opts))):
                if self.crossed.get(fid) == k:                   # 서류 달인이 지워 준 틀린 보기
                    pygame.draw.rect(surf, (236, 236, 236), r, border_radius=12)
                    ui.draw_text(surf, opts[k], r.center, 13, (176, 180, 184), True, center=True)
                    pygame.draw.line(surf, RED, (r.x + 14, r.centery), (r.right - 14, r.centery), 3)
                    continue
                on = self.answers[fid] == k
                pygame.draw.rect(surf, TEAL if on else (240, 246, 248), r, border_radius=12)
                pygame.draw.rect(surf, shade(TEAL, 0.8) if on else (214, 226, 230), r, 2, border_radius=12)
                size = 15 if len(opts[k]) < 13 else 13
                ui.draw_text(surf, opts[k], r.center, size, PAPER if on else INK, True, center=True)
        if "R05" in self.active:
            ui.draw_text(surf, "입찰보증금은 투찰가의 5% 이상이어야 해요.", (PANEL.x + 28, PANEL.bottom - 108), 12, SOFT, True)
        tip = "등록증과 똑같이, 빠진 것 없이!"
        if self.crossed:
            tip = f"{self.perks['docs'][2]['nick']}이(가) 틀린 보기에 줄을 그어 뒀어요."
        ui.draw_text(surf, tip, (PANEL.x + 28, PANEL.bottom - 52), 13, TEAL if self.crossed else SOFT, True)
        self.next_btn.label = "창구에 제출"
        self.next_btn.enabled = self.docs_ready()
        self.next_btn.draw(surf)
        self.next_btn.enabled = True

    def _draw_window(self, surf):
        ok = not self.violation
        y = self._panel(surf, "접수 완료!" if ok else "반려되었습니다", "조달청 계약심사과 창구", GREEN if ok else RED)
        clip = surf.get_clip()
        area = pygame.Rect(PANEL.x + 24, y, 190, 190)
        pygame.draw.rect(surf, (255, 240, 214), area, border_radius=16)
        surf.set_clip(area)
        self.clerk.draw(surf, (area.centerx, area.y + 22), scale=0.62)
        surf.set_clip(clip)
        ui.draw_text(surf, "조달청 심사관", (area.x, area.bottom + 8), 11, SOFT, True)
        tx = area.right + 20
        tw = PANEL.right - 28 - tx
        if ok:
            ui.draw_wrapped(surf, "“서류 이상 없습니다. 꼼꼼하게 챙겨 오셨네요! 개찰 결과는 곧 나옵니다.”", (tx, y + 10, tw, 120), 18, INK, True)
        else:
            r = self.app.data.rules_by_id[self.violation]
            chip(surf, (tx, y + 4, 60, 26), "반려", RED)
            ui.draw_text(surf, r["short"], (tx + 70, y + 5), 18, RED, "heavy")
            yy = ui.draw_wrapped(surf, r["text"], (tx, y + 42, tw, 60), 15, INK, True)
            ui.draw_wrapped(surf, r["explain"], (tx, yy + 8, tw, 90), 14, SOFT, True)
            if self.alt_btn.enabled:
                self.alt_btn.draw(surf)
        self.next_btn.draw(surf)

    def _draw_open(self, surf):
        n = self.pick
        y = self._panel(surf, "개찰 결과", "투찰함을 엽니다")
        y = self._notice_line(surf, y)
        x0, w = PANEL.x + 200, PANEL.w - 250
        lo, hi = self.p_min * 0.98, n["est"] * 1.04

        def px(v):
            return x0 + int(w * (v - lo) / (hi - lo))
        shown = min(len(self.bid_rows), int(self.phase_t / 0.35))
        for i, (name, price, mine) in enumerate(self.bid_rows):
            ry = y + 24 + i * 58
            ui.draw_text(surf, name, (PANEL.x + 28, ry + 4), 14, ORANGE if mine else INK, True)
            if i < shown:
                valid = self.floor <= price <= n["est"]
                win = self.winner and (name, price, mine) == self.winner and self.phase_t > 1.6
                col = (ORANGE if mine else TEAL) if valid else (190, 196, 200)
                pygame.draw.rect(surf, col, (x0, ry, max(8, px(price) - x0), 26), border_radius=8)
                ui.draw_text(surf, ui.won(price), (PANEL.x + 28, ry + 24), 13, SOFT, True)
                if not valid:
                    ui.draw_text(surf, "하한선 미달" if price < self.floor else "예정가격 초과", (px(price) + 8, ry + 4), 12, RED, True)
                elif win:
                    chip(surf, (px(price) + 8, ry, 54, 26), "낙찰", RED)
        for v, name, col in ((self.floor, "하한선", TEAL), (n["est"], "예정가격", RED)):
            pygame.draw.line(surf, col, (px(v), y + 14), (px(v), y + 250), 2)
            ui.draw_text(surf, name, (px(v), y - 2), 11, col, True, anchor="midtop")
        if self.phase_t > 1.6:
            won = self.today["won"]
            msg = "낙찰! 이제 납기 안에 만들어 내야 해요." if won else (
                "이번엔 놓쳤어요. 일반 거래처 주문으로 오늘을 채웁니다." if self.winner else "유효한 입찰이 없어 유찰됐어요.")
            ui.draw_text(surf, msg, (PANEL.x + 28, y + 276), 18, GREEN if won else INK, "heavy")
            ui.draw_text(surf, "※ 실제 낙찰 방식은 더 복잡해요. 게임에서는 단순하게 줄였습니다.", (PANEL.x + 28, y + 308), 12, SOFT, True)
            self.next_btn.draw(surf)

    def _draw_produce_ui(self, surf):
        n = self.pick
        card(surf, (WIDTH - 330, 20, 306, 124), 18)
        ui.draw_text(surf, f"{n['agency']} 납품", (WIDTH - 312, 30), 13, ORANGE, True)
        ui.draw_text(surf, f"{n['item']}", (WIDTH - 312, 48), 18, INK, "heavy")
        done = self.shipped + self.leaked
        ui.draw_text(surf, f"출하 {done} / {self.target}", (WIDTH - 312, 80), 14, INK, True)
        iso.bar(surf, (WIDTH - 312, 102, 270, 12), done / self.target, TEAL)
        hot = self.prod_left < 12
        ui.draw_text(surf, "연습: 제한 없음" if self.tutorial else f"납기 {int(self.prod_left)}초", (WIDTH - 42, 78), 16,
                     RED if hot else INK, "heavy", anchor="topright")
        iso.bar(surf, (WIDTH - 312, 120, 270, 8), self.prod_left / self.prod_total, RED if hot else GREEN)
        card(surf, (16, HEIGHT - 150, 400, 134), 18)
        ui.draw_text(surf, "라인 속도  (빠를수록 불량이 늘어요)", (30, HEIGHT - 138), 13, SOFT, True)
        for i, b in enumerate(self.speed_btns):
            b.rect.y = HEIGHT - 110
            if i == self.speed:
                pygame.draw.rect(surf, INK, b.rect.inflate(8, 8).move(0, 3), 3, border_radius=20)
            b.draw(surf)
        ui.draw_text(surf, f"빼낸 불량 {self.pulled}" + (f" (직원 {self.auto_pulled})" if self.auto_pulled else "")
                     + f"   새어 나간 불량 {self.leaked}", (30, HEIGHT - 40), 13,
                     RED if self.leaked else INK, True)
        chip(surf, (WIDTH // 2 - 190, HEIGHT - 52, 380, 36), "찌그러진 상자를 눌러서 빼내세요!", INK, size=15)

    def _draw_result(self, surf):
        t, n = self.today, self.pick
        over = max(0, t["leak"] - self.cfg["produce"]["leak_ok"])
        good = not t["late"] and not over
        y = self._panel(surf, "납품 완료!" if good else "납품은 했지만…", f"{n['agency']} 검수", GREEN if good else ORANGE)
        area = pygame.Rect(PANEL.x + 24, y, 190, 190)
        pygame.draw.rect(surf, (232, 244, 246), area, border_radius=16)
        clip = surf.get_clip()
        surf.set_clip(area)
        self.officer.draw(surf, (area.centerx, area.y + 22), scale=0.62)
        surf.set_clip(clip)
        case = n["shared"]
        who = f"{case['officer']['name']} {case['officer']['role']}" if case else "검수 담당자"
        ui.draw_text(surf, who, (area.x, area.bottom + 8), 12, SOFT, True)
        if good:
            line = case["thanks"] if case else "수량도 품질도 계약서 그대로네요. 수고하셨습니다!"
        elif t["late"]:
            line = "약속한 날짜를 넘기셨네요… 지체상금이 붙습니다."
        else:
            line = f"상자 {t['leak']}개가 찌그러져 있어요. 그만큼 대금에서 깎겠습니다."
        tx = area.right + 20
        ui.draw_wrapped(surf, f"“{line}”", (tx, y + 8, PANEL.right - 28 - tx, 120), 18, INK, True)
        rows = [("납기", "지연" if t["late"] else "준수", RED if t["late"] else GREEN),
                ("새어 나간 불량", f"{t['leak']}개", RED if over else GREEN),
                ("계약 대금", ui.won(t["paid"]), INK),
                ("감액·지체상금", "-" + ui.won(t["penalty"]) if t["penalty"] else "없음", RED if t["penalty"] else GREEN)]
        for i, (a, b, col) in enumerate(rows):
            ry = y + 240 + i * 34
            ui.draw_text(surf, a, (PANEL.x + 40, ry), 16, SOFT, True)
            ui.draw_text(surf, b, (PANEL.right - 40, ry - 2), 18, col, "heavy", anchor="topright")
        self.next_btn.draw(surf)

    def _draw_ledger(self, surf):
        t = self.today
        y = self._panel(surf, f"{self.day}일차 회사 장부", "오늘의 정산")
        if t["rejected"]:
            note = f"서류 반려({self.app.data.rules_by_id[t['rejected']]['short']})로 입찰에 참여하지 못했어요."
        elif not t["won"]:
            note = "낙찰받지 못한 날. 일반 거래처 주문으로 공장을 돌렸어요."
        else:
            note = f"{t['agency']}에 {t['item']} 납품!"
        ui.draw_wrapped(surf, note, (PANEL.x + 28, y, PANEL.w - 56, 40), 15, TEAL, True)
        rows = []
        if t["paid"]:
            rows.append(("계약 대금", t["paid"]))
        if t["side"]:
            rows.append(("일반 거래처 매출", t["side"]))
        if t["cost"]:
            rows.append(("원가 (재료·인건·운송)", -t["cost"]))
        if t["penalty"]:
            rows.append(("감액·지체상금", -t["penalty"]))
        rows += [(name, -v) for name, v in self.fixed_rows]
        yy = y + 50
        for name, v in rows:
            ui.draw_text(surf, name, (PANEL.x + 40, yy), 16, INK, True)
            ui.draw_text(surf, ("+" if v > 0 else "-") + ui.won(abs(v)), (PANEL.right - 40, yy - 1), 17, GREEN if v > 0 else RED, True,
                         anchor="topright")
            yy += 34
        pygame.draw.line(surf, (220, 230, 234), (PANEL.x + 40, yy + 4), (PANEL.right - 40, yy + 4), 3)
        ui.draw_text(surf, "오늘의 손익", (PANEL.x + 40, yy + 18), 18, INK, "heavy")
        ui.draw_text(surf, ("+" if t["net"] >= 0 else "-") + ui.won(abs(t["net"])), (PANEL.right - 40, yy + 12), 26,
                     GREEN if t["net"] >= 0 else RED, "heavy", anchor="topright")
        ui.draw_text(surf, f"통장  {ui.won(self.money_before)} → {ui.won(self.money)}", (PANEL.right - 40, yy + 54), 14, SOFT, True,
                     anchor="topright")
        self.next_btn.draw(surf)

    def _draw_end(self, surf):
        card(surf, (240, 70, 800, 590), 26)
        g, name = self.grade
        ui.draw_text(surf, f"납품하GO! 우리 공장 · {self.level['name']}", (WIDTH // 2, 100), 16, ORANGE, True, center=True)
        ui.draw_text(surf, "닷새의 결산" if not self.bad else "문 닫은 공장", (WIDTH // 2, 144), 38, INK, "heavy", center=True)
        pygame.draw.circle(surf, RED if self.bad else TEAL, (WIDTH // 2, 256), 64)
        ui.draw_text(surf, g, (WIDTH // 2, 254), 44 if self.bad else 64, PAPER, "heavy", center=True)
        ui.draw_text(surf, name, (WIDTH // 2, 346), 24, INK, "heavy", center=True)
        self.boss.draw(surf, (WIDTH // 2 - 250, 176), scale=0.5)          # 이 난이도의 사장
        wins = sum(1 for h in self.history if h["won"])
        rows = [("통장", ui.won(self.money)), ("신뢰도", str(self.trust)), ("공공 납품", f"{wins}건")]
        for i, (a, b) in enumerate(rows):
            x = WIDTH // 2 - 240 + i * 240
            ui.draw_text(surf, a, (x, 396), 14, SOFT, True, center=True)
            ui.draw_text(surf, b, (x, 426), 24, INK, "heavy", center=True)
        msg = ("담합은 함께 망하는 지름길입니다. 공정한 경쟁만이 공장을 지킵니다." if self.bad else
               "서류 한 장, 가격 한 줄, 상자 하나까지 — 정직하게 만든 물건이 세금을 값지게 씁니다.")
        ui.draw_wrapped(surf, msg, (WIDTH // 2 - 320, 478, 640, 60), 17, INK, True)
        lg = self.life_log
        ui.draw_text(surf, f"일하는 틈에 챙긴 일 {lg['solved']}건 · 미루다 터진 일 {lg['burst']}건", (WIDTH // 2, 534), 13,
                     RED if lg["burst"] else SOFT, True, center=True)
        ui.draw_text(surf, "창구 건너편 이야기는 ‘심사숙GO! 조달청’에서 이어집니다.", (WIDTH // 2, 556), 14, TEAL, True, center=True)
        self.next_btn.rect.center = (WIDTH // 2, 616)
        self.next_btn.draw(surf)

    def draw(self, surf):
        ph = self.phase
        if ph == END:
            self._draw_factory(surf, 0)
            veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            veil.fill((224, 238, 240, 150))
            surf.blit(veil, (0, 0))
            self._draw_end(surf)
            return
        self._draw_factory(surf, 0 if ph == PRODUCE else -250)
        if ph == PRODUCE:
            self._draw_produce_ui(surf)
        else:
            self.next_btn.rect.topleft = (PANEL.right - 250, PANEL.bottom - 76)
            {EVENT: self._draw_event, BOARD: self._draw_board, PRICE: self._draw_price, DOCS: self._draw_docs,
             WINDOW: self._draw_window, OPEN: self._draw_open, RESULT: self._draw_result, LEDGER: self._draw_ledger}[ph](surf)
        self._hud(surf)
        if self.tutorial:
            self._draw_tutorial(surf)
        if self.toast:
            w = min(WIDTH - 80, ui.fonts.get(15, True).size(self.toast[0])[0] + 44)
            chip(surf, ((WIDTH - w) // 2, 92 if ph == PRODUCE else HEIGHT - 44, w, 34), self.toast[0], INK, size=15)
        if self.life:
            self._draw_life(surf)
