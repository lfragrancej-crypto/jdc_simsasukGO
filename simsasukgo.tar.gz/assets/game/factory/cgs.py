"""납품하GO! 우리 공장의 이벤트 CG — 심사숙GO와 같은 CG 틀(game/cg.py)에 game="factory" 로 등록한다.

배역:  주인공(st.hero) = 그 난이도의 사장,  동료 자리(st.mate) = 채용한 직원.
정해진 때 나오는 CG(MILESTONES)와, 하루를 마칠 때 하나씩 나오는 CG(RANDOM)가 있다.
"""
import pygame

from .. import cg as C
from .. import props, ui
from ..cg import INK, Stage, cg
from ..config import HEIGHT, WIDTH

GAME = "factory"
MILESTONES = ("f_open", "f_firstwin", "f_hire", "f_refuse", "f_finale", "f_bad")
RANDOM = ("f_night", "f_truck", "f_snack")
TEAL, BOX = (72, 170, 196), (214, 170, 110)


def pick_random(run_seen, profile_seen, rng) -> str | None:
    pool = [c for c in RANDOM if c not in run_seen]
    if not pool:
        return None
    return rng.choices(pool, weights=[1.0 if c in profile_seen else 3.0 for c in pool])[0]


# ------------------------------------------------------------------ 배경
def front(s, mode="day", shutter=False):
    """공장 앞마당. mode: day / sunset / night"""
    top, bottom = {"day": ((130, 200, 250), (214, 238, 252)), "sunset": ((250, 170, 120), (255, 226, 170)),
                   "night": ((34, 38, 78), (86, 92, 140))}[mode]
    C.sky(s, top, bottom, 480)
    if mode == "night":
        pygame.draw.circle(s, (255, 244, 190), (1090, 100), 44)
        for x, y in ((120, 60), (300, 120), (520, 50), (760, 110), (960, 40), (1190, 200)):
            pygame.draw.circle(s, (255, 250, 220), (x, y), 3)
    else:
        pygame.draw.circle(s, (255, 242, 170), (1110, 96), 52)
        C.cloud(s, 60, 110, 130)
        C.cloud(s, 980, 190, 100)
    for i in range(4):                                           # 톱니 지붕
        pts = [(170 + i * 190, 152), (170 + i * 190, 72), (360 + i * 190, 152)]
        pygame.draw.polygon(s, (150, 196, 206), pts)
        pygame.draw.polygon(s, INK, pts, 4)
    wall = pygame.Rect(170, 150, 760, 332)
    props.box(s, wall, (214, 230, 234) if mode != "night" else (150, 166, 186), radius=6, shade=(184, 204, 210), offset=(7, 8))
    C.banner(s, (340, 168, 420, 62), "(주)한바퀴제작소", TEAL, 30)
    for x in (212, 782):                                         # 창
        w = pygame.Rect(x, 268, 106, 96)
        pygame.draw.rect(s, (255, 236, 160) if mode == "night" and not shutter else (236, 248, 252), w, border_radius=6)
        pygame.draw.rect(s, INK, w, 4, border_radius=6)
        pygame.draw.line(s, INK, (w.centerx, w.y), (w.centerx, w.bottom), 3)
    door = pygame.Rect(410, 262, 280, 220)
    if shutter:
        pygame.draw.rect(s, (176, 184, 196), door)
        for y in range(door.y + 18, door.bottom, 22):
            pygame.draw.line(s, (140, 148, 160), (door.x, y), (door.right, y), 3)
    else:
        pygame.draw.rect(s, (70, 82, 98), door)
        for i, (dx, dy) in enumerate(((40, 0), (120, 0), (200, 0), (80, -52), (160, -52))):
            r = pygame.Rect(door.x + dx, door.bottom - 56 + dy, 56, 50)
            pygame.draw.rect(s, BOX, r)
            pygame.draw.rect(s, INK, r, 3)
    pygame.draw.rect(s, INK, door, 5)
    C._ground(s, 482, (222, 214, 196) if mode != "night" else (120, 118, 130))
    C._tree(s, 1090, 484, 1.0, (120, 190, 110) if mode != "night" else (70, 110, 96))


def inside(s, night=False):
    """공장 안. 뒤쪽 벽에 창, 가운데 컨베이어."""
    s.fill((224, 236, 238) if not night else (120, 132, 160))
    for y in range(0, 430, 44):
        pygame.draw.line(s, (210, 224, 228) if not night else (108, 120, 148), (0, y), (WIDTH, y), 2)
    for x in (90, 420, 900):
        if night:
            C.night_window(s, (x, 70, 200, 150))
        else:
            props.draw_window(s, (x, 70, 200, 150), 4.0, 0.0)
    C._ground(s, 500, (236, 230, 216) if not night else (150, 146, 150))
    pygame.draw.line(s, (250, 196, 60), (0, 520), (WIDTH, 520), 6)                      # 안전선


def conveyor(s, y=400, boxes=(200, 470, 760, 1010), bad=None):
    belt = pygame.Rect(60, y, WIDTH - 120, 44)
    for x in range(120, WIDTH - 100, 250):
        pygame.draw.line(s, INK, (x, y + 40), (x - 24, y + 104), 8)
        pygame.draw.line(s, INK, (x, y + 40), (x + 24, y + 104), 8)
    props.box(s, belt, (86, 98, 112), radius=22, shade=(60, 70, 84), offset=(5, 6))
    for x in range(belt.x + 28, belt.right - 10, 46):
        pygame.draw.circle(s, (176, 184, 196), (x, belt.centery), 9)
        pygame.draw.circle(s, INK, (x, belt.centery), 9, 3)
    for i, x in enumerate(boxes):
        C.carton(s, x, y, 92, "A4" if i % 2 == 0 else "납품")
        if bad == i:
            pygame.draw.circle(s, (238, 92, 92), (x + 46, y - 70), 18)
            pygame.draw.circle(s, INK, (x + 46, y - 70), 18, 3)
            ui.draw_text(s, "!", (x + 46, y - 70), 22, (255, 255, 255), "heavy", center=True)


def truck(s, x, y):
    cargo = pygame.Rect(x, y - 210, 380, 180)
    props.box(s, cargo, (252, 252, 250), radius=8, shade=(220, 226, 230), offset=(6, 7))
    ui.draw_text(s, "한바퀴제작소", cargo.center, 30, TEAL, "heavy", center=True)
    cab = pygame.Rect(x + 384, y - 150, 130, 120)
    props.box(s, cab, (72, 142, 232), radius=10, shade=(50, 110, 196), offset=(6, 7))
    pygame.draw.rect(s, (214, 238, 250), (cab.x + 56, cab.y + 16, 60, 46), border_radius=6)
    pygame.draw.rect(s, INK, (cab.x + 56, cab.y + 16, 60, 46), 3, border_radius=6)
    for wx in (x + 80, x + 300, x + 450):
        pygame.draw.circle(s, INK, (wx, y - 18), 34)
        pygame.draw.circle(s, (176, 184, 196), (wx, y - 18), 14)


# ================================================================== 정해진 때 나오는 CG
@cg("f_open", "공장 문을 열다", "셔터를 올리는 손이 조금 떨렸다. 오늘부터 이 공장의 이름으로 입찰에 나선다.", slots=0, game=GAME)
def _open(st: Stage):
    s = st.s
    front(s, "day")
    C.carton(s, 300, 570, 104, "첫 주문")
    st.hero((560, 590), expr="happy", pose="cheer", scale=1.12, angle=-6, full=True, legs=(-16, 16), ground=604)
    C.speech(s, (700, 250, 400, 84), "좋아, 정직하게 한번 해 보는 거야!", (640, 380), 19)


@cg("f_firstwin", "첫 낙찰", "개찰 결과 맨 윗줄에 우리 공장 이름이 있었다. 몇 번을 다시 읽었다.", slots=1, game=GAME)
def _firstwin(st: Stage):
    s = st.s
    inside(s)
    C.whiteboard(s, (420, 60, 470, 250), ["1순위   (주)한바퀴제작소", "2순위   ○○산업", "3순위   △△테크"], "개찰 결과")
    C.banner(s, (930, 120, 250, 70), "낙찰!", (238, 92, 92), 40)
    st.hero((520, 548), expr="happy", pose="cheer", scale=1.16, angle=-10, full=True, legs=(-26, 26), ground=600)
    st.actor(st.mate(0), (880, 590), "happy", "clap", 1.0, 8, full=True, flip=True)
    C.confetti(s, 140, 8)


@cg("f_hire", "새 식구", "납품을 반듯하게 끝냈더니 일할 사람이 찾아왔다. 공장이 조금 더 시끌벅적해졌다.", slots=1, game=GAME)
def _hire(st: Stage):
    s = st.s
    inside(s)
    conveyor(s, 330, (240, 1040))
    C.bunting(s, 200, 1080, 20)
    C.banner(s, (430, 120, 420, 70), "환영합니다!", TEAL, 36)
    st.hero((470, 600), expr="happy", pose="wave", scale=1.1, angle=-4, full=True)
    st.actor(st.mate(0), (810, 600), "happy", "hi", 1.1, 6, full=True, flip=True)
    C.carton(s, 1090, 610, 100, "입사 선물")


@cg("f_refuse", "거절", "가격을 맞추자는 제안이었다. 문을 닫고 나니 손이 떨렸지만, 발걸음은 가벼웠다.", slots=0, game=GAME)
def _refuse(st: Stage):
    s = st.s
    front(s, "night")
    shady = next((c["look"] for c in st.data.companies if c["name"] == st.data.factory["collusion"]["who"]),
                 {"body": "#555566", "shape": "tall", "ears": "none", "acc": ["sunglasses"]})
    st.hero((500, 596), expr="neutral", pose="hip", scale=1.12, angle=-3, full=True)
    st.actor(shady, (960, 600), "shocked", "shock", 1.06, 10, full=True, flip=True)
    C.speech(s, (30, 262, 380, 84), "그런 얘기는 못 들은 걸로 하겠습니다.", (440, 370), 19)


@cg("f_finale", "닷새의 끝", "닷새 동안 서류를 꾸리고, 값을 쓰고, 상자를 날랐다. 다 같이 공장 앞에서 사진을 찍었다.", slots=3, game=GAME)
def _finale(st: Stage):
    s = st.s
    front(s, "sunset")
    C.bunting(s, 120, 1160, 24, 44)
    st.actor(st.mate(1), (300, 600), "happy", "wave", 0.96, -6, full=True)
    st.actor(st.mate(0), (880, 604), "happy", "cheer", 1.0, 7, full=True, flip=True)
    st.actor(st.mate(2), (1080, 596), "happy", "hi", 0.92, 5, full=True, flip=True)
    st.hero((590, 600), expr="happy", pose="cheer", scale=1.16, angle=-4, full=True, legs=(-14, 14), ground=612)
    C.carton(s, 150, 610, 100, "납품 완료")
    C.confetti(s, 150, 4)


@cg("f_bad", "닫힌 셔터", "짜고 써낸 가격은 금세 들통났다. 셔터에 붙은 종이 한 장이 모든 것을 말해 준다.", slots=0, game=GAME)
def _bad(st: Stage):
    s = st.s
    front(s, "night", shutter=True)
    note = pygame.Surface((230, 150), pygame.SRCALPHA)
    pygame.draw.rect(note, (255, 253, 247), (3, 3, 224, 144), border_radius=6)
    pygame.draw.rect(note, INK, (3, 3, 224, 144), 4, border_radius=6)
    ui.draw_text(note, "입찰참가자격", (115, 40), 26, (226, 76, 76), "heavy", center=True)
    ui.draw_text(note, "제한", (115, 78), 34, (226, 76, 76), "heavy", center=True)
    ui.draw_text(note, "사유: 입찰 담합", (115, 122), 15, INK, True, center=True)
    note = pygame.transform.rotozoom(note, 5, 1.0)
    s.blit(note, note.get_rect(center=(550, 370)))
    st.hero((900, 600), expr="sad", pose="slump", scale=1.1, angle=-8, full=True, flip=True)


# ================================================================== 하루를 마칠 때 하나씩 나오는 CG
@cg("f_night", "납기 전날 밤", "창밖은 깜깜한데 컨베이어는 아직 돈다. 약속한 날짜는 지켜야 하니까.", slots=2, game=GAME)
def _night(st: Stage):
    s = st.s
    inside(s, night=True)
    for x in (300, 640, 980):
        C.lamp(s, x, 150)
    conveyor(s, 380, (190, 420, 650, 880, 1100), bad=2)
    st.actor(st.mate(0), (250, 610), "nervous", "point", 0.96, -5, full=True)
    st.hero((640, 614), expr="nervous", pose="shrug", scale=1.1, angle=3, full=True)
    st.actor(st.mate(1), (1020, 610), "happy", "hi", 0.96, 6, full=True, flip=True)
    C.banner(s, (980, 40, 240, 60), "납기 D-1", (238, 92, 92), 30)


@cg("f_truck", "납품 가는 길", "상자를 가득 싣고 학교로 간다. 기다리는 사람이 있다는 건 꽤 든든한 일이다.", slots=1, game=GAME)
def _truck(st: Stage):
    s = st.s
    C.sky(s, (130, 200, 250), (214, 238, 252), 470)
    pygame.draw.circle(s, (255, 242, 170), (150, 100), 50)
    C.cloud(s, 420, 120, 140)
    C.cloud(s, 900, 80, 110)
    pygame.draw.rect(s, (150, 206, 130), (0, 400, WIDTH, 80))
    for x in (80, 1180):
        C._tree(s, x, 440, 0.9)
    school = pygame.Rect(860, 190, 300, 260)                      # 저 멀리 학교
    props.box(s, school, (255, 240, 214), radius=6, shade=(236, 214, 180), offset=(6, 7))
    C.banner(s, (890, 206, 240, 50), st.data.case_of(1)["agency"], (255, 138, 92), 24)
    for i in range(6):
        w = pygame.Rect(884 + (i % 3) * 88, 280 + (i // 3) * 76, 60, 50)
        pygame.draw.rect(s, (214, 238, 250), w, border_radius=4)
        pygame.draw.rect(s, INK, w, 3, border_radius=4)
    C._ground(s, 470, (176, 180, 190))
    for x in range(40, WIDTH, 160):
        pygame.draw.rect(s, (255, 253, 247), (x, 580, 80, 12))
    truck(s, 150, 560)
    st.actor(st.mate(0), (150, 640), "happy", "wave", 0.9, -5, full=True)
    st.hero((720, 640), expr="happy", pose="hi", scale=1.0, angle=4, full=True)
    st.actor(st.data.case_of(1)["officer"]["look"], (1010, 640), "happy", "cheer", 1.0, 6, full=True, flip=True)


@cg("f_snack", "새참 시간", "기계를 잠깐 세우고 마당에 둘러앉았다. 일은 고돼도 떡볶이는 맛있다.", slots=3, game=GAME)
def _snack(st: Stage):
    s = st.s
    front(s, "day")
    C.table(s, (470, 520, 340, 36))
    C.snack_plate(s, 540, 520)
    C.snack_plate(s, 700, 524)
    C.cup(s, 620, 520, (72, 170, 196))
    st.actor(st.mate(0), (300, 620), "happy", "clap", 0.98, -6, full=True)
    st.actor(st.mate(2), (160, 600), "happy", "hi", 0.84, -4, full=True)
    st.hero((640, 660), expr="happy", pose="cheer", scale=1.08, angle=0, full=True)
    st.actor(st.mate(1), (980, 620), "happy", "wave", 0.98, 7, full=True, flip=True)
    _ = HEIGHT
