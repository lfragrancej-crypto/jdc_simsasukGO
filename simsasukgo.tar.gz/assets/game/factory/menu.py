"""납품하GO! 우리 공장 — 시작 화면: 새로 시작(난이도 선택) / 이어하기."""
import math

import pygame

from .. import ui
from ..config import HEIGHT, WIDTH
from ..scenes.base import Scene
from . import scene as F
from .iso import GREEN, INK, ORANGE, PAPER, SOFT, TEAL, Btn, card, chip, shade


class FactoryTitleScene(Scene):
    BGM = "factory"
    HOME = "hub"

    def __init__(self, app):
        super().__init__(app)
        self.t = 0.0
        self.picking = False             # 난이도를 고르는 중인가
        self.levels = app.data.factory["levels"]
        self.saved = F.load_save(app)
        cx = WIDTH // 2
        self.new_btn = Btn((cx - 290, 400, 280, 62), "새로 시작", ORANGE, 22)
        self.cont_btn = Btn((cx + 10, 400, 280, 62), "이어하기", TEAL, 22)
        self.cont_btn.enabled = self.saved is not None
        self.back_btn = Btn((cx - 100, 600, 200, 50), "처음으로", (150, 160, 166), 17)

    def _level_rect(self, i):
        return pygame.Rect(130 + i * 350, 330, 320, 240)

    def start(self, i: int):
        F.delete_save(self.app)
        self.app.start_factory(self.levels[i])

    def resume(self):
        if self.saved:
            self.app.start_factory(self.saved["level"], self.saved)

    def handle_event(self, event):
        if self.picking:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i in range(len(self.levels)):
                    if self._level_rect(i).collidepoint(event.pos):
                        self.start(i)
                        return
            if self.back_btn.clicked(event):
                self.picking = False
        elif self.new_btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self.picking = True
        elif self.cont_btn.clicked(event):
            self.resume()
        elif self.back_btn.clicked(event):
            self.app.to_hub()

    def update(self, dt):
        self.t += dt
        for b in (self.new_btn, self.cont_btn, self.back_btn):
            b.update(dt)

    def draw(self, surf):
        bg, _ = F.background()
        surf.blit(bg, (0, 0))
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((224, 238, 240, 120))
        surf.blit(veil, (0, 0))
        card(surf, (WIDTH // 2 - 380, 60, 760, 230), 28)
        ui.draw_text(surf, "다함께! 조달 한바퀴  ·  파는 쪽 이야기", (WIDTH // 2, 92), 15, SOFT, True, center=True)
        f = ui.fonts.get(76, "heavy")
        a, b = f.render("납품하", True, INK), f.render("GO!", True, ORANGE)
        x = WIDTH // 2 - (a.get_width() + b.get_width()) // 2
        surf.blit(a, (x, 110))
        surf.blit(f.render("GO!", True, shade(ORANGE, 0.72)), (x + a.get_width() + 3, 115 + abs(math.sin(self.t * 3.2)) * -8))
        surf.blit(b, (x + a.get_width(), 110 + abs(math.sin(self.t * 3.2)) * -8))
        chip(surf, (WIDTH // 2 - 80, 204, 160, 36), "우리 공장", TEAL, size=20)
        ui.draw_text(surf, "정직하게 만든 물건이 세금을 값지게 쓴다", (WIDTH // 2, 262), 17, INK, True, center=True)
        if not self.picking:
            self.new_btn.draw(surf)
            self.cont_btn.draw(surf)
            if self.saved:
                s = self.saved
                text = f"이어하기: {s['level']['name']} · {s['day_i'] + 1}일차 아침 · 통장 {ui.won(s['money'])}"
                w = ui.fonts.get(13, True).size(text)[0] + 28
                chip(surf, (WIDTH // 2 - w // 2, 478, w, 28), text, PAPER, INK, 13)
        else:
            chip(surf, (WIDTH // 2 - 80, 292, 160, 30), "난이도 선택", INK, size=15)
            mouse = pygame.mouse.get_pos()
            rec = self.app.profile.data.get("factory", {}).get("levels", {})
            for i, lv in enumerate(self.levels):
                r = self._level_rect(i)
                hot = r.collidepoint(mouse)
                r = r.move(0, -6 if hot else 0)
                col = tuple(lv["color"])
                card(surf, r, 22)
                pygame.draw.rect(surf, col, (r.x, r.y, r.w, 70), border_top_left_radius=22, border_top_right_radius=22)
                ui.draw_text(surf, lv["name"], (r.centerx, r.y + 36), 26, PAPER, "heavy", center=True)
                chip(surf, (r.centerx - 70, r.y + 84, 140, 26), lv["tag"], shade(col, 0.85), size=13)
                ui.draw_wrapped(surf, lv["desc"], (r.x + 22, r.y + 124, r.w - 44, 80), 14, INK, True)
                if lv.get("tutorial"):
                    chip(surf, (r.x + 22, r.bottom - 40, 104, 26), "튜토리얼 포함", ORANGE, size=12)
                if lv["id"] in rec:
                    chip(surf, (r.right - 112, r.bottom - 40, 90, 26), f"클리어 {rec[lv['id']]}", GREEN, size=12)
        self.back_btn.label = "뒤로" if self.picking else "처음으로"
        self.back_btn.draw(surf)
