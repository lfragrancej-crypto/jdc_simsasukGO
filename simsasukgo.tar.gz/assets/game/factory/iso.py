"""아이소메트릭(비스듬히 내려다본) 그리기 도구 — 납품하GO! 우리 공장의 그림체.

심사숙GO(굵은 외곽선의 손그림풍)와 일부러 다르게: 외곽선 없이 면 세 개의 밝기 차이로 입체를 만들고,
화면은 흰 카드와 납작한 버튼으로 깔끔하게.
"""
import pygame

try:                                    # 웹 빌드에 gfxdraw 가 없을 때를 대비
    import pygame.gfxdraw as gfx
except Exception:                       # pragma: no cover
    gfx = None

from .. import sfx, ui

TW, TH, ZH = 46, 23, 30                 # 칸 하나의 가로·세로 반폭, 높이 1의 픽셀
INK = (40, 56, 66)
SOFT = (120, 136, 146)
TEAL = (72, 170, 196)
ORANGE = (250, 140, 70)
GREEN = (110, 190, 124)
RED = (236, 96, 80)
YELLOW = (250, 196, 60)
BLUE = (72, 142, 232)
PAPER = (255, 255, 255)
BOXCOL = (214, 170, 110)


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


class View:
    """격자 좌표 → 화면 좌표. scale=2 로 그려 두고 줄이면 가장자리가 매끈해진다."""

    def __init__(self, origin=(600, 150), scale=1):
        self.ox, self.oy, self.s = origin[0], origin[1], scale

    def pt(self, gx, gy, gz=0.0):
        return ((self.ox + (gx - gy) * TW) * self.s, (self.oy + (gx + gy) * TH - gz * ZH) * self.s)

    def poly(self, surf, color, pts):
        pts = [(int(x), int(y)) for x, y in pts]
        if gfx is None:
            pygame.draw.polygon(surf, color, pts)
            return
        gfx.filled_polygon(surf, pts, color)
        if self.s == 1:
            gfx.aapolygon(surf, pts, color)

    def cube(self, surf, gx, gy, w, d, h, col, z=0.0, top=None):
        p = self.pt
        a, b, c, e = p(gx, gy, z + h), p(gx + w, gy, z + h), p(gx + w, gy + d, z + h), p(gx, gy + d, z + h)
        f, g, i = p(gx, gy + d, z), p(gx + w, gy + d, z), p(gx + w, gy, z)
        self.poly(surf, shade(col, 0.80), [e, c, g, f])
        self.poly(surf, shade(col, 0.62), [c, b, i, g])
        self.poly(surf, top or shade(col, 1.08), [a, b, c, e])

    def tile(self, surf, gx, gy, col, w=1, d=1, z=0.0):
        p = self.pt
        self.poly(surf, col, [p(gx, gy, z), p(gx + w, gy, z), p(gx + w, gy + d, z), p(gx, gy + d, z)])

    def worker(self, surf, gx, gy, col, bob=0.0, helmet=YELLOW):
        x, y = self.pt(gx, gy)
        s = self.s
        pygame.draw.ellipse(surf, (176, 186, 182), (x - 13 * s, y - 5 * s, 26 * s, 11 * s))
        y -= bob * s
        pygame.draw.rect(surf, col, (x - 9 * s, y - 30 * s, 18 * s, 28 * s), border_radius=9 * s)
        pygame.draw.circle(surf, (255, 224, 196), (int(x), int(y - 38 * s)), 9 * s)
        pygame.draw.circle(surf, helmet, (int(x), int(y - 41 * s)), 9 * s, draw_top_left=True, draw_top_right=True)
        pygame.draw.rect(surf, helmet, (x - 11 * s, y - 43 * s, 22 * s, 3 * s), border_radius=s)


# ---------------------------------------------------------------------- 화면 부품 (흰 카드 · 납작한 버튼)
_shadow_cache: dict = {}


def card(surf, rect, radius=18, color=PAPER):
    r = pygame.Rect(rect)
    key = (r.w, r.h, radius)
    if key not in _shadow_cache:
        if len(_shadow_cache) > 80:
            _shadow_cache.clear()
        sh = pygame.Surface((r.w + 40, r.h + 40), pygame.SRCALPHA)
        pygame.draw.rect(sh, (40, 80, 90, 46), (20, 26, r.w, r.h), border_radius=radius)
        small = pygame.transform.smoothscale(sh, (max(1, sh.get_width() // 8), max(1, sh.get_height() // 8)))
        _shadow_cache[key] = pygame.transform.smoothscale(small, sh.get_size())
    surf.blit(_shadow_cache[key], (r.x - 20, r.y - 20))
    pygame.draw.rect(surf, color, r, border_radius=radius)
    return r


def chip(surf, rect, text, color, text_color=PAPER, size=13):
    r = pygame.Rect(rect)
    pygame.draw.rect(surf, color, r, border_radius=r.h // 2)
    ui.draw_text(surf, text, r.center, size, text_color, True, center=True)
    return r


def bar(surf, rect, ratio, color, back=(232, 240, 242)):
    r = pygame.Rect(rect)
    pygame.draw.rect(surf, back, r, border_radius=r.h // 2)
    w = int(r.w * max(0.0, min(1.0, ratio)))
    if w > r.h // 2:
        pygame.draw.rect(surf, color, (r.x, r.y, w, r.h), border_radius=r.h // 2)


class Btn:
    """납작한 버튼. 아래쪽에 한 톤 어두운 턱이 있어 눌리는 느낌이 난다."""

    def __init__(self, rect, label, color=ORANGE, size=19):
        self.rect = pygame.Rect(rect)
        self.label, self.color, self.size = label, color, size
        self.enabled = True
        self.down = 0.0

    def clicked(self, event) -> bool:
        if (self.enabled and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
                and self.rect.collidepoint(event.pos)):
            self.down = 0.12
            sfx.play("click", 0.5)
            return True
        return False

    def update(self, dt):
        self.down = max(0.0, self.down - dt)

    def draw(self, surf):
        col = self.color if self.enabled else (196, 204, 208)
        hot = self.enabled and self.rect.collidepoint(pygame.mouse.get_pos())
        if hot:
            col = shade(col, 1.07)
        push = 4 if self.down > 0 else 0
        r = self.rect.move(0, push)
        pygame.draw.rect(surf, shade(col, 0.72), self.rect.move(0, 6), border_radius=18)
        pygame.draw.rect(surf, col, r, border_radius=18)
        ui.draw_text(surf, self.label, r.center, self.size, PAPER, "heavy", center=True)
