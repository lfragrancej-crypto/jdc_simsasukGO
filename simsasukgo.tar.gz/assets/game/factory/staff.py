"""납품하GO! 직원 뽑기 — 공공 납품을 완벽하게 해내면 '채용 봉투'에서 직원 한 명이 온다 (최대 3명).

심사숙GO의 동료 뽑기(game/gacha.py, 봉투 연출은 scenes/gacha.py)를 그대로 쓰되, 명단과 기술만 공장용이다.
직원 명단은 data/staff.json. 기술마다 숙련도 S·A·B·C.
  docs     서류 달인   서류 꾸리기에서 틀린 보기를 미리 지워 준다
  qc       검사 고수   검사대를 지나는 불량 상자를 대신 빼낸다
  sales    영업 담당   경쟁 업체가 쓸 값을 미리 알아 온다
  craft    숙련공     불량이 덜 나온다
  account  살림꾼     원가를 아낀다
"""
from .. import gacha

MAX_STAFF = 3
SKILLS = {
    "docs": {"name": "서류 달인", "C": {"chance": 0.4}, "B": {"chance": 0.6}, "A": {"chance": 0.8}, "S": {"chance": 1.0}},
    "qc": {"name": "검사 고수", "C": {"chance": 0.25}, "B": {"chance": 0.4}, "A": {"chance": 0.6}, "S": {"chance": 0.8}},
    "sales": {"name": "영업 담당", "C": {"n": 1}, "B": {"n": 1}, "A": {"n": 2}, "S": {"n": 3}},
    "craft": {"name": "숙련공", "C": {"cut": 0.15}, "B": {"cut": 0.25}, "A": {"cut": 0.40}, "S": {"cut": 0.55}},
    "account": {"name": "살림꾼", "C": {"cut": 0.02}, "B": {"cut": 0.04}, "A": {"cut": 0.06}, "S": {"cut": 0.09}},
}
RARITY_TITLE = {"R": "새 직원", "SR": "우수 직원", "SSR": "특급 직원"}


def describe(skill: str, grade: str) -> str:
    p = SKILLS[skill][grade]
    if skill == "docs":
        return f"서류의 틀린 보기를 지워 줌 · 항목마다 {int(p['chance'] * 100)}%"
    if skill == "qc":
        return f"검사대에서 불량 상자를 대신 빼냄 · {int(p['chance'] * 100)}%"
    if skill == "sales":
        return f"경쟁 업체 {p['n']}곳의 투찰가를 미리 알아 옴"
    if skill == "craft":
        return f"불량이 {int(p['cut'] * 100)}% 덜 나옴"
    return f"원가 {int(p['cut'] * 100)}% 절감"


def perks(staff: list[dict]) -> dict:
    """기술 → (숙련도, 수치, 담당 직원). 같은 기술이 겹치면 숙련도가 높은 쪽."""
    out = {}
    for m in staff:
        for s in m["skills"]:
            cur = out.get(s["type"])
            if cur is None or gacha.GRADE_ORDER.index(s["grade"]) > gacha.GRADE_ORDER.index(cur[0]):
                out[s["type"]] = (s["grade"], SKILLS[s["type"]][s["grade"]], m)
    return out


def kit(app, scene, on_done) -> dict:
    """scenes/gacha.py 의 봉투 연출에 넘겨 줄 '공장용 한 벌'."""
    data = app.data.staff

    def mark(member_id):
        from .scene import record
        rec = record(app)
        rec["staff"][member_id] = rec["staff"].get(member_id, 0) + 1
        app.profile.save()

    from .scene import record
    return {"team": scene.staff, "roster": data["roster"], "say": data["skills"], "skills": SKILLS, "describe": describe,
            "seen": set(record(app)["staff"]), "mark": mark, "first_skill": None, "banner": "신규 채용!",
            "card": "새 직원 합류!", "titles": RARITY_TITLE, "button": "함께 만들어요 ", "done": on_done}
