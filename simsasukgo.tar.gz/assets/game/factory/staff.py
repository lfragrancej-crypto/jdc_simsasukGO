"""납품하GO! 직원 뽑기 — 공공 납품을 완벽하게 해내면 '채용 봉투'에서 직원 한 명이 온다 (최대 3명).

심사숙GO의 동료 뽑기(game/gacha.py, 봉투 연출은 scenes/gacha.py)를 그대로 쓰되, 명단과 기술만 공장용이다.
직원 명단은 data/staff.json. 기술마다 숙련도 S·A·B·C.
  tidy     서류 정리   책상에 흩어진 서류를 가지런히 펼쳐 준다
  check    꼼꼼 확인   봉투에 빠진 서류가 있으면 내기 전에 말해 준다
  mark     형광펜     꼭 챙겨야 하는 서류에 표시를 해 준다
  qc       검사 고수   실수로 누른 불량 상자를 대신 걸러 준다
  sales    영업 담당   경쟁 업체가 쓸 값을 미리 알아 온다
  craft    숙련공     박자 판정이 넉넉해진다 (조금 어긋나게 눌러도 맞은 것으로)
  account  살림꾼     원가를 아낀다
"""
from .. import gacha

MAX_STAFF = 3
SKILLS = {
    "tidy": {"name": "서류 정리", "C": {"delay": 10}, "B": {"delay": 5}, "A": {"delay": 2}, "S": {"delay": 0}},
    "check": {"name": "꼼꼼 확인", "C": {"chance": 0.5}, "B": {"chance": 0.7}, "A": {"chance": 0.85}, "S": {"chance": 1.0}},
    "mark": {"name": "형광펜", "C": {"n": 1}, "B": {"n": 2}, "A": {"n": 3}, "S": {"n": 99}},
    "qc": {"name": "검사 고수", "C": {"chance": 0.3}, "B": {"chance": 0.5}, "A": {"chance": 0.7}, "S": {"chance": 0.9}},
    "sales": {"name": "영업 담당", "C": {"n": 1}, "B": {"n": 1}, "A": {"n": 2}, "S": {"n": 3}},
    "craft": {"name": "숙련공", "C": {"wide": 0.15}, "B": {"wide": 0.25}, "A": {"wide": 0.40}, "S": {"wide": 0.60}},
    "account": {"name": "살림꾼", "C": {"cut": 0.02}, "B": {"cut": 0.04}, "A": {"cut": 0.06}, "S": {"cut": 0.09}},
}
RARITY_TITLE = {"R": "새 직원", "SR": "우수 직원", "SSR": "특급 직원"}


def describe(skill: str, grade: str) -> str:
    p = SKILLS[skill][grade]
    if skill == "tidy":
        return "흩어진 서류를 바로 가지런히 정리" if p["delay"] <= 0 else f"흩어진 서류를 {p['delay']}초 뒤 가지런히 정리"
    if skill == "check":
        return f"빠진 서류가 있으면 내기 전에 알려 줌 · {int(p['chance'] * 100)}%"
    if skill == "mark":
        return "꼭 챙길 서류 전부에 표시" if p["n"] > 9 else f"꼭 챙길 서류 {p['n']}장에 표시"
    if skill == "qc":
        return f"실수로 누른 불량 상자를 대신 걸러 줌 · {int(p['chance'] * 100)}%"
    if skill == "sales":
        return f"경쟁 업체 {p['n']}곳의 투찰가를 미리 알아 옴"
    if skill == "craft":
        return f"박자 판정이 {int(p['wide'] * 100)}% 넉넉해짐"
    return f"원가 {int(p['cut'] * 100)}% 절감"


def perks(staff: list[dict]) -> dict:
    """기술 → (숙련도, 수치, 담당 직원). 같은 기술이 겹치면 숙련도가 높은 쪽."""
    out = {}
    for m in staff:
        for s in m["skills"]:
            cur = out.get(s["type"])
            if cur is None or gacha.GRADE_ORDER.index(s["grade"]) > gacha.GRADE_ORDER.index(cur[0]):
                out[s["type"]] = (s["grade"], SKILLS[s["type"]][s["grade"]], m)
    return out


def kit(app, scene, on_done) -> dict:
    """scenes/gacha.py 의 봉투 연출에 넘겨 줄 '공장용 한 벌'."""
    data = app.data.staff

    def mark(member_id):
        from .scene import record
        rec = record(app)
        rec["staff"][member_id] = rec["staff"].get(member_id, 0) + 1
        app.profile.save()

    from .scene import record
    return {"team": scene.staff, "roster": data["roster"], "say": data["skills"], "skills": SKILLS, "describe": describe,
            "seen": set(record(app)["staff"]), "mark": mark, "first_skill": None, "banner": "신규 채용!",
            "card": "새 직원 합류!", "titles": RARITY_TITLE, "button": "함께 만들어요 ", "done": on_done}
