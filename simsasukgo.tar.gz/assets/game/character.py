"""둥글둥글한 캐릭터를 코드로 그린다 (이미지 에셋 없이 동작).

look = {"body": "#hex", "shape": "round|bean|tall", "ears": "bear|cat|rabbit|none", "acc": [...]}
acc: glasses, sunglasses, mustache, tie, bowtie, hardhat, beret, headset, bow, sprout, gift, idcard(주인공),
     crown(SSR 동료), halo·wings(천사 팀장), horns(악덕 팀장)
expression: neutral, happy, nervous, sad, shocked, sly, mean(심술)

2배 크기로 그린 뒤 smoothscale 로 줄여 가장자리를 부드럽게(안티에일리어싱) 만든다.
나중에 AI 생성 이미지로 교체할 때는 Character.render() 만 바꾸면 된다.
"""
import math
import random

import pygame

W, H = 220, 260          # 화면에 그려지는 크기
SS = 2                   # 슈퍼샘플링 배율
OUT = (74, 52, 40)       # 외곽선(진한 갈색)
LW = 7                   # 외곽선 두께(2배 좌표)
BLUSH = (255, 140, 150)
MOUTH = (160, 62, 62)
TONGUE = (240, 120, 120)


def hex2rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _ellipse(s, color, rect, outline=True):
    if outline:
        pygame.draw.ellipse(s, OUT, pygame.Rect(rect).inflate(LW * 2, LW * 2))
    pygame.draw.ellipse(s, color, rect)


def _poly(s, color, pts, outline=True):
    pygame.draw.polygon(s, color, pts)
    if outline:
        pygame.draw.polygon(s, OUT, pts, LW)


# 팔 각도(도): 0 = 아래로 늘어뜨림, 90 = 옆으로, 180 = 머리 위로   (왼팔, 오른팔)
POSES = {
    "idle": (16, 16), "wave": (16, 138), "cheer": (136, 136), "shock": (108, 108), "slump": (0, 0),
    "point": (16, 96), "hold": (60, 60), "shrug": (74, 74), "hip": (46, 46), "run": (76, -34),
    "hi": (138, 16), "clap": (96, 96),
}
FULL_BOTTOM = 440        # 전신 그림에서 몸통이 끝나는 높이(2배 좌표)


class Character:
    """둥근 몸 + '-o' 모양의 간단한 팔다리.

    pose   : POSES 의 이름. update() 가 팔을 부드럽게 그 자세로 옮긴다 (set_pose(snap=True) 는 즉시).
    full   : render/draw 에 full=True 를 주면 다리까지 있는 전신 (CG 용). 기본은 카운터 뒤 상반신.
    angle  : draw 에 각도를 주면 몸 전체가 기운다 — 걷기·점프·졸기 같은 역동적인 연출용.
    """

    def __init__(self, look: dict, seed: int | None = None):
        self.look = look
        self.body = hex2rgb(look.get("body", "#F7C59F"))
        self.shape = look.get("shape", "round")
        self.ears = look.get("ears", "none")
        self.acc = set(look.get("acc", []))
        self.expression = "neutral"
        rng = random.Random(seed)
        self.t = rng.random() * 10
        self.blink_in = rng.uniform(1.5, 4.0)
        self.blink = 0.0
        self.talking = False
        self.pose = "idle"
        self.arm = list(POSES["idle"])
        self.legs = (0, 0)                 # 전신일 때 다리 벌림(왼, 오른)
        self._full = False

    @property
    def voice(self) -> str:
        """말소리 높낮이: 키 큰 체형은 낮게, 동글한 체형은 높게. look 에 'voice' 가 있으면 우선."""
        return self.look.get("voice") or {"tall": "low", "round": "mid", "bean": "high"}.get(self.shape, "mid")

    # ------------------------------------------------------------ 애니메이션
    def set_pose(self, pose: str, snap: bool = False):
        self.pose = pose if pose in POSES else "idle"
        if snap:
            self.arm = list(POSES[self.pose])

    def update(self, dt: float):
        self.t += dt
        if self.blink > 0:
            self.blink -= dt
        else:
            self.blink_in -= dt
            if self.blink_in <= 0:
                self.blink = 0.13
                self.blink_in = random.uniform(2.0, 4.5)
        target = POSES.get(self.pose, POSES["idle"])
        k = min(1.0, dt * 11)
        self.arm[0] += (target[0] - self.arm[0]) * k
        self.arm[1] += (target[1] - self.arm[1]) * k

    def draw(self, surf, midtop, scale=1.0, bob=True, flip=False, angle=0.0, full=False):
        img = self.render(full)
        if flip:
            img = pygame.transform.flip(img, True, False)
        squash = 1.0
        oy = 0
        if bob:
            oy = math.sin(self.t * 2.4) * 4
            squash = 1 + math.sin(self.t * 2.4) * 0.012
        if scale != 1.0 or squash != 1.0:
            img = pygame.transform.smoothscale(img, (int(W * scale / squash), int(H * scale * squash)))
        base = img.get_rect(midtop=(midtop[0], midtop[1] + oy))
        if angle:
            img = pygame.transform.rotozoom(img, angle, 1.0)
        rect = img.get_rect(center=base.center)
        surf.blit(img, rect)
        return base

    # ------------------------------------------------------------ 그리기
    def render_hi(self, full: bool = False) -> pygame.Surface:
        """2배 해상도 원본 (아이콘 등 큰 이미지용)."""
        self._full = full
        s = pygame.Surface((W * SS, H * SS), pygame.SRCALPHA)
        cx = W * SS // 2
        bw, top = {"round": (300, 150), "bean": (280, 130), "tall": (250, 100)}.get(self.shape, (300, 150))
        face_y = top + 130
        body = self.body
        front_arms = self.pose in ("hold", "clap")

        self._ears(s, cx, top, bw)
        if not front_arms:
            self._arms(s, cx, face_y, bw)
        if full:
            self._legs(s, cx)
            rect = pygame.Rect(cx - bw // 2, top, bw, FULL_BOTTOM - top)
            radius = min(bw // 2, rect.h // 2)
            belly_h = FULL_BOTTOM - (face_y + 70) - 12
        else:                               # 상반신: 아래쪽은 화면 밖/카운터 뒤로 잘린다
            rect = pygame.Rect(cx - bw // 2, top, bw, H * SS - top + 200)
            radius = bw // 2
            belly_h = 260
        pygame.draw.rect(s, OUT, rect.inflate(LW * 2, LW * 2), border_radius=radius + LW)
        pygame.draw.rect(s, body, rect, border_radius=radius)
        belly = mix(body, (255, 255, 255), 0.35)
        pygame.draw.ellipse(s, belly, (cx - bw * 0.32, face_y + (70 if full else 90), bw * 0.64, belly_h))

        if "whiteface" in self.acc:                             # 달이: 얼굴 아래쪽과 배가 하얗다
            pygame.draw.ellipse(s, (255, 252, 246), (cx - bw * 0.43, face_y - 26, bw * 0.86, 150))
            pygame.draw.ellipse(s, (255, 252, 246), (cx - bw * 0.27, face_y + (96 if full else 120), bw * 0.54,
                                                     min(belly_h, 190)))
        if "stripes" in self.acc:                               # 달이: 이마의 줄무늬 세 줄
            dark = mix(body, (196, 84, 40), 0.75)
            for dx, h in ((-44, 46), (0, 60), (44, 46)):
                pygame.draw.line(s, dark, (cx + dx, top + 12), (cx + dx, top + 12 + h), 16)
                pygame.draw.circle(s, dark, (cx + dx, top + 12 + h), 8)
        if "backpack" in self.acc:                              # 달이: 배낭 끈
            for side in (-1, 1):
                pygame.draw.line(s, OUT, (cx + side * bw * 0.36, face_y + 108), (cx + side * bw * 0.30, face_y + 200), 22)
                pygame.draw.line(s, (150, 96, 60), (cx + side * bw * 0.36, face_y + 108),
                                 (cx + side * bw * 0.30, face_y + 200), 12)
        self._clothes(s, cx, face_y, bw)
        self._face(s, cx, face_y, bw)
        self._hats(s, cx, top, bw, face_y)
        if "gift" in self.acc:
            self._gift(s, cx + int(bw * 0.18), face_y + 95)
        if front_arms:
            self._arms(s, cx, face_y, bw)
        return s

    def _state_key(self, full: bool):
        """지금 모습을 결정하는 값들. 이 값이 같으면 그림도 같으므로 다시 그리지 않는다."""
        if self.pose == "clap":
            wiggle = round(abs(math.sin(self.t * 12)) * 8)
        elif self.pose in ("wave", "hi"):
            wiggle = round(math.sin(self.t * 11) * 7)
        elif self.pose == "cheer":
            wiggle = (round(math.sin(self.t * 9) * 5), round(math.sin(self.t * 9 + 1) * 5))
        else:
            wiggle = 0
        return (full, self.pose, self.expression, self.blink > 0, self.talking, tuple(self.legs),
                round(self.arm[0] / 2), round(self.arm[1] / 2), wiggle,
                self.body, self.shape, self.ears, frozenset(self.acc))

    def render(self, full: bool = False) -> pygame.Surface:
        key = self._state_key(full)
        if getattr(self, "_img_key", None) != key:
            self._img = pygame.transform.smoothscale(self.render_hi(full), (W, H))
            self._img_key = key
        return self._img

    def _arms(self, s, cx, fy, bw):
        """'-o' 팔: 굵은 선 + 동그란 손."""
        sy = fy + 84
        for i, side in enumerate((-1, 1)):
            sx = cx + side * (bw / 2 - 14)
            if self.pose in ("hold", "clap"):                    # 몸 앞으로 모은 손
                gap = 46 if self.pose == "hold" else 16 + abs(math.sin(self.t * 12)) * 26
                hx, hy = cx + side * gap, fy + 112
            else:
                deg = self.arm[i]
                if self.pose == "wave" and i == 1 or self.pose == "hi" and i == 0:
                    deg += math.sin(self.t * 11) * 20
                elif self.pose == "cheer":
                    deg += math.sin(self.t * 9 + i) * 8
                a = math.radians(deg)
                hx, hy = sx + side * math.sin(a) * 74, sy + math.cos(a) * 74
            pygame.draw.line(s, OUT, (sx, sy), (hx, hy), 12)
            pygame.draw.circle(s, OUT, (hx, hy), 18)
            pygame.draw.circle(s, (74, 74, 82) if "wingtips" in self.acc else self.body, (hx, hy), 12)

    def _legs(self, s, cx):
        """'-o' 다리: 짧은 선 + 동그란 발 (전신 그림 전용)."""
        for i, side in enumerate((-1, 1)):
            x0 = cx + side * 44
            fx, fy = x0 + self.legs[i], FULL_BOTTOM + 52
            pygame.draw.line(s, OUT, (x0, FULL_BOTTOM - 10), (fx, fy), 12)
            foot = pygame.Rect(0, 0, 50, 26)
            foot.center = (fx + side * 8, fy + 6)
            pygame.draw.ellipse(s, OUT, foot.inflate(10, 10))
            pygame.draw.ellipse(s, (246, 150, 50) if "beak" in self.acc else self.body, foot)

    def _ears(self, s, cx, top, bw):
        inner = mix(self.body, BLUSH, 0.45)
        if "crest" in self.acc:                                 # 나르미: 머리 뒤로 넘긴 깃
            for dx, dy, w, h in ((0.30, 22, 150, 86), (0.40, 62, 104, 60)):
                r = pygame.Rect(0, 0, w, h)
                r.center = (cx + bw * dx, top + dy)
                _ellipse(s, self.body, r)
        if "wings" in self.acc:                                  # 천사 날개 (몸 뒤로 살짝)
            for side in (-1, 1):
                for dx, dy, w, h in ((0.50, 168, 104, 58), (0.54, 206, 92, 50), (0.50, 242, 74, 42)):
                    r = pygame.Rect(0, 0, w, h)
                    r.center = (cx + side * (bw * dx + 6), top + dy)
                    _ellipse(s, (255, 255, 255), r)
                    pygame.draw.arc(s, (214, 226, 240), r.inflate(-20, -16), 0.3, 2.6, 4)
        for side in (-1, 1):
            if self.ears == "bear":
                c = (cx + side * bw * 0.36, top + 34)
                pygame.draw.circle(s, OUT, c, 50 + LW)
                pygame.draw.circle(s, self.body, c, 50)
                pygame.draw.circle(s, inner, c, 26)
            elif self.ears == "cat":
                pts = [(cx + side * bw * 0.14, top + 30), (cx + side * bw * 0.44, top + 100),
                       (cx + side * bw * 0.40, top - 55)]
                _poly(s, self.body, pts)
                ipts = [(cx + side * bw * 0.22, top + 40), (cx + side * bw * 0.39, top + 80),
                        (cx + side * bw * 0.37, top - 20)]
                pygame.draw.polygon(s, inner, ipts)
            elif self.ears == "rabbit":
                r = pygame.Rect(0, 0, 70, 190)
                r.center = (cx + side * bw * 0.2, top - 50)
                _ellipse(s, self.body, r)
                pygame.draw.ellipse(s, inner, r.inflate(-36, -60))

    def _clothes(self, s, cx, fy, bw):
        y = fy + (92 if self._full else 120)
        tl = 36 if self._full else 120           # 넥타이 길이
        if "idcard" in self.acc:                                 # 목에 건 공무원증 (주인공)
            cy = fy + (82 if self._full else 104)
            for side in (-1, 1):
                pygame.draw.line(s, (70, 130, 220), (cx + side * 70, fy + 60), (cx, cy + 4), 7)
            card = pygame.Rect(cx - 30, cy, 60, 50)
            pygame.draw.rect(s, OUT, card.inflate(10, 10), border_radius=9)
            pygame.draw.rect(s, (255, 255, 255), card, border_radius=6)
            pygame.draw.rect(s, (70, 130, 220), (card.x, card.y, card.w, 12), border_top_left_radius=6,
                             border_top_right_radius=6)
            pygame.draw.rect(s, self.body, (card.x + 7, card.y + 18, 18, 22))
            pygame.draw.rect(s, OUT, (card.x + 7, card.y + 18, 18, 22), 2)
            pygame.draw.line(s, OUT, (card.x + 32, card.y + 24), (card.right - 7, card.y + 24), 3)
            pygame.draw.line(s, OUT, (card.x + 32, card.y + 34), (card.right - 12, card.y + 34), 3)
        if "scarf" in self.acc:                                 # 나르미: 빨간 스카프
            band = pygame.Rect(cx - bw * 0.44, y - 22, bw * 0.88, 30)
            pygame.draw.rect(s, OUT, band.inflate(LW, LW), border_radius=14)
            pygame.draw.rect(s, (226, 60, 60), band, border_radius=12)
            _poly(s, (226, 60, 60), [(cx + bw * 0.22, y - 8), (cx + bw * 0.46, y - 26), (cx + bw * 0.42, y + 22)])
            _poly(s, (206, 44, 48), [(cx + bw * 0.22, y - 4), (cx + bw * 0.40, y + 34), (cx + bw * 0.16, y + 26)])
        if "tie" in self.acc:
            _poly(s, (226, 92, 92), [(cx - 18, y), (cx + 18, y), (cx + 10, y + 26), (cx - 10, y + 26)])
            _poly(s, (226, 92, 92), [(cx - 12, y + 26), (cx + 12, y + 26), (cx + 22, y + tl),
                                     (cx, y + tl + 25), (cx - 22, y + tl)])
        if "bowtie" in self.acc:
            _poly(s, (80, 120, 210), [(cx, y + 10), (cx - 50, y - 18), (cx - 50, y + 38)])
            _poly(s, (80, 120, 210), [(cx, y + 10), (cx + 50, y - 18), (cx + 50, y + 38)])
            pygame.draw.circle(s, OUT, (cx, y + 10), 15 + LW // 2)
            pygame.draw.circle(s, (100, 140, 230), (cx, y + 10), 15)

    def _eye(self, s, x, y, kind):
        if kind == "closed":
            pygame.draw.line(s, OUT, (x - 16, y), (x + 16, y), LW)
        elif kind == "happy":
            pygame.draw.arc(s, OUT, (x - 18, y - 12, 36, 30), 0.15, math.pi - 0.15, LW)
        elif kind == "wide":
            pygame.draw.circle(s, OUT, (x, y), 23)
            pygame.draw.circle(s, (255, 255, 255), (x, y), 17)
            pygame.draw.circle(s, OUT, (x, y + 2), 8)
        else:  # dot
            pygame.draw.circle(s, OUT, (x, y), 15)
            pygame.draw.circle(s, (255, 255, 255), (x - 5, y - 6), 5)
            if kind == "sly":   # 반쯤 감은 눈꺼풀
                pygame.draw.rect(s, self.body, (x - 20, y - 22, 40, 20))
                pygame.draw.line(s, OUT, (x - 18, y - 2), (x + 18, y - 2), LW)

    def _face(self, s, cx, fy, bw):
        ex = 54
        e = self.expression
        kind = {"happy": "happy", "shocked": "wide", "sly": "sly", "mean": "sly"}.get(e, "dot")
        if self.blink > 0 and kind in ("dot", "sly"):
            kind = "closed"
        if "goggles" in self.acc:                               # 나르미: 하늘색 고글
            g = pygame.Rect(cx - 124, fy - 56, 248, 100)
            pygame.draw.rect(s, OUT, g.inflate(LW * 2, LW * 2), border_radius=48)
            pygame.draw.rect(s, (206, 228, 242), g, border_radius=44)
            pygame.draw.arc(s, (255, 255, 255), (g.right - 70, g.y + 14, 50, 60), -0.9, 0.5, 7)
        for side in (-1, 1):
            self._eye(s, cx + side * ex, fy, kind)

        # 눈썹
        if e in ("nervous", "sad"):
            for side in (-1, 1):
                pygame.draw.line(s, OUT, (cx + side * (ex + 20), fy - 30), (cx + side * (ex - 18), fy - 44), 6)
        elif e == "sly":
            pygame.draw.line(s, OUT, (cx - ex - 20, fy - 40), (cx - ex + 18, fy - 34), 6)
            pygame.draw.line(s, OUT, (cx + ex - 18, fy - 46), (cx + ex + 20, fy - 40), 6)

        if e == "mean":                                          # 심술궂게 치켜뜬 눈썹
            for side in (-1, 1):
                pygame.draw.line(s, OUT, (cx + side * (ex + 26), fy - 48), (cx + side * (ex - 24), fy - 22), 10)

        # 볼터치
        blush = mix(self.body, BLUSH, 0.55)
        for side in (-1, 1):
            pygame.draw.ellipse(s, blush, (cx + side * 98 - 26, fy + 22, 52, 26))

        if "sunglasses" in self.acc:
            for side in (-1, 1):
                r = pygame.Rect(0, 0, 80, 50)
                r.center = (cx + side * ex, fy)
                pygame.draw.rect(s, (40, 38, 52), r, border_radius=18)
                pygame.draw.line(s, (200, 200, 230), (r.x + 16, r.y + 14), (r.x + 30, r.y + 10), 5)
            pygame.draw.line(s, (40, 38, 52), (cx - 14, fy - 6), (cx + 14, fy - 6), 7)
        if "glasses" in self.acc:
            for side in (-1, 1):
                pygame.draw.circle(s, OUT, (cx + side * ex, fy), 33, 6)
            pygame.draw.line(s, OUT, (cx - 21, fy - 4), (cx + 21, fy - 4), 6)

        if "beak" in self.acc:                                  # 나르미: 입 대신 부리
            opened = e in ("happy", "shocked") or self.talking
            by = fy + 30
            if opened:
                _poly(s, (226, 120, 40), [(cx - 20, by + 4), (cx + 20, by + 4), (cx, by + 34)])
            pygame.draw.ellipse(s, OUT, pygame.Rect(cx - 26, by - 16, 52, 34).inflate(LW, LW))
            pygame.draw.ellipse(s, (246, 160, 56), (cx - 26, by - 16, 52, 34))
            return
        # 입
        my = fy + 46
        if "mustache" in self.acc:
            for side in (-1, 1):
                pygame.draw.ellipse(s, (110, 76, 52), (cx + (0 if side > 0 else -54), my - 30, 54, 26))
            my += 6
        if e == "happy":
            pts = [(cx + 32 * math.cos(a), my - 6 + 30 * math.sin(a))
                   for a in [i * math.pi / 16 for i in range(17)]]
            pygame.draw.polygon(s, MOUTH, pts)
            pygame.draw.ellipse(s, TONGUE, (cx - 14, my + 8, 28, 16))
            pygame.draw.polygon(s, OUT, pts, 5)
        elif e == "sad":
            pygame.draw.arc(s, OUT, (cx - 22, my, 44, 30), 0.3, math.pi - 0.3, 6)
            pygame.draw.ellipse(s, (130, 190, 240), (cx - ex - 8, fy + 20, 16, 26))
        elif e == "nervous":
            pts = [(cx + x, my + 6 + 6 * math.sin(x * 0.35)) for x in range(-26, 27, 4)]
            pygame.draw.lines(s, OUT, False, pts, 6)
            # 땀방울
            dx, dy = cx + int(bw * 0.36), fy - 22
            pygame.draw.polygon(s, (150, 205, 245), [(dx, dy - 24), (dx - 14, dy), (dx + 14, dy)])
            pygame.draw.circle(s, (150, 205, 245), (dx, dy + 4), 15)
        elif e == "shocked":
            pygame.draw.ellipse(s, MOUTH, (cx - 16, my - 8, 32, 38))
            pygame.draw.ellipse(s, OUT, (cx - 16, my - 8, 32, 38), 5)
        elif e == "mean":                                        # 이를 드러낸 심술 웃음
            pts = [(cx - 36, my - 6), (cx + 36, my - 14), (cx + 28, my + 16), (cx - 24, my + 20)]
            pygame.draw.polygon(s, (255, 255, 255), pts)
            for x in (-14, 2, 16):
                pygame.draw.line(s, OUT, (cx + x, my - 8), (cx + x, my + 18), 3)
            pygame.draw.polygon(s, OUT, pts, 5)
        elif e == "sly":
            pygame.draw.arc(s, OUT, (cx - 6, my - 18, 44, 30), math.pi + 0.3, 2 * math.pi - 0.2, 6)
        else:
            pygame.draw.arc(s, OUT, (cx - 22, my - 16, 44, 30), math.pi + 0.3, 2 * math.pi - 0.3, 6)

    def _hats(self, s, cx, top, bw, fy):
        if "hardhat" in self.acc:
            yel = (250, 204, 70)
            r = bw * 0.5
            pts = [(cx + r * math.cos(a), top + 78 - r * 0.8 * math.sin(a))
                   for a in [i * math.pi / 20 for i in range(21)]]
            _poly(s, yel, pts)
            brim = pygame.Rect(cx - r - 22, top + 62, 2 * r + 44, 30)
            pygame.draw.rect(s, OUT, brim.inflate(LW * 2, LW * 2), border_radius=18)
            pygame.draw.rect(s, yel, brim, border_radius=15)
            pygame.draw.rect(s, mix(yel, (255, 255, 255), 0.5), (cx - 10, top - 20, 20, 80), border_radius=8)
        if "beret" in self.acc:
            r = pygame.Rect(0, 0, int(bw * 0.8), 80)
            r.center = (cx - 26, top + 6)
            _ellipse(s, (200, 70, 90), r)
            pygame.draw.circle(s, OUT, (cx - 26, top - 40), 12)
        if "headset" in self.acc:
            pygame.draw.arc(s, OUT, (cx - bw // 2 - 4, top - 30, bw + 8, 200), 0.1, math.pi - 0.1, 12)
            for side in (-1, 1):
                pygame.draw.rect(s, OUT, (cx + side * (bw // 2) - 22, fy - 50, 44, 70), border_radius=18)
                pygame.draw.rect(s, (110, 110, 140), (cx + side * (bw // 2) - 16, fy - 44, 32, 58), border_radius=14)
            pygame.draw.line(s, OUT, (cx - bw // 2, fy + 10), (cx - 40, fy + 66), 7)
            pygame.draw.circle(s, OUT, (cx - 40, fy + 66), 10)
        if "bow" in self.acc:
            bx, by = cx + int(bw * 0.28), top + 20
            _poly(s, (255, 120, 160), [(bx, by), (bx - 50, by - 30), (bx - 50, by + 30)])
            _poly(s, (255, 120, 160), [(bx, by), (bx + 50, by - 30), (bx + 50, by + 30)])
            pygame.draw.circle(s, OUT, (bx, by), 15)
            pygame.draw.circle(s, (255, 150, 185), (bx, by), 11)
        if "halo" in self.acc:                                   # 천사 고리
            r = pygame.Rect(0, 0, 132, 36)
            r.center = (cx, top - 42)
            pygame.draw.ellipse(s, OUT, r.inflate(10, 10), 16)
            pygame.draw.ellipse(s, (255, 224, 96), r, 9)
        if "horns" in self.acc:                                  # 악마 뿔
            for side in (-1, 1):
                pts = [(cx + side * bw * 0.14, top + 40), (cx + side * bw * 0.42, top + 84),
                       (cx + side * bw * 0.50, top - 44)]
                _poly(s, (124, 40, 58), pts)
                pygame.draw.line(s, (170, 70, 90), (cx + side * bw * 0.36, top + 40), (cx + side * bw * 0.46, top - 14), 5)
        if "crown" in self.acc:                                 # SSR 팀원의 왕관
            cy = top - 4
            pts = [(cx - 62, cy + 36), (cx - 72, cy - 28), (cx - 34, cy + 4), (cx, cy - 46),
                   (cx + 34, cy + 4), (cx + 72, cy - 28), (cx + 62, cy + 36)]
            _poly(s, (255, 208, 72), pts)
            pygame.draw.rect(s, (240, 176, 50), (cx - 62, cy + 20, 124, 16))
            pygame.draw.lines(s, OUT, False, [(cx - 62, cy + 20), (cx + 62, cy + 20)], 4)
            for dx, col in ((-36, (236, 96, 120)), (0, (110, 190, 250)), (36, (130, 210, 130))):
                pygame.draw.circle(s, OUT, (cx + dx, cy + 8), 11)
                pygame.draw.circle(s, col, (cx + dx, cy + 8), 8)
        if "sprout" in self.acc:
            pygame.draw.line(s, (90, 150, 70), (cx, top + 4), (cx, top - 60), 8)
            for side in (-1, 1):
                r = pygame.Rect(0, 0, 70, 38)
                r.center = (cx + side * 36, top - 62)
                _ellipse(s, (120, 200, 90), r)

    def _gift(self, s, x, y):
        box = pygame.Rect(x, y, 100, 84)
        pygame.draw.rect(s, OUT, box.inflate(LW * 2, LW * 2), border_radius=12)
        pygame.draw.rect(s, (220, 80, 80), box, border_radius=10)
        pygame.draw.rect(s, (250, 210, 80), (box.centerx - 9, box.y, 18, box.h))
        pygame.draw.rect(s, (250, 210, 80), (box.x, box.y + 30, box.w, 16))
        for side in (-1, 1):
            pygame.draw.circle(s, OUT, (box.centerx + side * 18, box.y - 12), 17)
            pygame.draw.circle(s, (250, 210, 80), (box.centerx + side * 18, box.y - 12), 12)
