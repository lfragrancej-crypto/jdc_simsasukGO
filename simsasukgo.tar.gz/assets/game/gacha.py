"""동료 뽑기(가챠) — 승진할 때마다 인사 발령 봉투에서 동료 한 명이 나온다.

동료는 고정 인물 명단(data/roster.json)에서 뽑는다. 사람마다 등급(R/SR/SSR)과 기술·숙련도가 정해져 있다.
기술마다 숙련도 S·A·B·C 가 있어서 같은 '서류 정리'라도 속도·정확도가 다르다.

  등급 확률  R 55% / SR 33% / SSR 12%
  규칙 1  첫 동료는 반드시 '서류 정리'를 가진 사람 (책상 더미가 너무 고달프지 않게)
  규칙 2  이미 팀에 있는 기술을 가진 사람은 나오지 않는다 (기술이 겹치지 않게)
  규칙 3  앞의 두 명이 모두 R 이면 세 번째는 SR 이상 확정
  규칙 4  아직 한 번도 뽑아 보지 못한 사람은 조금 더 잘 나온다 (가중치 1.5배 — 티 나지 않을 정도)
"""
import copy
import random

RARITIES = ["R", "SR", "SSR"]
RARITY_WEIGHT = {"R": 55, "SR": 33, "SSR": 12}
RARITY_COLOR = {"R": (96, 160, 240), "SR": (245, 184, 50), "SSR": (236, 96, 170)}
RARITY_STARS = {"R": 1, "SR": 2, "SSR": 3}
GRADE_COLOR = {"S": (240, 164, 30), "A": (176, 104, 220), "B": (72, 142, 232), "C": (140, 142, 156)}
GRADE_ORDER = "CBAS"
UNSEEN_BONUS = 1.5

SKILLS = {
    "tidy": {"name": "서류 정리",
             "C": {"delay": 1.8, "miss": 0.34, "cool": 8.0},
             "B": {"delay": 1.1, "miss": 0.18, "cool": 5.0},
             "A": {"delay": 0.5, "miss": 0.06, "cool": 2.5},
             "S": {"delay": 0.0, "miss": 0.0, "cool": 0.6}},
    "time": {"name": "일정 관리",
             "C": {"bonus": 0.08}, "B": {"bonus": 0.14}, "A": {"bonus": 0.20}, "S": {"bonus": 0.30}},
    "check": {"name": "재검토",
              "C": {"uses": 1, "chance": 0.5}, "B": {"uses": 1, "chance": 1.0},
              "A": {"uses": 2, "chance": 1.0}, "S": {"uses": 3, "chance": 1.0}},
    "spot": {"name": "눈썰미",
             "C": {"chance": 0.20}, "B": {"chance": 0.35}, "A": {"chance": 0.55}, "S": {"chance": 0.80}},
    "bonus": {"name": "칭찬 요정",
              "C": {"bonus": 0.05}, "B": {"bonus": 0.10}, "A": {"bonus": 0.15}, "S": {"bonus": 0.25}},
}


def describe(skill: str, grade: str) -> str:
    p = SKILLS[skill][grade]
    if skill == "tidy":
        speed = "즉시" if p["delay"] <= 0 else f"{p['delay']:g}초 뒤"
        return f"서류를 {speed} 정리 · 정확도 {int((1 - p['miss']) * 100)}%"
    if skill == "time":
        return f"하루 심사 시간 +{int(p['bonus'] * 100)}%"
    if skill == "check":
        tail = " (성공률 50%)" if p["chance"] < 1 else ""
        return f"오판을 하루 {p['uses']}번 말려 줌{tail}"
    if skill == "spot":
        return f"수상한 서류에 ? 표시 · 확률 {int(p['chance'] * 100)}%"
    return f"정답마다 점수 +{int(p['bonus'] * 100)}%"


def _weighted(rng: random.Random, table: dict):
    return rng.choices(list(table), weights=list(table.values()))[0]


def roll_rarity(rng: random.Random, team: list[dict]) -> str:
    table = dict(RARITY_WEIGHT)
    if len(team) >= 2 and all(m["rarity"] == "R" for m in team):
        table.pop("R")                        # 천장: 둘 다 R 이었으면 SR 이상 확정
    return _weighted(rng, table)


def candidates(team: list[dict], roster: list[dict]) -> list[dict]:
    """지금 팀에 합류할 수 있는 사람들 (이미 있는 사람·기술이 겹치는 사람 제외)."""
    in_team = {m["id"] for m in team}
    owned = {s["type"] for m in team for s in m["skills"]}
    pool = [p for p in roster if p["id"] not in in_team and not ({s["type"] for s in p["skills"]} & owned)]
    if not team:
        pool = [p for p in pool if any(s["type"] == "tidy" for s in p["skills"])]
    return pool


def pull(rng: random.Random, team: list[dict], roster: list[dict], say_pool: dict, seen=()) -> dict:
    """동료 한 명을 뽑는다. seen = 지금까지 한 번이라도 뽑아 본 사람들의 id."""
    pool = candidates(team, roster)
    if not pool:                              # 기술이 다 찼으면 겹쳐도 허용
        in_team = {m["id"] for m in team}
        pool = [p for p in roster if p["id"] not in in_team]
    rarity = roll_rarity(rng, team)
    tier = [p for p in pool if p["rarity"] == rarity]
    if not tier:                              # 그 등급에 남은 사람이 없으면 가까운 등급으로
        for alt in sorted(RARITIES, key=lambda r: abs(RARITIES.index(r) - RARITIES.index(rarity))):
            tier = [p for p in pool if p["rarity"] == alt]
            if tier:
                break
    seen = set(seen)
    weights = [1.0 if p["id"] in seen else UNSEEN_BONUS for p in tier]
    person = rng.choices(tier, weights=weights)[0]
    member = copy.deepcopy(person)
    member["say"] = {s["type"]: rng.choice(say_pool[s["type"]]["say"]) for s in member["skills"]}
    member["new"] = person["id"] not in seen
    return member


def team_perks(team: list[dict]) -> dict:
    """기술 → (숙련도, 수치, 담당 동료). 같은 기술이 겹치면 숙련도가 높은 쪽."""
    perks = {}
    for m in team:
        for s in m["skills"]:
            cur = perks.get(s["type"])
            if cur is None or GRADE_ORDER.index(s["grade"]) > GRADE_ORDER.index(cur[0]):
                perks[s["type"]] = (s["grade"], SKILLS[s["type"]][s["grade"]], m)
    return perks
