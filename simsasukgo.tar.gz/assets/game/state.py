from dataclasses import dataclass, field

from .rules import CORRECT, PARTIAL, WRONG

SCORE = {CORRECT: 100, PARTIAL: 50, WRONG: 0}


@dataclass
class DayStats:
    day: int
    processed: int = 0
    correct: int = 0
    partial: int = 0
    wrong: int = 0
    score: int = 0
    saved: int = 0          # 예산 절감액(원)
    overtime: bool = False  # 야근을 했는가
    fair: int = 0           # 성실한 업체를 바르게 통과시킨 건수
    caught: dict = field(default_factory=dict)      # 규정 id → 바르게 걸러낸 건수 (정책 효과)
    leftover: int = 0       # 퇴근 시간까지 못 끝낸 건수
    carried: int = 0        # 그중 다음 날 잔업으로 넘긴 건수 (나머지는 기한 만료로 이관)

    def record(self, result: str, saved: int = 0):
        self.processed += 1
        self.score += SCORE[result]
        self.saved += saved
        if result == CORRECT:
            self.correct += 1
        elif result == PARTIAL:
            self.partial += 1
        else:
            self.wrong += 1


@dataclass
class GameState:
    day_index: int = 0                 # days.json 인덱스
    level: int = 1                     # 직급 (data/levels.json) — 정산 화면에서 승진 처리
    team: list[dict] = field(default_factory=list)    # 뽑기로 합류한 동료들 (최대 3명) — game/gacha.py
    chief: dict | None = None          # 함께 일하는 팀장 = 난이도 (data/chiefs.json)
    run_cgs: list[str] = field(default_factory=list)   # 이번 판에서 이미 본 CG
    money: int = 50                    # 통장 잔고 (만원) — 퇴근 후 생활 사건으로 바뀐다
    stress: int = 20                   # 스트레스 0~100 — 높으면 다음 날 심사 시간이 줄어든다
    life_seen: list[str] = field(default_factory=list)   # 이번 판에서 겪은 생활 사건
    health: int = 70                   # 건강 0~100 — 낮으면 다음 날 심사 시간이 줄어든다
    bond: int = 50                     # 가족·친구와의 관계 0~100 — 낮으면 외로워서 스트레스가 더 쌓인다
    fixed: dict = field(default_factory=dict)            # 고정지출 (id → 하루 만원). 이사·대출 선택으로 바뀐다
    buff: str | None = None            # 어젯밤 활동의 효과 (예: 'study' = 오늘 힌트 증가)
    backlog: int = 0                   # 어제 못 끝내고 오늘로 넘어온 잔업 건수
    stolen: int = 0                    # 팀장이 가로챈 공로 (점수) — 지옥 모드 엔딩에서 내 이름으로 돌아온다
    stolen_n: int = 0                  # 가로챈 횟수
    promoted_today: bool = False       # 오늘 승진했는가 (가계부의 승진 축하금)
    history: list[DayStats] = field(default_factory=list)

    @property
    def total_score(self) -> int:
        return sum(d.score for d in self.history)

    @property
    def warnings(self) -> int:
        return sum(d.wrong for d in self.history)

    @property
    def total_saved(self) -> int:
        return sum(d.saved for d in self.history)

    @property
    def accuracy(self) -> float:
        n = sum(d.processed for d in self.history)
        return (sum(d.correct for d in self.history) / n) if n else 0.0

    def level_info(self, levels: list[dict]) -> dict:
        return next(lv for lv in levels if lv["level"] == self.level)

    def grade(self) -> tuple[str, str]:
        a = self.accuracy
        if a >= 0.9:
            return "S", "청렴 심사관 — 공정 조달의 수호자"
        if a >= 0.75:
            return "A", "믿음직한 베테랑 심사관"
        if a >= 0.55:
            return "B", "성장 중인 심사관"
        return "C", "재교육이 필요한 심사관"
