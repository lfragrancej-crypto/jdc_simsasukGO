"""기록 저장소 — PC 에서는 파일, 웹(브라우저)에서는 localStorage.

브라우저 안의 파일은 새로고침하면 사라지므로, 웹에서는 브라우저가 기억해 주는 localStorage 에 글자로 저장한다.
profile.py(도감·설정)와 save.py(이어하기)가 이 모듈만 통해서 읽고 쓴다.
"""
import os
import sys

IS_WEB = sys.platform == "emscripten"
PREFIX = "simsasukgo:"


def _local_storage():
    import platform                     # pygbag 가 브라우저 window 를 platform.window 로 내준다
    return platform.window.localStorage


def read(directory: str, name: str) -> str | None:
    try:
        if IS_WEB:
            value = _local_storage().getItem(PREFIX + name)
            return str(value) if value else None
        with open(os.path.join(directory, name), encoding="utf-8") as f:
            return f.read()
    except Exception:
        return None


def write(directory: str, name: str, text: str) -> bool:
    try:
        if IS_WEB:
            _local_storage().setItem(PREFIX + name, text)
            return True
        os.makedirs(directory, exist_ok=True)
        path = os.path.join(directory, name)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def delete(directory: str, name: str):
    try:
        if IS_WEB:
            _local_storage().removeItem(PREFIX + name)
        else:
            os.remove(os.path.join(directory, name))
    except Exception:
        pass


def exists(directory: str, name: str) -> bool:
    if IS_WEB:
        return read(directory, name) is not None
    return os.path.exists(os.path.join(directory, name))
