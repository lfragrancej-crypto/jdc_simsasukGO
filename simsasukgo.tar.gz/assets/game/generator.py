"""입찰 서류 자동 생성기.

1) 모든 규정을 통과하는 '정상 서류'를 만든 뒤
2) violation_rate 확률로 오늘 활성화된 규정 중 하나를 골라 위반을 주입한다.
"""
import math
import random
from datetime import date, time, timedelta

from .config import GUARANTEE_RATE
from .data_loader import GameData
from .models import Bid, Notice


def _round(v: float, unit: int = 1000) -> int:
    return int(round(v / unit) * unit)


def _clock(rng: random.Random, start_min: int, end_min: int) -> time:
    m = rng.randint(start_min, end_min)
    return time(m // 60, m % 60)


class BidGenerator:
    def __init__(self, data: GameData, seed: int | None = None):
        self.data = data
        self.rng = random.Random(seed)

    # ------------------------------------------------------------------ 공고
    def make_notice(self, day_cfg: dict) -> Notice:
        pool = [i for i in self.data.items if i["sme_only"] == day_cfg["sme_only"]]
        item = self.rng.choice(pool)
        return Notice(
            notice_no=f"R26BK{self.rng.randint(10000000, 99999999)}",
            item=item["name"],
            qty=item["qty"],
            unit=item["unit"],
            est_price=item["qty"] * item["unit_price"],
            deadline=time(10, 0),
            today=date.fromisoformat(day_cfg["date"]),
            sme_only=item["sme_only"],
        )

    # ------------------------------------------------------------- 정상 서류
    def make_clean(self, notice: Notice, company: dict | None = None) -> Bid:
        rng = self.rng
        c = company or rng.choice(self.data.clean_companies)
        price = _round(notice.est_price * rng.uniform(0.87, 0.995))
        guarantee = math.ceil(price * GUARANTEE_RATE / 10000) * 10000
        today = notice.today
        deadline_min = notice.deadline.hour * 60 + notice.deadline.minute

        docs = {
            "bid_form": {
                "상호": c["name"], "사업자번호": c["biz_no"], "대표자": c["ceo"],
                "품목": notice.item, "투찰금액": price,
                "제출시각": _clock(rng, deadline_min - 120, deadline_min - 1),
            },
            "registration": {
                "상호": c["name"], "사업자번호": c["biz_no"],
                "등록번호": f"2026-{rng.randint(10000, 99999)}",
            },
            "guarantee": {
                "상호": c["name"], "보증금액": guarantee,
                "보증만료일": today + timedelta(days=rng.randint(10, 60)),
            },
            "integrity": {"상호": c["name"], "서명": True},
        }
        if notice.sme_only:
            docs["direct_production"] = {
                "상호": c["name"], "확인품목": notice.item,
                "유효기간": today + timedelta(days=rng.randint(30, 365)),
            }
        return Bid(docs=docs)

    # ------------------------------------------------------------- 위반 주입
    def _inj_r01(self, bid, notice):
        del bid.docs["registration"]

    def _inj_r02(self, bid, notice):
        reg = bid.docs["registration"]
        digits = list(reg["사업자번호"])
        idx = self.rng.choice([i for i, ch in enumerate(digits) if ch.isdigit()])
        digits[idx] = self.rng.choice([d for d in "0123456789" if d != digits[idx]])
        reg["사업자번호"] = "".join(digits)

    def _inj_r03(self, bid, notice):
        dl = notice.deadline.hour * 60 + notice.deadline.minute
        bid.form["제출시각"] = _clock(self.rng, dl + 1, dl + 90)

    def _inj_r04(self, bid, notice):
        bad = self.rng.choice(self.data.debarred)
        fresh = self.make_clean(notice, company=bad)
        bid.docs = fresh.docs

    def _inj_r05(self, bid, notice):
        if self.rng.random() < 0.28:                 # 서류 불충분: 보증서를 아예 안 냄
            del bid.docs["guarantee"]
            return
        g = bid.docs["guarantee"]
        if self.rng.random() < 0.5:
            g["보증만료일"] = notice.today - timedelta(days=self.rng.randint(1, 20))
        else:
            g["보증금액"] = math.floor(bid.price * self.rng.uniform(0.02, 0.045) / 10000) * 10000

    def _inj_r06(self, bid, notice):
        price = _round(notice.est_price * self.rng.uniform(1.005, 1.08))
        bid.form["투찰금액"] = price
        bid.docs["guarantee"]["보증금액"] = math.ceil(price * GUARANTEE_RATE / 10000) * 10000

    def _inj_r07(self, bid, notice):
        roll = self.rng.random()
        if roll < 0.34:
            del bid.docs["direct_production"]
        elif roll < 0.67:
            others = [i["name"] for i in self.data.items if i["name"] != notice.item]
            bid.docs["direct_production"]["확인품목"] = self.rng.choice(others)
        else:
            bid.docs["direct_production"]["유효기간"] = notice.today - timedelta(days=self.rng.randint(1, 90))

    def _inj_r08(self, bid, notice):
        if self.rng.random() < 0.35:                 # 서류 불충분: 서약서를 아예 안 냄
            del bid.docs["integrity"]
        else:
            bid.docs["integrity"]["서명"] = False

    def _inj_r09(self, bid, notice):
        company = next(c for c in self.data.companies if c["name"] == bid.company)
        target = self.rng.choice([k for k in bid.docs if k != "bid_form"])
        bid.docs[target]["상호"] = company["lookalike"]

    INJECTORS = {
        "R01": _inj_r01, "R02": _inj_r02, "R03": _inj_r03, "R04": _inj_r04, "R05": _inj_r05,
        "R06": _inj_r06, "R07": _inj_r07, "R08": _inj_r08, "R09": _inj_r09,
    }

    def injectable(self, notice: Notice, active_ids) -> list[str]:
        return [rid for rid in active_ids if rid in self.INJECTORS and (rid != "R07" or notice.sme_only)]

    def make_bid(self, notice: Notice, active_ids, violation_rate: float) -> Bid:
        bid = self.make_clean(notice)
        candidates = self.injectable(notice, active_ids)
        if candidates and self.rng.random() < violation_rate:
            rid = self.rng.choice(candidates)
            self.INJECTORS[rid](self, bid, notice)
            bid.injected = rid
        self._add_extras(bid)
        return bid

    def _add_extras(self, bid: Bid):
        """가끔 심사와 상관없는 종이가 섞여 온다 (특정 업체 전용 종이는 항상)."""
        biz = bid.form["사업자번호"]
        special = [d for d in self.data.decoys if d.get("only") == biz]
        generic = [d for d in self.data.decoys if "only" not in d]
        if special:
            bid.extras = [self.rng.choice(special)]
        elif generic and self.rng.random() < 0.3:
            bid.extras = [self.rng.choice(generic)]

    def make_day(self, day_cfg: dict) -> tuple[Notice, list[Bid]]:
        notice = self.make_notice(day_cfg)
        active = [r["id"] for r in self.data.active_rules(day_cfg["day"])]
        bids = [self.make_bid(notice, active, day_cfg["violation_rate"]) for _ in range(day_cfg["bids"])]
        return notice, bids
