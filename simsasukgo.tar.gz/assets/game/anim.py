"""이징 함수와 간단한 파티클 — 화면 전환·등장·도장 연출을 부드럽게."""
import math
import random

import pygame


def clamp01(x: float) -> float:
    return 0.0 if x < 0 else 1.0 if x > 1 else x


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def ease_out_cubic(t: float) -> float:
    t = clamp01(t)
    return 1 - (1 - t) ** 3


def ease_in_cubic(t: float) -> float:
    t = clamp01(t)
    return t ** 3


def ease_in_out_sine(t: float) -> float:
    t = clamp01(t)
    return -(math.cos(math.pi * t) - 1) / 2


def ease_out_back(t: float, s: float = 1.70158) -> float:
    """살짝 지나쳤다가 돌아오는 '통통' 튀는 느낌."""
    t = clamp01(t) - 1
    return t * t * ((s + 1) * t + s) + 1


class Particles:
    """도장/정답 때 터지는 별·동그라미 조각."""

    def __init__(self):
        self.items: list[list] = []

    def burst(self, x, y, colors, n=18, speed=260, size=(4, 9)):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            v = random.uniform(speed * 0.4, speed)
            life = random.uniform(0.5, 0.9)
            self.items.append([x, y, math.cos(a) * v, math.sin(a) * v - 120, life, life,
                               random.choice(colors), random.uniform(*size)])

    def update(self, dt):
        for p in self.items:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 600 * dt          # 중력
            p[2] *= 0.98
            p[4] -= dt
        self.items = [p for p in self.items if p[4] > 0]

    def draw(self, surf):
        for x, y, _, _, life, maxlife, color, size in self.items:
            r = max(1, int(size * (life / maxlife)))
            pygame.draw.circle(surf, color, (int(x), int(y)), r)
