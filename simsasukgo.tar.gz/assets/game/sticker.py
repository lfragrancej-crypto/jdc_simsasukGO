"""말랑한 '스티커 글씨' — 아이콘의 '숙GO!' 와 풍선 버튼이 함께 쓴다.

굵은 둥근 글씨(나눔스퀘어라운드 EB) 둘레를 진갈색으로 두툼하게 감싸서 스티커처럼 보이게 한다.
렌더링 비용이 커서 결과를 캐시한다.
"""
import math

import pygame

from . import fonts

INK = (74, 52, 40)
WHITE = (255, 253, 247)
YELLOW = (255, 214, 90)

_cache: dict = {}


def sticker_text(text, size, fill=WHITE, stroke=INK, stroke_w=None, steps=None) -> pygame.Surface:
    stroke_w = stroke_w if stroke_w is not None else max(2, size // 9)
    steps = steps or (48 if stroke_w > 12 else 24)
    key = ("t", text, size, fill, stroke, stroke_w, steps)
    if key in _cache:
        return _cache[key]
    font = fonts.get(size, "heavy")
    core = font.render(text, True, fill)
    edge = font.render(text, True, stroke)
    pad = stroke_w + 2
    out = pygame.Surface((core.get_width() + pad * 2, core.get_height() + pad * 2), pygame.SRCALPHA)
    for r in range(stroke_w, 0, -max(1, stroke_w // 4)):      # 여러 반지름으로 채워 구멍 없이 둥글게
        for k in range(steps):
            a = 2 * math.pi * k / steps
            out.blit(edge, (pad + round(math.cos(a) * r), pad + round(math.sin(a) * r)))
    out.blit(core, (pad, pad))
    _cache[key] = out
    return out


def sticker_line(parts, size, stroke=INK, stroke_w=None) -> pygame.Surface:
    """parts = [("적격 ", WHITE), ("GO!", YELLOW)] 처럼 색이 다른 조각을 한 줄로 이어 붙인다."""
    stroke_w = stroke_w if stroke_w is not None else max(2, size // 9)
    key = ("l", tuple(parts), size, stroke, stroke_w)
    if key in _cache:
        return _cache[key]
    imgs = [sticker_text(t, size, c, stroke, stroke_w) for t, c in parts if t]
    overlap = stroke_w + max(2, size // 30)
    w = sum(i.get_width() for i in imgs) - overlap * (len(imgs) - 1)
    h = max(i.get_height() for i in imgs)
    line = pygame.Surface((w, h), pygame.SRCALPHA)
    x = 0
    for i in imgs:
        line.blit(i, (x, (h - i.get_height()) // 2))
        x += i.get_width() - overlap
    _cache[key] = line
    return line


def fit(img: pygame.Surface, max_w: int, max_h: int | None = None) -> pygame.Surface:
    k = min(1.0, max_w / img.get_width(), (max_h / img.get_height()) if max_h else 1.0)
    if k >= 1.0:
        return img
    return pygame.transform.smoothscale(img, (max(1, int(img.get_width() * k)), max(1, int(img.get_height() * k))))
