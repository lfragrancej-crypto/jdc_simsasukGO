"""불꽃놀이 — 쏘아 올린 폭죽이 꼬리를 끌며 올라가 여러 모양으로 터진다.

  peony   둥글게 퍼지는 기본 꽃
  ring    고리 모양 (안쪽에 작은 고리 하나 더)
  willow  버들처럼 길게 늘어지며 떨어진다
  double  한 번 터진 불똥이 한 번 더 터진다
불똥마다 꼬리(지나온 자리)를 남기고, 사라지기 직전에 반짝인다.
"""
import math
import random

import pygame

KINDS = ("peony", "ring", "willow", "double", "peony")


def _hue(h, s=75, v=100):
    c = pygame.Color(0)
    c.hsva = (h % 360, s, v, 100)
    return (c.r, c.g, c.b)


class Fireworks:
    def __init__(self):
        self.rockets = []            # [x, y, vx, vy, 터질 높이, 색조, 모양, 꼬리]
        self.sparks = []             # [x, y, vx, vy, 남은 수명, 전체 수명, 색, 크기, 꼬리, 중력, 두 번째 터짐?]
        self.flash = 0.0             # 터지는 순간 하늘이 번쩍

    @property
    def items(self):
        return self.rockets + self.sparks

    def launch(self, x, ground, target_y=None, kind=None, vx=None, vy=None):
        """(x, ground) 에서 쏘아 올린다. vx·vy 를 주면 그 방향으로 날아가 가장 높은 곳에서 터진다."""
        ty = target_y if target_y is not None else (-999 if vy is not None else random.uniform(90, 300))
        self.rockets.append([x, ground, vx if vx is not None else random.uniform(-40, 40),
                             vy if vy is not None else -random.uniform(620, 760), ty, random.uniform(0, 360),
                             kind or random.choice(KINDS), []])

    def _burst(self, x, y, hue, kind, small=False):
        n = 26 if small else {"peony": 90, "ring": 64, "willow": 70, "double": 46}[kind]
        speed = 190 if small else {"peony": 330, "ring": 300, "willow": 250, "double": 280}[kind]
        for i in range(n):
            a = i / n * math.tau + random.uniform(-0.05, 0.05)
            if kind == "ring" and not small:
                v = speed * (1.0 if i % 2 else 0.5)                # 바깥 고리 + 안쪽 고리
                col = _hue(hue if i % 2 else hue + 150)
            else:
                v = speed * math.sqrt(random.uniform(0.08, 1.0))    # 공처럼 고르게
                col = _hue(hue + random.choice((0, 0, 0, 30, 180 if kind == "peony" else 0)), random.choice((40, 75, 90)))
            life = random.uniform(1.6, 2.4) if kind == "willow" else random.uniform(0.9, 1.5)
            if small:
                life *= 0.6
            self.sparks.append([x, y, math.cos(a) * v, math.sin(a) * v, life, life, col, random.uniform(3, 6) * (0.7 if small else 1), [],
                                420 if kind == "willow" else 170, kind == "double" and not small and i % 5 == 0])
        self.flash = max(self.flash, 0.5 if small else 1.0)

    def update(self, dt):
        """갱신. 이번에 새로 터진 폭죽 수를 돌려준다 (소리를 내려고)."""
        self.flash = max(0.0, self.flash - dt * 3.5)
        booms = 0
        for r in self.rockets:
            r[7].append((r[0], r[1]))
            del r[7][:-10]
            r[0] += r[2] * dt
            r[1] += r[3] * dt
            r[3] += 520 * dt
        for r in [r for r in self.rockets if r[1] <= r[4] or r[3] >= -40]:
            self.rockets.remove(r)
            self._burst(r[0], r[1], r[5], r[6])
            booms += 1
        for s in self.sparks:
            s[8].append((s[0], s[1]))
            del s[8][:-6]
            s[0] += s[2] * dt
            s[1] += s[3] * dt
            s[2] *= 1 - 1.6 * dt
            s[3] = s[3] * (1 - 1.6 * dt) + s[9] * dt
            s[4] -= dt
        for s in [s for s in self.sparks if s[4] <= 0]:
            self.sparks.remove(s)
            if s[10]:                                              # 한 번 더 터진다
                self._burst(s[0], s[1], random.uniform(0, 360), "peony", small=True)
        return booms

    def draw(self, surf):
        if not self.rockets and not self.sparks and self.flash <= 0:
            return
        veil = pygame.Surface(surf.get_size(), pygame.SRCALPHA)        # 밤하늘처럼 살짝 어둡게 → 불꽃이 또렷해진다
        busy = min(1.0, (len(self.sparks) + len(self.rockets) * 30) / 120)
        veil.fill((16, 18, 44, int(120 * busy)))
        surf.blit(veil, (0, 0))
        if self.flash > 0:
            fl = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            fl.fill((255, 255, 240, int(46 * self.flash)))
            surf.blit(fl, (0, 0))
        for r in self.rockets:                                       # 올라가는 폭죽: 금빛 꼬리
            pts = r[7] + [(r[0], r[1])]
            for k in range(1, len(pts)):
                pygame.draw.line(surf, (255, 200 + k * 4, 110), pts[k - 1], pts[k], max(1, k // 2))
            pygame.draw.circle(surf, (255, 255, 230), (int(r[0]), int(r[1])), 4)
        for x, y, _, _, life, total, col, size, trail, _, _ in self.sparks:
            k = life / total
            if k < 0.25 and random.random() < 0.4:                   # 사라지기 직전에 깜빡
                continue
            pts = trail + [(x, y)]
            for i in range(1, len(pts)):
                c = tuple(int(v * (0.35 + 0.65 * i / len(pts)) * (0.4 + 0.6 * k)) for v in col)
                pygame.draw.line(surf, c, pts[i - 1], pts[i], max(1, int(size * k * i / len(pts))))
            rad = max(1, int(size * (0.5 + 0.5 * k)))
            pygame.draw.circle(surf, col, (int(x), int(y)), rad)
            if rad >= 2:
                pygame.draw.circle(surf, (255, 255, 255), (int(x), int(y)), max(1, rad // 2))
