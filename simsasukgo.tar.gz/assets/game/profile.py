"""플레이 기록(프로필) — 게임을 꺼도 남는 것: 만난 동료, 클리어 기록, 본 CG.

저장 위치: PC 는 %APPDATA%\\SimsasukGO\\profile.json (환경변수 JDC_PROFILE_DIR 로 바꿀 수 있음 — 테스트용),
          웹은 브라우저 localStorage (game/storage.py).

도감의 공개 단계:
  성격 1 — 한 번이라도 뽑으면 공개
  성격 2 — 그 동료와 함께 엔딩을 보면 공개
  성격 3 — 그 동료와 함께 '지옥' 난이도 엔딩을 보면 공개
"""
import json
import os
from datetime import date

from . import storage

HELL = "hell"


def default_dir() -> str:
    custom = os.environ.get("JDC_PROFILE_DIR")
    if custom:
        return custom
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "SimsasukGO")


class Profile:
    def __init__(self, directory: str | None = None):
        self.dir = directory or default_dir()
        self.path = os.path.join(self.dir, "profile.json")
        self.data = self._blank()
        self.load()

    @staticmethod
    def _blank() -> dict:
        return {"members": {}, "chiefs": {}, "cgs": [], "rules": [], "factory": {}, "agency": {}, "hidden": {}, "settings": {"bgm": 70, "sfx": 100, "fullscreen": False}}

    @property
    def settings(self) -> dict:
        return self.data["settings"]

    def reset(self):
        """도감·클리어 기록을 모두 지운다 (설정은 남긴다)."""
        keep = self.data["settings"]
        self.data = self._blank()
        self.data["settings"] = keep
        self.save()

    # ------------------------------------------------------------ 파일
    def load(self):
        text = storage.read(self.dir, "profile.json")
        if not text:
            return
        try:
            loaded = json.loads(text)
        except ValueError:
            return
        for key in self.data:
            if key in loaded:
                if key == "settings":
                    self.data[key].update(loaded[key])
                else:
                    self.data[key] = loaded[key]

    def save(self):
        storage.write(self.dir, "profile.json", json.dumps(self.data, ensure_ascii=False, indent=1))

    # ------------------------------------------------------------ 동료
    def seen(self) -> set[str]:
        return set(self.data["members"])

    def mark_pulled(self, member_id: str):
        rec = self.data["members"].setdefault(member_id, {"pulled": 0, "cleared": []})
        rec["pulled"] += 1
        rec.setdefault("first", date.today().strftime("%Y.%m.%d"))
        self.save()

    def bio_level(self, member_id: str) -> int:
        """0 = 미해금, 1 = 성격1, 2 = 성격2(함께 클리어), 3 = 성격3(함께 지옥 클리어)."""
        rec = self.data["members"].get(member_id)
        if not rec:
            return 0
        if HELL in rec["cleared"]:
            return 3
        return 2 if rec["cleared"] else 1

    # ------------------------------------------------------------ 클리어 / CG
    def mark_clear(self, chief_id: str, member_ids, grade: str):
        for mid in member_ids:
            rec = self.data["members"].setdefault(mid, {"pulled": 1, "cleared": []})
            if chief_id not in rec["cleared"]:
                rec["cleared"].append(chief_id)
            rec["last_clear"] = date.today().strftime("%Y.%m.%d")
        best = self.data["chiefs"].get(chief_id)
        order = "CBAS"
        if best is None or order.index(grade) > order.index(best):
            self.data["chiefs"][chief_id] = grade
        self.save()

    def chief_cleared(self, chief_id: str) -> bool:
        return chief_id in self.data["chiefs"]

    def mark_rules(self, rule_ids):
        """근무에서 배운 규정을 도감에 적어 둔다."""
        new = [r for r in rule_ids if r not in self.data["rules"]]
        if new:
            self.data["rules"] += new
            self.save()

    def mark_cg(self, cg_id: str) -> bool:
        """처음 본 CG 면 True."""
        if cg_id in self.data["cgs"]:
            return False
        self.data["cgs"].append(cg_id)
        self.save()
        return True
