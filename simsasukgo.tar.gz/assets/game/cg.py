"""이벤트 CG — 게임 캐릭터와 소품으로 연출하는 한 장면.

배역 규칙:
  주인공(hero)  항상 같은 모습 (data/dialogue.json 의 hero)
  팀장(chief)   그 판에서 고른 팀장
  동료(mates)   자리(slot)만 정해져 있고 사람은 바뀐다
                - 플레이 중: 지금 내 팀원이 나온다
                - 앨범에서 볼 때: 해금한 동료 중 무작위

새 CG 추가:  @cg("id", "제목", "한 줄 설명", chiefs=["hell"], slots=2)  def draw(st): ...
            st.actor(...) 로 인물을 세우고, st.mate(i) 로 i 번째 동료 자리를 쓴다(없으면 None).
"""
import math
import random

import pygame

from . import props, sticker, ui
from .character import Character
from .config import HEIGHT, WIDTH

INK = props.INK
CGS: dict[str, dict] = {}
FOOT = 255            # 전신 캐릭터의 발바닥 높이(배율 1 기준, 그림 위쪽에서부터)


def cg(cg_id, title, text, chiefs=None, slots=0):
    def deco(fn):
        CGS[cg_id] = {"id": cg_id, "title": title, "text": text, "chiefs": chiefs, "slots": slots, "draw": fn}
        return fn
    return deco


def available(chief_id: str) -> list[dict]:
    return [c for c in CGS.values() if c["chiefs"] is None or chief_id in c["chiefs"]]


class Stage:
    def __init__(self, surf, hero_look, chief, mates):
        self.s = surf
        self.hero_look = hero_look
        self.chief = chief
        self.mates = list(mates)
        self.data = None

    def mate(self, i):
        return self.mates[i] if i < len(self.mates) else None

    def actor(self, look, pos, expr="happy", pose="idle", scale=1.0, angle=0.0, full=False, flip=False,
              legs=(0, 0), ground=None):
        """인물 한 명. full=True 면 pos 는 발이 닿는 바닥 위치(가운데 아래), 아니면 머리 위(midtop).
        ground 를 주면 그 높이에 그림자를 깐다(점프 표현)."""
        if look is None:
            return
        ch = Character(look, seed=hash(look.get("body", "")) % 97)
        ch.expression = expr
        ch.blink = 0
        ch.legs = legs
        ch.t = 0.4
        ch.set_pose(pose, snap=True)
        if full:
            gy = ground if ground is not None else pos[1]
            w = int(150 * scale * (0.7 if ground is not None and ground > pos[1] + 8 else 1))
            sh = pygame.Surface((w, 26), pygame.SRCALPHA)
            pygame.draw.ellipse(sh, (60, 35, 20, 70), sh.get_rect())
            self.s.blit(sh, sh.get_rect(center=(pos[0], gy + 4)))
            ch.draw(self.s, (pos[0], pos[1] - FOOT * scale), scale=scale, bob=False, flip=flip, angle=angle, full=True)
        else:
            ch.draw(self.s, pos, scale=scale, bob=False, flip=flip, angle=angle)

    def hero(self, pos, **kw):
        self.actor(self.hero_look, pos, **kw)

    def boss(self, pos, **kw):
        kw.setdefault("expr", self.chief.get("expression", "neutral"))
        self.actor(self.chief["look"], pos, **kw)


# ------------------------------------------------------------------ 소품
def confetti(surf, n, seed, area=(0, 0, WIDTH, 470)):
    rng = random.Random(seed)
    colors = [(255, 208, 84), (255, 138, 92), (110, 190, 250), (130, 210, 130), (236, 120, 170), (255, 255, 255)]
    for _ in range(n):
        x, y = rng.randint(area[0], area[2]), rng.randint(area[1], area[3])
        w, h = rng.choice(((10, 5), (6, 6), (12, 4)))
        img = pygame.Surface((w, h), pygame.SRCALPHA)
        img.fill(rng.choice(colors))
        surf.blit(pygame.transform.rotate(img, rng.randint(0, 180)), (x, y))


def bunting(surf, x0, x1, y, sag=34):
    n = 14
    pts = [(x0 + (x1 - x0) * i / n, y + math.sin(math.pi * i / n) * sag) for i in range(n + 1)]
    pygame.draw.lines(surf, INK, False, pts, 4)
    colors = [(255, 138, 92), (255, 208, 84), (110, 190, 250), (130, 210, 130), (236, 120, 170)]
    for i in range(n):
        (ax, ay), (bx, by) = pts[i], pts[i + 1]
        tri = [(ax + 3, ay + 2), (bx - 3, by + 2), ((ax + bx) / 2, (ay + by) / 2 + 40)]
        pygame.draw.polygon(surf, colors[i % 5], tri)
        pygame.draw.polygon(surf, INK, tri, 3)


def balloon(surf, pos, color, r=34):
    x, y = pos
    pygame.draw.line(surf, INK, (x, y + r), (x + 10, y + r + 120), 3)
    pygame.draw.ellipse(surf, INK, (x - r - 4, y - r * 1.2 - 4, r * 2 + 8, r * 2.4 + 8))
    pygame.draw.ellipse(surf, color, (x - r, y - r * 1.2, r * 2, r * 2.4))
    pygame.draw.ellipse(surf, tuple(min(255, c + 60) for c in color), (x - r * 0.5, y - r * 0.9, r * 0.6, r * 0.8))


def paper_stack(surf, x, y, n, w=120):
    rng = random.Random(x * 7 + n)
    for i in range(n):
        r = pygame.Rect(x + rng.randint(-6, 6), y - i * 9, w + rng.randint(-8, 8), 12)
        pygame.draw.rect(surf, (255, 253, 247), r, border_radius=2)
        pygame.draw.rect(surf, INK, r, 2, border_radius=2)


def snack_plate(surf, x, y):
    pygame.draw.ellipse(surf, (255, 253, 247), (x - 60, y - 14, 120, 30))
    pygame.draw.ellipse(surf, INK, (x - 60, y - 14, 120, 30), 3)
    for dx, col in ((-30, (236, 170, 90)), (-6, (226, 150, 70)), (18, (240, 180, 100)), (-18, (220, 140, 60))):
        pygame.draw.circle(surf, col, (x + dx, y - 6 - abs(dx) // 6), 15)
        pygame.draw.circle(surf, INK, (x + dx, y - 6 - abs(dx) // 6), 15, 3)


def cup(surf, x, y, color):
    pts = [(x - 16, y - 40), (x + 16, y - 40), (x + 11, y), (x - 11, y)]
    pygame.draw.polygon(surf, color, pts)
    pygame.draw.polygon(surf, INK, pts, 3)
    pygame.draw.line(surf, INK, (x + 4, y - 40), (x + 14, y - 66), 4)


def table(surf, rect, color=(214, 160, 106)):
    r = pygame.Rect(rect)
    for lx in (r.x + 16, r.right - 28):
        pygame.draw.rect(surf, (176, 124, 78), (lx, r.bottom - 4, 12, 44))
        pygame.draw.rect(surf, INK, (lx, r.bottom - 4, 12, 44), 3)
    props.box(surf, r, color, radius=8, shade=tuple(max(0, c - 34) for c in color))


def night_window(surf, rect):
    r = pygame.Rect(rect)
    pygame.draw.rect(surf, (40, 48, 96), r)
    rng = random.Random(3)
    for _ in range(26):
        pygame.draw.circle(surf, (255, 250, 210), (rng.randint(r.x + 6, r.right - 6), rng.randint(r.y + 6, r.bottom - 30)),
                           rng.choice((1, 2, 2)))
    pygame.draw.circle(surf, (255, 240, 170), (r.right - 60, r.y + 52), 30)
    pygame.draw.circle(surf, (40, 48, 96), (r.right - 46, r.y + 44), 26)
    pygame.draw.rect(surf, (24, 28, 60), (r.x, r.bottom - 34, r.w, 34))
    for i in range(6):
        pygame.draw.rect(surf, (255, 220, 120), (r.x + 14 + i * 38, r.bottom - 26, 10, 8))
    pygame.draw.line(surf, (255, 252, 244), (r.centerx, r.y), (r.centerx, r.bottom), 7)
    pygame.draw.line(surf, (255, 252, 244), (r.x, r.centery), (r.right, r.centery), 7)
    pygame.draw.rect(surf, (255, 252, 244), r.inflate(14, 14), 9, border_radius=8)
    pygame.draw.rect(surf, INK, r.inflate(16, 16), 3, border_radius=9)


def floor_room(surf, wall_h=500, ratio=0.0, t=0.0):
    """벽 + 바닥이 보이는 방 (전신 인물용)."""
    props.draw_wall(surf, wall_h, t, ratio)
    props.draw_desk(surf, wall_h)
    pygame.draw.line(surf, INK, (0, wall_h), (WIDTH, wall_h), 4)


def _fixed(text):
    tw = ui.Typewriter(text)
    tw.skip()
    tw.age = 1.0
    return tw


def caption(surf, title, text, tag):
    bar = pygame.Surface((WIDTH, 104), pygame.SRCALPHA)
    bar.fill((40, 28, 22, 205))
    surf.blit(bar, (0, HEIGHT - 104))
    pygame.draw.line(surf, (255, 208, 84), (0, HEIGHT - 104), (WIDTH, HEIGHT - 104), 4)
    img = sticker.sticker_text(title, 42, sticker.YELLOW)
    surf.blit(img, (40, HEIGHT - 98))
    ui.draw_text(surf, text, (44, HEIGHT - 38), 19, (255, 250, 236), True)
    if tag:
        ui.pill(surf, (WIDTH - 250, 18, 220, 34), tag, (255, 250, 236), INK, 14)


def render(cg_id: str, data, chief: dict, mate_looks, with_caption=True) -> pygame.Surface:
    """CG 한 장을 그린다. mate_looks = 동료 자리에 세울 사람들의 look (0명이어도 된다)."""
    spec = CGS[cg_id]
    surf = pygame.Surface((WIDTH, HEIGHT))
    st = Stage(surf, data.dialogue["hero"]["look"], chief, list(mate_looks)[: spec["slots"]])
    st.data = data
    spec["draw"](st)
    if with_caption:
        caption(surf, spec["title"], spec["text"], chief["difficulty"])
    return surf


# ================================================================== CG 목록
@cg("holiday", "무두절", "팀장님이 외근 가신 날. 사무실에 치킨과 평화가 찾아왔다.", chiefs=["normal"], slots=3)
def _holiday(st: Stage):
    s = st.s
    floor_room(s, 500)
    props.draw_window(s, (70, 70, 230, 170), 4.0, 0.0)
    props.draw_clock(s, (1180, 120), 52, 11 * 60 + 40)
    bunting(s, 300, 1080, 24)
    balloon(s, (430, 150), (255, 138, 92))
    balloon(s, (870, 130), (110, 190, 250))
    balloon(s, (1010, 210), (255, 208, 84), 28)
    sign = pygame.Surface((240, 96), pygame.SRCALPHA)                 # 빈 팀장 자리의 팻말
    pygame.draw.rect(sign, (255, 253, 247), (3, 3, 234, 90), border_radius=10)
    pygame.draw.rect(sign, INK, (3, 3, 234, 90), 4, border_radius=10)
    ui.draw_text(sign, "외근 중", (120, 34), 34, (226, 76, 76), "heavy", center=True)
    ui.draw_text(sign, f"{st.chief['name']} · 내일 복귀", (120, 70), 15, INK, True, center=True)
    sign = pygame.transform.rotozoom(sign, -7, 1.0)
    s.blit(sign, sign.get_rect(center=(1090, 340)))
    props.pin(s, (1090, 300))
    table(s, (150, 452, 300, 34))
    snack_plate(s, 230, 452)
    snack_plate(s, 370, 456)
    cup(s, 300, 452, (236, 96, 96))
    st.actor(st.mate(2), (190, 548), "happy", "hi", 0.82, -6, full=True)
    st.actor(st.mate(0), (470, 566), "happy", "wave", 1.0, 8, full=True, legs=(-10, 14))
    st.hero((700, 520), expr="happy", pose="cheer", scale=1.12, angle=-9, full=True, legs=(-24, 24), ground=574)
    st.actor(st.mate(1), (950, 560), "sly", "hip", 1.0, 12, full=True, flip=True)
    confetti(s, 130, 5)
    for i, ang in enumerate((18, -24)):                                # 종이비행기
        pl = pygame.Surface((90, 50), pygame.SRCALPHA)
        pygame.draw.polygon(pl, (255, 253, 247), [(2, 24), (88, 4), (40, 46)])
        pygame.draw.polygon(pl, INK, [(2, 24), (88, 4), (40, 46)], 3)
        pygame.draw.line(pl, INK, (2, 24), (56, 22), 3)
        pl = pygame.transform.rotozoom(pl, ang, 1.0)
        s.blit(pl, (560 + i * 300, 70 + i * 150))


@cg("overtime", "야근", "감사 자료 제출 하루 전. 오늘도 사무실 불은 꺼지지 않는다.", chiefs=["hell"], slots=2)
def _overtime(st: Stage):
    s = st.s
    props.draw_wall(s, 470, 0, 0.0)
    night_window(s, (70, 70, 230, 170))
    props.draw_clock(s, (1180, 120), 52, 22 * 60 + 10)
    props.draw_calendar(s, (1010, 60, 110, 126), 11, 19, "감사 D-1")
    st.actor(st.mate(0), (250, 240), "nervous", "shrug", 1.05, -6)
    st.hero((530, 276), expr="sad", pose="slump", scale=1.08, angle=-26)
    st.actor(st.mate(1), (770, 262), "shocked", "shock", 0.95, 5, flip=True)
    st.boss((1010, 196), pose="point", scale=1.22, angle=-4, flip=True)
    props.draw_counter(s, 470)
    paper_stack(s, 120, 470, 9)
    paper_stack(s, 350, 470, 5)
    paper_stack(s, 640, 470, 15, 110)
    paper_stack(s, 840, 470, 10, 100)
    cup(s, 330, 478, (236, 96, 96))
    props.draw_desk(s, 504)
    props.draw_mug(s, (240, 574), 2.0)
    props.draw_pen(s, (700, 572), 14)
    dark = pygame.Surface((WIDTH, HEIGHT))                            # 밤: 전체를 살짝 어둡게
    dark.fill((128, 134, 180))
    s.blit(dark, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    light = pygame.Surface((WIDTH, HEIGHT))                           # 스탠드 불빛
    for cx, w in ((480, 520), (860, 420)):
        pygame.draw.polygon(light, (70, 58, 22), [(cx - 30, 150), (cx + 30, 150), (cx + w // 2, 520), (cx - w // 2, 520)])
        pygame.draw.ellipse(light, (56, 44, 16), (cx - w // 2, 476, w, 110))
    s.blit(light, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    for cx in (480, 860):
        shade = [(cx - 44, 150), (cx + 44, 150), (cx + 26, 104), (cx - 26, 104)]
        pygame.draw.polygon(s, (250, 208, 90), shade)
        pygame.draw.polygon(s, INK, shade, 4)
        pygame.draw.line(s, INK, (cx, 104), (cx, 0), 5)
    for i, (x, y) in enumerate(((640, 250), (664, 222), (694, 190))):
        ui.draw_text(s, "z", (x, y), 22 + i * 8, (236, 240, 255), "heavy")


@cg("promotion", "첫 승진", "임용장을 받았다. 팀장님이 나보다 더 기뻐하신다.", slots=2)
def _promotion(st: Stage):
    s = st.s
    floor_room(s, 500, 0.2)
    props.draw_window(s, (70, 80, 230, 170), 9.0, 0.2)
    bunting(s, 340, 1240, 20)
    banner = pygame.Rect(390, 62, 640, 84)
    props.box(s, banner, (255, 138, 92), radius=14, shade=(214, 104, 66))
    img = sticker.sticker_text("승진을 축하합니다!", 46, sticker.WHITE)
    s.blit(img, img.get_rect(center=banner.center))
    props.draw_plant(s, 1200, 500, 0.5)
    st.actor(st.mate(0), (200, 556), "happy", "clap", 0.9, -8, full=True)
    st.actor(st.mate(1), (1060, 552), "happy", "cheer", 0.92, 10, full=True, flip=True, legs=(-12, 12))
    st.boss((490, 572), expr="happy", pose="point", scale=1.12, angle=-5, full=True)
    cert = pygame.Surface((300, 190), pygame.SRCALPHA)                # 팀장님이 내미는 임용장
    pygame.draw.rect(cert, (255, 250, 236), (3, 3, 294, 184), border_radius=6)
    pygame.draw.rect(cert, (214, 170, 80), (13, 13, 274, 164), 4, border_radius=4)
    pygame.draw.rect(cert, INK, (3, 3, 294, 184), 4, border_radius=6)
    ui.draw_text(cert, "임 용 장", (150, 50), 32, INK, "heavy", center=True)
    ui.draw_text(cert, "8급 서기에 임함", (150, 96), 19, INK, True, center=True)
    pygame.draw.circle(cert, (226, 76, 76), (236, 138), 26, 4)
    ui.draw_text(cert, "조달", (236, 138), 15, (226, 76, 76), "heavy", center=True)
    cert = pygame.transform.rotozoom(cert, -8, 0.7)
    r = cert.get_rect(center=(650, 528))
    s.blit(props.silhouette_shadow(cert, 60), r.move(5, 6))
    s.blit(cert, r)
    st.hero((850, 512), expr="happy", pose="cheer", scale=1.12, angle=11, full=True, legs=(-22, 22), ground=574)
    confetti(s, 170, 11)


# ================================================================== 추가 소품
def sky(surf, top, bottom, h):
    for y in range(0, h, 4):
        t = y / h
        pygame.draw.rect(surf, tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)), (0, y, WIDTH, 4))


def cloud(surf, x, y, w=120):
    for dx, dy, r in ((0, 0, 0.30), (0.28, -0.12, 0.36), (0.6, 0, 0.28)):
        pygame.draw.circle(surf, (255, 255, 255), (int(x + w * dx), int(y + w * dy)), int(w * r))


def speech(surf, rect, text, tail, size=19):
    ui.speech_bubble(surf, rect, _fixed(text), tail=tail, size=size)


def banner(surf, rect, text, color=(255, 138, 92), size=40):
    r = pygame.Rect(rect)
    props.box(surf, r, color, radius=14, shade=tuple(max(0, c - 40) for c in color))
    img = sticker.fit(sticker.sticker_text(text, size, sticker.WHITE), r.w - 30)
    surf.blit(img, img.get_rect(center=r.center))


def umbrella(surf, x, y, color=(236, 96, 96), r=120):
    pygame.draw.line(surf, INK, (x, y), (x, y + 210), 6)
    pts = [(x + math.cos(a) * r, y - math.sin(a) * r * 0.8) for a in [i * math.pi / 16 for i in range(17)]]
    pygame.draw.polygon(surf, color, pts)
    for i in range(1, 4):
        pygame.draw.line(surf, tuple(max(0, c - 40) for c in color), (x, y - r * 0.8), (x - r + i * r / 2, y), 3)
    pygame.draw.polygon(surf, INK, pts, 4)


def rain(surf, seed=1, n=150):
    rng = random.Random(seed)
    for _ in range(n):
        x, y = rng.randint(-40, WIDTH), rng.randint(0, 600)
        pygame.draw.line(surf, (190, 214, 240), (x, y), (x + 8, y + 26), 3)


def tray(surf, x, y, cups=3, tilt=0.0):
    t = pygame.Surface((190, 90), pygame.SRCALPHA)
    pygame.draw.ellipse(t, (176, 124, 78), (4, 56, 182, 28))
    pygame.draw.ellipse(t, INK, (4, 56, 182, 28), 4)
    for i in range(cups):
        cx = 40 + i * (110 // max(1, cups - 1)) if cups > 1 else 95
        pygame.draw.rect(t, (255, 253, 247), (cx - 13, 22, 26, 44), border_radius=5)
        pygame.draw.rect(t, (150, 96, 60), (cx - 13, 22, 26, 12), border_top_left_radius=5, border_top_right_radius=5)
        pygame.draw.rect(t, INK, (cx - 13, 22, 26, 44), 3, border_radius=5)
    t = pygame.transform.rotozoom(t, tilt, 1.0)
    surf.blit(t, t.get_rect(center=(x, y)))


def carton(surf, x, y, w=96, label="서류"):
    r = pygame.Rect(x - w // 2, y - 64, w, 64)
    props.box(surf, r, (214, 170, 110), radius=4, shade=(186, 142, 86), offset=(3, 4))
    pygame.draw.line(surf, INK, (r.x, r.y + 16), (r.right, r.y + 16), 3)
    ui.draw_text(surf, label, (r.centerx, r.centery + 8), 14, INK, True, center=True)


def trophy(surf, x, y, k=1.0):
    gold, dark = (255, 208, 72), (226, 164, 40)
    cup_pts = [(x - 34 * k, y - 96 * k), (x + 34 * k, y - 96 * k), (x + 22 * k, y - 40 * k), (x - 22 * k, y - 40 * k)]
    for side in (-1, 1):
        pygame.draw.arc(surf, INK, (x + side * 26 * k - 20 * k, y - 92 * k, 40 * k, 40 * k), 0, math.tau, max(3, int(6 * k)))
    pygame.draw.polygon(surf, gold, cup_pts)
    pygame.draw.polygon(surf, INK, cup_pts, 4)
    pygame.draw.rect(surf, dark, (x - 8 * k, y - 40 * k, 16 * k, 22 * k))
    pygame.draw.rect(surf, INK, (x - 8 * k, y - 40 * k, 16 * k, 22 * k), 3)
    base = pygame.Rect(x - 30 * k, y - 18 * k, 60 * k, 18 * k)
    pygame.draw.rect(surf, dark, base, border_radius=4)
    pygame.draw.rect(surf, INK, base, 3, border_radius=4)


def whiteboard(surf, rect, lines, title=None):
    r = pygame.Rect(rect)
    props.box(surf, r, (255, 255, 255), radius=8, offset=(6, 7))
    pygame.draw.rect(surf, (176, 184, 196), (r.x + 20, r.bottom - 4, r.w - 40, 12), border_radius=4)
    y = r.y + 18
    if title:
        ui.draw_text(surf, title, (r.centerx, y + 8), 26, (226, 76, 76), "heavy", center=True)
        y += 44
    for i, line in enumerate(lines):
        ui.draw_text(surf, line, (r.x + 26, y), 19, (52, 96, 190) if i % 2 == 0 else INK, True)
        y += 34


def lamp(surf, x, y, color=(255, 196, 110)):
    pygame.draw.line(surf, INK, (x, 0), (x, y - 30), 4)
    pygame.draw.ellipse(surf, INK, (x - 34, y - 40, 68, 76))
    pygame.draw.ellipse(surf, color, (x - 30, y - 36, 60, 68))
    pygame.draw.ellipse(surf, (255, 240, 200), (x - 16, y - 24, 22, 28))


def zzz(surf, x, y, color=(120, 130, 190)):
    for i in range(3):
        ui.draw_text(surf, "z", (x + i * 24, y - i * 28), 22 + i * 8, color, "heavy")


def exit_door(surf, x, y, h=300):
    r = pygame.Rect(x, y - h, 150, h)
    props.box(surf, r, (176, 208, 150), radius=6, shade=(150, 186, 126), offset=(5, 6))
    pygame.draw.circle(surf, (255, 208, 72), (r.right - 22, r.centery + 10), 9)
    pygame.draw.circle(surf, INK, (r.right - 22, r.centery + 10), 9, 3)
    sign = pygame.Rect(x + 15, r.y - 46, 120, 36)
    props.box(surf, sign, (84, 180, 110), radius=6, offset=(3, 4))
    ui.draw_text(surf, "퇴근 →", sign.center, 18, (255, 255, 255), True, center=True)


def desk_row(st, y=470):
    """카운터 + 책상 (상반신 인물용 무대)."""
    props.draw_counter(st.s, y)
    props.draw_desk(st.s, y + 34)


# ================================================================== 공통 CG (모든 난이도)
@cg("first_day", "첫 출근", "떨리는 마음으로 창구 앞에 섰다. 오늘부터 나도 조달청 사람이다.", slots=0)
def _first_day(st: Stage):
    s = st.s
    bg_building(s)
    carton(s, 300, 566, 110, "내 짐")
    st.hero((480, 572), expr="nervous", pose="shrug", scale=1.1, angle=-5, full=True)
    st.boss((900, 574), pose="wave", scale=1.18, angle=4, full=True, flip=True)
    speech(s, (540, 150, 350, 84), st.chief["briefing"][0][0], (860, 300), 18)


@cg("lunch", "점심시간", "구내식당에 제육볶음이 나오는 날은 줄이 두 배다.", slots=2)
def _lunch(st: Stage):
    s = st.s
    props.draw_wall(s, 470, 0, 0.0)
    whiteboard(s, (80, 60, 330, 190), ["제육볶음", "된장찌개", "계란말이 (선착순)"], "오늘의 메뉴")
    props.draw_clock(s, (1180, 120), 52, 12 * 60 + 5)
    lamp(s, 640, 110)
    lamp(s, 940, 110)
    st.actor(st.mate(0), (300, 238), "happy", "hold", 1.05, 4)
    st.hero((640, 222), expr="happy", pose="cheer", scale=1.15, angle=-5)
    st.actor(st.mate(1), (980, 244), "shocked", "hold", 1.0, -4, flip=True)
    desk_row(st)
    for x in (300, 640, 980):
        tray(s, x, 486, 0)
        snack_plate(s, x - 20, 480)
        cup(s, x + 62, 492, (110, 190, 250))
    speech(s, (1000, 130, 220, 64), "계란말이 품절?!", (1010, 250), 17)


@cg("rain", "비 오는 날", "우산이 하나뿐이라, 조금씩 젖으면서 같이 걸었다.", slots=1)
def _rain(st: Stage):
    s = st.s
    sky(s, (150, 164, 190), (200, 208, 222), 520)
    for x, w in ((80, 220), (360, 170), (900, 260)):                   # 멀리 보이는 건물
        pygame.draw.rect(s, (168, 178, 200), (x, 520 - w, 150, w))
        for wy in range(520 - w + 20, 500, 44):
            for wx in (x + 22, x + 86):
                pygame.draw.rect(s, (236, 226, 170), (wx, wy, 34, 22))
    pygame.draw.rect(s, (150, 156, 172), (0, 520, WIDTH, 200))
    pygame.draw.line(s, INK, (0, 520), (WIDTH, 520), 4)
    for x, w in ((260, 180), (760, 240), (1040, 150)):                 # 물웅덩이
        pygame.draw.ellipse(s, (186, 206, 232), (x, 590, w, 30))
    umbrella(s, 640, 250, (236, 96, 96), 190)
    st.hero((560, 590), expr="happy", pose="hip", scale=1.05, angle=5, full=True, legs=(-8, 10))
    st.actor(st.mate(0), (740, 592), "happy", "wave", 1.0, -5, full=True, flip=True, legs=(-10, 8))
    rain(s, 4)


@cg("newmate", "새 동료", "새 동료가 왔다. 창구가 조금 더 북적인다.", slots=3)
def _newmate(st: Stage):
    s = st.s
    bg_cafe(s)
    banner(s, (440, 296, 400, 66), "환영합니다!", (84, 180, 110), 34)
    table(s, (960, 452, 240, 34))
    pygame.draw.rect(s, (255, 236, 220), (1030, 392, 100, 60), border_radius=10)      # 케이크
    pygame.draw.rect(s, (236, 120, 150), (1030, 392, 100, 18), border_top_left_radius=10, border_top_right_radius=10)
    pygame.draw.rect(s, INK, (1030, 392, 100, 60), 4, border_radius=10)
    pygame.draw.line(s, INK, (1080, 392), (1080, 366), 4)
    pygame.draw.circle(s, (255, 208, 72), (1080, 360), 8)
    newest = st.mates[-1] if st.mates else None
    others = st.mates[:-1]
    st.actor(others[0] if others else None, (230, 556), "happy", "clap", 0.9, -7, full=True)
    st.hero((470, 566), expr="happy", pose="wave", scale=1.08, angle=-6, full=True)
    st.actor(newest, (720, 570), "nervous", "shrug", 1.12, 5, full=True, flip=True)
    st.actor(others[1] if len(others) > 1 else None, (900, 552), "happy", "cheer", 0.88, 9, full=True, flip=True)
    confetti(s, 90, 21)


@cg("finale", "마지막 퇴근", "닷새가 지났다. 이 창구가 벌써 내 자리 같다.", slots=3)
def _finale(st: Stage):
    s = st.s
    bg_building(s, sunset=True)
    banner(s, (30, 30, 440, 70), "5일간 수고했어요!", (255, 138, 92), 32)
    st.actor(st.mate(2), (160, 548), "happy", "hi", 0.84, -8, full=True)
    st.actor(st.mate(0), (360, 562), "happy", "wave", 0.96, -4, full=True)
    st.hero((600, 574), expr="happy", pose="cheer", scale=1.14, angle=3, full=True)
    st.boss((860, 572), expr="happy", pose="hi", scale=1.14, angle=-3, full=True, flip=True)
    st.actor(st.mate(1), (1090, 558), "happy", "cheer", 0.94, 8, full=True, flip=True, legs=(-10, 10))
    confetti(s, 70, 33)


# ================================================================== 쌩신입 (천사 팀장)
@cg("snack", "간식 타임", "팀장님의 서랍은 과자 창고다. 오후 세 시가 기다려진다.", chiefs=["easy"], slots=2)
def _snack(st: Stage):
    s = st.s
    bg_pantry(s)
    st.actor(st.mate(0), (270, 250), "happy", "cheer", 1.0, -6)
    st.hero((520, 236), expr="happy", pose="clap", scale=1.1, angle=4)
    st.boss((820, 214), expr="happy", pose="hold", scale=1.22, flip=True)
    st.actor(st.mate(1), (1080, 256), "happy", "hi", 0.95, 6, flip=True)
    desk_row(st)
    for x in (420, 640, 860):
        snack_plate(s, x, 476)
    cup(s, 540, 488, (236, 120, 170))
    cup(s, 760, 488, (255, 208, 84))
    speech(s, (560, 160, 250, 64), "하나씩 더 먹어요~", (800, 240), 17)


@cg("picnic", "봄 소풍", "팀장님이 김밥을 서른 줄 싸 오셨다. 서른 줄.", chiefs=["easy"], slots=2)
def _picnic(st: Stage):
    s = st.s
    sky(s, (150, 208, 250), (214, 238, 250), 440)
    pygame.draw.circle(s, (255, 240, 170), (1100, 110), 54)
    cloud(s, 180, 120, 150)
    cloud(s, 700, 80, 110)
    pygame.draw.ellipse(s, (150, 206, 130), (-100, 360, 700, 300))
    pygame.draw.ellipse(s, (130, 194, 118), (500, 340, 900, 320))
    pygame.draw.rect(s, (140, 200, 122), (0, 470, WIDTH, 250))
    mat = [(300, 520), (1000, 520), (1080, 620), (220, 620)]             # 돗자리
    pygame.draw.polygon(s, (255, 253, 247), mat)
    for i in range(1, 8):
        x0, x1 = 300 + i * 87.5, 220 + i * 107.5
        pygame.draw.line(s, (236, 120, 120), (x0, 520), (x1, 620), 6)
    pygame.draw.polygon(s, INK, mat, 4)
    st.actor(st.mate(0), (330, 548), "happy", "wave", 0.92, -8, full=True)
    st.hero((560, 572), expr="happy", pose="hold", scale=1.05, angle=5, full=True)
    st.boss((800, 568), expr="happy", pose="cheer", scale=1.14, angle=-4, full=True, flip=True)
    st.actor(st.mate(1), (1010, 552), "happy", "clap", 0.9, 8, full=True, flip=True)
    for i in range(6):                                                   # 김밥 도시락
        pygame.draw.circle(s, INK, (640 + i * 22, 606), 12)
        pygame.draw.circle(s, (255, 253, 247), (640 + i * 22, 606), 8)
        pygame.draw.circle(s, (240, 170, 80), (640 + i * 22, 606), 3)
    for x, y in ((420, 300), (930, 260)):                                # 나비
        for side in (-1, 1):
            pygame.draw.ellipse(s, (255, 190, 220), (x + side * 12 - 10, y - 10, 20, 24))
        pygame.draw.line(s, INK, (x, y - 8), (x, y + 10), 3)


@cg("praise", "칭찬 스티커", "칭찬 스티커판이 생겼다. 유치하다고 생각했는데… 다 모으고 싶다.", chiefs=["easy"], slots=1)
def _praise(st: Stage):
    s = st.s
    floor_room(s, 500)
    board = pygame.Rect(360, 70, 520, 300)
    props.box(s, board, (255, 253, 247), radius=10, offset=(6, 7))
    ui.draw_text(s, "참 잘했어요 스티커판", (board.centerx, board.y + 30), 26, (226, 76, 76), "heavy", center=True)
    rng = random.Random(8)
    for row in range(3):
        for col in range(7):
            c = (board.x + 62 + col * 66, board.y + 96 + row * 66)
            pygame.draw.circle(s, (236, 224, 204), c, 24, 3)
            if rng.random() < 0.62:
                pts = [(c[0] + math.cos(-math.pi / 2 + j * math.pi / 5) * (20 if j % 2 == 0 else 9),
                        c[1] + math.sin(-math.pi / 2 + j * math.pi / 5) * (20 if j % 2 == 0 else 9)) for j in range(10)]
                pygame.draw.polygon(s, (255, 208, 72), pts)
                pygame.draw.polygon(s, INK, pts, 3)
    st.actor(st.mate(0), (200, 560), "happy", "clap", 0.92, -7, full=True)
    st.boss((1010, 572), expr="happy", pose="point", scale=1.14, angle=3, full=True, flip=True)
    st.hero((660, 524), expr="happy", pose="cheer", scale=1.1, angle=-8, full=True, legs=(-22, 22), ground=576)
    confetti(s, 50, 41, (0, 0, WIDTH, 300))


@cg("nap", "꾸벅꾸벅", "깜빡 졸았는데, 눈을 뜨니 어깨에 담요가 있었다.", chiefs=["easy"], slots=1)
def _nap(st: Stage):
    s = st.s
    props.draw_wall(s, 470, 0, 0.8)
    props.draw_window(s, (70, 70, 230, 170), 7.0, 0.8)
    props.draw_clock(s, (1180, 120), 52, 16 * 60 + 20)
    st.actor(st.mate(0), (1060, 260), "happy", "hip", 0.92, 4, flip=True)
    st.boss((300, 220), expr="happy", pose="point", scale=1.16, angle=3)
    st.hero((640, 286), expr="happy", pose="slump", scale=1.14, angle=-22)
    blanket = [(560, 420), (800, 388), (840, 470), (540, 470)]            # 담요
    pygame.draw.polygon(s, (255, 190, 200), blanket)
    for i in range(1, 5):
        pygame.draw.line(s, (255, 226, 232), (560 + i * 52, 420 - i * 7), (540 + i * 62, 470), 6)
    pygame.draw.polygon(s, INK, blanket, 4)
    desk_row(st)
    paper_stack(s, 880, 470, 4)
    props.draw_mug(s, (420, 560), 1.0)
    zzz(s, 780, 250)
    speech(s, (150, 96, 150, 60), "쉿…", (300, 240), 20)


@cg("vacation", "첫 휴가", "팀장님이 '연차는 무조건 다 쓰세요' 하며 결재해 주셨다.", chiefs=["easy"], slots=1)
def _vacation(st: Stage):
    s = st.s
    sky(s, (120, 200, 250), (200, 236, 250), 360)
    pygame.draw.circle(s, (255, 240, 170), (1080, 110), 60)
    cloud(s, 200, 110, 150)
    cloud(s, 760, 150, 100)
    pygame.draw.rect(s, (90, 180, 230), (0, 340, WIDTH, 150))             # 바다
    for y in range(360, 480, 30):
        for x in range((y // 30 % 2) * 60, WIDTH, 120):
            pygame.draw.arc(s, (190, 230, 250), (x, y, 60, 20), 0, math.pi, 4)
    pygame.draw.rect(s, (250, 226, 170), (0, 480, WIDTH, 240))            # 모래
    pygame.draw.line(s, INK, (0, 480), (WIDTH, 480), 4)
    umbrella(s, 260, 320, (255, 138, 92), 150)
    pygame.draw.rect(s, (110, 190, 250), (150, 560, 220, 26), border_radius=8)   # 돗자리
    pygame.draw.rect(s, INK, (150, 560, 220, 26), 3, border_radius=8)
    st.actor(st.mate(0), (980, 590), "happy", "hold", 0.95, 6, full=True, flip=True)
    pts = [(1060, 600), (1100, 520), (1140, 600)]                         # 모래성
    pygame.draw.polygon(s, (236, 204, 140), pts)
    pygame.draw.polygon(s, INK, pts, 4)
    st.hero((640, 560), expr="happy", pose="cheer", scale=1.15, angle=-7, full=True, legs=(-20, 20), ground=612)
    pygame.draw.ellipse(s, (255, 120, 150), (540, 470, 200, 70), 22)      # 튜브
    pygame.draw.ellipse(s, INK, (530, 460, 220, 90), 4)


# ================================================================== 숙련된조교 (원칙 팀장)
@cg("training", "규정 교육", "\"질문 있나?\" 하면 아무도 손을 들지 않는다. 나만 빼고.", chiefs=["normal"], slots=2)
def _training(st: Stage):
    s = st.s
    props.draw_wall(s, 470, 0, 0.0)
    whiteboard(s, (430, 50, 520, 240), ["제1조  등록증 확인", "제5조  보증금 5% 이상", "제9조  상호는 한 글자씩!"], "오늘의 규정")
    st.boss((1090, 210), pose="point", scale=1.2, angle=3, flip=True)
    st.actor(st.mate(0), (210, 268), "nervous", "shrug", 0.98, -4)
    st.hero((470, 300), expr="happy", pose="hi", scale=1.05, angle=4)
    st.actor(st.mate(1), (720, 310), "neutral", "hold", 0.95, -3)
    desk_row(st)
    for x in (200, 470, 720):
        paper_stack(s, x - 50, 480, 2, 100)
    props.draw_pen(s, (560, 570), 20)


@cg("audit", "감사 대비", "감사 일주일 전. 창고의 서류가 전부 걸어 나왔다.", chiefs=["normal"], slots=2)
def _audit(st: Stage):
    s = st.s
    bg_archive(s)
    props.draw_calendar(s, (575, 150, 130, 150), 11, 13, "감사 D-7")
    for x in (330, 420, 510):
        for k in range(3):
            carton(s, x, 500 - k * 62, 86, "")
    st.boss((1060, 572), pose="point", scale=1.14, angle=-3, full=True, flip=True)
    st.actor(st.mate(0), (250, 580), "nervous", "hold", 1.0, -10, full=True, legs=(-16, 12))
    carton(s, 262, 500, 100)
    st.hero((700, 572), expr="shocked", pose="shock", scale=1.1, angle=6, full=True)
    st.actor(st.mate(1), (880, 586), "sad", "hold", 0.94, 9, full=True, flip=True, legs=(-10, 16))
    carton(s, 868, 512, 96)
    rng = random.Random(6)
    for _ in range(9):                                                   # 날리는 서류
        p = pygame.Surface((54, 40), pygame.SRCALPHA)
        pygame.draw.rect(p, (255, 253, 247), (2, 2, 50, 36))
        pygame.draw.rect(p, INK, (2, 2, 50, 36), 3)
        p = pygame.transform.rotozoom(p, rng.randint(-40, 40), 1.0)
        s.blit(p, (rng.randint(520, 980), rng.randint(120, 380)))
    speech(s, (900, 180, 250, 64), "작년 것도 꺼내게.", (1040, 300), 17)


@cg("dinner", "회식 2차", "'딱 1차만'이라던 팀장님이 노래방 마이크를 놓지 않는다.", chiefs=["normal"], slots=2)
def _dinner(st: Stage):
    s = st.s
    bg_karaoke(s)
    st.actor(st.mate(0), (260, 250), "happy", "clap", 1.0, -6)
    st.hero((540, 238), expr="nervous", pose="shrug", scale=1.08, angle=4)
    st.boss((860, 200), expr="happy", pose="hi", scale=1.22, angle=-6, flip=True)
    st.actor(st.mate(1), (1110, 262), "happy", "cheer", 0.92, 8, flip=True)
    pygame.draw.line(s, INK, (770, 262), (742, 196), 8)                    # 마이크
    pygame.draw.circle(s, (90, 96, 110), (740, 190), 18)
    pygame.draw.circle(s, INK, (740, 190), 18, 4)
    for i, (x, y) in enumerate(((650, 150), (690, 110), (610, 100))):      # 음표
        pygame.draw.circle(s, (255, 236, 150), (x, y), 10)
        pygame.draw.line(s, (255, 236, 150), (x + 9, y), (x + 9, y - 34), 4)
    desk_row(st)
    for x in (360, 640, 920):
        snack_plate(s, x, 478)
    for x, col in ((250, (255, 208, 84)), (500, (255, 208, 84)), (780, (236, 96, 96)), (1050, (255, 208, 84))):
        cup(s, x, 492, col)


@cg("award", "모범 창구상", "우리 창구가 이달의 모범 창구로 뽑혔다. 팀장님이 처음으로 웃었다.", chiefs=["normal"], slots=2)
def _award(st: Stage):
    s = st.s
    bg_auditorium(s)
    banner(s, (360, 70, 560, 80), "이달의 모범 창구", (245, 184, 50), 40)
    st.actor(st.mate(0), (220, 558), "happy", "clap", 0.92, -8, full=True)
    st.boss((440, 574), expr="happy", pose="clap", scale=1.12, angle=-3, full=True)
    st.hero((720, 520), expr="happy", pose="cheer", scale=1.12, angle=7, full=True, legs=(-22, 22), ground=576)
    trophy(s, 724, 262, 1.25)
    st.actor(st.mate(1), (1010, 560), "happy", "cheer", 0.94, 9, full=True, flip=True, legs=(-12, 12))
    confetti(s, 150, 17)


# ================================================================== 지옥 (악덕 팀장)
@cg("coffee", "커피 심부름", "아메리카노 넷, 라떼 둘, 그리고 '아무거나'. 아무거나가 제일 어렵다.", chiefs=["hell"], slots=1)
def _coffee(st: Stage):
    s = st.s
    bg_cafe(s)
    props.draw_clock(s, (640, 110), 46, 13 * 60 + 57, 1.0, 0.03)
    st.actor(st.mate(0), (200, 556), "shocked", "shock", 0.88, -6, full=True)
    st.boss((1040, 572), pose="point", scale=1.16, angle=-4, full=True, flip=True)
    speech(s, (840, 190, 220, 64), "3분 남았다.", (1010, 300), 18)
    st.hero((560, 566), expr="nervous", pose="hold", scale=1.1, angle=-16, full=True, legs=(-34, 30))
    tray(s, 668, 420, 4, -14)
    for i, (x, y) in enumerate(((760, 350), (800, 400), (740, 300))):      # 튀는 커피
        pygame.draw.circle(s, (150, 96, 60), (x, y), 9 - i * 2)
        pygame.draw.circle(s, INK, (x, y), 9 - i * 2, 2)
    for i in range(4):                                                    # 속도선
        pygame.draw.line(s, (200, 170, 130), (300 + i * 20, 400 + i * 34), (420 + i * 20, 400 + i * 34), 6)


@cg("credit", "공로 가로채기", "내가 밤새 만든 보고서로 팀장님이 상을 받았다.", chiefs=["hell"], slots=2)
def _credit(st: Stage):
    s = st.s
    pygame.draw.rect(s, (70, 50, 90), (0, 0, WIDTH, HEIGHT))
    for x in range(0, WIDTH, 120):                                         # 커튼
        pygame.draw.rect(s, (150, 50, 66), (x, 0, 60, 460))
        pygame.draw.rect(s, (130, 40, 56), (x + 60, 0, 60, 460))
    pygame.draw.rect(s, (110, 76, 60), (0, 460, WIDTH, 260))
    pygame.draw.line(s, INK, (0, 460), (WIDTH, 460), 4)
    spot = pygame.Surface((WIDTH, HEIGHT))
    pygame.draw.polygon(spot, (84, 76, 40), [(800, 0), (920, 0), (1120, 560), (640, 560)])
    pygame.draw.ellipse(spot, (70, 62, 30), (640, 520, 480, 90))
    s.blit(spot, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    banner(s, (640, 60, 470, 70), "최우수 심사 유공", (245, 184, 50), 34)
    stage = pygame.Rect(660, 520, 440, 50)
    props.box(s, stage, (176, 124, 78), radius=8, shade=(150, 100, 60))
    st.boss((880, 524), pose="cheer", scale=1.18, angle=4, full=True, flip=True)
    trophy(s, 880, 236, 1.2)
    st.actor(st.mate(0), (160, 590), "shocked", "shock", 0.9, -6, full=True)
    st.hero((400, 596), expr="shocked", pose="point", scale=1.12, angle=-6, full=True)
    st.actor(st.mate(1), (590, 600), "sad", "slump", 0.86, 6, full=True, flip=True)
    speech(s, (220, 210, 260, 64), "저거… 내 보고서인데?", (400, 330), 17)


@cg("weekend", "주말 출근", "토요일의 사무실은 조용하다. 너무 조용하다.", chiefs=["hell"], slots=0)
def _weekend(st: Stage):
    s = st.s
    props.draw_wall(s, 470, 0, 0.0)
    props.draw_window(s, (70, 70, 230, 170), 8.0, 0.0)
    props.draw_calendar(s, (980, 56, 140, 160), 11, 21, "토요일")
    props.draw_clock(s, (1190, 130), 50, 10 * 60 + 15)
    st.hero((520, 262), expr="sad", pose="slump", scale=1.14, angle=6)
    desk_row(st)
    paper_stack(s, 180, 470, 12)
    paper_stack(s, 330, 470, 7)
    paper_stack(s, 700, 470, 15, 110)
    props.draw_mug(s, (300, 580), 1.0)
    phone = pygame.Rect(820, 520, 250, 150)                                # 책상 위 휴대폰
    props.box(s, phone, (60, 60, 76), radius=18)
    pygame.draw.rect(s, (236, 244, 255), phone.inflate(-20, -20), border_radius=10)
    ui.draw_text(s, st.chief["name"], (phone.x + 26, phone.y + 24), 14, (120, 124, 150), True)
    ui.draw_wrapped(s, "나는 골프 중. 월요일 아침까지 끝내 놔라.", (phone.x + 26, phone.y + 48, 200, 80), 16, INK, True)
    for x, y in ((150, 110), (190, 130)):                                  # 창밖의 새
        pygame.draw.arc(s, INK, (x, y, 20, 14), 0.2, math.pi - 0.2, 3)
        pygame.draw.arc(s, INK, (x + 18, y, 20, 14), 0.2, math.pi - 0.2, 3)


@cg("escape", "칼퇴 작전", "여섯 시 정각. 발소리를 죽이고 문까지 열두 걸음.", chiefs=["hell"], slots=2)
def _escape(st: Stage):
    s = st.s
    floor_room(s, 500, 0.9)
    props.draw_clock(s, (640, 110), 54, 18 * 60)
    exit_door(s, 60, 500)
    table(s, (940, 420, 300, 40))
    st.boss((1090, 190), expr="happy", pose="slump", scale=1.16, angle=-18, flip=True)
    paper_stack(s, 960, 420, 5)
    zzz(s, 1010, 170, (236, 240, 255))
    st.hero((330, 580), expr="nervous", pose="run", scale=1.06, angle=12, full=True, legs=(-28, 24), flip=True)
    st.actor(st.mate(0), (540, 584), "nervous", "run", 0.98, 12, full=True, legs=(-22, 26), flip=True)
    st.actor(st.mate(1), (740, 588), "shocked", "run", 0.92, 12, full=True, legs=(-26, 20), flip=True)
    speech(s, (380, 250, 150, 58), "쉿…!", (360, 330), 18)
    for x in (430, 630, 830):                                             # 살금살금 먼지
        for k in range(3):
            pygame.draw.circle(s, (214, 180, 140), (x + k * 14, 600 - k * 4), 6 - k)


@cg("bad_end", "감사실 호출", "감사 경고 다섯 장. 오늘은 창구가 아니라 감사실로 출근했다.", chiefs=["normal", "hell"], slots=0)
def _bad_end(st: Stage):
    s = st.s
    s.fill((56, 60, 84))                                                   # 어두운 감사실
    pygame.draw.rect(s, (46, 48, 70), (0, 0, WIDTH, 96))
    for x in range(80, WIDTH, 170):
        pygame.draw.line(s, (66, 70, 98), (x, 96), (x, 480), 3)
    pygame.draw.rect(s, (92, 80, 88), (0, 480, WIDTH, HEIGHT - 480))
    pygame.draw.line(s, INK, (0, 480), (WIDTH, 480), 4)
    spot = pygame.Surface((WIDTH, HEIGHT))                                 # 취조등 불빛
    pygame.draw.polygon(spot, (78, 70, 38), [(590, 0), (690, 0), (960, 640), (320, 640)])
    s.blit(spot, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    lamp(s, 640, 110, (255, 226, 130))
    plate = pygame.Rect(70, 130, 190, 62)                                  # 문패
    props.box(s, plate, (236, 226, 206), radius=8)
    ui.draw_text(s, "감 사 실", plate.center, 26, INK, "heavy", center=True)
    props.draw_clock(s, (1150, 180), 46, 9 * 60 + 5)
    st.actor({"body": "#4A4E6A", "shape": "tall", "ears": "none", "acc": ["glasses", "tie"]}, (200, 620),
             "neutral", "hold", 1.12, 3, full=True)                        # 감사관
    st.boss((1070, 616), pose="hip", scale=1.08, angle=-3, full=True, flip=True)
    st.hero((640, 236), expr="sad", pose="slump", scale=1.16, angle=5)
    front = pygame.Rect(346, 506, 588, 96)                                 # 책상 앞판 (다리 사이를 가린다)
    pygame.draw.rect(s, (112, 84, 72), front, border_radius=6)
    pygame.draw.rect(s, INK, front, 4, border_radius=6)
    pygame.draw.line(s, (96, 70, 60), (front.x + 12, front.y + 48), (front.right - 12, front.y + 48), 3)
    for lx in (346, 922):                                                  # 책상 다리
        pygame.draw.rect(s, (112, 84, 72), (lx, 596, 14, 30))
        pygame.draw.rect(s, INK, (lx, 596, 14, 30), 3)
    props.box(s, pygame.Rect(330, 470, 620, 48), (150, 116, 96), radius=8, shade=(116, 82, 62))
    for i in range(5):                                                     # 책상 위 경고장 다섯 장
        sheet = pygame.Rect(366 + i * 112, 420 + (i % 2) * 8, 90, 62)
        props.box(s, sheet, (255, 250, 240), radius=4, offset=(3, 4))
        pygame.draw.circle(s, (224, 78, 70), (sheet.x + 22, sheet.centery), 14)
        pygame.draw.circle(s, INK, (sheet.x + 22, sheet.centery), 14, 2)
        ui.draw_text(s, "!", (sheet.x + 22, sheet.centery), 20, (255, 255, 255), "heavy", center=True)
        ui.draw_text(s, "경고", (sheet.x + 60, sheet.centery), 15, INK, True, center=True)
    speech(s, (70, 250, 290, 64), "이 도장들… 설명해 보시죠.", (210, 356), 17)
    for dx in (-70, 74):                                                   # 식은땀
        pygame.draw.circle(s, (150, 210, 250), (640 + dx, 300 + abs(dx) // 6), 7)
        pygame.draw.circle(s, INK, (640 + dx, 300 + abs(dx) // 6), 7, 2)


# 흐름에서 정해진 때에만 나오는 CG (그 밖의 CG 는 날과 날 사이에 무작위로)
MILESTONES = ("first_day", "promotion", "newmate", "finale", "bad_end")


def pick_random(chief_id: str, run_seen, profile_seen, rng) -> str | None:
    """오늘 보여 줄 CG. 이번 판에서 아직 안 본 것 중, 한 번도 못 본 CG 를 3배 우선한다."""
    pool = [c["id"] for c in available(chief_id) if c["id"] not in MILESTONES and c["id"] not in run_seen]
    if not pool:
        return None
    weights = [1.0 if c in profile_seen else 3.0 for c in pool]
    return rng.choices(pool, weights=weights)[0]


# ================================================================== 배경 모음 — 장면마다 장소가 달라야 덜 밋밋하다
def _ground(surf, y, color, line=True):
    pygame.draw.rect(surf, color, (0, y, WIDTH, HEIGHT - y))
    if line:
        pygame.draw.line(surf, INK, (0, y), (WIDTH, y), 4)


def _tree(surf, x, y, k=1.0, color=(120, 190, 110)):
    pygame.draw.rect(surf, (150, 104, 66), (x - 10 * k, y - 70 * k, 20 * k, 70 * k))
    pygame.draw.rect(surf, INK, (x - 10 * k, y - 70 * k, 20 * k, 70 * k), 3)
    for dx, dy, r in ((0, -120, 56), (-38, -86, 44), (38, -86, 44)):
        pygame.draw.circle(surf, INK, (int(x + dx * k), int(y + dy * k)), int(r * k) + 4)
    for dx, dy, r in ((0, -120, 56), (-38, -86, 44), (38, -86, 44)):
        pygame.draw.circle(surf, color, (int(x + dx * k), int(y + dy * k)), int(r * k))


def bg_building(surf, sunset=False):
    """조달청 청사 앞 거리."""
    if sunset:
        sky(surf, (255, 170, 110), (255, 220, 170), 500)
        pygame.draw.circle(surf, (255, 120, 80), (1050, 330), 70)
    else:
        sky(surf, (140, 204, 250), (214, 238, 252), 500)
        pygame.draw.circle(surf, (255, 242, 170), (1090, 100), 50)
        cloud(surf, 120, 110, 150)
        cloud(surf, 900, 170, 110)
    wall = (236, 228, 214) if not sunset else (244, 206, 170)
    b = pygame.Rect(330, 70, 620, 430)
    pygame.draw.rect(surf, wall, b)
    pygame.draw.rect(surf, tuple(max(0, c - 24) for c in wall), (b.x, b.y, b.w, 40))
    glass = (170, 214, 240) if not sunset else (255, 214, 150)
    for row in range(3):
        for col in range(6):
            w = pygame.Rect(b.x + 34 + col * 96, b.y + 64 + row * 86, 68, 58)
            pygame.draw.rect(surf, glass, w)
            pygame.draw.rect(surf, INK, w, 3)
    door = pygame.Rect(b.centerx - 90, 348, 180, 152)
    pygame.draw.rect(surf, glass, door)
    pygame.draw.line(surf, INK, (door.centerx, door.y), (door.centerx, door.bottom), 4)
    pygame.draw.rect(surf, INK, door, 4)
    pygame.draw.rect(surf, INK, b, 4)
    sign = pygame.Rect(b.centerx - 130, 288, 260, 50)
    props.box(surf, sign, (72, 142, 232), radius=8, offset=(4, 5))
    ui.draw_text(surf, "조 달 청", sign.center, 28, (255, 255, 255), "heavy", center=True)
    _tree(surf, 170, 500, 1.3)
    _tree(surf, 1120, 500, 1.15, (140, 200, 120) if not sunset else (170, 170, 100))
    _ground(surf, 500, (224, 216, 204) if not sunset else (232, 190, 150))
    for x in range(0, WIDTH, 160):
        pygame.draw.line(surf, (200, 190, 176), (x, 500), (x - 60, HEIGHT), 3)


def bg_cafe(surf):
    pygame.draw.rect(surf, (250, 230, 208), (0, 0, WIDTH, 500))
    pygame.draw.rect(surf, (196, 150, 110), (0, 380, WIDTH, 120))
    pygame.draw.line(surf, INK, (0, 380), (WIDTH, 380), 3)
    board = pygame.Rect(70, 60, 330, 230)                              # 칠판 메뉴
    props.box(surf, board, (60, 90, 76), radius=8, offset=(6, 7))
    pygame.draw.rect(surf, (176, 124, 78), board, 8, border_radius=8)
    ui.draw_text(surf, "MENU", (board.centerx, board.y + 34), 26, (255, 236, 150), "heavy", center=True)
    for i, t in enumerate(("아메리카노   2,000", "카페라떼    2,500", "오늘의 케이크 3,000")):
        ui.draw_text(surf, t, (board.x + 34, board.y + 76 + i * 44), 20, (240, 244, 236), True)
    shelf = pygame.Rect(860, 150, 340, 14)
    pygame.draw.rect(surf, (176, 124, 78), shelf)
    pygame.draw.rect(surf, INK, shelf, 3)
    for i, col in enumerate(((255, 253, 247), (236, 120, 150), (110, 190, 250), (255, 208, 84), (255, 253, 247))):
        cup(surf, 900 + i * 66, 150, col)
    for x in (560, 720):
        lamp(surf, x, 120, (255, 208, 130))
    mach = pygame.Rect(930, 250, 190, 130)                              # 에스프레소 머신
    props.box(surf, mach, (190, 196, 206), radius=10, shade=(150, 156, 170))
    pygame.draw.rect(surf, (60, 60, 76), (mach.x + 24, mach.y + 20, 142, 40), border_radius=6)
    pygame.draw.circle(surf, (236, 96, 96), (mach.x + 150, mach.y + 90), 10)
    props.draw_desk(surf, 500)
    pygame.draw.line(surf, INK, (0, 500), (WIDTH, 500), 4)


def bg_pantry(surf):
    """탕비실 (상반신 무대용)."""
    pygame.draw.rect(surf, (226, 244, 236), (0, 0, WIDTH, 470))
    for i in range(5):                                                  # 상부장
        r = pygame.Rect(300 + i * 150, 20, 140, 120)
        pygame.draw.rect(surf, (255, 253, 247), r, border_radius=6)
        pygame.draw.rect(surf, INK, r, 3, border_radius=6)
        pygame.draw.circle(surf, INK, (r.right - 18, r.bottom - 22), 5)
    fridge = pygame.Rect(60, 60, 170, 410)
    props.box(surf, fridge, (214, 232, 244), radius=12, shade=(186, 210, 228))
    pygame.draw.line(surf, INK, (fridge.x, fridge.y + 150), (fridge.right, fridge.y + 150), 3)
    for y in (fridge.y + 60, fridge.y + 190):
        pygame.draw.rect(surf, INK, (fridge.right - 30, y, 8, 60), border_radius=4)
    micro = pygame.Rect(1080, 300, 150, 100)
    props.box(surf, micro, (255, 253, 247), radius=8)
    pygame.draw.rect(surf, (60, 60, 76), (micro.x + 14, micro.y + 16, 90, 66), border_radius=6)
    props.draw_clock(surf, (1170, 200), 44, 15 * 60)


def bg_archive(surf):
    """문서고: 양쪽에 서류 선반, 알전구 하나."""
    pygame.draw.rect(surf, (206, 198, 190), (0, 0, WIDTH, 500))
    rng = random.Random(12)
    colors = [(236, 96, 96), (110, 190, 250), (255, 208, 84), (130, 210, 130), (190, 150, 220), (255, 253, 247)]
    for x0 in (20, 1000):
        frame = pygame.Rect(x0, 30, 260, 470)
        pygame.draw.rect(surf, (150, 110, 76), frame)
        for row in range(5):
            y = frame.y + 12 + row * 92
            pygame.draw.rect(surf, (120, 86, 58), (frame.x + 8, y, frame.w - 16, 78))
            x = frame.x + 14
            while x < frame.right - 30:
                w = rng.choice((16, 20, 26))
                h = rng.randint(54, 74)
                pygame.draw.rect(surf, rng.choice(colors), (x, y + 78 - h, w, h))
                pygame.draw.rect(surf, INK, (x, y + 78 - h, w, h), 2)
                x += w + 2
        pygame.draw.rect(surf, INK, frame, 4)
    pygame.draw.line(surf, INK, (640, 0), (640, 70), 4)                 # 알전구
    pygame.draw.circle(surf, (255, 236, 150), (640, 86), 20)
    pygame.draw.circle(surf, INK, (640, 86), 20, 3)
    glow = pygame.Surface((WIDTH, HEIGHT))
    pygame.draw.circle(glow, (40, 34, 12), (640, 120), 330)
    surf.blit(glow, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    _ground(surf, 500, (176, 166, 156))


def bg_auditorium(surf):
    """강당 무대: 파란 커튼 + 조명."""
    for x in range(0, WIDTH, 100):
        pygame.draw.rect(surf, (70, 110, 190), (x, 0, 50, 500))
        pygame.draw.rect(surf, (56, 92, 168), (x + 50, 0, 50, 500))
    pygame.draw.rect(surf, (150, 50, 66), (0, 0, WIDTH, 50))
    for x in range(0, WIDTH, 80):
        pygame.draw.circle(surf, (150, 50, 66), (x + 40, 50), 40)
    _ground(surf, 500, (196, 150, 104))
    spot = pygame.Surface((WIDTH, HEIGHT))
    pygame.draw.polygon(spot, (60, 56, 30), [(580, 0), (700, 0), (980, 560), (460, 560)])
    pygame.draw.ellipse(spot, (50, 46, 22), (460, 520, 520, 90))
    surf.blit(spot, (0, 0), special_flags=pygame.BLEND_RGB_ADD)


def bg_karaoke(surf):
    """노래방 (상반신 무대용): 미러볼과 색 조명."""
    pygame.draw.rect(surf, (60, 40, 92), (0, 0, WIDTH, 470))
    beams = pygame.Surface((WIDTH, HEIGHT))
    for (x0, x1, col) in ((640, 80, (70, 20, 60)), (640, 420, (20, 60, 70)), (640, 860, (70, 60, 16)), (640, 1220, (30, 60, 30))):
        pygame.draw.polygon(beams, col, [(x0 - 12, 70), (x0 + 12, 70), (x1 + 110, 470), (x1 - 110, 470)])
    surf.blit(beams, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    pygame.draw.line(surf, INK, (640, 0), (640, 30), 4)                 # 미러볼
    pygame.draw.circle(surf, (214, 220, 236), (640, 70), 44)
    for i in range(-3, 4):
        pygame.draw.line(surf, (150, 160, 190), (640 + i * 12, 30), (640 + i * 12, 110), 2)
        pygame.draw.line(surf, (150, 160, 190), (598, 70 + i * 12), (682, 70 + i * 12), 2)
    pygame.draw.circle(surf, INK, (640, 70), 44, 4)
    rng = random.Random(9)
    for _ in range(40):
        pygame.draw.circle(surf, rng.choice(((255, 150, 200), (150, 230, 250), (255, 236, 150))),
                           (rng.randint(0, WIDTH), rng.randint(20, 440)), rng.choice((3, 4, 6)))
    screen = pygame.Rect(60, 120, 300, 180)                             # 가사 화면
    props.box(surf, screen, (30, 30, 50), radius=10)
    ui.draw_text(surf, "애창곡 메들리", (screen.centerx, screen.y + 50), 20, (255, 236, 150), True, center=True)
    ui.draw_text(surf, "점수  98점", (screen.centerx, screen.y + 110), 30, (255, 150, 200), "heavy", center=True)
    neon = sticker.sticker_text("노래방", 44, (255, 150, 200), (90, 30, 80))
    surf.blit(neon, neon.get_rect(center=(1090, 90)))


def bg_camp(surf):
    """워크숍 캠핑장의 밤: 별, 산, 텐트, 모닥불."""
    sky(surf, (28, 30, 70), (80, 60, 110), 500)
    rng = random.Random(4)
    for _ in range(90):
        pygame.draw.circle(surf, (255, 250, 210), (rng.randint(0, WIDTH), rng.randint(0, 330)), rng.choice((1, 2, 2, 3)))
    pygame.draw.circle(surf, (255, 240, 170), (1080, 100), 46)
    pygame.draw.circle(surf, (36, 36, 78), (1098, 90), 40)
    pygame.draw.polygon(surf, (50, 56, 96), [(0, 500), (220, 250), (430, 430), (640, 220), (900, 440), (1080, 290), (1280, 500)])
    pygame.draw.polygon(surf, (40, 70, 70), [(0, 500), (0, 400), (300, 350), (700, 420), (1280, 360), (1280, 500)])
    for x in (60, 150, 1130, 1220):                                     # 소나무
        for k in range(3):
            pygame.draw.polygon(surf, (30, 80, 60), [(x - 46 + k * 8, 470 - k * 54), (x + 46 - k * 8, 470 - k * 54), (x, 380 - k * 54)])
        pygame.draw.rect(surf, (90, 60, 40), (x - 8, 470, 16, 30))
    for x, col in ((260, (236, 120, 90)), (1010, (110, 170, 230))):     # 텐트
        tent = [(x - 110, 500), (x, 360), (x + 110, 500)]
        pygame.draw.polygon(surf, col, tent)
        pygame.draw.polygon(surf, tuple(max(0, c - 60) for c in col), [(x - 26, 500), (x, 410), (x + 26, 500)])
        pygame.draw.polygon(surf, INK, tent, 4)
    _ground(surf, 500, (60, 90, 70))
    pygame.draw.line(surf, INK, (380, 250), (900, 250), 3)              # 꼬마전구
    for i, x in enumerate(range(400, 900, 50)):
        pygame.draw.circle(surf, ((255, 208, 84), (255, 140, 120), (150, 220, 250))[i % 3], (x, 262 + (i % 2) * 6), 9)


def campfire(surf, x, y):
    for dx, ang in ((-34, 18), (34, -18)):
        log = pygame.Surface((110, 24), pygame.SRCALPHA)
        pygame.draw.rect(log, (130, 86, 54), (2, 2, 106, 20), border_radius=8)
        pygame.draw.rect(log, INK, (2, 2, 106, 20), 3, border_radius=8)
        log = pygame.transform.rotozoom(log, ang, 1.0)
        surf.blit(log, log.get_rect(center=(x + dx * 0.3, y)))
    for pts, col in (([(x - 46, y - 6), (x - 20, y - 70), (x, y - 40), (x + 14, y - 104), (x + 46, y - 6)], (255, 138, 60)),
                     ([(x - 26, y - 6), (x - 6, y - 50), (x + 10, y - 66), (x + 26, y - 6)], (255, 220, 100))):
        pygame.draw.polygon(surf, col, pts)
        pygame.draw.polygon(surf, INK, pts, 3)
    glow = pygame.Surface((WIDTH, HEIGHT))
    for r, c in ((360, (26, 14, 4)), (230, (40, 22, 6)), (130, (56, 30, 8))):
        pygame.draw.circle(glow, c, (x, y - 40), r)
    surf.blit(glow, (0, 0), special_flags=pygame.BLEND_RGB_ADD)


def bg_rooftop(surf):
    """옥상의 노을: 도시 스카이라인과 난간."""
    sky(surf, (255, 150, 110), (255, 220, 150), 500)
    pygame.draw.circle(surf, (255, 110, 80), (880, 360), 80)
    cloud(surf, 200, 120, 130)
    cloud(surf, 980, 90, 100)
    rng = random.Random(15)
    x = 0
    while x < WIDTH:
        w, h = rng.randint(70, 130), rng.randint(120, 300)
        pygame.draw.rect(surf, (150, 110, 130), (x, 500 - h, w, h))
        for wy in range(500 - h + 16, 480, 30):
            for wx in range(x + 12, x + w - 14, 26):
                if rng.random() < 0.55:
                    pygame.draw.rect(surf, (255, 226, 150), (wx, wy, 12, 14))
        x += w + rng.randint(4, 22)
    _ground(surf, 500, (190, 176, 170))
    for px in range(0, WIDTH + 1, 160):                                 # 난간
        pygame.draw.rect(surf, (120, 124, 140), (px - 6, 404, 12, 96))
        pygame.draw.rect(surf, INK, (px - 6, 404, 12, 96), 3)
    for y in (410, 450):
        pygame.draw.rect(surf, (150, 154, 170), (0, y, WIDTH, 10))
        pygame.draw.rect(surf, INK, (0, y, WIDTH, 10), 2)
    bench = pygame.Rect(120, 520, 260, 26)
    table(surf, bench, (176, 124, 78))


def bg_home(surf):
    """내 방: 소파, TV, 밤 창문."""
    pygame.draw.rect(surf, (252, 234, 222), (0, 0, WIDTH, 500))
    for y in range(30, 500, 60):
        for x in range(30 + (y // 60 % 2) * 40, WIDTH, 80):
            pygame.draw.circle(surf, (246, 218, 204), (x, y), 6)
    night_window(surf, (90, 70, 230, 170))
    for i, col in enumerate(((255, 208, 84), (150, 220, 250), (255, 150, 180))):   # 벽 액자
        fr = pygame.Rect(430 + i * 110, 90 + (i % 2) * 30, 86, 70)
        props.box(surf, fr, col, radius=4, offset=(3, 4))
    props.draw_desk(surf, 500)
    pygame.draw.line(surf, INK, (0, 500), (WIDTH, 500), 4)
    pygame.draw.ellipse(surf, (236, 150, 150), (240, 560, 760, 110))    # 러그
    pygame.draw.ellipse(surf, INK, (240, 560, 760, 110), 4)
    tv = pygame.Rect(960, 260, 250, 160)
    props.box(surf, tv, (40, 40, 56), radius=10)
    pygame.draw.rect(surf, (150, 210, 250), tv.inflate(-22, -22), border_radius=6)
    ui.draw_text(surf, "16부작 정주행 중", tv.center, 18, (40, 60, 110), True, center=True)
    pygame.draw.rect(surf, (90, 60, 40), (tv.centerx - 60, tv.bottom, 120, 80))
    pygame.draw.rect(surf, INK, (tv.centerx - 60, tv.bottom, 120, 80), 3)


def sofa(surf, x, y, w=420):
    back = pygame.Rect(x, y - 150, w, 150)
    props.box(surf, back, (130, 190, 170), radius=30, shade=(104, 164, 146), offset=(6, 8))
    seat = pygame.Rect(x - 20, y - 50, w + 40, 80)
    props.box(surf, seat, (150, 210, 190), radius=24, shade=(120, 180, 160), offset=(6, 8))
    for ax in (x - 34, x + w - 26):
        arm = pygame.Rect(ax, y - 110, 60, 140)
        props.box(surf, arm, (130, 190, 170), radius=24, shadow=False)


def bg_lobby_storm(surf):
    """민원실: 유리문 밖은 천둥번개."""
    pygame.draw.rect(surf, (226, 226, 232), (0, 0, WIDTH, 500))
    door = pygame.Rect(40, 60, 420, 440)
    pygame.draw.rect(surf, (70, 76, 104), door)
    for cx, cy, w in ((120, 130, 160), (320, 110, 200), (220, 190, 150)):
        pygame.draw.ellipse(surf, (50, 54, 78), (cx - w // 2, cy - 30, w, 70))
    bolt = [(270, 130), (230, 250), (268, 250), (226, 380), (316, 220), (276, 220), (310, 130)]
    pygame.draw.polygon(surf, (255, 240, 130), bolt)
    pygame.draw.polygon(surf, INK, bolt, 3)
    clip = surf.get_clip()
    surf.set_clip(door)
    rain(surf, 7, 220)
    surf.set_clip(clip)
    pygame.draw.line(surf, INK, (door.centerx, door.y), (door.centerx, door.bottom), 6)
    pygame.draw.rect(surf, (236, 240, 246), door, 10)
    pygame.draw.rect(surf, INK, door.inflate(10, 10), 4)
    disp = pygame.Rect(840, 60, 360, 110)                               # 번호표 전광판
    props.box(surf, disp, (40, 40, 56), radius=10)
    ui.draw_text(surf, "대기 인원", (disp.x + 30, disp.y + 22), 20, (150, 230, 160), True)
    ui.draw_text(surf, "37 명", (disp.right - 30, disp.y + 40), 46, (255, 120, 110), "heavy", anchor="topright")
    _ground(surf, 500, (206, 206, 214))
    for x in (560, 760):                                                # 줄 서는 봉
        pygame.draw.rect(surf, (214, 180, 80), (x - 6, 420, 12, 110))
        pygame.draw.rect(surf, INK, (x - 6, 420, 12, 110), 3)
        pygame.draw.circle(surf, (214, 180, 80), (x, 416), 12)
        pygame.draw.circle(surf, INK, (x, 416), 12, 3)
    pygame.draw.line(surf, (200, 60, 70), (560, 432), (760, 432), 8)


def bg_subway(surf):
    """출근길 지하철 안."""
    pygame.draw.rect(surf, (214, 220, 228), (0, 0, WIDTH, HEIGHT))
    for x in (60, 480, 900):                                            # 창문 (터널이라 캄캄)
        w = pygame.Rect(x, 110, 330, 190)
        pygame.draw.rect(surf, (40, 44, 66), w, border_radius=16)
        pygame.draw.rect(surf, (255, 236, 150), (w.x + 40 + (x // 7) % 120, w.y + 60, 60, 8))
        pygame.draw.rect(surf, INK, w, 5, border_radius=16)
    pygame.draw.rect(surf, (150, 156, 172), (0, 60, WIDTH, 12))         # 손잡이 봉
    pygame.draw.rect(surf, INK, (0, 60, WIDTH, 12), 3)
    for x in range(90, WIDTH, 150):
        pygame.draw.line(surf, INK, (x, 72), (x, 130), 5)
        pygame.draw.ellipse(surf, (255, 253, 247), (x - 22, 124, 44, 40))
        pygame.draw.ellipse(surf, INK, (x - 22, 124, 44, 40), 5)
    route = pygame.Rect(440, 8, 400, 40)
    props.box(surf, route, (255, 253, 247), radius=8, offset=(3, 4))
    ui.draw_text(surf, "이번 역은 정부청사, 정부청사역입니다", route.center, 16, INK, True, center=True)
    _ground(surf, 560, (176, 180, 192))


def bg_field(surf):
    """체육대회 운동장."""
    sky(surf, (130, 200, 250), (210, 236, 252), 420)
    pygame.draw.circle(surf, (255, 242, 170), (1100, 100), 54)
    cloud(surf, 240, 110, 150)
    cloud(surf, 760, 150, 110)
    pygame.draw.rect(surf, (150, 206, 130), (0, 400, WIDTH, 60))
    for x in range(0, WIDTH, 220):
        _tree(surf, x + 100, 420, 0.8)
    _ground(surf, 440, (226, 150, 110))
    for i, y in enumerate((470, 530, 600, 680)):                        # 트랙 줄
        pygame.draw.line(surf, (255, 253, 247), (0, y), (WIDTH, y), 5)
    bunting(surf, 0, WIDTH, 30, 50)


# ================================================================== 새 CG — 배경이 다른 장면들
ANGRY = {"body": "#F0A060", "shape": "tall", "ears": "none", "acc": ["sunglasses", "tie"]}       # 악성 민원인
AGENT = {"body": "#A9CDA0", "shape": "bean", "ears": "none", "acc": ["headset"]}                  # 사회복무요원


@cg("workshop", "워크숍의 밤", "모닥불 앞에서는 팀장님도 그냥 사람 같다. 마시멜로는 내가 다 태웠다.", slots=3)
def _workshop(st: Stage):
    s = st.s
    bg_camp(s)
    st.actor(st.mate(2), (160, 584), "happy", "hi", 0.84, -6, full=True)
    st.actor(st.mate(0), (360, 600), "happy", "clap", 0.96, -5, full=True)
    st.boss((930, 598), expr="happy", pose="shrug", scale=1.1, angle=5, full=True, flip=True)
    st.actor(st.mate(1), (1130, 586), "happy", "cheer", 0.88, 8, full=True, flip=True)
    campfire(s, 640, 610)
    st.hero((560, 612), expr="nervous", pose="point", scale=1.04, angle=-6, full=True)
    pygame.draw.line(s, INK, (624, 520), (700, 548), 5)                 # 마시멜로 꼬치
    pygame.draw.circle(s, (70, 50, 40), (704, 550), 13)
    pygame.draw.circle(s, INK, (704, 550), 13, 3)
    for i in range(3):
        ui.draw_text(s, "~", (700 + i * 6, 510 - i * 18), 20, (220, 220, 230), True)


@cg("rest", "5분의 휴식", "옥상에서 캔커피 하나. 5분이면 다시 버틸 수 있다.", slots=0)
def _rest(st: Stage):
    s = st.s
    bg_rooftop(s)
    for x, y in ((420, 150), (470, 130), (540, 160)):                   # 저녁 새
        pygame.draw.arc(s, INK, (x, y, 22, 14), 0.2, math.pi - 0.2, 3)
        pygame.draw.arc(s, INK, (x + 20, y, 22, 14), 0.2, math.pi - 0.2, 3)
    st.hero((640, 600), expr="happy", pose="hi", scale=1.16, angle=-5, full=True)
    can = pygame.Rect(560, 392, 28, 46)                                 # 캔커피
    pygame.draw.rect(s, (150, 96, 60), can, border_radius=6)
    pygame.draw.rect(s, (255, 236, 150), (can.x, can.y + 14, can.w, 12))
    pygame.draw.rect(s, INK, can, 3, border_radius=6)
    for i in range(2):
        pts = [(can.centerx - 6 + i * 12 + math.sin(k) * 4, can.y - 6 - k * 9) for k in range(5)]
        pygame.draw.lines(s, (255, 255, 255), False, pts, 3)
    cup(s, 250, 520, (110, 190, 250))


@cg("birthday", "팀장님 생일", "몰래 준비한 케이크. 팀장님의 저런 표정은 처음 본다.", slots=3)
def _birthday(st: Stage):
    s = st.s
    floor_room(s, 500)
    bunting(s, 100, 1180, 20)
    for x, col in ((150, (255, 138, 92)), (1130, (110, 190, 250)), (240, (255, 208, 84)), (1040, (236, 120, 170))):
        balloon(s, (x, 160 + (x % 3) * 20), col, 30)
    st.actor(st.mate(2), (150, 556), "happy", "clap", 0.84, -8, full=True)
    st.actor(st.mate(0), (340, 572), "happy", "cheer", 0.96, -6, full=True, legs=(-12, 12))
    st.boss((640, 470), expr="shocked", pose="shock", scale=1.2, angle=0, full=True)
    st.actor(st.mate(1), (1080, 566), "happy", "cheer", 0.9, 8, full=True, flip=True)
    dark = pygame.Surface((WIDTH, HEIGHT))                              # 불 끈 방
    dark.fill((120, 110, 150))
    s.blit(dark, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    glow = pygame.Surface((WIDTH, HEIGHT))
    for r, c in ((420, (30, 22, 8)), (280, (44, 32, 10)), (160, (60, 44, 14))):
        pygame.draw.circle(glow, c, (640, 500), r)
    s.blit(glow, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    table(s, (520, 560, 240, 30))
    cake = pygame.Rect(560, 470, 160, 90)
    pygame.draw.rect(s, (255, 240, 224), cake, border_radius=12)
    pygame.draw.rect(s, (236, 120, 150), (cake.x, cake.y, cake.w, 26), border_top_left_radius=12, border_top_right_radius=12)
    pygame.draw.rect(s, INK, cake, 4, border_radius=12)
    for i in range(5):
        cx = cake.x + 24 + i * 28
        pygame.draw.line(s, (110, 190, 250), (cx, cake.y), (cx, cake.y - 30), 6)
        pygame.draw.polygon(s, (255, 220, 100), [(cx - 7, cake.y - 30), (cx, cake.y - 52), (cx + 7, cake.y - 30)])
    st.hero((880, 590), expr="happy", pose="clap", scale=1.06, angle=6, full=True, flip=True)
    banner(s, (330, 60, 620, 78), "팀장님 생일 축하합니다!", (236, 120, 150), 36)
    confetti(s, 60, 51, (0, 150, WIDTH, 420))


@cg("solo_home", "나만의 휴가", "아무 계획 없는 휴가. 소파와 나, 그리고 밀린 드라마 열여섯 편.", chiefs=["normal"], slots=0)
def _solo_home(st: Stage):
    s = st.s
    bg_home(s)
    sofa(s, 330, 560)
    st.hero((540, 548), expr="happy", pose="cheer", scale=1.08, angle=16, full=True, legs=(-16, 22))
    snack_plate(s, 770, 600)
    cup(s, 850, 612, (236, 96, 96))
    phone = pygame.Rect(180, 590, 100, 60)                              # 꺼 둔 휴대폰
    props.box(s, phone, (60, 60, 76), radius=10, offset=(3, 4))
    ui.draw_text(s, "방해 금지", phone.center, 14, (200, 204, 220), True, center=True)
    zzz(s, 700, 330, (150, 140, 190))


@cg("complaint", "악성 민원인의 습격", "\"책임자 나오라고 해!\" …그 순간 다들 나를 쳐다봤다.", chiefs=["normal", "hell"], slots=2)
def _complaint(st: Stage):
    s = st.s
    bg_lobby_storm(s)
    counter = pygame.Rect(820, 400, 460, 130)                           # 창구 뒤에 숨은 동료들
    st.actor(st.mate(0), (930, 250), "nervous", "shrug", 0.9, 4, flip=True)
    st.actor(st.mate(1), (1090, 262), "shocked", "shock", 0.86, -4, flip=True)
    st.boss((1210, 240), pose="point", scale=0.9, angle=-4, flip=True)
    props.box(s, counter, (214, 160, 106), radius=10, shade=(180, 130, 84))
    ui.draw_text(s, "민 원 창 구", (counter.centerx, counter.y + 40), 26, INK, "heavy", center=True)
    st.actor(ANGRY, (430, 600), "mean", "cheer", 1.3, -8, full=True, legs=(-20, 20))
    speech(s, (150, 60, 330, 96), "책임자 나오라고 해!!", (400, 250), 26)
    st.hero((730, 604), expr="shocked", pose="shock", scale=1.04, angle=8, full=True, flip=True)
    rng = random.Random(3)
    for _ in range(8):                                                  # 날아다니는 서류
        p = pygame.Surface((54, 40), pygame.SRCALPHA)
        pygame.draw.rect(p, (255, 253, 247), (2, 2, 50, 36))
        pygame.draw.rect(p, INK, (2, 2, 50, 36), 3)
        p = pygame.transform.rotozoom(p, rng.randint(-50, 50), 1.0)
        s.blit(p, (rng.randint(480, 760), rng.randint(180, 420)))
    for x, y in ((560, 300), (620, 250)):                               # 화난 김
        pygame.draw.circle(s, (255, 255, 255), (x, y), 14)
        pygame.draw.circle(s, INK, (x, y), 14, 3)


@cg("rebel", "사회복무요원의 반란", "\"저도 여섯 시에 집에 갑니다!\" 팀장님이 처음으로 말을 잃었다.", chiefs=["hell"], slots=1)
def _rebel(st: Stage):
    s = st.s
    bg_archive(s)
    for k in range(3):                                                  # 서류 상자 단상
        carton(s, 640 - 60 + (k % 2) * 20, 590 - k * 62, 150, "")
    carton(s, 500, 590, 110, "")
    carton(s, 790, 590, 110, "")
    st.actor(AGENT, (640, 404), "happy", "hi", 1.1, -6, full=True, legs=(-14, 14))
    pygame.draw.line(s, INK, (566, 300), (566, 110), 7)                 # 깃발
    flag = [(566, 110), (760, 136), (566, 196)]
    pygame.draw.polygon(s, (236, 96, 96), flag)
    pygame.draw.polygon(s, INK, flag, 4)
    ui.draw_text(s, "칼퇴", (626, 148), 28, (255, 255, 255), "heavy", center=True)
    st.boss((1010, 600), expr="shocked", pose="shock", scale=1.1, angle=8, full=True, flip=True)
    st.hero((330, 602), expr="sly", pose="clap", scale=1.02, angle=-6, full=True)
    st.actor(st.mate(0), (160, 590), "happy", "cheer", 0.86, -8, full=True)
    speech(s, (760, 190, 300, 66), "저도 6시에 갑니다!", (700, 240), 19)


@cg("sports", "명랑 체육대회", "2인 3각. 팀장님과 발이 이렇게 안 맞을 줄이야.", chiefs=["easy"], slots=2)
def _sports(st: Stage):
    s = st.s
    bg_field(s)
    banner(s, (380, 110, 520, 70), "명랑 체육대회", (255, 138, 92), 38)
    st.actor(st.mate(0), (200, 520), "happy", "cheer", 0.8, -8, full=True)
    st.actor(st.mate(1), (1100, 524), "happy", "clap", 0.8, 8, full=True, flip=True)
    st.boss((720, 632), expr="happy", pose="run", scale=1.12, angle=-10, full=True, legs=(-30, 4))
    st.hero((560, 636), expr="nervous", pose="run", scale=1.08, angle=-14, full=True, legs=(8, 34))
    pygame.draw.line(s, (236, 96, 96), (610, 642), (670, 640), 12)      # 발목 끈
    for i in range(4):
        pygame.draw.line(s, (255, 253, 247), (300 + i * 18, 520 + i * 36), (400 + i * 18, 520 + i * 36), 6)
    pts = [(1010, 600), (1010, 470), (1100, 500), (1010, 530)]          # 결승 깃발
    pygame.draw.polygon(s, (255, 208, 84), pts[1:])
    pygame.draw.polygon(s, INK, pts[1:], 4)
    pygame.draw.line(s, INK, pts[0], pts[1], 6)


@cg("commute", "출근길 지옥철", "창구에 도착하기도 전에 체력이 절반 남았다.", chiefs=["hell"], slots=0)
def _commute(st: Stage):
    s = st.s
    bg_subway(s)
    crowd = [c["look"] for c in st.data.companies] if st.data else []
    spots = [(120, 600, 1.0, 6), (300, 620, 1.1, -8), (470, 596, 0.96, 10), (820, 612, 1.08, -10),
             (990, 598, 1.0, 8), (1160, 618, 1.1, -6)]
    for i, (x, y, k, ang) in enumerate(spots):
        if i < len(crowd):
            st.actor(crowd[(i * 2) % len(crowd)], (x, y), ("neutral", "nervous", "sad")[i % 3], "slump", k, ang, full=True,
                     flip=i % 2 == 0)
    st.hero((645, 616), expr="shocked", pose="shock", scale=0.98, angle=-14, full=True)
    for x, y in ((560, 330), (730, 300), (640, 250)):                   # 식은땀
        pygame.draw.polygon(s, (150, 205, 245), [(x, y - 18), (x - 10, y), (x + 10, y)])
        pygame.draw.circle(s, (150, 205, 245), (x, y + 4), 11)
