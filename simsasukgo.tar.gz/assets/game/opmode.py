"""운영자 모드 — 묶음 첫 화면 왼쪽 아래를 빠르게 다섯 번 누르면 켜진다 (심사·시연용).

켜면 도감과 해금 요소가 전부 열린다: 인재 40명(성격 3단계까지), 난이도 9개, 추억(CG), 규정, 납품처 도장판, 히든 엔딩.
켜기 직전의 기록은 따로 보관해 두었다가, 같은 자리를 다시 다섯 번 누르면 그대로 되돌린다.
"""
import copy
from datetime import date

KEY = "op_backup"
KEEP = ("settings", KEY)             # 되돌릴 때 건드리지 않는 것


def is_on(app) -> bool:
    return isinstance(app.profile.data.get(KEY), dict)


def turn_on(app):
    from . import cg
    from .agency import scene as agency
    from .factory import scene as factory
    prof, data = app.profile, app.data
    if is_on(app):
        return
    prof.data[KEY] = copy.deepcopy({k: v for k, v in prof.data.items() if k not in KEEP})
    today = date.today().strftime("%Y.%m.%d")
    chiefs = [c["id"] for c in data.chiefs]
    for p in data.roster:                                       # 동료: 모든 팀장과 함께 끝낸 것으로 (성격 3단계까지)
        rec = prof.data["members"].setdefault(p["id"], {"pulled": 1, "cleared": []})
        rec["pulled"] = max(1, rec.get("pulled", 0))
        rec["cleared"] = chiefs[:]
        rec.setdefault("first", today)
        rec.setdefault("last_clear", today)
    prof.data["chiefs"] = {c: "S" for c in chiefs}
    prof.data["cgs"] = list(cg.CGS)
    prof.data["rules"] = [r["id"] for r in data.rules]
    f = factory.record(app)
    f["levels"] = {lv["id"]: "S" for lv in data.factory["levels"]}
    for p in data.staff["roster"]:
        f["staff"].setdefault(p["id"], 1)
    for c in factory.clients(data):
        f["delivered"].setdefault(c["key"], 1)
    f["clear"] = True
    a = agency.record(app)
    a["levels"] = {lv["id"]: "S" for lv in data.agency["levels"]}
    for p in data.agency["helpers"]["roster"]:
        a["helpers"].setdefault(p["id"], 1)
    a["clear"] = True
    prof.data["hidden"] = {"mid": True, "hard": True}           # 히든 엔딩도 본 것으로 (도감의 엔딩 탭에서 다시 볼 수 있다)
    prof.save()


def turn_off(app):
    """켜기 직전의 기록으로 되돌린다."""
    prof = app.profile
    if not is_on(app):
        return
    back = prof.data[KEY]
    for k in [k for k in prof.data if k not in KEEP]:
        prof.data[k] = copy.deepcopy(back.get(k, prof._blank()[k]))
    prof.data[KEY] = None
    prof.save()


def toggle(app) -> bool:
    """켜져 있으면 끄고, 꺼져 있으면 켠다. 바뀐 뒤의 상태를 돌려준다."""
    (turn_off if is_on(app) else turn_on)(app)
    return is_on(app)
