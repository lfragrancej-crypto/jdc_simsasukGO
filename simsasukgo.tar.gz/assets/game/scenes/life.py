"""퇴근 후 저녁 — 주인공의 '삶'을 돌보는 시간.

이 장면의 목표: 공무원도 결국 한 명의 사람이자 인격체라는 것을 느끼게 하는 것.
창구에서는 규정을 지키는 심사관이지만, 문을 나서면 월세를 걱정하고 부모님 병원비를 챙기고
친구 결혼식 봉투를 고민하는 보통 사람이다. 그래서 일만 잘해서는 안 되고, 삶을 놓치면 일에도 지장이 온다.

매일 정산이 끝나면 세 단계를 거친다.
  1) 가계부   수입(기본급 + 성과 수당 + 무결점 보너스 + 승진 축하금) - 고정지출(주거비·식비·교통통신비)
  2) 생활 사건 집 문제 / 스트레스 해소 / 뜻밖의 일 — 선택지 중 하나를 고른다
  3) 저녁 활동 푹 쉬기 · 운동 · 가족·친구에게 연락 · 규정집 공부  (야근은 퇴근 전 사무실에서 고른다)

돌봐야 하는 것 (수치·사건은 모두 data/life.json):
  통장      마이너스가 되면 걱정 때문에 매일 스트레스가 더 쌓인다
  스트레스   70 이상 → 다음 날 심사 시간 -10%, 90 이상 → -20%
  건강      매일 조금씩 닳는다. 30 아래 → 다음 날 심사 시간 -10%
  관계      연락하지 않으면 멀어진다. 25 아래 → 외로워서 매일 스트레스가 더 쌓인다
엔딩에서는 일 성적과 별도로 '삶의 균형' 등급을 매긴다 (life_grade).
"""
import pygame

from .. import cg, props, sfx, sticker, ui
from ..anim import ease_out_back
from ..character import Character
from ..config import C_ACCENT, C_GOOD, C_INK, C_INK_SOFT, C_REJECT, C_WARN, C_WHITE, WIDTH
from .base import Scene

CAT_NAME = {"relief": ("스트레스 해소", (84, 180, 110)), "surprise": ("뜻밖의 일", (245, 166, 48)),
            "housing": ("집 문제", (72, 142, 232))}
OPTION_COLORS = [(255, 138, 92), (72, 142, 232), (150, 140, 130), (84, 180, 110), (176, 104, 220)]
LEDGER, EVENT, ACTIVITY, DONE = "ledger", "event", "activity", "done"
LIFE_COMMENT = {
    ("hi", "hi"): "일도 삶도 지켜 냈다. 공무원이기 전에, 한 사람으로서.",
    ("hi", "lo"): "일은 완벽했다. 하지만 창구 안쪽의 '사람'은 돌보지 못했다.",
    ("lo", "hi"): "서툴렀지만 무너지지 않았다. 사람이니까, 내일 더 잘하면 된다.",
    ("lo", "lo"): "힘든 닷새였다. 공무원도 사람이다. 오늘은 푹 쉬자.",
}


def clamp(v) -> int:
    return max(0, min(100, int(v)))


clamp_stress = clamp


def signed(v: int, unit: str = "") -> str:
    return f"{'+' if v > 0 else ''}{v}{unit}"


def effect_text(opt: dict) -> str:
    parts = []
    if opt.get("money"):
        parts.append(signed(opt["money"], "만원"))
    for key, name in (("stress", "스트레스"), ("health", "건강"), ("bond", "관계")):
        if opt.get(key):
            parts.append(f"{name} {signed(opt[key])}")
    for delta in opt.get("fixed", {}).values():
        if delta:
            parts.append(f"주거비 {signed(delta, '만')}/일")
    if opt.get("buff") == "study":
        parts.append("내일 힌트 증가")
    return " · ".join(parts) or "변화 없음"


def time_factor(stress: int, cfg: dict) -> float:
    """스트레스가 높으면 다음 날 심사 시간이 줄어든다."""
    if stress >= cfg["burnout_at"]:
        return cfg["burnout_time"]
    if stress >= cfg["tired_at"]:
        return cfg["tired_time"]
    return 1.0


def health_factor(health: int, cfg: dict) -> float:
    """몸이 안 좋으면 다음 날 심사 시간이 줄어든다."""
    return cfg["sick_time"] if health < cfg["sick_at"] else 1.0


def fixed_total(state) -> int:
    return sum(state.fixed.values())


def life_score(state) -> float:
    money = max(0, min(100, (state.money + 50) / 2))            # 통장 -50만 → 0점, 150만 → 100점
    return (100 - state.stress) * 0.35 + state.health * 0.30 + state.bond * 0.25 + money * 0.10


def life_grade(state) -> str:
    s = life_score(state)
    return "S" if s >= 78 else "A" if s >= 62 else "B" if s >= 45 else "C"


def life_comment(work_grade: str, life: str) -> str:
    return LIFE_COMMENT[("hi" if work_grade in "SA" else "lo", "hi" if life in "SA" else "lo")]


def pick_event(cfg: dict, day_index: int, seen, rng) -> dict:
    cat = cfg["order"][min(day_index, len(cfg["order"]) - 1)]
    fresh = [e for e in cfg["events"] if e["id"] not in seen]
    pool = [e for e in fresh if cat == "any" or e["cat"] == cat] or fresh or cfg["events"]
    return rng.choice(pool)


def apply_option(state, opt: dict):
    state.money += opt.get("money", 0)
    state.stress = clamp(state.stress + opt.get("stress", 0))
    state.health = clamp(state.health + opt.get("health", 0))
    state.bond = clamp(state.bond + opt.get("bond", 0))
    for key, delta in opt.get("fixed", {}).items():
        state.fixed[key] = max(0, state.fixed.get(key, 0) + delta)
    if opt.get("buff"):
        state.buff = opt["buff"]


class LifeScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        cfg = self.cfg = app.data.life
        st = app.state
        today = st.history[-1]
        self.day = today.day
        self.rank = st.level_info(app.data.levels)["title"]
        if not st.fixed:
            st.fixed = {f["id"]: f["cost"] for f in cfg["fixed"]}
        st.buff = None                                   # 어제 공부한 효과는 오늘 하루로 끝

        # ---- 1) 가계부
        self.money_before = st.money
        self.income = [(f"기본급 ({self.rank})", cfg["pay"][str(st.level)])]
        if today.correct:
            self.income.append((f"성과 수당 (정확한 판단 {today.correct}건)", today.correct * cfg["pay_per_correct"]))
        if today.processed and today.wrong == 0:
            self.income.append(("무결점 보너스", cfg["bonus_perfect"]))
        if today.overtime:
            self.income.append(("초과근무수당 (야근 3시간)", cfg["overtime"]["pay"][str(st.level)]))
        if st.promoted_today:
            self.income.append(("승진 축하금", cfg["bonus_promotion"]))
            st.promoted_today = False
        names = {f["id"]: f["name"] for f in cfg["fixed"]}
        self.expense = [(names.get(k, k), v) for k, v in st.fixed.items() if v]
        self.pay = sum(v for _, v in self.income)
        self.spent = sum(v for _, v in self.expense)
        st.money += self.pay - self.spent

        # ---- 하루가 지나며 저절로 변하는 것
        chief_id = app.chief["id"]
        gain = cfg["stress_per_day"][chief_id] + today.wrong * cfg["stress_per_wrong"]
        if today.processed and today.wrong == 0:
            gain += cfg["stress_perfect_day"]
        self.notes = []
        if self.money_before < 0:
            gain += cfg["stress_debt"]
            self.notes.append(f"마이너스 통장 걱정으로 스트레스 +{cfg['stress_debt']}")
        if today.overtime:                                      # 야근: 수당은 나오지만 몸과 마음이 닳는다
            ot = cfg["overtime"]
            gain += ot["stress"]
            st.health = clamp(st.health + ot["health"])
            self.notes.append(f"야근으로 스트레스 +{ot['stress']}, 건강 {ot['health']}")
        if today.carried:                                       # 쌓인 잔업은 퇴근 후에도 마음에 걸린다
            extra = today.carried * cfg["stress_per_backlog"]
            gain += extra
            self.notes.append(f"내일로 넘긴 잔업 {today.carried}건 걱정으로 스트레스 +{extra}")
        if st.bond < cfg["lonely_at"]:
            gain += cfg["lonely_stress"]
            self.notes.append(f"외로워서 스트레스 +{cfg['lonely_stress']}")
        self.gain = gain
        st.stress = clamp(st.stress + gain)
        st.health = clamp(st.health + cfg["health_per_day"][chief_id])
        st.bond = clamp(st.bond + cfg["bond_per_day"])

        # ---- 2) 사건, 3) 저녁 활동
        self.event = pick_event(cfg, st.day_index, st.life_seen, app.rng)
        st.life_seen.append(self.event["id"])
        self.chosen = None
        self.activity = None
        self.step = LEDGER
        self.t = 0.0
        self.step_t = 0.0
        self.hero = Character(app.data.dialogue["hero"]["look"])
        self._mood()
        voices = cfg["voices"]                           # 주인공의 속마음 — 공무원도 한 사람이다
        self.voice = ui.Typewriter(voices[min(st.day_index, len(voices) - 1)], 30)
        self.options = [self._option_button(i, opt, 448, 76, 58) for i, opt in enumerate(self.event["options"])]
        self.act_buttons = [self._option_button(i, act, 196, 66, 54) for i, act in enumerate(cfg["activities"])]
        self.next = ui.Button((WIDTH - 372, 624, 330, 60), "", C_ACCENT, size=24, parts=[("확인 ", sticker.WHITE), ("GO!", sticker.YELLOW)])
        sfx.play("pop", 0.5)

    @staticmethod
    def _option_button(i, opt, y0, dy, h):
        return ui.Button((690, y0 + i * dy, 560, h), "", OPTION_COLORS[i % len(OPTION_COLORS)], size=17, float_amp=1.0,
                         parts=[(opt["label"] + "  ", sticker.WHITE), (effect_text(opt), sticker.YELLOW)])

    # ---------------------------------------------------------------- 진행
    def _mood(self, delta=0):
        st = self.app.state
        bad = st.stress >= 70 or st.health < self.cfg["sick_at"]
        mid = st.stress >= 45
        self.hero.expression = "sad" if bad else "nervous" if mid else "happy"
        self.hero.set_pose("slump" if bad else "shrug" if mid else "hip")
        if delta <= -10:                                 # 확 풀렸을 때만 만세
            self.hero.expression = "happy"
            self.hero.set_pose("cheer")

    def _go(self, step):
        self.step, self.step_t = step, 0.0
        label = {EVENT: "다음 ", ACTIVITY: "다음 ", DONE: "내일로 "}.get(step, "확인 ")
        self.next.parts = [(label, sticker.WHITE), ("GO!", sticker.YELLOW)]

    def confirm_ledger(self):
        if self.step == LEDGER:
            self._go(EVENT)
            sfx.play("paper", 0.5)

    def choose(self, i: int):
        """생활 사건의 선택지를 고른다."""
        if self.step != EVENT or self.chosen is not None:
            return
        opt = self.event["options"][i]
        apply_option(self.app.state, opt)
        self.chosen = opt
        self.step_t = 0.0
        self._mood(opt.get("stress", 0))
        sfx.play("correct" if opt.get("stress", 0) <= 0 else "wrong", 0.6)

    def choose_activity(self, i: int):
        if self.step != ACTIVITY or self.activity is not None:
            return
        act = self.cfg["activities"][i]
        apply_option(self.app.state, act)
        self.activity = act
        self._mood(act.get("stress", 0))
        sfx.play("correct", 0.6)
        self._go(DONE)

    def advance(self):
        """'다음' 버튼: 가계부 → 사건(고른 뒤) → 저녁 활동 → 내일."""
        if self.step == LEDGER:
            self.confirm_ledger()
        elif self.step == EVENT and self.chosen is not None:
            self._go(ACTIVITY)
        elif self.step == DONE:
            self.app.proceed()

    def handle_event(self, event):
        key_next = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE)
        number = event.key - pygame.K_1 if event.type == pygame.KEYDOWN and pygame.K_1 <= event.key <= pygame.K_9 else None
        if self.step == EVENT and self.chosen is None:
            for i, btn in enumerate(self.options):
                if btn.clicked(event) or number == i:
                    self.choose(i)
                    return
        elif self.step == ACTIVITY:
            for i, btn in enumerate(self.act_buttons):
                if btn.clicked(event) or number == i:
                    self.choose_activity(i)
                    return
        elif self.step_t > 0.4 and (self.next.clicked(event) or key_next):
            self.advance()

    def update(self, dt):
        self.t += dt
        self.step_t += dt
        self.hero.update(dt)
        if self.t > 0.5:
            self.voice.update(dt)
        for btn in self.options + self.act_buttons:
            btn.update(dt)
        self.next.update(dt)

    # ---------------------------------------------------------------- 그리기
    def _bar(self, surf, x, y, label, value, good_high, mark, warn):
        """막대 하나. good_high=True 면 높을수록 좋은 수치(건강·관계)."""
        bad = (value < mark) if good_high else (value >= mark)
        mid = (value < mark + 20) if good_high else (value >= mark - 25)
        color = C_REJECT if bad else C_WARN if mid else C_GOOD
        ui.draw_text(surf, label, (x, y + 2), 15, C_INK_SOFT, True)
        bar = pygame.Rect(x + 82, y, 250, 22)
        pygame.draw.rect(surf, (236, 224, 204), bar, border_radius=11)
        if value > 3:
            pygame.draw.rect(surf, color, (bar.x, bar.y, int(bar.w * value / 100), bar.h), border_radius=11)
        mx = bar.x + int(bar.w * mark / 100)
        pygame.draw.line(surf, C_INK, (mx, bar.y - 3), (mx, bar.bottom + 3), 3)
        pygame.draw.rect(surf, C_INK, bar, 3, border_radius=11)
        ui.draw_text(surf, str(value), (bar.right + 10, y + 1), 16, C_INK, True)
        if bad:
            ui.draw_text(surf, warn, (bar.right + 50, y + 3), 13, C_REJECT, True)

    def _draw_status(self, surf):
        st, cfg = self.app.state, self.cfg
        panel = pygame.Rect(26, 22, 620, 214)
        props.box(surf, panel, (255, 250, 236), radius=12, offset=(5, 6))
        ui.draw_text(surf, f"{self.day}일차 저녁  ·  퇴근 후", (panel.x + 22, panel.y + 14), 22, C_INK, "heavy")
        ui.draw_text(surf, "통장", (panel.x + 22, panel.y + 62), 15, C_INK_SOFT, True)
        ui.draw_text(surf, f"{st.money:,}만원", (panel.x + 70, panel.y + 52), 28, C_REJECT if st.money < 0 else C_INK, "heavy")
        ui.draw_text(surf, f"고정지출  하루 -{fixed_total(st)}만원", (panel.right - 22, panel.y + 62), 14, C_INK_SOFT, True,
                     anchor="topright")
        y = panel.y + 104
        self._bar(surf, panel.x + 22, y, "스트레스", st.stress, False, cfg["tired_at"], "내일 시간 줄어듦")
        self._bar(surf, panel.x + 22, y + 34, "건강", st.health, True, cfg["sick_at"], "내일 시간 줄어듦")
        self._bar(surf, panel.x + 22, y + 68, "관계", st.bond, True, cfg["lonely_at"], "외로워서 스트레스 증가")

    def _paper(self, surf, h, title, tag=None, tag_color=C_ACCENT):
        k = ease_out_back(self.step_t / 0.35, 1.2)
        card = pygame.Rect(0, 0, 570, h)
        card.topleft = (684 + (1 - k) * 700, 44)
        props.box(surf, card, (255, 253, 247), radius=10, offset=(6, 8))
        props.tape(surf, (card.centerx, card.y + 2), 3, 64, 20)
        y = card.y + 26
        if tag:
            ui.pill(surf, (card.x + 24, y, 150, 30), tag, tag_color, C_WHITE, 14)
            y += 42
        ui.draw_text(surf, title, (card.x + 24, y), 30, C_INK, "heavy")
        pygame.draw.line(surf, C_INK, (card.x + 24, y + 46), (card.right - 24, y + 46), 3)
        return card, y + 62

    def _draw_ledger(self, surf):
        st = self.app.state
        card, y = self._paper(surf, 520, f"{self.day}일차 가계부", "수입과 지출", (84, 180, 110))
        x, right = card.x + 30, card.right - 30
        ui.draw_text(surf, "들어온 돈", (x, y), 15, C_GOOD, True)
        y += 26
        for name, v in self.income:
            ui.draw_text(surf, name, (x + 10, y), 17, C_INK)
            ui.draw_text(surf, f"+{v}만", (right, y), 18, C_GOOD, True, anchor="topright")
            y += 30
        y += 8
        ui.draw_text(surf, "나간 돈 (고정지출)", (x, y), 15, C_REJECT, True)
        y += 26
        for name, v in self.expense:
            ui.draw_text(surf, name, (x + 10, y), 17, C_INK)
            ui.draw_text(surf, f"-{v}만", (right, y), 18, C_REJECT, True, anchor="topright")
            y += 30
        pygame.draw.line(surf, C_INK, (x, y + 6), (right, y + 6), 3)
        net = self.pay - self.spent
        ui.draw_text(surf, "오늘의 손익", (x, y + 20), 20, C_INK, True)
        ui.draw_text(surf, f"{signed(net)}만원", (right, y + 14), 28, C_GOOD if net >= 0 else C_REJECT, "heavy", anchor="topright")
        ui.draw_text(surf, f"통장  {self.money_before:,}만원 → {self.money_before + net:,}만원", (right, y + 56), 15, C_INK_SOFT, True,
                     anchor="topright")
        yy = card.bottom - 30 - len(self.notes) * 20
        ui.draw_text(surf, f"오늘 쌓인 스트레스 {signed(self.gain)}", (x, yy - 22), 14, C_REJECT if self.gain > 0 else C_GOOD, True)
        for note in self.notes:
            ui.draw_text(surf, "· " + note, (x, yy), 13, C_REJECT, True)
            yy += 20

    def _result_box(self, surf, rect, opt):
        kk = ease_out_back(self.step_t / 0.35, 1.4)
        if kk <= 0.05:
            return
        box = pygame.Rect(rect)
        pygame.draw.rect(surf, (255, 240, 200), box, border_radius=10)
        pygame.draw.rect(surf, C_INK, box, 3, border_radius=10)
        ui.draw_text(surf, f"→ {opt['label']}", (box.x + 16, box.y + 10), 15, C_ACCENT, True)
        ui.draw_wrapped(surf, opt["result"], (box.x + 16, box.y + 34, box.w - 32, 50), 16)
        ui.draw_text(surf, effect_text(opt), (box.right - 16, box.bottom - 26), 14, C_INK_SOFT, True, anchor="topright")

    def _draw_event(self, surf):
        ev = self.event
        name, color = CAT_NAME[ev["cat"]]
        card, y = self._paper(surf, 356, ev["title"], name, color)
        y = ui.draw_wrapped(surf, ev["text"], (card.x + 26, y, card.w - 52, 150), 18)
        if self.chosen:
            self._result_box(surf, (card.x + 20, max(y + 12, card.y + 224), card.w - 40, 112), self.chosen)
        else:
            for btn in self.options:
                btn.draw(surf)
            ui.pill(surf, (790, 408, 360, 28), "어떻게 할까요?  (숫자 키로도 고를 수 있어요)", (255, 250, 236), C_INK, 13)

    def _draw_activity(self, surf):
        card, y = self._paper(surf, 132, "오늘 저녁은 어떻게 보낼까?")
        if self.activity is None:
            for btn in self.act_buttons:
                btn.draw(surf)
        else:
            self._result_box(surf, (card.x, card.bottom + 24, card.w, 120), self.activity)
            if self.chosen:
                ui.draw_text(surf, f"오늘의 사건: {self.event['title']} → {self.chosen['label']}", (card.x + 6, card.bottom + 164), 14,
                             C_INK_SOFT, True)

    def draw(self, surf):
        cg.bg_home(surf)
        cg.sofa(surf, 150, 590, 360)
        self.hero.draw(surf, (330, 590 - cg.FOOT * 1.1), scale=1.1, full=True,
                       angle=-12 if self.hero.pose == "slump" else 6)
        self._draw_status(surf)
        if self.t > 0.5:                                     # 생각 풍선
            ui.speech_bubble(surf, (40, 252, 560, 66), self.voice, tail=(300, 352), size=16)
        if self.step == LEDGER:
            self._draw_ledger(surf)
        elif self.step == EVENT:
            self._draw_event(surf)
        else:
            self._draw_activity(surf)
        show_next = self.step in (LEDGER, DONE) or (self.step == EVENT and self.chosen is not None)
        if show_next and self.step_t > 0.4:
            self.next.draw(surf)
