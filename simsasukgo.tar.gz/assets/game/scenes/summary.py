import math

import pygame

from .. import gacha, props, sfx, sticker, ui
from ..anim import ease_out_back, ease_out_cubic
from ..character import Character
from ..config import C_ACCENT, C_GOOD, C_INK, C_INK_SOFT, C_REJECT, C_WARN, C_WHITE, HEIGHT, WIDTH
from .base import Scene

WALL_H = 200
T_PROMO = 2.4          # 승진 발표가 나오는 시각(초)


class SummaryScene(Scene):
    """일일 정산 — 퇴근 무렵 노을 진 사무실.

    왼쪽: 클립보드에 끼운 업무 일지 (숫자가 차르륵)
    오른쪽: 인사 발령 통지 — 누적 점수로 직급이 오르고(9급 서기보 → 6급 주사),
           승진하면 인사 발령 봉투가 도착한다 → 버튼을 누르면 봉투 열기(동료 뽑기) 화면으로.
    """

    def __init__(self, app):
        super().__init__(app)
        self.stats = app.state.history[-1]
        self.t = 0.0
        chief = app.chief
        self.chief_name = chief["name"]
        self.chief = Character(chief["look"])
        s = self.stats
        acc = s.correct / s.processed if s.processed else 0
        self.chief.expression = "happy" if acc >= 0.75 else chief.get("expression", "neutral") if acc >= 0.5 else "nervous"

        # 승진 판정
        st, levels = app.state, app.data.levels
        total = st.total_score
        new_level = max(lv["level"] for lv in levels if lv["need"] <= total)
        self.old = st.level_info(levels)
        self.promoted = new_level > st.level
        self.pulls = sum(1 for lv in levels if st.level < lv["level"] <= new_level and lv.get("pull"))
        self.pulls = min(self.pulls, 3 - len(st.team))              # 동료는 최대 3명
        st.level = max(st.level, new_level)
        st.promoted_today = self.promoted
        self.cur = st.level_info(levels)
        self.next = next((lv for lv in levels if lv["level"] == st.level + 1), None)
        self.team = list(st.team)
        self.team_chars = [Character(m["look"]) for m in self.team]
        for ch in self.team_chars:
            ch.expression = "happy"
        self.chief.set_pose("cheer" if (self.promoted or acc >= 0.75) else "hip" if acc >= 0.5 else "shrug")
        self.promo_played = False

        last = app.state.day_index >= len(app.data.days) - 1
        label = "봉투 열기 " if self.pulls else ("최종 평가 " if last else "다음 날로 ")
        self.btn = ui.Button((930, 644, 300, 58), "", C_ACCENT, size=24,
                             parts=[(label, sticker.WHITE), ("GO!", sticker.YELLOW)])
        if self.promoted:
            self.comment = chief["summary"]["promo"].format(title=self.cur["title"])
        else:
            self.comment = chief["summary"]["good" if acc >= 0.75 else "ok" if acc >= 0.5 else "bad"]
        if s.carried:                                           # 못 끝낸 일은 내일 잔업으로
            self.comment += f"  (남은 {s.leftover}건 중 {s.carried}건은 내일 잔업)"
        elif s.leftover:
            self.comment += f"  (남은 {s.leftover}건은 다른 창구로 이관)"
        self.tw = ui.Typewriter(self.comment, 34, self.chief.voice)
        sfx.play("bell", 0.6)

    def _go(self):
        self.app.after_summary(self.pulls, self.promoted)

    def handle_event(self, event):
        if self.btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self._go()

    def update(self, dt):
        self.t += dt
        self.btn.update(dt)
        self.chief.update(dt)
        for ch in self.team_chars:
            ch.update(dt)
        if self.t > 1.6:
            self.tw.update(dt)
        if self.promoted and not self.promo_played and self.t >= T_PROMO:
            self.promo_played = True
            sfx.play("fanfare", 0.7)
        self.btn.pulse = bool(self.pulls) and self.t > T_PROMO + 0.5

    # ---------------------------------------------------------------- 인사 발령 통지
    def _draw_envelope(self, surf, center, k):
        """도착한 인사 발령 봉투 (열기 전)."""
        wob = math.sin(self.t * 9) * 4
        r = pygame.Rect(0, 0, int(150 * k), int(96 * k))
        r.center = (center[0] + wob, center[1])
        props.hard_shadow(surf, r, 8, (4, 6))
        pygame.draw.rect(surf, (255, 250, 236), r, border_radius=8)
        pygame.draw.lines(surf, C_INK, False, [r.topleft, (r.centerx, r.centery + 8), r.topright], 3)
        pygame.draw.rect(surf, C_INK, r, 4, border_radius=8)
        pygame.draw.circle(surf, C_REJECT, (r.centerx, r.centery + 8), int(18 * k))
        pygame.draw.circle(surf, C_INK, (r.centerx, r.centery + 8), int(18 * k), 3)
        ui.draw_text(surf, "인사", (r.centerx, r.centery + 8), int(13 * k), C_WHITE, True, center=True)

    def _draw_promotion(self, surf):
        k = ease_out_back((self.t - 0.9) / 0.5, 1.1)
        if k <= 0.02:
            return
        card = pygame.Rect(0, 0, 350, 372)
        card.topleft = (896, 256 + (1 - k) * 500)
        props.box(surf, card, (255, 250, 236), radius=8, offset=(6, 8))
        props.tape(surf, (card.centerx, card.y + 2), -3)
        ui.draw_text(surf, "인 사 발 령", (card.centerx, card.y + 30), 20, C_INK, "heavy", center=True)
        pygame.draw.line(surf, C_INK, (card.x + 22, card.y + 50), (card.right - 22, card.y + 50), 3)

        shown = self.cur if (not self.promoted or self.t >= T_PROMO) else self.old
        ui.draw_text(surf, shown["title"], (card.x + 24, card.y + 62), 30, C_INK, "heavy")
        ui.draw_text(surf, "주무관", (card.right - 24, card.y + 74), 17, C_INK_SOFT, True, anchor="topright")

        total = self.app.state.total_score
        bar = pygame.Rect(card.x + 24, card.y + 108, card.w - 48, 20)
        if self.next:
            frac = (total - self.cur["need"]) / max(1, self.next["need"] - self.cur["need"])
            label = f"{self.next['title']} 승진까지 {max(0, self.next['need'] - total):,}점"
        else:
            frac, label = 1.0, "창구 최고 직급 달성!"
        frac = max(0.0, min(1.0, frac)) * ease_out_cubic((self.t - 1.2) / 0.8)
        pygame.draw.rect(surf, (236, 224, 204), bar, border_radius=10)
        if frac > 0.02:
            pygame.draw.rect(surf, C_ACCENT, (bar.x, bar.y, int(bar.w * frac), bar.h), border_radius=10)
        pygame.draw.rect(surf, C_INK, bar, 3, border_radius=10)
        ui.draw_text(surf, label, (card.x + 24, bar.bottom + 6), 14, C_INK_SOFT, True)
        pygame.draw.line(surf, (236, 224, 204), (card.x + 22, card.y + 158), (card.right - 22, card.y + 158), 2)

        y0 = card.y + 168
        if self.pulls and self.t >= T_PROMO:
            kk = ease_out_back((self.t - T_PROMO) / 0.4, 1.8)
            self._draw_envelope(surf, (card.centerx, y0 + 62), max(0.1, kk))
            text = "인사 발령 봉투 도착!" if self.pulls == 1 else f"인사 발령 봉투 {self.pulls}개 도착!"
            ui.draw_text(surf, text, (card.centerx, y0 + 130), 19, C_REJECT, "heavy", center=True)
            ui.draw_text(surf, "어떤 동료가 올까요?", (card.centerx, y0 + 158), 15, C_INK_SOFT, True, center=True)
            if kk > 0.3:
                img = sticker.sticker_text("승진!", 34, sticker.YELLOW)
                img = pygame.transform.rotozoom(img, 12, min(1.0, kk))
                surf.blit(img, img.get_rect(center=(card.right - 34, card.y + 6)))
        elif self.team:
            ui.draw_text(surf, "함께 일하는 동료", (card.x + 24, y0 + 2), 15, C_INK, True)
            for i, (m, ch) in enumerate(zip(self.team, self.team_chars)):
                x = card.x + 62 + i * 112
                ch.draw(surf, (x, y0 + 26), scale=0.36)
                tag = pygame.Rect(0, 0, 40, 18)
                tag.center = (x, y0 + 126)
                pygame.draw.rect(surf, gacha.RARITY_COLOR[m["rarity"]], tag, border_radius=8)
                pygame.draw.rect(surf, C_INK, tag, 2, border_radius=8)
                ui.draw_text(surf, m["rarity"], tag.center, 12, C_WHITE, True, center=True)
                ui.draw_text(surf, m["name"], (x, y0 + 148), 13, C_INK, True, center=True)
                for j, sk in enumerate(m["skills"]):
                    cx = x - (len(m["skills"]) - 1) * 13 + j * 26
                    pygame.draw.circle(surf, gacha.GRADE_COLOR[sk["grade"]], (cx, y0 + 176), 11)
                    pygame.draw.circle(surf, C_INK, (cx, y0 + 176), 11, 2)
                    ui.draw_text(surf, sk["grade"], (cx, y0 + 176), 13, C_WHITE, True, center=True)
        else:
            ui.draw_wrapped(surf, self.cur.get("desc", ""), (card.x + 24, y0 + 6, card.w - 48, 60), 15)
            ui.draw_wrapped(surf, "점수를 모아 승진하면 인사 발령 봉투에서 함께 일할 동료가 나와요!",
                            (card.x + 24, y0 + 78, card.w - 48, 60), 15, C_ACCENT, True)

    def draw(self, surf):
        props.draw_wall(surf, WALL_H, self.t, 1.0)                 # 노을
        props.draw_window(surf, (60, 22, 200, 118), self.t, 1.0)
        props.draw_clock(surf, (350, 84), 46, 1080, 0, self.t)     # 18:00 퇴근
        self.chief.draw(surf, (1070, 8), scale=0.9)
        props.draw_counter(surf, WALL_H)
        props.draw_desk(surf, WALL_H + 34)
        ui.speech_bubble(surf, (560, 30, 400, 124), self.tw, tail=(982, 110), name=self.chief_name, size=18)

        # 클립보드 + 업무 일지
        s = self.stats
        k = ease_out_back(self.t / 0.5, 1.1)
        board = pygame.Rect(0, 0, 580, 458)
        board.midtop = (WIDTH // 2 - 190, 250 + (1 - k) * 480)
        props.box(surf, board, (176, 124, 78), radius=16, offset=(7, 8))
        page = pygame.Rect(board.x + 18, board.y + 40, board.w - 36, board.h - 58)
        for o in (6, 3):
            pygame.draw.rect(surf, (238, 230, 212), page.move(o, o))
            pygame.draw.rect(surf, C_INK, page.move(o, o), 2)
        pygame.draw.rect(surf, (255, 253, 247), page)
        for y in range(page.y + 124, page.bottom - 4, 44):         # 줄 공책
            pygame.draw.line(surf, (214, 228, 240), (page.x + 20, y), (page.right - 20, y), 2)
        pygame.draw.rect(surf, C_INK, page, 3)
        clip = pygame.Rect(0, 0, 150, 40)
        clip.midtop = (board.centerx, board.y + 10)
        pygame.draw.rect(surf, (196, 200, 210), clip, border_radius=10)
        pygame.draw.rect(surf, (156, 162, 176), (clip.x, clip.bottom - 12, clip.w, 12),
                         border_bottom_left_radius=10, border_bottom_right_radius=10)
        pygame.draw.rect(surf, C_INK, clip, 3, border_radius=10)

        ui.draw_text(surf, f"{s.day}일차 업무 일지", (page.centerx, page.y + 46), 30, C_INK, "heavy", center=True)
        pygame.draw.line(surf, C_INK, (page.x + 24, page.y + 76), (page.right - 24, page.y + 76), 3)
        rows = [
            ("처리 건수", s.processed, "건", C_INK),
            ("정확한 판단", s.correct, "건", C_GOOD),
            ("사유 불일치", s.partial, "건", C_WARN),
            ("오판 (감사 경고)", s.wrong, "건", C_REJECT),
            ("오늘 점수", s.score, "점", C_INK),
            ("아낀 세금", s.saved, "원", C_GOOD),
            ("누적 점수", self.app.state.total_score, "점", C_INK),
        ]
        for i, (label, value, unit, color) in enumerate(rows):
            rt = ease_out_cubic((self.t - 0.4 - i * 0.12) / 0.6)
            if rt <= 0:
                continue
            y = page.y + 88 + i * 44
            ui.draw_text(surf, label, (page.x + 32, y + 4), 20, C_INK_SOFT, True)
            ui.draw_text(surf, f"{int(value * rt):,}{unit}", (page.right - 32, y), 24, color, True,
                         anchor="topright")
        if self.t > 1.9 and s.processed and s.wrong == 0:          # 무결점 칭찬 도장
            kk = ease_out_back((self.t - 1.9) / 0.3, 2.0)
            if kk > 0.05:
                st = pygame.Surface((150, 150), pygame.SRCALPHA)
                pygame.draw.circle(st, (*C_REJECT, 220), (75, 75), 66, 7)
                pygame.draw.circle(st, (*C_REJECT, 150), (75, 75), 54, 2)
                ui.draw_text(st, "참 잘", (75, 56), 26, C_REJECT, "heavy", center=True)
                ui.draw_text(st, "했어요", (75, 90), 26, C_REJECT, "heavy", center=True)
                st = pygame.transform.rotozoom(st, 14, kk * 0.72)
                surf.blit(st, st.get_rect(center=(page.x + 74, page.y + 42)))

        self._draw_promotion(surf)
        self.btn.draw(surf)
