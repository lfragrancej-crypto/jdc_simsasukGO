"""히든 엔딩 — 세 편(심사숙GO · 납품하GO · 요청하GO)을 모두 끝내면, 묶음 첫 화면으로 돌아왔을 때 저절로 시작된다.

  mid   세 편을 모두 중간 난이도 이상으로 클리어 → '조달 한 바퀴' (그림 7장)
  hard  세 편을 모두 가장 어려운 난이도로 클리어 → '진짜 한 바퀴' (그림 9장: 위 7장 + 두 장 더)
가장 쉬운 난이도로만 깬 것은 세지 않는다. 한 번 본 뒤에는 도감의 '엔딩' 탭에서 다시 볼 수 있다.
"""
import math

import pygame

from .. import cg as C
from .. import props, sfx, sticker, ui
from ..agency import cgs as acg
from ..cg import INK, Stage
from ..config import HEIGHT, WIDTH
from ..factory import cgs as fcg
from .base import Scene

TIERS = {"mid": {"title": "조달 한 바퀴", "need": "세 편을 모두 중간 난이도 이상으로 클리어"},
         "hard": {"title": "진짜 한 바퀴", "need": "세 편을 모두 가장 어려운 난이도로 클리어"}}
MID_OK = {"review": ("normal", "hell"), "factory": ("normal", "hard"), "agency": ("normal", "hard")}
HARD_OK = {"review": ("hell",), "factory": ("hard",), "agency": ("hard",)}


# ------------------------------------------------------------------ 조건과 기록
def _cleared(app) -> dict:
    prof = app.profile.data
    return {"review": set(prof.get("chiefs", {})), "factory": set(prof.get("factory", {}).get("levels", {})),
            "agency": set(prof.get("agency", {}).get("levels", {}))}


def done_tiers(app) -> list[str]:
    """조건을 채운 엔딩들."""
    got = _cleared(app)
    out = []
    if all(got[g] & set(MID_OK[g]) for g in got):
        out.append("mid")
    if all(got[g] & set(HARD_OK[g]) for g in got):
        out.append("hard")
    return out


def seen(app) -> dict:
    rec = app.profile.data.get("hidden")
    if not isinstance(rec, dict):
        rec = app.profile.data["hidden"] = {}
    return rec


def pending(app) -> str | None:
    """지금 보여 줘야 할(조건은 채웠는데 아직 안 본) 엔딩. 진짜 한 바퀴가 먼저."""
    done, s = done_tiers(app), seen(app)
    for tier in ("hard", "mid"):
        if tier in done and not s.get(tier):
            return tier
    return None


def mark_seen(app, tier):
    s = seen(app)
    s[tier] = True
    if tier == "hard":                                             # 진짜 한 바퀴는 앞의 일곱 장을 품고 있다
        s["mid"] = True
    app.profile.save()


# ------------------------------------------------------------------ 배역
def _cast(data, hard=False):
    fl, al = data.factory["levels"], data.agency["levels"]
    return {"hero": data.dialogue["hero"]["look"],                       # 심사관
            "boss": (fl[2] if hard else fl[1])["look"],                 # 사장
            "officer": (al[2] if hard else al[1])["look"],              # 주무관
            "chief": data.chiefs[2 if hard else 1],                     # 팀장
            "school": data.case_of(1)["officer"]["look"],               # 한아름 주무관
            "narmi": data.dialogue["mascots"]["narmi"]["look"], "dali": data.dialogue["mascots"]["dali"]["look"],
            "shady": next(c["look"] for c in data.companies if c["name"] == data.factory["collusion"]["who"])}


def _table_scene(s, sign):
    """분식집 — 셋이 처음 한자리에 앉는 곳."""
    C.bg_cafe(s)
    C.banner(s, (430, 40, 420, 64), sign, (236, 96, 80), 34)
    C.table(s, (300, 470, 680, 44))
    for x in (420, 640, 860):
        C.snack_plate(s, x, 470)
    C.cup(s, 540, 470, (72, 170, 196))
    C.cup(s, 760, 470, (255, 138, 92))


# ------------------------------------------------------------------ 장면들 (제목, 설명, 그리기)
def _s1(st, c):
    s = st.s
    acg.classroom(s, "의자가 삐걱거려요")
    C.table(s, (470, 520, 340, 40))
    acg.paper_blocks(s, 500, 470, 4)
    st.actor(c["school"], (330, 640), "nervous", "point", 1.0, -4, full=True)
    st.actor(c["officer"], (900, 640), "happy", "hip", 1.08, 5, full=True, flip=True)
    C.speech(s, (560, 350, 430, 80), "알겠습니다. 요청서, 제가 씁니다!", (870, 440), 19)


def _s2(st, c):
    s = st.s
    props.draw_wall(s, 430, 4.0, 0.0)
    props.draw_window(s, (60, 60, 230, 180), 4.0, 0.0)
    props.draw_clock(s, (1180, 120), 52, 12 * 60 + 50)
    st.actor(c["chief"]["look"], (980, 200), c["chief"].get("expression", "neutral"), "hip", 1.0)
    st.actor(c["hero"], (460, 170), "nervous", "point", 1.2)
    C.desk_row(st, 430)
    for i in range(4):
        C.paper_stack(s, 180 + i * 120, 470, 5 + i * 2)
    stamp = pygame.Surface((220, 110), pygame.SRCALPHA)
    pygame.draw.rect(stamp, (72, 142, 232), stamp.get_rect(), 8, border_radius=14)
    ui.draw_text(stamp, "적격", (110, 55), 56, (72, 142, 232), "heavy", center=True)
    stamp = pygame.transform.rotozoom(stamp, 10, 1.0)
    s.blit(stamp, stamp.get_rect(center=(800, 540)))
    C.speech(s, (560, 60, 420, 80), "…사업자번호, 한 글자씩 다 맞네.", (520, 200), 19)


def _s3(st, c):
    s = st.s
    fcg.inside(s, night=True)
    for x in (300, 640, 980):
        C.lamp(s, x, 150)
    fcg.conveyor(s, 380, (190, 420, 650, 880, 1100))
    st.actor(c["boss"], (520, 614), "nervous", "cheer", 1.1, -4, full=True, legs=(-14, 14))
    C.banner(s, (930, 40, 290, 60), "납기 D-1", (238, 92, 92), 30)
    for i, (x, y) in enumerate(((760, 300), (840, 250), (920, 300))):       # 박자표
        pygame.draw.circle(s, (255, 226, 110), (x, y), 14)
        pygame.draw.line(s, (255, 226, 110), (x + 12, y), (x + 12, y - 50), 6)
    C.speech(s, (140, 200, 380, 80), "쿵, 딱, 쿵, 딱… 박자만 맞추면 된다!", (480, 340), 19)


def _s4(st, c):
    s = st.s
    C.sky(s, (130, 200, 250), (214, 238, 252), 470)
    pygame.draw.circle(s, (255, 242, 170), (150, 100), 50)
    C.cloud(s, 420, 120, 140)
    pygame.draw.rect(s, (150, 206, 130), (0, 400, WIDTH, 80))
    school = pygame.Rect(820, 170, 360, 290)
    props.box(s, school, (255, 240, 214), radius=6, shade=(236, 214, 180), offset=(6, 7))
    C.banner(s, (860, 188, 280, 54), st.data.case_of(1)["agency"], (255, 138, 92), 26)
    C._ground(s, 470, (176, 180, 190))
    fcg.truck(s, 110, 560)
    st.actor(c["boss"], (700, 640), "happy", "hi", 0.98, -4, full=True)
    st.actor(c["school"], (900, 640), "happy", "cheer", 1.0, 4, full=True, flip=True, legs=(-14, 14), ground=652)
    st.actor(c["officer"], (1080, 640), "happy", "clap", 1.0, 6, full=True, flip=True)
    C.confetti(s, 110, 9)


def _s5(st, c):
    s = st.s
    C.bg_cafe(s)
    st.actor(c["officer"], (330, 250), "shocked", "shock", 1.0)
    st.actor(c["hero"], (640, 240), "nervous", "shrug", 1.0)
    st.actor(c["boss"], (950, 250), "shocked", "point", 1.0, flip=True)
    C.desk_row(st, 470)
    C.table(s, (300, 470, 680, 44))
    for x in (420, 640, 860):
        C.snack_plate(s, x, 470)
    C.speech(s, (40, 96, 330, 100), "그 요청서, 보완하라고 돌려보낸 게… 당신이었어요?", (300, 260), 17)
    C.speech(s, (880, 96, 360, 100), "3분 늦었다고 안 받아 준 게… 당신이었어요?!", (960, 260), 17)
    C.speech(s, (470, 20, 340, 70), "…떡볶이는 제가 살게요.", (640, 230), 18)


def _s6(st, c):
    s = st.s
    C.sky(s, (255, 236, 200), (255, 250, 236), HEIGHT)
    cx, cy, r = WIDTH // 2, 330, 220
    pygame.draw.circle(s, (255, 226, 150), (cx, cy), r + 26)
    pygame.draw.circle(s, (255, 250, 236), (cx, cy), r - 26)
    pygame.draw.circle(s, INK, (cx, cy), r + 26, 4)
    pygame.draw.circle(s, INK, (cx, cy), r - 26, 4)
    for k in range(3):                                             # 고리 위의 화살촉 세 개
        a = -math.pi / 2 + k * math.tau / 3 + 0.9
        px, py = cx + math.cos(a) * r, cy + math.sin(a) * r
        t = a + math.pi / 2
        pts = [(px + math.cos(t) * 26, py + math.sin(t) * 26), (px + math.cos(t + 2.5) * 22, py + math.sin(t + 2.5) * 22),
               (px + math.cos(t - 2.5) * 22, py + math.sin(t - 2.5) * 22)]
        pygame.draw.polygon(s, (255, 138, 92), pts)
        pygame.draw.polygon(s, INK, pts, 3)
    spots = (("officer", "요청하고", -math.pi / 2), ("hero", "심사하고", -math.pi / 2 + math.tau / 3), ("boss", "납품하고", -math.pi / 2 + 2 * math.tau / 3))
    for who, word, a in spots:
        px, py = cx + math.cos(a) * r, cy + math.sin(a) * r
        st.actor(c[who], (px, py + 70), "happy", "wave", 0.6, 0, full=True)
        ui.pill(s, (px - 60, py + 78, 120, 32), word, (255, 138, 92), (255, 255, 255), 17)
    ui.draw_text(s, "세금", (cx, cy - 18), 40, (226, 76, 76), "heavy", center=True)
    ui.draw_text(s, "한 바퀴", (cx, cy + 28), 26, INK, "heavy", center=True)
    st.actor(c["narmi"], (150, 640), "happy", "point", 0.9, -6, full=True)
    st.actor(c["dali"], (1130, 640), "happy", "clap", 0.9, 6, full=True, flip=True)


def _s7(st, c):
    s = st.s
    C.bg_building(s, sunset=True)
    C.bunting(s, 60, 1220, 20, 44)
    st.actor(c["narmi"], (170, 600), "happy", "cheer", 0.86, -8, full=True)
    st.actor(c["school"], (330, 606), "happy", "wave", 0.94, -5, full=True)
    st.actor(c["officer"], (500, 610), "happy", "cheer", 1.04, -3, full=True)
    st.actor(c["hero"], (680, 612), "happy", "cheer", 1.12, 0, full=True, legs=(-14, 14), ground=624)
    st.actor(c["boss"], (860, 610), "happy", "cheer", 1.04, 3, full=True, flip=True)
    st.actor(c["chief"]["look"], (1020, 606), "happy", "clap", 0.94, 5, full=True, flip=True)
    st.actor(c["dali"], (1160, 600), "happy", "cheer", 0.86, 8, full=True, flip=True)
    st.actor(c["shady"], (1300, 610), "nervous", "hi", 0.96, 10, full=True, flip=True)        # 사진 가장자리에서 잘린다
    C.confetti(s, 180, 2)


def _h1(st, c):
    s = st.s
    C.bg_cafe(s)
    C.banner(s, (400, 40, 480, 64), "가장 어려운 길을 걸은 모임", (60, 60, 80), 28)
    st.actor(c["officer"], (330, 250), "neutral", "idle", 1.0)
    st.actor(c["chief"]["look"], (640, 240), "neutral", "hip", 1.0)
    st.actor(c["boss"], (950, 250), "neutral", "idle", 1.0, flip=True)
    C.desk_row(st, 470)
    C.table(s, (300, 470, 680, 44))
    for x in (420, 640, 860):
        C.cup(s, x, 470, (120, 86, 60))
    for x in (330, 640, 950):
        ui.draw_text(s, "…", (x, 150), 54, INK, "heavy", center=True)
    ui.pill(s, (470, 600, 340, 40), "(눈빛 번역: 고생했다.)", (255, 250, 236), INK, 18)


def _h2(st, c):
    s = st.s
    C.bg_building(s)
    st.actor(c["narmi"], (460, 600), "happy", "point", 1.1, -4, full=True)
    st.actor(c["hero"], (820, 606), "happy", "cheer", 1.08, 4, full=True, flip=True, legs=(-12, 12), ground=618)
    book = pygame.Rect(560, 300, 190, 240)                         # 금빛 서류철
    props.box(s, book, (250, 206, 80), radius=10, shade=(214, 166, 40), offset=(7, 9))
    pygame.draw.rect(s, (255, 244, 200), (book.x + 22, book.y + 40, book.w - 44, 96), border_radius=6)
    pygame.draw.rect(s, INK, (book.x + 22, book.y + 40, book.w - 44, 96), 3, border_radius=6)
    ui.draw_text(s, "전설의", (book.centerx, book.y + 68), 22, INK, "heavy", center=True)
    ui.draw_text(s, "서류철", (book.centerx, book.y + 104), 26, (226, 76, 76), "heavy", center=True)
    ui.draw_text(s, "점심은", (book.centerx, book.y + 168), 18, INK, True, center=True)
    ui.draw_text(s, "드셨습니까?", (book.centerx, book.y + 194), 18, INK, True, center=True)
    C.confetti(s, 150, 5)


SLIDES = [
    {"id": "h1", "title": "한 장의 요청서", "text": "시작은 “의자가 삐걱거려요” 한마디였다. 누군가 그 말을 받아 적었다.", "draw": _s1},
    {"id": "h2", "title": "창구의 도장", "text": "누군가는 서류 더미에서 틀린 숫자 하나를 찾아냈다. (그날 점심은 걸렀다.)", "draw": _s2},
    {"id": "h3", "title": "공장의 밤", "text": "누군가는 약속한 날짜를 지키려고 밤새 박자를 맞췄다. (허리도 같이 맞췄다.)", "draw": _s3},
    {"id": "h4", "title": "의자가 도착한 날", "text": "그렇게 의자 하나가 교실에 닿았다. 아이들은 그 뒤에 누가 있었는지 모른다.", "draw": _s4},
    {"id": "h5", "title": "셋이 만나다", "text": "어느 저녁, 세 사람이 분식집 한 테이블에 앉았다. 서로 누군지 깨닫는 데는 3초가 걸렸다.", "draw": _s5},
    {"id": "x1", "title": "가장 어려운 길", "text": "제일 험한 자리만 골라 걸어온 셋은 말이 없었다. 커피가 식을 때까지.", "draw": _h1, "hard": True},
    {"id": "h6", "title": "돌고 도는 한 바퀴", "text": "요청하고, 심사하고, 납품하고. 세금은 그렇게 한 바퀴를 돌아 다시 우리에게 온다.", "draw": _s6},
    {"id": "x2", "title": "전설의 서류철", "text": "세 자리의 가장 높은 곳을 모두 본 사람에게 주는 상. 표지의 글귀는 수상자만 읽을 수 있다.", "draw": _h2, "hard": True},
    {"id": "h7", "title": "다함께! 조달 한바퀴", "text": "공정한 한 바퀴는 혼자서는 못 돌린다. (검은거래 사장은 사진에서 잘렸다.)", "draw": _s7},
]


def slides(tier) -> list[dict]:
    return [sl for sl in SLIDES if tier == "hard" or not sl.get("hard")]


def render(slide, data, hard=False) -> pygame.Surface:
    surf = pygame.Surface((WIDTH, HEIGHT))
    st = Stage(surf, data.dialogue["hero"]["look"], data.chiefs[1], [])
    st.data = data
    slide["draw"](st, _cast(data, hard))
    return surf


class HiddenEndingScene(Scene):
    """히든 엔딩을 한 장씩 넘겨 본다. viewer=True 면 도감에서 다시 보는 중 (기록은 건드리지 않는다)."""
    BGM = "hub"
    HOME = "hub"

    def __init__(self, app, tier, viewer=False, on_done=None):
        super().__init__(app)
        self.tier = tier
        self.viewer = viewer
        self.on_done = on_done
        self.slides = slides(tier)
        self.i = -1                       # -1 = 제목 장
        self.t = 0.0
        self.img = None
        if not viewer:
            mark_seen(app, tier)          # 시작하는 순간 '봤다' — 중간에 나가도 도감에서 다시 볼 수 있다
        sfx.play("fanfare", 0.6)

    def _next(self):
        if self.i >= len(self.slides) - 1:
            if self.on_done:
                self.on_done()
            else:
                self.app.to_hub()
            return
        self.i += 1
        self.t = 0.0
        self.img = render(self.slides[self.i], self.app.data, self.tier == "hard")
        sfx.play("paper" if self.i < len(self.slides) - 1 else "fanfare", 0.5)

    def handle_event(self, event):
        click = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        key = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_RIGHT)
        if (click or key) and self.t > 0.6:
            self._next()

    def update(self, dt):
        self.t += dt

    def draw(self, surf):
        if self.i < 0:                                             # 제목 장
            surf.fill((40, 30, 56))
            for k in range(12):
                a = self.t * 0.3 + k * math.tau / 12
                pts = [(WIDTH // 2, HEIGHT // 2), (WIDTH // 2 + math.cos(a) * 1200, HEIGHT // 2 + math.sin(a) * 1200),
                       (WIDTH // 2 + math.cos(a + 0.26) * 1200, HEIGHT // 2 + math.sin(a + 0.26) * 1200)]
                pygame.draw.polygon(surf, (58, 44, 84), pts)
            img = sticker.sticker_text("히든 엔딩", 46, sticker.YELLOW)
            surf.blit(img, img.get_rect(center=(WIDTH // 2, 230)))
            big = sticker.sticker_text(TIERS[self.tier]["title"], 104, sticker.WHITE)
            surf.blit(big, big.get_rect(center=(WIDTH // 2, 350 + math.sin(self.t * 2.4) * 6)))
            ui.draw_text(surf, "세 편을 모두 끝낸 당신에게만 보이는 이야기", (WIDTH // 2, 470), 20, (236, 230, 250), True, center=True)
        else:
            k = 1.0 + 0.03 * min(1.0, self.t / 7.0)
            img = self.img if k <= 1.001 else pygame.transform.smoothscale(self.img, (int(WIDTH * k), int(HEIGHT * k)))
            surf.blit(img, img.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
            sl = self.slides[self.i]
            C.caption(surf, sl["title"], sl["text"], None)
            ui.pill(surf, (WIDTH - 150, 18, 120, 32), f"{self.i + 1} / {len(self.slides)}", (255, 250, 236), INK, 15)
        if self.t > 0.8:
            a = (math.sin(self.t * 4) + 1) / 2
            last = self.i >= len(self.slides) - 1
            ui.draw_text(surf, "클릭해서 마치기 →" if last else "클릭해서 계속 →", (WIDTH - 40, HEIGHT - 36), 16,
                         tuple(int(170 + 80 * a) for _ in range(3)), True, anchor="topright")
