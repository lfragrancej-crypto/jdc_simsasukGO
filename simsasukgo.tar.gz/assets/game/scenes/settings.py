"""설정 — 배경음악·효과음 크기, 전체 화면, 기록 초기화."""
import pygame

from .. import bgm, props, save, sfx, ui
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_REJECT, WIDTH
from .base import Scene

ROW_Y = {"bgm": 230, "sfx": 310, "fullscreen": 390, "reset": 490}
GRAY = (190, 170, 150)


class SettingsScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.st = app.profile.settings
        self.t = 0.0
        self.confirm_reset = False
        self.buttons = {}
        for key in ("bgm", "sfx"):
            self.buttons[key + "-"] = ui.Button((760, ROW_Y[key], 56, 48), "-", GRAY, size=22, float_amp=0)
            self.buttons[key + "+"] = ui.Button((1030, ROW_Y[key], 56, 48), "+", C_ACCENT, size=22, float_amp=0)
        self.buttons["fullscreen"] = ui.Button((760, ROW_Y["fullscreen"], 326, 50), "", GRAY, size=18, float_amp=0)
        self.buttons["reset"] = ui.Button((760, ROW_Y["reset"], 326, 50), "", C_REJECT, size=18, float_amp=0)
        self.buttons["back"] = ui.Button((WIDTH // 2 - 130, 610, 260, 56), "돌아가기", C_ACCENT, size=22)
        self._relabel()

    def _relabel(self):
        self.buttons["fullscreen"].parts = [("전체 화면 켜짐" if self.st["fullscreen"] else "창 모드", (255, 253, 247))]
        self.buttons["fullscreen"].color = (84, 180, 110) if self.st["fullscreen"] else GRAY
        self.buttons["reset"].parts = [("한 번 더 누르면 정말 지워요!" if self.confirm_reset else "기록 초기화", (255, 253, 247))]

    def handle_event(self, event):
        b = self.buttons
        for key in ("bgm", "sfx"):
            for sign, delta in (("-", -10), ("+", 10)):
                if b[key + sign].clicked(event):
                    self.st[key] = max(0, min(100, self.st[key] + delta))
                    self.app.profile.save()
                    self.app.apply_settings()
                    if key == "sfx":
                        sfx.play("correct", 0.6)
                    return
        if not self.app.device["web"] and b["fullscreen"].clicked(event):
            self.st["fullscreen"] = not self.st["fullscreen"]
            self.app.profile.save()
            self.app.set_fullscreen(self.st["fullscreen"])
            self._relabel()
        elif b["reset"].clicked(event):
            if self.confirm_reset:
                self.app.profile.reset()
                save.delete(self.app.profile.dir)
                self.confirm_reset = False
                sfx.play("stamp", 0.7)
            else:
                self.confirm_reset = True
            self._relabel()
        elif b["back"].clicked(event):
            self.app.to_title()
        elif event.type == pygame.MOUSEBUTTONDOWN and self.confirm_reset:
            self.confirm_reset = False
            self._relabel()

    def update(self, dt):
        self.t += dt
        for btn in self.buttons.values():
            btn.update(dt)

    def _bar(self, surf, key):
        r = pygame.Rect(830, ROW_Y[key] + 12, 186, 24)
        pygame.draw.rect(surf, (236, 224, 204), r, border_radius=12)
        w = int(r.w * self.st[key] / 100)
        if w > 6:
            pygame.draw.rect(surf, C_ACCENT, (r.x, r.y, w, r.h), border_radius=12)
        pygame.draw.rect(surf, C_INK, r, 3, border_radius=12)
        ui.draw_text(surf, str(self.st[key]), r.center, 14, C_INK, True, center=True)

    def draw(self, surf):
        props.draw_desk(surf, 0)
        panel = pygame.Rect(140, 80, 1000, 500)
        props.box(surf, panel, (255, 250, 236), radius=16, offset=(8, 10))
        props.tape(surf, (panel.centerx, panel.y + 2), -3, 70, 22)
        ui.draw_text(surf, "설 정", (panel.centerx, panel.y + 62), 40, C_INK, "heavy", center=True)
        pygame.draw.line(surf, C_INK, (panel.x + 60, panel.y + 104), (panel.right - 60, panel.y + 104), 3)
        rows = [("bgm", "배경음악 크기", "잔잔하게 깔리는 음악"), ("sfx", "효과음 크기", "도장, 말소리, 종이 소리"),
                ("fullscreen", "화면", "전체 화면으로 크게 보기"),
                ("reset", "기록", "도감·클리어 기록·이어하기를 모두 지웁니다")]
        for key, title, desc in rows:
            y = ROW_Y[key]
            ui.draw_text(surf, title, (panel.x + 80, y + 2), 24, C_INK, True)
            ui.draw_text(surf, desc, (panel.x + 80, y + 32), 14, C_INK_SOFT, True)
        self._bar(surf, "bgm")
        self._bar(surf, "sfx")
        for name, btn in self.buttons.items():
            if name == "fullscreen" and self.app.device["web"]:
                ui.draw_text(surf, "브라우저의 전체 화면 기능(F11)을 쓰세요", btn.rect.center, 15, C_INK_SOFT, True, center=True)
                continue
            btn.draw(surf)
        ui.draw_text(surf, "M 키: 언제든 소리 끄기/켜기   ·   Esc: 타이틀로", (WIDTH // 2, 690), 14, (120, 80, 50), True,
                     center=True)
