"""인사 발령 봉투 열기 — 동료 합류 연출.

'인사 발령!' 과 함께 봉투가 내려온다. 봉투는 가만히 있다가,
  마우스를 올리면 → 떨리면서 틈으로 빛이 새어 나온다 (빛의 색 = 등급 힌트)
  클릭하면      → 열린다

봉투가 보여 주는 빛(패턴)은 등급마다 이렇게 정해진다.
  R    100%  파란 빛
  SR    80%  금빛
        20%  파란 빛(R 인 척) → 여는 순간 중간 정도의 효과와 함께 금빛으로 바뀜
  SSR   60%  무지갯빛
        20%  금빛(SR 인 척) → 여는 순간 화려한 효과와 함께 무지갯빛으로 바뀜
        20%  황금 봉투 (봉투 자체가 금색, 마우스를 올리면 훨씬 세게 떨린다)
"""
import math
import random

import pygame

from .. import gacha, props, sfx, sticker, ui
from ..anim import Particles, clamp01, ease_out_back, ease_out_cubic, lerp
from ..character import Character
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_WHITE, HEIGHT, WIDTH
from .base import Scene

BLUE, GOLD = (96, 160, 240), (250, 196, 60)
T_DROP = 0.6
CENTER = (WIDTH // 2, 370)
ENVELOPE = pygame.Rect(CENTER[0] - 175, CENTER[1] - 120, 350, 240)      # 마우스 감지 범위
# 바뀌는 연출: 길이(초), '쩍!' 하는 시각들, 흔들림, 조각 수
MORPH = {"SR": {"dur": 0.85, "cracks": (0.3,), "shake": 0.22, "burst": 40},
         "SSR": {"dur": 1.45, "cracks": (0.3, 0.8), "shake": 0.42, "burst": 90}}


def rainbow(t, sat=62, val=100):
    c = pygame.Color(0)
    c.hsva = ((t * 360) % 360, sat, val, 100)
    return (c.r, c.g, c.b)


def choose_pattern(rng, rarity: str) -> tuple[str, str]:
    """(패턴, 봉투가 처음 보여 주는 등급).  패턴: plain(그대로) / fake(낮은 등급인 척) / gold(황금 봉투)"""
    roll = rng.random()
    if rarity == "SSR":
        if roll < 0.2:
            return "fake", "SR"
        if roll < 0.4:
            return "gold", "SSR"
        return "plain", "SSR"
    if rarity == "SR" and roll < 0.2:
        return "fake", "R"
    return "plain", rarity


class GachaScene(Scene):
    BGM = None                       # 연출 동안 배경음악을 멈춰 긴장감을 준다

    def __init__(self, app, count):
        super().__init__(app)
        self.left = count                 # 열 봉투 수
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.rays = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self.btn = ui.Button((WIDTH - 372, 624, 330, 60), "", C_ACCENT, size=24, parts=[("", sticker.WHITE)])
        self._next()

    def _next(self):
        self.left -= 1
        st = self.app.state
        self.m = gacha.pull(self.app.rng, st.team, self.app.data.roster, self.app.data.team["skills"],
                            self.app.profile.seen())
        st.team.append(self.m)
        self.app.profile.mark_pulled(self.m["id"])
        self.rarity = self.m["rarity"]
        self.pattern, self.tier = choose_pattern(self.app.rng, self.rarity)     # tier = 지금 봉투가 내는 빛
        self.char = Character(self.m["look"])
        self.char.expression = "happy"
        self.char.set_pose("cheer")
        self.t = 0.0
        self.hover = 0.0                  # 마우스가 올라간 정도 (0~1, 부드럽게 변함)
        self.hovering = False
        self.touched = False              # 터치 기기: 봉투를 한 번 눌러 둔 상태
        self.morph = None                 # 빛이 바뀌는 중이면 [경과 시간, 남은 '쩍' 시각들]
        self.revealed = False
        self.reveal_t = 0.0
        self.flash = 0.0
        self.shake = 0.0
        self.particles = Particles()
        label = "다음 봉투 열기 " if self.left > 0 else "함께 일해요 "
        self.btn = ui.Button((WIDTH - 372, 624, 330, 60), "", C_ACCENT, size=24,
                             parts=[(label, sticker.WHITE), ("GO!", sticker.YELLOW)])
        sfx.play("pop", 0.6)

    # ---------------------------------------------------------------- 진행
    def _tier_color(self, tier):
        if tier == "SSR":
            return rainbow(self.t * 0.6)
        return GOLD if tier == "SR" else BLUE

    def _color(self):
        if self.revealed:
            return self._tier_color(self.rarity)
        if self.morph:                                    # 낮은 등급의 빛 → 진짜 등급의 빛
            k = clamp01(self.morph[0] / MORPH[self.rarity]["dur"])
            a, b = self._tier_color(self.tier), self._tier_color(self.rarity)
            return tuple(int(lerp(a[i], b[i], k)) for i in range(3))
        return self._tier_color(self.tier)

    def _rainbow_now(self):
        if self.revealed:
            return self.rarity == "SSR"
        if self.morph:
            return self.rarity == "SSR" and self.morph[0] > MORPH["SSR"]["cracks"][-1]
        return self.tier == "SSR"

    def open(self):
        """봉투를 연다. '인 척' 하던 봉투는 먼저 빛이 바뀌는 연출을 거친다."""
        if self.revealed or self.morph or self.t < T_DROP:
            return
        if self.pattern == "fake":
            self.morph = [0.0, list(MORPH[self.rarity]["cracks"])]
            sfx.play("gacha_riser", 0.7)
        else:
            self._reveal()

    def _reveal(self):
        if self.revealed:
            return
        self.revealed = True
        self.morph = None
        self.tier = self.rarity
        self.flash = 1.0
        self.shake = {"R": 0.12, "SR": 0.28, "SSR": 0.5}[self.rarity]
        sfx.play("stamp", 0.7)
        sfx.play({"R": "gacha_r", "SR": "gacha_sr", "SSR": "gacha_ssr"}[self.rarity], 0.8)
        n = {"R": 30, "SR": 70, "SSR": 130}[self.rarity]
        colors = {"R": [BLUE, C_WHITE, (170, 210, 255)],
                  "SR": [GOLD, C_WHITE, (255, 230, 150), C_ACCENT],
                  "SSR": [rainbow(i / 7) for i in range(7)] + [C_WHITE]}[self.rarity]
        for _ in range(max(1, n // 30)):
            self.particles.burst(CENTER[0] + random.uniform(-260, 260), CENTER[1] + random.uniform(-120, 60),
                                 colors, 30, 520, (5, 11))

    def handle_event(self, event):
        click = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        key = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE)
        if not self.revealed:
            on_envelope = click and ENVELOPE.collidepoint(event.pos)
            if on_envelope and self.app.device["touch"] and not self.touched and self.t > T_DROP:
                self.touched = True                           # 첫 터치는 '올려 보기'
            elif key or on_envelope:
                self.open()
            elif click:
                self.touched = False
            return
        if self.reveal_t > 0.9 and (self.btn.clicked(event) or key):
            if self.left > 0:
                self._next()
            else:
                self.app.proceed()

    def update(self, dt):
        self.t += dt
        self.char.update(dt)
        self.particles.update(dt)
        self.btn.update(dt)
        self.shake = max(0.0, self.shake - dt)
        self.flash = max(0.0, self.flash - dt * 2.6)
        if not self.revealed:
            was = self.hovering
            if self.app.device["touch"]:
                self.hovering = self.touched
            else:
                self.hovering = self.t > T_DROP and ENVELOPE.collidepoint(pygame.mouse.get_pos())
            if self.hovering and not was and not self.morph:
                sfx.play("gacha_riser", 0.35)                         # 올리는 순간 두구두구
            self.hover += ((1.0 if self.hovering else 0.0) - self.hover) * min(1.0, dt * 7)
            if self.morph:
                spec = MORPH[self.rarity]
                self.morph[0] += dt
                if self.morph[1] and self.morph[0] >= self.morph[1][0]:       # '쩍!' 빛이 바뀐다
                    self.morph[1].pop(0)
                    self.shake = spec["shake"]
                    self.flash = 0.5 if self.rarity == "SR" else 0.75
                    sfx.play("gacha_crack", 0.8)
                    cols = [self._tier_color(self.rarity), C_WHITE, GOLD]
                    if self.rarity == "SSR":
                        cols += [rainbow(i / 6) for i in range(6)]
                    self.particles.burst(CENTER[0], CENTER[1], cols, spec["burst"], 560, (5, 12))
                if self.morph[0] >= spec["dur"]:
                    self._reveal()
        else:
            self.reveal_t += dt
            rate = {"R": 0, "SR": 0.25, "SSR": 0.8}[self.rarity]          # 별비
            if random.random() < rate:
                col = rainbow(random.random()) if self.rarity == "SSR" else GOLD
                self.particles.items.append([random.uniform(0, WIDTH), -10, random.uniform(-30, 30),
                                             random.uniform(60, 160), 2.2, 2.2, col, random.uniform(4, 8)])

    def _power(self) -> float:
        """빛의 세기 0~1: 평소엔 거의 없고, 마우스를 올리면 새어 나오고, 바뀌는 중엔 최대."""
        if self.revealed:
            return 1.0
        if self.morph:
            return 0.6 + 0.4 * clamp01(self.morph[0] / MORPH[self.rarity]["dur"])
        return self.hover * (0.6 if self.pattern == "gold" else 0.42)

    # ---------------------------------------------------------------- 그리기
    def _draw_rays(self, s, color, strength):
        self.rays.fill((0, 0, 0, 0))
        n = 14
        spin = self.t * (0.9 if self.revealed else 0.35)
        rainbow_on = self._rainbow_now()
        for i in range(n):
            a0 = spin + i * math.tau / n
            a1 = a0 + math.tau / n * 0.5
            col = rainbow(i / n + self.t * 0.2) if rainbow_on else color
            pts = [CENTER, (CENTER[0] + math.cos(a0) * 1100, CENTER[1] + math.sin(a0) * 1100),
                   (CENTER[0] + math.cos(a1) * 1100, CENTER[1] + math.sin(a1) * 1100)]
            pygame.draw.polygon(self.rays, (*col, int(70 * strength)), pts)
        s.blit(self.rays, (0, 0))
        glow = pygame.Surface((720, 720))                                 # 가운데 후광 (빛을 더하는 방식)
        for r, k in ((350, 0.10), (250, 0.14), (150, 0.20)):
            pygame.draw.circle(glow, tuple(int(c * k * strength) for c in color), (360, 360), r)
        s.blit(glow, (CENTER[0] - 360, CENTER[1] - 360), special_flags=pygame.BLEND_RGB_ADD)

    def _draw_envelope(self, s, color, power):
        gold = self.pattern == "gold"
        drop = ease_out_back(self.t / T_DROP, 1.4)
        if self.morph:
            amp = 9 + 9 * clamp01(self.morph[0] / MORPH[self.rarity]["dur"])
        else:
            amp = self.hover * (13 if gold else 5)                    # 황금 봉투는 훨씬 세게 떨린다
        cx = CENTER[0] + math.sin(self.t * 43) * amp
        cy = lerp(-160, CENTER[1], drop) + math.cos(self.t * 37) * amp * 0.5
        k = 1 + 0.04 * math.sin(self.t * 9) * power
        w, h = int(310 * k), int(200 * k)
        r = pygame.Rect(0, 0, w, h)
        r.center = (cx, cy)

        # 틈으로 새어 나오는 빛: 봉투 둘레의 은은한 빛 + 뚜껑 틈에서 위로 뻗는 빛줄기
        if power > 0.02:
            glow = pygame.Surface((w + 80, h + 80), pygame.SRCALPHA)
            for i, a in enumerate((40, 80, 140)):
                pygame.draw.rect(glow, (*color, int(a * power)), glow.get_rect().inflate(-i * 20, -i * 20), border_radius=30)
            s.blit(glow, glow.get_rect(center=r.center))
            beams = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            seam = (r.centerx, r.centery + 10)
            for i in range(5):
                a = -math.pi / 2 + (i - 2) * 0.34 + math.sin(self.t * 3 + i) * 0.06
                length = (150 + 60 * math.sin(self.t * 5 + i * 1.7)) * (0.5 + power)
                tip = (seam[0] + math.cos(a) * length, seam[1] + math.sin(a) * length)
                side = (math.cos(a + math.pi / 2) * 9, math.sin(a + math.pi / 2) * 9)
                col = rainbow(i / 5 + self.t * 0.3) if self._rainbow_now() else color
                pygame.draw.polygon(beams, (*col, int(150 * power)),
                                    [(seam[0] - side[0], seam[1] - side[1]), (seam[0] + side[0], seam[1] + side[1]), tip])
            s.blit(beams, (0, 0))

        body, lower = ((255, 214, 90), (240, 180, 56)) if gold else ((255, 250, 236), (240, 226, 200))
        pygame.draw.rect(s, body, r, border_radius=12)
        pygame.draw.rect(s, lower, (r.x, r.centery, r.w, r.h // 2), border_bottom_left_radius=12,
                         border_bottom_right_radius=12)
        if gold:                                                      # 금박 광택
            shine = pygame.Surface(r.size, pygame.SRCALPHA)
            x = int(((self.t * 0.7) % 1.6 - 0.3) * r.w)
            pygame.draw.polygon(shine, (255, 255, 255, 120), [(x, 0), (x + 36, 0), (x - 24, r.h), (x - 60, r.h)])
            s.blit(shine, r.topleft)
        if power > 0.02:                                              # 뚜껑 틈의 빛
            pygame.draw.lines(s, color, False, [r.topleft, (r.centerx, r.centery + 14), r.topright], 4 + int(8 * power))
        pygame.draw.lines(s, C_INK, False, [r.topleft, (r.centerx, r.centery + 14), r.topright], 4)
        pygame.draw.lines(s, C_INK, False, [r.bottomleft, (r.centerx - 30, r.centery - 8)], 3)
        pygame.draw.lines(s, C_INK, False, [r.bottomright, (r.centerx + 30, r.centery - 8)], 3)
        pygame.draw.rect(s, C_INK, r, 5, border_radius=12)
        seal = (r.centerx, r.centery + 14)
        pygame.draw.circle(s, (226, 76, 76), seal, int(34 * k))
        pygame.draw.circle(s, C_INK, seal, int(34 * k), 4)
        ui.draw_text(s, "인사", seal, int(22 * k), C_WHITE, "heavy", center=True)
        if gold:
            for i in range(4):                                        # 금가루 반짝
                a = self.t * 1.4 + i * 1.6
                p = (r.centerx + math.cos(a) * (r.w * 0.6), r.centery + math.sin(a * 1.3) * (r.h * 0.7))
                size = 4 + 3 * math.sin(self.t * 6 + i)
                pygame.draw.polygon(s, (255, 250, 200), [(p[0], p[1] - size * 2), (p[0] + size, p[1]), (p[0], p[1] + size * 2),
                                                         (p[0] - size, p[1])])
        if power > 0.05:                                              # 빨려 들어오는 반짝이
            for i in range(10):
                p = (self.t * 0.9 + i * 0.37) % 1
                a = i * 2.4 + self.t * 0.6
                rr = lerp(360, 110, p)
                pos = (CENTER[0] + math.cos(a) * rr, CENTER[1] + math.sin(a) * rr * 0.7)
                pygame.draw.circle(s, C_WHITE if i % 2 else color, pos, 2 + int(4 * p * power + 1))

    def _draw_member(self, s, color):
        m = self.m
        k = ease_out_back(self.reveal_t / 0.45, 1.6)
        # 무대
        pygame.draw.ellipse(s, (20, 16, 36), (190, 566, 340, 56))
        pygame.draw.ellipse(s, color, (190, 566, 340, 56), 4)
        self.char.draw(s, (360, 212 + (1 - k) * 80), scale=1.5 * max(0.1, k))
        pygame.draw.ellipse(s, (52, 44, 84), (140, 588, 440, 150))                 # 무대 (발밑 가림)
        pygame.draw.ellipse(s, color, (140, 588, 440, 150), 5)

        # 등급 스티커 쾅 + 별
        kk = ease_out_cubic((self.reveal_t - 0.15) / 0.25)
        if kk > 0:
            col = rainbow(int(self.t * 9) / 12) if self.rarity == "SSR" else color
            img = sticker.sticker_text(gacha.RARITY_TITLE[self.rarity], 84, col, C_INK)
            img = pygame.transform.rotozoom(img, 10, lerp(2.6, 1.0, kk))
            s.blit(img, img.get_rect(center=(170, 132)))
            for i in range(gacha.RARITY_STARS[self.rarity]):
                cx, cy = 96 + i * 50, 212
                pts = [(cx + math.cos(-math.pi / 2 + j * math.pi / 5) * (20 if j % 2 == 0 else 9),
                        cy + math.sin(-math.pi / 2 + j * math.pi / 5) * (20 if j % 2 == 0 else 9)) for j in range(10)]
                pygame.draw.polygon(s, (255, 214, 90), pts)
                pygame.draw.polygon(s, C_INK, pts, 3)

        # 인사 기록 카드
        ck = ease_out_back((self.reveal_t - 0.3) / 0.45, 1.1)
        if ck <= 0.02:
            return
        card = pygame.Rect(0, 0, 590, 430)
        card.topleft = (636 + (1 - ck) * 700, 172)
        props.box(s, card, (255, 250, 236), radius=10, offset=(7, 9))
        pygame.draw.rect(s, color, (card.x + 4, card.y + 4, card.w - 8, 16), border_top_left_radius=8,
                         border_top_right_radius=8)
        pygame.draw.rect(s, C_INK, card, 3, border_radius=10)
        ui.draw_text(s, "새 동료 합류!", (card.x + 30, card.y + 34), 16, (226, 76, 76), True)
        ui.draw_text(s, m["name"], (card.x + 30, card.y + 56), 40, C_INK, "heavy")
        ui.draw_text(s, f"{m['role']} · {m['age']}세", (card.right - 30, card.y + 76), 18, C_INK_SOFT, True,
                     anchor="topright")
        if m.get("new"):                                         # 처음 만난 동료
            img = pygame.transform.rotozoom(sticker.sticker_text("NEW!", 30, sticker.YELLOW), -10, 1.0)
            s.blit(img, img.get_rect(center=(card.right - 44, card.y + 2)))
        pygame.draw.line(s, C_INK, (card.x + 28, card.y + 114), (card.right - 28, card.y + 114), 3)
        y = card.y + 132
        for sk in m["skills"]:
            g = sk["grade"]
            c = (card.x + 58, y + 30)
            pygame.draw.circle(s, gacha.GRADE_COLOR[g], c, 28)
            pygame.draw.circle(s, C_INK, c, 28, 3)
            ui.draw_text(s, g, c, 32, C_WHITE, "heavy", center=True)
            ui.draw_text(s, gacha.SKILLS[sk["type"]]["name"], (card.x + 104, y + 4), 23, C_INK, True)
            ui.draw_text(s, gacha.describe(sk["type"], g), (card.x + 104, y + 36), 16, C_INK_SOFT, True)
            y += 82
        ui.draw_wrapped(s, f"“{m['line']}”", (card.x + 30, card.bottom - 70, card.w - 60, 60), 17, C_INK)

    def draw(self, surf):
        s = self.canvas
        s.fill((34, 28, 56))
        color = self._color()
        power = self._power()
        # 배경 광선: 마우스를 올렸을 땐 은은하게만, 빛이 바뀌거나 열린 뒤에는 환하게
        quiet = not self.revealed and not self.morph
        self._draw_rays(s, color, 0.04 + power * (0.6 if quiet else 0.96))
        if not self.revealed:
            img = sticker.sticker_text("인사 발령!", 64, sticker.YELLOW)
            s.blit(img, img.get_rect(center=(WIDTH // 2, 96 + math.sin(self.t * 3) * 4)))
            self._draw_envelope(s, color, power)
            if not self.morph and self.t > T_DROP:
                if self.app.device["touch"]:
                    hint = "한 번 더 눌러서 열기!" if self.hovering else "봉투를 눌러 보세요"
                else:
                    hint = "클릭해서 열기!" if self.hovering else "봉투에 마우스를 올려 보세요"
                ui.draw_text(s, hint, (WIDTH // 2, HEIGHT - 60), 20, (236, 230, 250), True, center=True)
        else:
            self._draw_member(s, color)
            if self.reveal_t > 0.9:
                self.btn.draw(s)
        self.particles.draw(s)
        if self.flash > 0:
            fl = pygame.Surface((WIDTH, HEIGHT))
            fl.fill((255, 255, 255))
            fl.set_alpha(int(255 * min(1.0, self.flash)))
            s.blit(fl, (0, 0))
        off = (0, 0)
        if self.shake > 0:
            amp = 26 * self.shake
            off = (random.uniform(-amp, amp), random.uniform(-amp, amp))
        surf.fill((34, 28, 56))
        surf.blit(s, off)
