"""심사 데스크 — 메인 게임플레이 화면.

화면 = 하나의 현장:
  위쪽  창구 풍경 (벽·창문·대기 줄·벽시계=게임 시간·일력=일차·게시판=오늘의 실적)
  아래쪽 내 책상 (클립보드에 끼운 공고문, 책상에 놓인 서류 종이들, 스프링 노트 규정집, 결정 풍선)

한 업체당 흐름:  ENTER(걸어 들어옴) → REVIEW(인사 + 서류를 건네받음, 플레이어 심사)
               → STAMP(도장 쾅!) → REACT(업체 반응 + 과장님 메모) → LEAVE(퇴장) → 다음 업체
"""
import math
import random

import pygame

from .. import gacha, paper, props, sfx, sticker, ui
from ..anim import Particles, ease_in_cubic, ease_out_back, lerp
from ..character import Character
from ..config import (C_ACCENT, C_APPROVE, C_BG, C_GOOD, C_INK, C_INK_SOFT, C_REJECT, C_SELECT, C_STICKY,
                      C_WARN, C_WHITE, DOC_TITLES, HEIGHT, WIDTH)
from ..rules import CORRECT, PARTIAL, WRONG, Context, evaluate, judge
from ..state import DayStats
from .base import Scene

ENTER, REVIEW, STAMP, REACT, LEAVE, TIMEUP = "enter", "review", "stamp", "react", "leave", "timeup"
OT_ASK = "ot_ask"                                  # 18시: 야근할지 묻는 중
OT_END = 21 * 60                                   # 야근은 21시까지
T_ENTER, T_STAMP, T_LEAVE, T_REACT_AUTO = 0.75, 0.62, 0.55, 8.0
T_IMPACT = 0.2

# --- 창구 풍경
WALL_H = 250
COUNTER_Y = 250
DESK_Y = 284
WINDOW = pygame.Rect(40, 28, 200, 138)
VIS_X, VIS_Y, VIS_SCALE = 400, 34, 0.92
BUBBLE = pygame.Rect(540, 38, 410, 120)
CORK = pygame.Rect(978, 18, 196, 214)
CLOCK_C, CLOCK_R = (1228, 58), 42
WORK_START, WORK_END = 13 * 60, 18 * 60          # 심사 근무 시간 (분): 오후 1시 ~ 6시
CAL = pygame.Rect(1188, 132, 80, 92)
# --- 책상
CLIP = pygame.Rect(14, 298, 270, 410)
PAGE_SIZE = (216, 338)
NB = pygame.Rect(1004, 294, 262, 0)           # 규정집 노트 (높이는 규정 수에 맞춤)
BTN_OK = pygame.Rect(1012, 596, 246, 48)      # 'GO!' 풍선 (승인)
BTN_NG = pygame.Rect(1012, 656, 246, 48)      # 'NO!' 풍선 (반려)
MEMO = pygame.Rect(0, 0, 540, 214)
TIDY_SLOTS = [(416, 400), (646, 400), (876, 400), (416, 604), (642, 604), (842, 576)]
BELL = (790, 690)                             # 정리 벨 (정리 담당이 있을 때만)
HELPER_X0, HELPER_DX = 852, 58                # 책상 아래쪽에서 빼꼼 내다보는 팀원들


class DeskScene(Scene):
    BGM = "desk"

    def __init__(self, app, notice, bids, tutorial=False):
        super().__init__(app)
        data = app.data
        self.data = data
        self.dlg = data.dialogue
        self.cfg = app.day_cfg()
        self.mods = app.chief["mods"]
        self.notice = notice
        self.queue = list(bids)
        self.total = len(bids)
        self.tutorial = tutorial     # 연습: 시간이 흐르지 않고 기록에도 남지 않는다. 오래 걸리면 힌트가 점점 친절해진다
        self.tut_drag_t = None       # 처음 서류를 끌어 본 시각
        self.tut_flagged = False     # 틀린 서류에 표시를 붙였는가
        self.stats = DayStats(day=0) if tutorial else app.begin_day_stats()
        self.active_rules = data.active_rules(self.cfg["day"])
        self.active_ids = [r["id"] for r in self.active_rules]
        self.show_debarred = "R04" in self.active_ids
        app.profile.mark_rules(self.active_ids)       # 오늘 적용되는 규정은 도감(규정 탭)에 남는다
        self.ctx = Context(notice, {c["biz_no"] for c in data.debarred})

        # 동료(가챠로 합류, 최대 3명) — game/gacha.py
        self.team = app.state.team
        self.perks = gacha.team_perks(self.team)      # 기술 → (숙련도, 수치, 담당 동료)
        self.helper_imgs: dict = {}
        self.helper_say = None        # (동료 번호, 글, 남은 시간)
        self.check_left = self.perks["check"][1]["uses"] if "check" in self.perks else 0
        self.tidy_t = 0.0
        self.tidy_in = None           # 정리 담당이 손대기까지 남은 시간
        self.bell_cd = 0.0            # 정리 벨 재사용 대기
        self.bonus_pts = 0
        self.event = None             # 팀장 돌발 사건 배너: [글, 결과, 좋은 일?, 남은 시간, 나이]
        self.event_in = None          # 다음 사건까지 남은 시간
        self.stolen = False           # 이번 건의 공로를 팀장이 가로챘는가

        self.t = 0.0
        time_bonus = self.perks["time"][1]["bonus"] if "time" in self.perks else 0.0
        self.time_total = float(self.cfg["time_limit"]) * (1 + time_bonus)
        self.time_left = self.time_total
        self.reason: str | None = None
        self.reason_t = 0.0
        self.pending_reject = False
        self.particles = Particles()
        self.shake = 0.0
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.bubble = ui.Typewriter()
        self.memo_text = None
        self.memo_img = None
        self.memo_t = 0.0
        self.toast = None            # (텍스트, 남은 시간)
        self.first_of_day = True
        self.backlog = app.state.backlog          # 어제에서 넘어온 잔업 건수 (오늘 줄의 맨 앞)
        self.overtime = False        # 야근 중인가 (하루에 한 번만)
        self.ot_total = 1.0          # 야근으로 얻은 시간
        self.ot_forced = False       # 팀장이 시킨 야근인가
        self.ot_resume = REVIEW      # 야근을 시작하면 돌아갈 곳 (보던 서류 / 다음 업체)
        self.ot_yes = ui.Button((WIDTH // 2 - 290, 452, 270, 58), "", (120, 110, 190), size=22,
                                parts=[("야근한다 ", sticker.WHITE), ("GO!", sticker.YELLOW)])
        self.ot_no = ui.Button((WIDTH // 2 + 20, 452, 270, 58), "퇴근한다", (84, 180, 110), size=22)
        if self.backlog:
            self.toast = (f"어제 못 끝낸 잔업 {self.backlog}건부터 처리해요", 5.0)
        self.papers: list[paper.Paper] = []
        self.drag = None             # (Paper, dx, dy)
        self.tap = None              # 터치: (누른 위치, 누른 시각) — 끌지 않고 톡 누르면 크게 보기
        self.zoom = None             # 크게 보고 있는 서류 그림
        self.minis: dict[int, pygame.Surface] = {}
        self.chief_face = None

        # 클립보드: 공고문 / (2일차부터) 부정당업자 명단 / 심사 요령
        pages = [("공고", paper.render_notice(notice, PAGE_SIZE), (255, 214, 120))]
        if self.show_debarred:
            pages.append(("명단", paper.render_debarred(data.debarred, PAGE_SIZE), (255, 160, 150)))
        pages.append(("요령", paper.render_howto(PAGE_SIZE, self.show_debarred), (160, 204, 250)))
        self.clip = props.Clipboard(CLIP, pages)

        # 규정집 노트
        y = NB.y + 50
        self.rule_rects: list[tuple[pygame.Rect, dict]] = []
        for r in self.active_rules:
            self.rule_rects.append((pygame.Rect(NB.x + 36, y, NB.w - 48, 24), r))
            y += 26
        self.book = pygame.Rect(NB.x, NB.y, NB.w, y - NB.y + 10)

        # 결정 풍선 — 아이콘의 '숙GO!' 스티커 글씨를 그대로 재활용
        self.btn_ok = ui.Button(BTN_OK, "", C_APPROVE, size=22, float_amp=1.5,
                                parts=[("적격 ", sticker.WHITE), ("GO!", sticker.YELLOW)])
        self.btn_ng = ui.Button(BTN_NG, "", C_REJECT, size=22, float_amp=1.5,
                                parts=[("부적격 ", sticker.WHITE), ("NO!", sticker.YELLOW)])

        self._start_bid()

    # ================================================================ 흐름
    @property
    def current(self):
        return self.queue[0] if self.queue else None

    def _set_phase(self, phase):
        self.phase = phase
        self.phase_t = 0.0

    def _start_bid(self):
        bid = self.current
        self.company = self.data.company_by_biz(bid.form["사업자번호"])
        self.char = Character(self.company["look"])
        self.char.expression = "neutral"
        self.pose_t = 0.0
        self.bubble.voice = self.char.voice
        self.char_x = -150.0
        sfx.play("boing", 0.45)
        self.papers = []
        self.drag = None
        self.tidy_in = None
        self.event_in = None
        self.stolen = False
        self.stamp_approved = None
        self.result = None
        self.reason = None
        self.pending_reject = False
        self.hurry = 0                # 이 업체가 재촉한 단계 (0 없음 / 1 초조 / 2 다급)
        self.bubble.set("")
        self.memo_text = None
        self.memo_img = None
        self._set_phase(ENTER)

    def _hand_over_papers(self):
        """업체가 카운터 너머로 서류를 건넨다 → 책상 위에 한 장씩 착 착 놓인다."""
        bid = self.current
        sheets = [(k, paper.render_doc(k, bid.docs[k])) for k, _ in DOC_TITLES if k in bid.docs]
        sheets += [("extra", paper.render_decoy(d)) for d in bid.extras]
        random.shuffle(sheets)                                   # 건네는 순서는 그때그때 다름
        for i, (key, surf) in enumerate(sheets):
            # 기본: 겹쳐진 채 툭 놓인 더미 → 직접 끌어서 펼친다
            home = (random.uniform(500, 790), random.uniform(410, 560))
            self.papers.append(paper.Paper(key, surf, home, random.uniform(-11, 11),
                                           (VIS_X + 20, COUNTER_Y + 6), i * 0.09))
        if "tidy" in self.perks:                                 # 정리 담당: 숙련도에 따라 즉시 또는 잠시 뒤에
            delay = self.perks["tidy"][1]["delay"]
            if delay <= 0:
                self.tidy(announce=False)
            else:
                self.tidy_in = delay
        self._spot_check(bid)

    def tidy(self, announce=True, by_bell=False):
        """정리 담당 동료: 서류를 종류 순서대로 가지런히 놓는다. 숙련도가 낮으면 가끔 삐뚤게 놓는다."""
        if "tidy" not in self.perks or not self.papers:
            return
        if by_bell and self.bell_cd > 0:
            return
        _, p, _ = self.perks["tidy"]
        order = [k for k, _ in DOC_TITLES] + ["extra"]
        ranked = sorted(self.papers, key=lambda q: order.index(q.key))
        for slot, q in zip(TIDY_SLOTS, ranked):
            q.dragging = False
            if random.random() < p["miss"]:                      # 앗, 실수
                q.home = [slot[0] + random.uniform(-70, 70), slot[1] + random.uniform(-44, 44)]
                q.home_angle = random.uniform(-10, 10)
            else:
                q.home = [slot[0] + random.uniform(-5, 5), slot[1] + random.uniform(-4, 4)]
                q.home_angle = random.uniform(-2.2, 2.2)
            q.tx, q.ty = q.home
            q.hover(False)
        self.papers = ranked
        self.drag = None
        self.bell_cd = p["cool"]
        if announce:
            self.tidy_t = 0.5
            self._say("tidy")
            sfx.play("paper", 0.6)
            sfx.play("click", 0.5)

    def _say(self, skill, seconds=2.4, text=None):
        if skill not in self.perks:
            return
        member = self.perks[skill][2]
        self.helper_say = (self.team.index(member), text or member["say"][skill], seconds)
        sfx.play("pop", 0.45)

    def _fire_event(self):
        """팀장 돌발 사건 (data/chiefs.json 의 events). 천사 팀장은 도와주고, 악덕 팀장은 괴롭힌다."""
        ev = random.choice(self.app.chief["events"])
        kind = ev["type"]
        if kind == "coffee":
            self.time_left = max(5.0, self.time_left - ev["value"])
        elif kind == "snack":
            self.time_left += ev["value"]
        elif kind == "slam":                                     # 책상 쾅 → 서류가 흩어진다
            for q in self.papers:
                if q.dragging:
                    continue
                q.home = [random.uniform(430, 860), random.uniform(390, 600)]
                q.tx, q.ty = q.home
                q.home_angle = random.uniform(-14, 14)
                q.hover(False)
            self.shake = 0.3
            sfx.play("stamp", 0.8)
        elif kind == "neat":                                     # 팀장님이 서류를 펴 준다
            order = [k for k, _ in DOC_TITLES] + ["extra"]
            ranked = sorted(self.papers, key=lambda q: order.index(q.key))
            for slot, q in zip(TIDY_SLOTS, ranked):
                q.dragging = False
                q.home = [slot[0] + random.uniform(-5, 5), slot[1] + random.uniform(-4, 4)]
                q.tx, q.ty = q.home
                q.home_angle = random.uniform(-2.2, 2.2)
                q.hover(False)
            self.papers = ranked
            self.drag = None
            sfx.play("paper", 0.6)
        elif kind == "extra":                                    # 일이 더 쌓인다
            self.queue.append(self.app.generator.make_bid(self.notice, self.active_ids, self.cfg["violation_rate"]))
            self.total += 1
        self.event = [ev["text"], ev["note"], ev.get("good", False), 3.6, 0.0]
        sfx.play("correct" if ev.get("good") else "wrong", 0.5)

    def _chief_face(self) -> pygame.Surface:
        if self.chief_face is None:
            chief = Character(self.app.chief["look"])
            chief.expression = self.app.chief.get("expression", "happy")
            self.chief_face = pygame.transform.smoothscale(chief.render(), (88, 104))
        return self.chief_face

    def _draw_event(self, s):
        """말풍선 아래로 쓱 들어오는 팀장 돌발 사건 배너."""
        if not self.event:
            return
        text, note, good, left, age = self.event
        k = ease_out_back(age / 0.3, 1.3) if left > 0.3 else max(0.0, left / 0.3)
        r = pygame.Rect(0, 0, 400, 72)
        r.topleft = (548 + (1 - k) * 760, 166)
        color = C_GOOD if good else C_REJECT
        props.box(s, r, (255, 250, 236), radius=10, offset=(4, 5))
        pygame.draw.rect(s, color, r, 4, border_radius=10)
        s.set_clip(pygame.Rect(r.x + 6, r.y + 6, 64, 60))
        s.blit(self._chief_face(), (r.x - 4, r.y - 18))
        s.set_clip(None)
        ui.draw_text(s, self.app.chief["name"], (r.x + 78, r.y + 8), 12, C_INK_SOFT, True)
        ui.draw_text(s, text, (r.x + 78, r.y + 25), 16, C_INK, True)
        ui.draw_text(s, note, (r.x + 78, r.y + 48), 13, color, True)

    def _spot_check(self, bid):
        """눈썰미 담당: 위반이 있는 서류에 가끔 '?' 깃발을 붙여 준다 (어디가 틀렸는지는 직접 찾아야 함)."""
        if "spot" not in self.perks or not bid.injected:
            return
        if random.random() >= self.perks["spot"][1]["chance"]:
            return
        key = {"R02": "registration", "R03": "bid_form", "R04": "bid_form", "R05": "guarantee", "R06": "bid_form",
               "R07": "direct_production", "R08": "integrity"}.get(bid.injected)
        if bid.injected == "R09":
            key = next((k for k, d in bid.docs.items() if d.get("상호", bid.company) != bid.company), None)
        target = self._paper(key) if key else None
        if target is None:                                       # 서류가 통째로 빠진 경우
            self._say("spot", 3.2, random.choice(self.data.team["skills"]["spot"]["missing"]))
        else:
            target.set_surface(paper.flag_doc(target.base))
            self._say("spot", 3.0)

    def _paper(self, key):
        return next((p for p in self.papers if p.key == key), None)

    def _greeting(self) -> tuple[str, str]:
        bid, comp, rules = self.current, self.company, self.data.rules_by_id
        if comp["debarred"]:
            return random.choice(comp["greet"]), "sly"
        hint = self.mods["hint"] + (self.data.life["study_hint"] if self.app.state.buff == "study" else 0)   # 어젯밤 공부
        if bid.injected and rules[bid.injected]["hint"] and random.random() < hint:
            return random.choice(rules[bid.injected]["hint"]), "nervous"
        if random.random() < self.mods["herring"]:
            return random.choice(self.dlg["red_herring"]), "nervous"   # 무죄지만 수상한 척
        return random.choice(comp["greet"]), "neutral"

    def _reaction(self, result, approved, violations) -> tuple[str, str]:
        comp, rules = self.company, self.data.rules_by_id
        if approved and result == CORRECT:
            return random.choice(comp["approve"]), "happy"
        if approved:                                  # 위반 서류를 통과시킴
            return random.choice(self.dlg["sneaky_pass"]), "sly"
        if not violations:                            # 정상 서류를 반려함
            return random.choice(self.dlg["wrongly_rejected"]), "sad"
        if comp["debarred"] and "caught" in comp:
            return random.choice(comp["caught"]), "shocked"
        return random.choice(rules[violations[0]]["caught"]), "shocked"

    def decide(self, approved: bool):
        if self.phase != REVIEW or self.current is None:
            return
        if not approved and self.reason is None:
            self.pending_reject = True
            self.toast = (self.dlg["need_reason"], 2.5)
            sfx.play("pop", 0.5)
            return
        if self.drag:
            self.drag[0].drop()
            self.drag = None
        bid = self.current
        violations = evaluate(bid, self.ctx, self.active_ids)
        result = judge(violations, approved, None if approved else self.reason)
        if result == WRONG and self.check_left > 0 and random.random() < self.perks["check"][1]["chance"]:
            self.check_left -= 1                      # 재검토 담당이 오판을 말려 준다
            self.pending_reject = False
            self._say("check", 3.2)
            return
        saved = self.notice.est_price - bid.price if (approved and result == CORRECT) else 0
        self.stats.record(result, saved)
        if result == CORRECT:                                    # 정책 효과: 무엇을 지켜냈는가
            if approved:
                self.stats.fair += 1
            elif violations:
                self.stats.caught[violations[0]] = self.stats.caught.get(violations[0], 0) + 1
        limit = self.app.chief.get("warn_limit", 0)
        if result == WRONG and limit and self.app.state.warnings == limit - 1:
            self.toast = (f"감사 경고 {limit - 1}번! 한 번만 더 받으면 재교육이에요", 4.0)
        self.bonus_pts = 0
        if result == CORRECT and "bonus" in self.perks:   # 칭찬 요정: 정답 보너스
            self.bonus_pts = int(100 * self.perks["bonus"][1]["bonus"])
            self.stats.score += self.bonus_pts
        if result == CORRECT and not self.tutorial and random.random() < self.mods.get("steal", 0):
            self.app.state.stolen += 100 + self.bonus_pts     # (엔딩에서 내 이름으로 돌아온다)
            self.app.state.stolen_n += 1
            self.stats.score -= 100 + self.bonus_pts          # 악덕 팀장: 공로 가로채기
            self.bonus_pts = 0
            self.stolen = True
        self.result = (result, approved, violations)
        self.stamp_approved = approved
        self.pending_reject = False
        self.first_of_day = False
        self.toast = None
        self.event_in = None
        form = self._paper("bid_form")
        if form:                                      # 도장 찍을 입찰서를 맨 위로
            self.papers.remove(form)
            self.papers.append(form)
        for p in self.papers:
            p.hover(False)
        self._set_phase(STAMP)

    def _stamp_point(self):
        form = self._paper("bid_form")
        if not form:
            return (646, 420)
        return (form.x + form.w / 2 - 76, form.y + form.h / 2 - 46)

    def _on_stamp_impact(self):
        result, approved, violations = self.result
        sfx.play("stamp", 0.8)
        self.shake = 0.18
        form = self._paper("bid_form")
        if form:
            form.set_surface(paper.render_doc("bid_form", self.current.docs["bid_form"], mark=approved))
            form.scale = 0.94                          # 눌렸다가 튕김
        cx, cy = self._stamp_point()
        colors = [C_APPROVE, (150, 200, 255)] if approved else [C_REJECT, (255, 170, 160)]
        self.particles.burst(cx, cy, colors + [C_SELECT], n=22)
        line, expr = self._reaction(result, approved, violations)
        self.char.expression = expr
        self.char.set_pose({"happy": "cheer", "shocked": "shock", "sad": "slump", "sly": "hip"}.get(expr, "idle"))
        self.pose_t = 0.0
        self.bubble.set(line)
        head = random.choice(self.app.chief["memo"][result])
        if self.bonus_pts:
            head += f"  (+{self.bonus_pts} 칭찬 보너스)"
        if violations:
            r = self.data.rules_by_id[violations[0]]
            body = f"위반 규정: {r['short']}  [{r['policy']}]\n{r['explain']}"
        else:
            body = "이 서류는 모든 규정을 지킨 정상 입찰이었어."
            if approved:
                body += f"\n예정가격보다 {ui.won(self.notice.est_price - self.current.price)} 아꼈네!"
        if self.stolen:
            head = random.choice(self.app.chief["steal_lines"])
            body += "\n※ 팀장이 공로를 가로챘다! (이번 점수 0점)"
        self.memo_text = (result, head, body)
        self.memo_img = self._render_memo(result, head, body)
        self.memo_t = 0.0
        sfx.play("correct" if result == CORRECT else "wrong", 0.6)
        if result == CORRECT:
            self.particles.burst(WIDTH // 2, 500, [C_SELECT, C_GOOD, C_ACCENT], n=26, speed=320)
            if self.bonus_pts:
                self._say("bonus")

    def _check_hurry(self):
        """마감이 다가오면 서류를 낸 업체가 초조해하며 재촉한다 (업체마다 단계별로 한 번씩)."""
        ratio = self.time_left / (self.ot_total if self.overtime else self.time_total)
        stage = 2 if (ratio < 0.10 or self.time_left < 8) else 1 if (ratio < 0.25 or self.time_left < 20) else 0
        if stage <= self.hurry or self.phase_t < 4.0 or not self.bubble.done or self.time_left <= 0:
            return
        self.hurry = stage
        self.bubble.set(random.choice(self.dlg["hurry_last" if stage == 2 else "hurry"]))
        self.char.expression = "shocked" if stage == 2 else "nervous"
        self.char.set_pose("shock" if stage == 2 else "shrug")
        self.pose_t = 0.0                                        # 계속 초조한 자세로 있는다
        sfx.play("pop", 0.5)

    def _finish_bid(self):
        self.queue.pop(0)
        if self.app.over_limit():                                # 감사 경고가 한도에 닿았다 → BAD 엔딩
            self.app.bad_end()
            return
        if self.tutorial:
            if self.queue:
                self._start_bid()
            else:
                self.app.proceed()                               # 연습 끝 → 진짜 첫 근무(브리핑)로
            return
        if not self.queue:
            self.app.end_day()
        elif self.time_left <= 0:
            self._time_up(resume=ENTER)
        else:
            self._start_bid()

    def _time_up(self, resume=REVIEW):
        self.toast = None
        self.zoom = None
        if self.drag:
            self.drag[0].drop()
            self.drag = None
        sfx.play("bell", 0.7)
        if self.queue and not self.overtime:                     # 일이 남았다 → 야근할까?
            ot = self.data.life["overtime"]
            self.ot_resume = resume
            self.ot_forced = random.random() < ot["force"].get(self.app.chief["id"], 0)
            self.ot_line = ot["forced"] if self.ot_forced else ot["ask"][self.app.chief["id"]]
            self._set_phase(OT_ASK)
            return
        self._set_phase(TIMEUP)

    def choose_overtime(self, stay: bool):
        """18시의 선택. 남으면 21시까지 시간이 더 생기지만 그날 저녁 스트레스·건강에 값을 치른다."""
        if self.phase != OT_ASK:
            return
        if not stay and not self.ot_forced:
            self._set_phase(TIMEUP)
            return
        self.overtime = True
        self.stats.overtime = True
        self.ot_total = max(30.0, self.time_total * self.data.life["overtime"]["time"])
        self.time_left = self.ot_total
        self.toast = ("야근 시작! 21시까지 조금만 더 힘내요", 3.5)
        sfx.play("pop", 0.6)
        if self.ot_resume == REVIEW:
            self._set_phase(REVIEW)
            self.phase_t = 5.0                                   # 보던 서류로 바로 돌아간다
        else:
            self._start_bid()

    def _begin_leave(self):
        for i, p in enumerate(self.papers):
            p.fly_out(i * 0.04)
        self.bubble.set("")
        self._set_phase(LEAVE)
        sfx.play("paper", 0.5)

    # ================================================================ 입력
    def handle_event(self, event):
        if self.phase == OT_ASK:
            if self.phase_t < 0.5:
                return
            if self.ot_yes.clicked(event):
                self.choose_overtime(True)
            elif not self.ot_forced and self.ot_no.clicked(event):
                self.choose_overtime(False)
            return
        if self.zoom is not None:                               # 크게 보는 중: 아무 곳이나 누르면 닫힘
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                self.zoom = None
                sfx.play("paper", 0.35)
            return
        if self.phase == REACT:
            if (event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN) and self.phase_t > 0.5:
                if not self.bubble.done:
                    self.bubble.skip()
                else:
                    self._begin_leave()
            return

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag:
            paper_ = self.drag[0]
            paper_.drop()
            if self.tut_drag_t is None:
                self.tut_drag_t = self.t
            self.drag = None
            if self.app.device["touch"] and self.tap and self.phase == REVIEW:
                (x0, y0), t0 = self.tap
                if self.t - t0 < 0.35 and abs(event.pos[0] - x0) + abs(event.pos[1] - y0) < 14:
                    self._zoom_in(paper_)
            self.tap = None
            sfx.play("paper", 0.35)
            return
        if event.type == pygame.MOUSEMOTION and self.drag:
            p, dx, dy = self.drag
            p.tx, p.ty = event.pos[0] + dx, event.pos[1] + dy
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.phase == REVIEW:
                for p in reversed(self.papers):                 # 맨 위 종이부터
                    if p.hit(event.pos):
                        self.papers.remove(p)
                        self.papers.append(p)
                        p.grab()
                        self.drag = (p, p.x - event.pos[0], p.y - event.pos[1])
                        self.tap = (event.pos, self.t)
                        sfx.play("paper", 0.35)
                        return
                if "tidy" in self.perks and pygame.Rect(BELL[0] - 36, BELL[1] - 34, 72, 62).collidepoint(event.pos):
                    self.tidy(by_bell=True)
                    return
                if self.btn_ok.clicked(event):
                    self.decide(True)
                    return
                if self.btn_ng.clicked(event):
                    self.decide(False)
                    return
                for rect, rule in self.rule_rects:
                    if rect.inflate(40, 2).collidepoint(event.pos):
                        sfx.play("click", 0.4)
                        self.reason = None if self.reason == rule["id"] else rule["id"]
                        self.reason_t = 0.0
                        if self.pending_reject and self.reason:
                            self.decide(False)      # '부적격'을 먼저 눌렀다면 사유 선택 즉시 도장
                        return
            if self.clip.click(event.pos):
                return
            if event.pos[1] < COUNTER_Y:
                self.bubble.skip()
        elif event.type == pygame.KEYDOWN and self.phase == REVIEW:
            if event.key == pygame.K_a:
                self.btn_ok.press()
                self.decide(True)
            elif event.key == pygame.K_r:
                self.btn_ng.press()
                self.decide(False)
            elif event.key == pygame.K_SPACE:
                self.tidy(by_bell=True)

    def _zoom_in(self, p):
        """작은 화면용: 서류 한 장을 화면 가득 크게 보여 준다."""
        bw, bh = p.base.get_size()
        k = min((HEIGHT - 90) / bh, (WIDTH - 200) / bw)
        self.zoom = pygame.transform.smoothscale(p.base, (int(bw * k), int(bh * k)))

    def _draw_zoom(self, s):
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 20, 150))
        s.blit(dim, (0, 0))
        r = self.zoom.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 14))
        ui.shadow(s, r, 6, 70, (8, 10))
        s.blit(self.zoom, r)
        ui.pill(s, (WIDTH // 2 - 130, HEIGHT - 44, 260, 32), "아무 곳이나 누르면 닫혀요", (255, 250, 236), C_INK, 15)

    # ================================================================ 업데이트
    def update(self, dt):
        self.t += dt
        self.phase_t += dt
        self.reason_t += dt
        self.ot_yes.update(dt)
        self.ot_no.update(dt)
        self.char.update(dt)
        self.bubble.update(dt)
        self.particles.update(dt)
        self.clip.update(dt)
        self.shake = max(0.0, self.shake - dt)
        self.memo_t += dt
        self.tidy_t = max(0.0, self.tidy_t - dt)
        if self.pose_t > 0:                                      # 인사 손짓이 끝나면 팔을 내린다
            self.pose_t -= dt
            if self.pose_t <= 0 and self.phase == REVIEW:
                self.char.set_pose("idle")
        self.bell_cd = max(0.0, self.bell_cd - dt)
        if self.event:
            self.event[3] -= dt
            self.event[4] += dt
            if self.event[3] <= 0:
                self.event = None
        if self.tidy_in is not None and self.phase == REVIEW:
            self.tidy_in -= dt
            if self.tidy_in <= 0:
                self.tidy_in = None
                self.tidy()
        if self.helper_say:
            idx, text, left = self.helper_say
            self.helper_say = (idx, text, left - dt) if left - dt > 0 else None
        if self.toast:
            self.toast = (self.toast[0], self.toast[1] - dt) if self.toast[1] - dt > 0 else None
        for btn in (self.btn_ok, self.btn_ng):
            btn.enabled = self.phase == REVIEW
            btn.update(dt)
        self.btn_ng.pulse = self.pending_reject

        # 종이: 마우스 아래 맨 위 한 장만 살짝 들림
        mouse = pygame.mouse.get_pos()
        top = None
        if self.phase == REVIEW and not self.drag:
            top = next((p for p in reversed(self.papers) if p.hit(mouse)), None)
        for p in self.papers:
            if self.phase == REVIEW:
                p.hover(p is top)
            p.update(dt)

        if self.phase == ENTER:
            self.char_x = lerp(-150, VIS_X, ease_out_back(self.phase_t / T_ENTER, 1.2))
            if self.phase_t >= T_ENTER:
                line, expr = self._greeting()
                self.char.expression = expr
                self.char.set_pose("shrug" if expr == "nervous" else "wave")
                self.pose_t = 1.5
                self.bubble.set(line)
                self._hand_over_papers()
                sfx.play("pop", 0.5)
                sfx.play("paper", 0.5)
                if not self.tutorial and self.app.chief.get("events") and random.random() < self.mods.get("event", 0):
                    self.event_in = random.uniform(2.0, 5.5)
                self._set_phase(REVIEW)
        elif self.phase == REVIEW:
            if not self.tutorial:
                self.time_left -= dt
                self._check_hurry()
            else:
                self._tutorial_hint()
            if self.event_in is not None:
                self.event_in -= dt
                if self.event_in <= 0:
                    self.event_in = None
                    self._fire_event()
            if self.time_left <= 0:
                self._time_up()
        elif self.phase == STAMP:
            if self.phase_t >= T_IMPACT and self.memo_text is None:
                self._on_stamp_impact()
            if self.phase_t >= T_STAMP:
                self._set_phase(REACT)
        elif self.phase == REACT:
            if self.phase_t >= T_REACT_AUTO:
                self._begin_leave()
        elif self.phase == LEAVE:
            self.char_x = lerp(VIS_X, -180, ease_in_cubic(self.phase_t / T_LEAVE))
            if self.phase_t >= T_LEAVE:
                self._finish_bid()
        elif self.phase == TIMEUP:
            if self.phase_t >= 2.8:
                self.app.end_day(len(self.queue))

    # ================================================================ 그리기: 창구 풍경
    def _time_ratio(self):
        if self.overtime:
            return 1.0                                             # 야근 중: 창밖은 이미 저녁
        return max(0.0, 1 - max(0.0, self.time_left) / self.time_total)

    def _draw_overtime_ask(self, s):
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 20, 140))
        s.blit(dim, (0, 0))
        k = ease_out_back(self.phase_t / 0.35, 1.4)
        panel = pygame.Rect(0, 0, 680, 330)
        panel.center = (WIDTH // 2, HEIGHT // 2 + 10 + int((1 - min(1.0, k)) * 40))
        props.box(s, panel, (255, 250, 236), radius=16, offset=(7, 9))
        head = sticker.sticker_text("야근 확정!" if self.ot_forced else "18:00 퇴근 시간!", 44, sticker.YELLOW)
        s.blit(head, head.get_rect(center=(panel.centerx, panel.y + 6)))
        ui.draw_text(s, self.app.chief["name"], (panel.x + 40, panel.y + 52), 15, C_ACCENT, True)
        ui.draw_wrapped(s, f"“{self.ot_line}”", (panel.x + 40, panel.y + 76, panel.w - 80, 60), 19, C_INK, True)
        ot = self.data.life["overtime"]
        ui.pill(s, (panel.x + 40, panel.y + 150, panel.w - 80, 34),
                f"남은 업무 {len(self.queue)}건  ·  야근하면 스트레스 +{ot['stress']}, 건강 {ot['health']}, 수당 +{ot['pay'][str(self.app.state.level)]}만",
                (255, 236, 150), C_INK, 15)
        self.ot_yes.rect.y = self.ot_no.rect.y = panel.y + 216
        if self.ot_forced:
            self.ot_yes.rect.centerx = panel.centerx
        else:
            self.ot_yes.rect.x = panel.centerx - 290
            self.ot_no.draw(s)
        self.ot_yes.draw(s)

    def _mini(self, bid) -> pygame.Surface:
        if id(bid) not in self.minis:
            comp = self.data.company_by_biz(bid.form["사업자번호"])
            self.minis[id(bid)] = pygame.transform.smoothscale(Character(comp["look"]).render(), (92, 109))
        return self.minis[id(bid)]

    def _draw_lobby(self, s):
        ratio = self._time_ratio()
        props.draw_wall(s, WALL_H, self.t, ratio)
        props.draw_window(s, WINDOW, self.t, ratio)

        # 대기 줄 (뒤에 서 있는 다음 업체들)
        waiting = self.queue[1:]
        for i, bid in reversed(list(enumerate(waiting[:3]))):
            img = self._mini(bid)
            x = 262 - i * 72
            y = 150 + math.sin(self.t * 2.2 + i * 1.7) * 2
            s.blit(img, img.get_rect(midtop=(x, y)))
        if len(waiting) > 3:
            ui.pill(s, (20, 198, 62, 26), f"+{len(waiting) - 3}", C_WHITE, C_INK, 14)

        # 게시판: 오늘의 실적
        st = self.app.state
        done = self.total - len(self.queue) + (1 if self.phase in (REACT, LEAVE) else 0)
        lv = st.level_info(self.data.levels)
        lines = [(f"{lv['title']} 주무관", C_INK, True),
                 (f"처리   {min(done, self.total)} / {self.total}" + (f"  (잔업 {self.backlog})" if self.backlog else ""),
                  C_INK, False),
                 (f"점수   {st.total_score:,}", C_INK, False),
                 (f"아낀 세금 {st.total_saved // 10000:,}만원", (40, 130, 70), True),
                 (f"통장 {st.money}만 · 스트레스 {st.stress}", C_REJECT if st.stress >= 70 else C_INK_SOFT, True)]
        props.draw_corkboard(s, CORK, lines, st.warnings)

        # 전자시계 = 지금 시각. 오전에 접수가 마감된 서류를 오후에 심사한다 (13:00 → 18:00 퇴근), 일력 = 일차
        if self.overtime:                                         # 야근: 18:00 → 21:00
            ot_ratio = max(0.0, 1 - max(0.0, self.time_left) / self.ot_total)
            alarm = 1.0 if (ot_ratio > 0.85 and self.phase != TIMEUP) else 0.0
            props.draw_digital_clock(s, CLOCK_C, WORK_END + ot_ratio * (OT_END - WORK_END), alarm, self.t, "야근 중 21:00")
        else:
            alarm = 1.0 if (ratio > 0.85 and self.phase not in (TIMEUP, OT_ASK)) else 0.0
            props.draw_digital_clock(s, CLOCK_C, WORK_START + ratio * (WORK_END - WORK_START), alarm, self.t, "퇴근 18:00")
        month, day = self.cfg["date"][5:7], self.cfg["date"][8:10]
        props.draw_calendar(s, CAL, int(month), int(day), f"{self.cfg['day']}일차")

        # 방문 업체
        if self.phase in (ENTER, LEAVE):                         # 뒤뚱뒤뚱 걸어 들어오고 나간다
            step = math.sin(self.phase_t * 17)
            lean, hop = step * 7 * (1 if self.phase == ENTER else -1), -abs(step) * 9
        else:
            lean, hop = math.sin(self.t * 1.6) * 1.6, 0
        self.char.draw(s, (int(self.char_x), VIS_Y + hop), scale=VIS_SCALE, angle=lean)

        props.draw_counter(s, COUNTER_Y)
        props.draw_plant(s, 934, COUNTER_Y + 4, self.t)
        if self.phase not in (ENTER, LEAVE):                     # 카운터에 올려 둔 명함
            k = ease_out_back(min(1.0, self.phase_t / 0.3)) if self.phase == REVIEW else 1.0
            card = pygame.Rect(0, 0, int(286 * k), 32)
            card.midbottom = (VIS_X, COUNTER_Y + 13)
            props.box(s, card, C_WHITE, radius=5, offset=(3, 4))
            if k > 0.9:
                ui.draw_text(s, f"{self.company['name']}  ·  대표 {self.company['ceo']}", card.center, 15,
                             C_INK, True, center=True)
        ui.speech_bubble(s, BUBBLE, self.bubble, tail=(int(self.char_x) + 96, 124))
        self._draw_event(s)

    # ================================================================ 그리기: 책상
    def _draw_rulebook(self, s):
        b = self.book
        pulse = self.pending_reject and int(self.t * 6) % 2 == 0
        props.draw_notebook(s, b, f"심사 규정집  ·  {self.cfg['day']}일차", C_REJECT if pulse else None)
        mouse = pygame.mouse.get_pos()
        hover = None
        for i, (rect, rule) in enumerate(self.rule_rects):
            selected = self.reason == rule["id"]
            hot = rect.inflate(40, 2).collidepoint(mouse) and self.phase == REVIEW and not self.drag
            if hot:
                hover = rule
            if selected:                                         # 형광펜
                k = min(1.0, self.reason_t / 0.18)
                pygame.draw.rect(s, (255, 236, 130), (rect.x - 4, rect.y + 3, int((rect.w + 4) * k), rect.h - 4),
                                 border_radius=5)
            ui.draw_text(s, f"{i + 1}.", (rect.x - 22, rect.y + 3), 14, C_INK_SOFT, True)
            ui.draw_text(s, rule["short"], (rect.x, rect.y + 3), 14, C_INK, selected or hot)
            if hot and not selected:
                pygame.draw.line(s, C_INK_SOFT, (rect.x, rect.bottom - 2), (rect.right - 30, rect.bottom - 2), 2)
            if rule["day"] == self.cfg["day"]:                   # 새 규정 스티커
                c = (rect.right - 10, rect.centery)
                pygame.draw.circle(s, C_ACCENT, c, 9)
                pygame.draw.circle(s, C_INK, c, 9, 2)
                ui.draw_text(s, "N", c, 11, C_WHITE, True, center=True)
            if selected:
                props.pen_circle(s, pygame.Rect(rect.x - 8, rect.y + 1, rect.w - 14, rect.h - 2),
                                 self.reason_t / 0.3)
        return hover

    def _draw_rule_tip(self, s, rule):
        lines = ui.wrap(rule["text"], 14, 270)
        tip = pygame.Rect(0, 0, 296, 22 + len(lines) * 20)
        my = pygame.mouse.get_pos()[1]
        tip.topright = (self.book.x - 14, max(DESK_Y + 8, min(my - 16, HEIGHT - tip.h - 10)))
        props.box(s, tip, (255, 250, 232), radius=8)
        tri = [(tip.right - 2, tip.y + 14), (tip.right + 12, tip.y + 22), (tip.right - 2, tip.y + 30)]
        pygame.draw.polygon(s, (255, 250, 232), tri)
        pygame.draw.lines(s, C_INK, False, tri, 3)
        ui.draw_wrapped(s, rule["text"], (tip.x + 13, tip.y + 11, 270, tip.h), 14)

    def _draw_stamp_anim(self, s):
        """도장이 위에서 내려와 쾅 찍고 다시 올라간다."""
        if self.phase != STAMP:
            return
        t = self.phase_t
        px, py = self._stamp_point()
        if t < T_IMPACT:
            off, squash = lerp(-300, 0, ease_in_cubic(t / T_IMPACT)), 1.0
        elif t < T_IMPACT + 0.12:
            off, squash = 0, 0.8
        else:
            off, squash = lerp(0, -380, ease_in_cubic((t - T_IMPACT - 0.12) / 0.3)), 1.0
        color = C_APPROVE if self.stamp_approved else C_REJECT
        props.draw_stamp_tool(s, (px, py + 20 + off), color, squash)

    def _render_memo(self, result, head, body) -> pygame.Surface:
        """팀장님 포스트잇 (살짝 비뚤게 붙인다)."""
        w, h = MEMO.size
        m = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(m, C_STICKY, (2, 2, w - 4, h - 4), border_radius=6)
        pygame.draw.rect(m, (240, 214, 110), (4, h - 26, w - 8, 22), border_bottom_left_radius=6,
                         border_bottom_right_radius=6)
        pygame.draw.polygon(m, (226, 196, 90), [(w - 34, h - 3), (w - 3, h - 34), (w - 3, h - 3)])
        pygame.draw.rect(m, C_INK, (2, 2, w - 4, h - 4), 3, border_radius=6)
        m.set_clip(pygame.Rect(14, 12, 76, 62))
        m.blit(self._chief_face(), (8, -18))
        m.set_clip(None)
        color = {CORRECT: C_GOOD, PARTIAL: C_WARN, WRONG: C_REJECT}[result]
        icon = {CORRECT: "O", PARTIAL: "△", WRONG: "X"}[result]
        pygame.draw.circle(m, color, (84, 62), 15)
        pygame.draw.circle(m, C_INK, (84, 62), 15, 2)
        ui.draw_text(m, icon, (84, 62), 17, C_WHITE, True, center=True)
        ui.draw_text(m, "팀장님 메모", (110, 16), 13, C_INK_SOFT, True)
        ui.draw_text(m, head + ("  (감사 경고 +1)" if result == WRONG else ""), (110, 36), 19, color, True)
        ui.draw_wrapped(m, body, (24, 86, w - 48, h), 16)
        return pygame.transform.rotozoom(m, -1.6, 1.0)

    def _draw_memo(self, s):
        if not self.memo_img:
            return
        if self.phase == LEAVE:
            k = 1 - ease_in_cubic(self.phase_t / 0.3)
        else:
            k = ease_out_back(self.memo_t / 0.35, 1.4)
        if k <= 0.02:
            return
        img = self.memo_img if k >= 0.999 else pygame.transform.rotozoom(self.memo_img, (1 - k) * 8, max(0.05, k))
        r = img.get_rect(center=(640, 596))
        s.blit(props.silhouette_shadow(img, 60), r.move(6, 8))
        s.blit(img, r)
        if k >= 0.999:
            props.tape(s, (r.centerx, r.y + 12), 3)
            if self.phase == REACT and self.phase_t > 0.5:
                a = (math.sin(self.phase_t * 5) + 1) / 2
                ui.draw_text(s, "아무 곳이나 눌러 다음 업체 →", (r.right - 34, r.bottom - 40), 14,
                             tuple(int(lerp(160, 74, a)) for _ in range(3)), True, anchor="topright")

    # ================================================================ 튜토리얼 안내
    def _tut_step(self):
        """지금 보여 줄 안내 단계. 1번 업체 = 정상(적격), 2번 업체 = 사업자번호 불일치(부적격)."""
        if self.phase in (REACT, STAMP):
            return "memo"
        if self.phase != REVIEW:
            return None
        first = self.total - len(self.queue) == 0
        if first:
            if self.tut_drag_t is None and self.phase_t < 14:
                return "drag"
            if self.tut_drag_t is not None and self.t - self.tut_drag_t < 7:
                return "compare"
            return "approve"
        if self.reason == "R02":
            return "reject"
        if self.phase_t < 10:
            return "find"
        if self.phase_t < 20:
            return "find_hint"
        return "reason"

    def _tutorial_hint(self):
        """오래 걸리면: 틀린 서류 두 장에 '?' 표시를 붙여 준다."""
        if self.tut_flagged or self._tut_step() not in ("find_hint", "reason"):
            return
        self.tut_flagged = True
        for key in ("registration", "bid_form"):
            p = self._paper(key)
            if p:
                p.set_surface(paper.flag_doc(p.base))
        sfx.play("pop", 0.5)

    def _glow(self, s, rect, pad=8):
        a = (math.sin(self.t * 6) + 1) / 2
        r = pygame.Rect(rect).inflate(pad * 2 + int(a * 8), pad * 2 + int(a * 8))
        pygame.draw.rect(s, (255, 214, 60), r, 6, border_radius=14)
        pygame.draw.rect(s, C_ACCENT, r.inflate(6, 6), 3, border_radius=16)

    def _arrow(self, s, tip):
        y = tip[1] - 14 - abs(math.sin(self.t * 5)) * 14
        pts = [(tip[0] - 20, y - 30), (tip[0] + 20, y - 30), (tip[0], y)]
        pygame.draw.polygon(s, C_ACCENT, pts)
        pygame.draw.polygon(s, C_INK, pts, 4)

    def _draw_tutorial(self, s):
        tag = sticker.sticker_text("튜토리얼", 40, sticker.YELLOW)
        tag = pygame.transform.rotozoom(tag, -4, 1.0)
        s.blit(tag, tag.get_rect(center=(410, 40)))
        step = self._tut_step()
        rule = next((r for r, ru in self.rule_rects if ru["id"] == "R02"), None)
        pair = [p for p in (self._paper("registration"), self._paper("bid_form")) if p]
        text = {
            "drag": "1. 책상 위 서류를 끌어서 겹치지 않게 펼쳐 보세요",
            "compare": "2. 왼쪽 공고문, 오른쪽 규정집과 서류 내용을 비교해요",
            "approve": "3. 이 업체는 문제가 없어요. '적격 GO!'를 눌러요",
            "find": "4. 이번 업체는 어딘가 이상해요. 서류끼리 비교해 보세요",
            "find_hint": "힌트! '?'가 붙은 두 서류의 사업자번호를 비교해 보세요",
            "reason": "5. 사업자번호가 달라요! 규정집의 '사업자번호 일치'를 눌러요",
            "reject": "6. 사유를 골랐으니 '부적격 NO!'를 눌러요",
            "memo": "팀장님 메모를 읽고, 화면을 누르면 다음으로 넘어가요",
        }.get(step)
        if not text:
            return
        if step == "drag" and self.papers:
            self._arrow(s, (int(self.papers[-1].x), int(self.papers[-1].y) - 70))
        elif step == "compare":
            self._glow(s, CLIP, 2)
            self._glow(s, self.book, 2)
        elif step == "approve":
            self._glow(s, self.btn_ok.rect)
            self._arrow(s, self.btn_ok.rect.midtop)
        elif step in ("find_hint", "reason"):
            for p in pair:                                          # 틀린 곳이 있는 서류 두 장
                self._glow(s, p._img.get_rect(center=(int(p.x), int(p.y - p.lift))), 0)
            if step == "reason" and rule:
                self._glow(s, rule, 4)
                self._arrow(s, rule.midtop)
        elif step == "reject":
            self._glow(s, self.btn_ng.rect)
            self._arrow(s, self.btn_ng.rect.midtop)
        w = ui.fonts.get(19, True).size(text)[0] + 56
        r = pygame.Rect(0, 0, w, 46)
        r.center = (WIDTH // 2 + 20, 292)
        props.box(s, r, (255, 236, 150), radius=23, offset=(4, 5))
        ui.draw_text(s, text, r.center, 19, C_INK, True, center=True)

    def _draw_tip(self, s):
        if self.tutorial:
            return
        if not (self.cfg["day"] == 1 and self.first_of_day and self.phase == REVIEW and self.phase_t > 0.9):
            return
        r = pygame.Rect(770, 508, 214, 158)
        props.box(s, r, C_STICKY, radius=4, shade=(240, 214, 110), offset=(4, 5))
        props.tape(s, (r.centerx, r.y + 2), -4)
        ui.draw_wrapped(s, self.dlg["tip_day1"], (r.x + 14, r.y + 20, r.w - 28, r.h), 14)

    def _helper_img(self, idx, dim=False) -> pygame.Surface:
        key = (idx, dim)
        if key not in self.helper_imgs:
            ch = Character(self.team[idx]["look"])
            ch.expression = "neutral" if dim else "happy"
            img = pygame.transform.smoothscale(ch.render(), (80, 95))
            if dim:
                img.set_alpha(150)
            self.helper_imgs[key] = img
        return self.helper_imgs[key]

    def _draw_helpers(self, s):
        """책상 아래쪽에서 빼꼼 내다보는 동료들 + 정리 벨."""
        tidy_m = self.perks["tidy"][2] if "tidy" in self.perks else None
        check_m = self.perks["check"][2] if "check" in self.perks else None
        for i, m in enumerate(self.team):
            used = m is check_m and self.check_left <= 0
            img = self._helper_img(i, used)
            hop = -abs(math.sin(self.tidy_t * 18)) * 16 if (m is tidy_m and self.tidy_t > 0) else 0
            x = HELPER_X0 + i * HELPER_DX
            y = HEIGHT - 72 + math.sin(self.t * 2 + i * 1.3) * 2 + hop
            s.blit(img, img.get_rect(midtop=(x, y)))
            tag = pygame.Rect(0, 0, 30, 15)                      # 등급 꼬리표
            tag.midbottom = (x, HEIGHT - 2)
            pygame.draw.rect(s, gacha.RARITY_COLOR[m["rarity"]], tag, border_radius=6)
            pygame.draw.rect(s, C_INK, tag, 2, border_radius=6)
            ui.draw_text(s, gacha.RARITY_LABEL[m["rarity"]], tag.center, 10, C_WHITE, True, center=True)
            if used:
                ui.draw_text(s, "z z", (x + 22, HEIGHT - 88), 13, C_INK_SOFT, True)
        if tidy_m:
            props.draw_bell(s, BELL, self.tidy_t > 0.3)
            label = f"{math.ceil(self.bell_cd)}초" if self.bell_cd > 0.5 else "정리"
            ui.draw_text(s, label, (BELL[0], BELL[1] + 24), 12, C_INK_SOFT if self.bell_cd > 0.5 else C_INK, True,
                         anchor="midtop")

    def _draw_helper_say(self, s):
        if not self.helper_say:
            return
        idx, text, _ = self.helper_say
        hx = HELPER_X0 + idx * HELPER_DX
        w = ui.fonts.get(15, True).size(text)[0] + 36
        r = pygame.Rect(0, 0, w, 42)
        r.midbottom = (max(r.w // 2 + 300, min(WIDTH - 290 - r.w // 2, hx)), HEIGHT - 94)
        props.box(s, r, C_WHITE, radius=20, offset=(3, 4))
        tri = [(hx - 9, r.bottom - 2), (hx, r.bottom + 12), (hx + 9, r.bottom - 2)]
        pygame.draw.polygon(s, C_WHITE, tri)
        pygame.draw.lines(s, C_INK, False, tri, 3)
        ui.draw_text(s, text, r.center, 15, C_INK, True, center=True)

    def _draw_toast(self, s):
        if self.phase == TIMEUP:
            k = ease_out_back(self.phase_t / 0.4, 2.2)
            img = sticker.sticker_text("야근 끝! 퇴근!" if self.overtime else "퇴근 시간!", 96, sticker.YELLOW)
            img = pygame.transform.rotozoom(img, -6 + math.sin(self.t * 5) * 2, max(0.05, k))
            s.blit(img, img.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
            ui.pill(s, (WIDTH // 2 - 190, HEIGHT // 2 + 56, 380, 40), self.dlg["time_up"], C_WHITE, C_INK, 18)
            left = len(self.queue)
            if left:                                             # 못 끝낸 일의 행방
                last = self.app.state.day_index >= len(self.data.days) - 1
                carry = 0 if last else min(left, self.data.life["backlog_max"])
                msg = f"남은 업무 {left}건"
                msg += f"  →  {carry}건은 내일 잔업" if carry else "  →  다른 창구로 이관"
                if carry and left > carry:
                    msg += f", {left - carry}건은 기한이 촉박해 이관"
                ui.pill(s, (WIDTH // 2 - 260, HEIGHT // 2 + 106, 520, 36), msg, (255, 236, 150), C_INK, 16)
            return
        if not self.toast:
            return
        text, _ = self.toast
        w = ui.fonts.get(15, True).size(text)[0] + 40
        r = pygame.Rect(0, 0, w, 44)
        r.midright = (self.book.x - 12, self.book.y + 30)
        props.box(s, r, C_INK, radius=22, offset=(3, 4))
        ui.draw_text(s, text, r.center, 15, C_WHITE, True, center=True)

    def draw(self, surf):
        s = self.canvas
        self._draw_lobby(s)
        props.draw_desk(s, DESK_Y)
        props.draw_mug(s, (960, 540), self.t)
        props.draw_pen(s, (346, 694), -18)
        self.clip.draw(s)
        hover_rule = self._draw_rulebook(s)
        self.btn_ok.draw(s)
        self.btn_ng.draw(s)
        self._draw_tip(s)
        self._draw_helpers(s)
        for p in self.papers:
            p.draw(s)
        self._draw_helper_say(s)
        self._draw_stamp_anim(s)
        self._draw_memo(s)
        if hover_rule:
            self._draw_rule_tip(s, hover_rule)
        self.particles.draw(s)
        self._draw_toast(s)
        if self.tutorial:
            self._draw_tutorial(s)
        if self.phase == OT_ASK:
            self._draw_overtime_ask(s)
        if self.zoom is not None:
            self._draw_zoom(s)
        off = (0, 0)
        if self.shake > 0:
            amp = 6 * (self.shake / 0.18)
            off = (random.uniform(-amp, amp), random.uniform(-amp, amp))
        surf.fill(C_BG)
        surf.blit(s, off)
