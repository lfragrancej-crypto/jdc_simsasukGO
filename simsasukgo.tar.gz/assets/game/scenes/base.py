class Scene:
    BGM: str | None = "title"     # 이 장면에서 흐를 배경음악 (bgm.py)
    HOME = "title"                # Esc·메뉴 버튼으로 돌아갈 곳: 'title'(심사숙GO 타이틀) / 'hub'(묶음 첫 화면) / None(종료)

    def __init__(self, app):
        self.app = app   # main.App — data, state, generator, change_scene() 보유

    def handle_event(self, event):
        pass

    def update(self, dt: float):
        pass

    def draw(self, surf):
        pass
