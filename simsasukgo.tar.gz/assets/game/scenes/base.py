class Scene:
    BGM: str | None = "title"     # 이 장면에서 흐를 배경음악 (bgm.py)

    def __init__(self, app):
        self.app = app   # main.App — data, state, generator, change_scene() 보유

    def handle_event(self, event):
        pass

    def update(self, dt: float):
        pass

    def draw(self, surf):
        pass
