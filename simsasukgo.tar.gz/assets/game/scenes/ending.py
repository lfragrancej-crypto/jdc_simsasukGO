import pygame

from .. import props, sfx, ui
from ..anim import Particles, ease_out_back, ease_out_cubic, lerp
from ..character import Character
from ..config import C_ACCENT, C_GOOD, C_INK, C_INK_SOFT, C_REJECT, C_SELECT, WIDTH
from .base import Scene
from .life import life_comment, life_grade

GRADE_COLOR = {"S": (230, 160, 30), "A": (72, 142, 232), "B": C_GOOD, "C": C_REJECT, "BAD": (150, 60, 70)}
WALL_H = 250
GOLD = (214, 170, 80)


class EndingScene(Scene):
    """엔딩 — 과장님이 건네는 근무 평가서 위에 등급 도장이 쾅."""

    def __init__(self, app, bad=False):
        super().__init__(app)
        self.btn = ui.Button((930, 610, 280, 58), "타이틀로", C_ACCENT, size=22)
        self.bad = bad                 # 감사 경고 누적으로 중간에 끝난 경우 (클리어로 치지 않는다)
        self.grade, self.title = app.state.grade()
        self.chief = Character(app.chief["look"])
        if bad:
            self.grade, self.title = "BAD", "감사 경고 누적 — 근무 중단"
            self.chief.expression = app.chief.get("expression", "neutral") if app.chief["id"] == "hell" else "sad"
            self.chief.set_pose("hip" if app.chief["id"] == "hell" else "slump")
        else:
            app.profile.mark_clear(app.chief["id"], [m["id"] for m in app.state.team], self.grade)
            self.chief.expression = "happy" if self.grade in "SA" else "nervous"
            self.chief.set_pose("cheer" if self.grade in "SA" else "hip")
        self.tw = ui.Typewriter(app.chief["ending"][self.grade], 32, self.chief.voice)
        self.particles = Particles()
        self.t = 0.0
        self.landed = False
        self.shake = 0.0

    def handle_event(self, event):
        if self.btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self.app.to_title()

    def update(self, dt):
        self.t += dt
        self.chief.update(dt)
        self.btn.update(dt)
        self.particles.update(dt)
        self.shake = max(0.0, self.shake - dt)
        if self.t > 1.4:
            self.tw.update(dt)
        if not self.landed and self.t > 0.95:
            self.landed = True
            self.shake = 0.18
            sfx.play("stamp", 0.9)
            sfx.play("wrong" if self.bad else "fanfare", 0.7)
            if self.grade in "SA":
                for x in (300, 640, 980):
                    self.particles.burst(x, 300, [C_SELECT, C_ACCENT, C_GOOD, (120, 170, 240)], 30, 420)

    def draw(self, surf):
        props.draw_wall(surf, WALL_H, self.t, 0.3)
        props.draw_window(surf, (40, 28, 200, 138), self.t, 0.3)
        props.draw_clock(surf, (1214, 84), 46, 1080, 0, self.t)
        self.chief.draw(surf, (250, 30), scale=0.95)
        props.draw_counter(surf, WALL_H)
        props.draw_plant(surf, 1110, WALL_H + 4, self.t)
        props.draw_desk(surf, WALL_H + 34)
        props.draw_mug(surf, (1060, 470), self.t)
        ui.speech_bubble(surf, (410, 44, 730, 124), self.tw, tail=(352, 128), name=self.app.chief["name"], size=19)

        # 근무 평가서 (살짝 떨어져 내려와 책상에 놓인다)
        st = self.app.state
        k = ease_out_back(self.t / 0.5, 1.1)
        dy = int((1 - k) * 460) + (int(self.shake * 40) if self.shake else 0)
        cert = pygame.Rect(150, 306 + dy, 700, 392)
        props.box(surf, cert, (255, 250, 236), radius=6, offset=(7, 9))
        pygame.draw.rect(surf, GOLD, cert.inflate(-18, -18), 4, border_radius=4)
        pygame.draw.rect(surf, GOLD, cert.inflate(-32, -32), 2, border_radius=3)
        for cx, cy in ((cert.x + 20, cert.y + 20), (cert.right - 20, cert.y + 20),
                       (cert.x + 20, cert.bottom - 20), (cert.right - 20, cert.bottom - 20)):
            pygame.draw.circle(surf, GOLD, (cx, cy), 9)
            pygame.draw.circle(surf, C_INK, (cx, cy), 9, 2)

        ui.draw_text(surf, "심사관 근무 평가서", (cert.x + 50, cert.y + 40), 30, C_INK, "heavy")
        pygame.draw.line(surf, C_INK, (cert.x + 50, cert.y + 86), (cert.x + 400, cert.y + 86), 3)
        rows = [("정확도", f"{st.accuracy * 100:.0f}%", C_INK), ("총점", f"{st.total_score:,}점", C_INK),
                ("지켜낸 세금", f"{st.total_saved:,}원", C_GOOD), ("감사 경고", f"{st.warnings}회", C_INK),
                ("최종 직급", st.level_info(self.app.data.levels)["title"], C_INK)]
        if self.bad:
            rows[4] = ("감사 경고", f"{st.warnings}회 (한도 초과)", C_REJECT)
        rows[3] = ("통장 · 건강 · 관계", f"{st.money:,}만 · {st.health} · {st.bond}", C_INK)
        for i, (label, value, color) in enumerate(rows):
            y = cert.y + 104 + i * 44
            ui.draw_text(surf, label, (cert.x + 54, y + 3), 20, C_INK_SOFT, True)
            ui.draw_text(surf, value, (cert.x + 400, y), 24, color, True, anchor="topright")
            pygame.draw.line(surf, (236, 224, 204), (cert.x + 50, y + 36), (cert.x + 400, y + 36), 2)
        life = life_grade(st)                                     # 일과 별도로 매기는 삶의 성적
        ui.draw_text(surf, f"삶의 균형  {life}", (cert.x + 54, cert.bottom - 66), 16, C_REJECT if life == "C" else C_INK,
                     "heavy")
        ui.draw_text(surf, life_comment(self.grade, life), (cert.x + 54, cert.bottom - 42), 13, C_INK_SOFT, True)

        # 등급 도장 쾅
        sc = (cert.right - 150, cert.centery - 6)
        if self.t > 0.6:
            kk = ease_out_cubic((self.t - 0.6) / 0.35)
            color = GRADE_COLOR[self.grade]
            r = int(lerp(230, 104, kk))
            stamp = pygame.Surface((r * 2 + 10, r * 2 + 10), pygame.SRCALPHA)
            c = (r + 5, r + 5)
            pygame.draw.circle(stamp, (*color, 235), c, r, max(5, r // 9))
            pygame.draw.circle(stamp, (*color, 150), c, int(r * 0.8), max(2, r // 30))
            ui.draw_text(stamp, self.grade, c, int(r * (1.15 if len(self.grade) == 1 else 0.62)), color, "heavy",
                         center=True)
            stamp = pygame.transform.rotate(stamp, 10)
            surf.blit(stamp, stamp.get_rect(center=sc))
        if self.t > 1.1:
            kk = ease_out_back((self.t - 1.1) / 0.4)
            ui.draw_text(surf, self.title, (sc[0], cert.bottom - 62 + (1 - kk) * 20), 17, C_INK, True, center=True)
            ui.draw_text(surf, f"조달청 계약심사과  {self.app.chief['name']}", (sc[0], cert.bottom - 36), 13, C_INK_SOFT,
                         True, center=True)

        if self.t > 2.2:                                     # 이 게임이 전하고 싶은 한마디
            msg = "실수는 누구나 합니다. 다시 도전해 보세요" if self.bad else self.app.data.life["message"]
            ui.pill(surf, (896, 548, 348, 38), msg, (255, 250, 236), C_INK, 16)
        self.particles.draw(surf)
        self.btn.draw(surf)
