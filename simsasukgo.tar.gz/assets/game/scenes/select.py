"""난이도 선택 = 함께 일할 팀장 고르기.

세 팀장이 카운터 뒤에 서 있고, 머리 위 간판에 난이도가 걸려 있다.
  쌩신입(천사 같은 팀장) / 숙련된조교(원칙주의 팀장) / 지옥에서내가돌아왔다(악덕 팀장)
"""
import math

import pygame

from .. import props, sfx, sticker, ui
from ..character import Character, hex2rgb
from ..config import C_INK, C_INK_SOFT, C_WHITE, HEIGHT, WIDTH
from .base import Scene

WALL_H = 400
COLS = (232, 640, 1048)


class SelectScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.chiefs = app.data.chiefs
        self.chars = [Character(c["look"]) for c in self.chiefs]
        for ch, c in zip(self.chars, self.chiefs):
            ch.expression = c.get("expression", "neutral")
        self.hover = [0.0] * len(self.chiefs)
        self.t = 0.0
        self.last_hover = -1

    def _col_at(self, pos):
        for i, x in enumerate(COLS):
            if abs(pos[0] - x) < 190 and 20 < pos[1] < HEIGHT - 46:
                return i
        return -1

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            i = self._col_at(event.pos)
            if i >= 0:
                sfx.play("stamp", 0.7)
                self.app.new_game(self.chiefs[i])
        elif event.type == pygame.KEYDOWN and event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
            self.app.new_game(self.chiefs[event.key - pygame.K_1])
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_BACKSPACE:
            self.app.to_title()

    def update(self, dt):
        self.t += dt
        cur = self._col_at(pygame.mouse.get_pos())
        if cur != self.last_hover and cur >= 0:
            sfx.play("pop", 0.35)
        self.last_hover = cur
        for i, ch in enumerate(self.chars):
            ch.update(dt)
            target = 1.0 if i == cur else 0.0
            ch.set_pose("cheer" if i == cur else "idle")
            self.hover[i] += (target - self.hover[i]) * min(1.0, dt * 12)

    def draw(self, surf):
        props.draw_wall(surf, WALL_H, self.t, 0.0)
        title = sticker.sticker_text("난이도 선택", 28, sticker.YELLOW)
        ask = sticker.sticker_text("어느 팀장님과 일할까요?", 24, sticker.WHITE)

        for i, (c, ch, x) in enumerate(zip(self.chiefs, self.chars, COLS)):
            h = self.hover[i]
            color = hex2rgb(c["color"])
            # 천장에 매단 난이도 간판
            sign = pygame.Rect(0, 0, 336, 96)
            sign.midtop = (x, 50 + math.sin(self.t * 1.6 + i) * 3 - h * 4)
            for dx in (-120, 120):
                pygame.draw.line(surf, C_INK, (x + dx, 0), (x + dx, sign.y + 4), 4)
            props.box(surf, sign, color, radius=14, shade=tuple(max(0, v - 36) for v in color), offset=(5, 7))
            label = sticker.fit(sticker.sticker_text(c["difficulty"], 38, sticker.WHITE), sign.w - 30)
            surf.blit(label, label.get_rect(center=(sign.centerx, sign.y + 38)))
            for k in range(3):                                   # 난이도 별
                cx, cy = sign.centerx - 26 + k * 26, sign.bottom - 18
                pts = [(cx + math.cos(-math.pi / 2 + j * math.pi / 5) * (10 if j % 2 == 0 else 4.5),
                        cy + math.sin(-math.pi / 2 + j * math.pi / 5) * (10 if j % 2 == 0 else 4.5)) for j in range(10)]
                pygame.draw.polygon(surf, (255, 222, 90) if k < c["stars"] else tuple(max(0, v - 50) for v in color), pts)
                pygame.draw.polygon(surf, C_INK, pts, 2)
            # 팀장
            ch.draw(surf, (x, 204 - h * 12 - abs(math.sin(self.t * 9)) * 6 * h), scale=1.04 + 0.08 * h)

        props.draw_counter(surf, WALL_H)
        props.draw_desk(surf, WALL_H + 34)

        for i, (c, x) in enumerate(zip(self.chiefs, COLS)):
            h = self.hover[i]
            color = hex2rgb(c["color"])
            plate = pygame.Rect(0, 0, 200, 36)                   # 명패
            plate.midbottom = (x, WALL_H + 15)
            props.box(surf, plate, (255, 214, 120), radius=5, offset=(3, 4))
            ui.draw_text(surf, c["name"], plate.center, 17, C_INK, True, center=True)
            # 책상 위 소개 쪽지
            card = pygame.Rect(0, 0, 350, 214)
            card.midtop = (x, 456 - h * 10)
            props.box(surf, card, (255, 253, 247), radius=8, offset=(5 + int(h * 3), 7 + int(h * 5)))
            if h > 0.05:
                pygame.draw.rect(surf, color, card, 5, border_radius=8)
            props.tape(surf, (card.centerx, card.y + 1), (-3, 2, -2)[i], 50, 16)
            y = ui.draw_wrapped(surf, f"“{c['tagline']}”", (card.x + 22, card.y + 22, card.w - 44, 60), 17, C_INK, True)
            pygame.draw.line(surf, (236, 224, 204), (card.x + 20, y + 4), (card.right - 20, y + 4), 2)
            y += 14
            for line in c["desc"]:
                pygame.draw.circle(surf, color, (card.x + 30, y + 10), 5)
                ui.draw_text(surf, line, (card.x + 44, y), 15, C_INK)
                y += 26
            ui.draw_text(surf, f"{i + 1} 키", (card.right - 16, card.bottom - 26), 12, C_INK_SOFT, True, anchor="topright")

        surf.blit(title, title.get_rect(center=(WIDTH // 2, 24)))
        surf.blit(ask, ask.get_rect(center=(WIDTH // 2, 178)))
        ui.draw_text(surf, "팀장님을 클릭하면 근무가 시작됩니다   ·   Backspace: 타이틀로", (WIDTH // 2, HEIGHT - 22), 14,
                     (120, 80, 50), True, center=True)
