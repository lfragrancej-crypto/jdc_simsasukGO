"""다함께! 조달 한바퀴 — 묶음 첫 화면. 어느 자리에서 조달을 겪을지 고른다.

  사는 쪽(공무원)  심사숙GO! 조달청      파는 쪽(제조업체)  납품하GO! 우리 공장      쓰는 쪽(수요기관)  준비 중
세 자리가 같은 닷새, 같은 공고(data/world.json)로 이어져 조달의 한 바퀴를 이룬다.
"""
import math
import os
import random

import pygame

from .. import collection, device, sfx, ui
from ..anim import Particles
from ..character import Character
from ..config import HEIGHT, WIDTH
from ..factory.iso import BLUE, GREEN, INK, ORANGE, PAPER, SOFT, TEAL, Btn, View, card, chip, shade
from .base import Scene

DOORS = [
    {"id": "review", "role": "사는 쪽 · 조달청 심사관", "title": "심사숙GO! 조달청", "color": (255, 138, 92),
     "desc": "쏟아지는 입찰 서류에서 틀린 곳을 찾아 적격·부적격을 가린다."},
    {"id": "factory", "role": "파는 쪽 · 제조업체 사장", "title": "납품하GO! 우리 공장", "color": TEAL,
     "desc": "공고를 읽고, 값을 정하고, 서류를 꾸려 낙찰받은 뒤 납기 안에 만들어 납품한다."},
    {"id": "agency", "role": "쓰는 쪽 · 수요기관 담당자", "title": "요청하GO! 우리 학교", "color": (140, 110, 200),
     "desc": "현장에 필요한 물건을 색종이 블록으로 칠판에 채운다. 예산 안에서, 떳떳한 방법으로."},
]


class HubScene(Scene):
    BGM = "hub"
    HOME = None

    def __init__(self, app):
        super().__init__(app)
        self.t = 0.0
        self.web = app.device["web"]
        d = app.data
        looks = [d.dialogue["hero"]["look"], d.factory["company"]["look"], d.agency["levels"][1]["look"]]
        self.cast = [Character(look) for look in looks]
        for ch, pose in zip(self.cast, ("wave", "hip", "idle")):
            ch.expression = "happy"
            ch.set_pose(pose)
        self.mascots = [Character(d.dialogue["mascots"][k]["look"]) for k in ("narmi", "dali")]
        for ch in self.mascots:
            ch.expression = "happy"
            ch.set_pose("cheer")
        self.toast = 0.0
        self._ring = None
        self.hidden_checked = False
        self.album_done = collection.complete(app)      # 도감을 모두 채웠는가
        self.album_pct = collection.percent(app)
        self.fire_btn = pygame.Rect(40, 186, 60, 60)        # 폭죽 단추 (도감을 다 채우면 열린다)
        self.fireworks = Particles()
        self.fire_queue = []                                # 곧 터질 폭죽들 (남은 시간, x, y)
        self.party = 0.0                                    # 축하 글귀가 떠 있는 시간
        self.lock_toast = 0.0
        self.album_btn = Btn((WIDTH - 196, 192, 160, 44), "도감 보기", GREEN, 16)

    def _door(self, i):
        return pygame.Rect(70 + i * 390, 250, 360, 380)

    def enter(self, i: int):
        door = DOORS[i]
        if door["id"] == "review":
            self.app.to_title()
        elif door["id"] == "factory":
            self.app.to_factory()
        elif door["id"] == "agency":
            self.app.to_agency()
        else:
            self.toast = 2.0
            sfx.play("wrong", 0.4)
            return
        sfx.play("pop", 0.6)

    def firework(self, n=3, spread=0.0):
        """폭죽을 n발 쏜다 (spread 초에 걸쳐 여기저기서)."""
        for k in range(n):
            self.fire_queue.append([spread * k / max(1, n), random.uniform(140, WIDTH - 140), random.uniform(90, 330)])

    def celebrate(self):
        """도감 완성 축하: 팡파레와 함께 폭죽이 연달아 터진다."""
        self.party = 5.0
        self.firework(12, 3.0)
        sfx.play("fanfare", 0.7)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.fire_btn.collidepoint(event.pos):
            if self.album_done:                                  # 누를 때마다 폭죽
                self.firework(3, 0.25)
            else:
                self.lock_toast = 2.4
                sfx.play("wrong", 0.3)
            return
        if self.album_btn.clicked(event):
            self.app.to_album("mates", "hub")
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(DOORS)):
                if self._door(i).collidepoint(event.pos):
                    self.enter(i)
                    return
        elif event.type == pygame.KEYDOWN and pygame.K_1 <= event.key <= pygame.K_3:
            self.enter(event.key - pygame.K_1)

    def update(self, dt):
        self.t += dt
        self.toast = max(0.0, self.toast - dt)
        self.album_btn.update(dt)
        if self.t > 0.5 and not self.hidden_checked and self.app.fade_next is None:    # 세 편을 다 끝냈으면 히든 엔딩이 저절로
            self.hidden_checked = True
            from . import hidden
            tier = None if os.environ.get("JDC_NO_HIDDEN") else hidden.pending(self.app)
            if tier:
                self.app.change(lambda: hidden.HiddenEndingScene(self.app, tier))
            elif self.album_done:                                # 도감을 다 채웠으면 돌아올 때마다 축하
                self.celebrate()
        self.party = max(0.0, self.party - dt)
        self.lock_toast = max(0.0, self.lock_toast - dt)
        for f in self.fire_queue:
            f[0] -= dt
        for f in [f for f in self.fire_queue if f[0] <= 0]:
            self.fire_queue.remove(f)
            base = random.random()
            colors = []
            for k in range(4):                                   # 폭죽마다 비슷한 계열의 색
                c = pygame.Color(0)
                c.hsva = ((base * 360 + k * 18) % 360, 70, 100, 100)
                colors.append((c.r, c.g, c.b))
            self.fireworks.burst(f[1], f[2], colors + [(255, 255, 255)], 46, 430, (4, 10))
            sfx.play("pop", 0.5)
        self.fireworks.update(dt)
        for ch in self.cast + self.mascots:
            ch.update(dt)

    def _background(self):
        if self._ring is None:
            s = pygame.Surface((WIDTH, HEIGHT))
            g = pygame.Surface((1, 2))
            g.set_at((0, 0), (255, 246, 230))
            g.set_at((0, 1), (222, 238, 240))
            s.blit(pygame.transform.smoothscale(g, (WIDTH, HEIGHT)), (0, 0))
            v = View((WIDTH // 2, 420))                            # 바닥의 큰 고리 = 조달 한 바퀴
            for k in range(72):
                a = k / 72 * math.tau
                gx, gy = math.cos(a) * 9.5, math.sin(a) * 9.5
                v.tile(s, gx - 0.3, gy - 0.3, (255, 226, 190) if k % 2 else (206, 232, 236), 0.6, 0.6)
            self._ring = s.convert()
        return self._ring

    def draw(self, surf):
        surf.blit(self._background(), (0, 0))
        # 제목
        ui.draw_text(surf, "사는 쪽 · 파는 쪽 · 쓰는 쪽이 이어 달리는", (WIDTH // 2, 44), 17, SOFT, True, center=True)
        f = ui.fonts.get(70, "heavy")
        a, b = f.render("다함께! ", True, ORANGE), f.render("조달 한바퀴", True, INK)
        x = WIDTH // 2 - (a.get_width() + b.get_width()) // 2
        bounce = abs(math.sin(self.t * 3)) * -8
        surf.blit(f.render("다함께! ", True, shade(ORANGE, 0.75)), (x + 3, 72 + bounce + 5))
        surf.blit(a, (x, 72 + bounce))
        surf.blit(f.render("조달 한바퀴", True, (206, 220, 226)), (x + a.get_width() + 3, 77))
        surf.blit(b, (x + a.get_width(), 72))
        chip(surf, (WIDTH // 2 - 150, 176, 300, 34), "어느 자리에서 일해 볼까요?", INK, size=16)
        self.mascots[0].draw(surf, (120, 58), scale=0.5)
        self.mascots[1].draw(surf, (WIDTH - 120, 58), scale=0.5)

        self.album_btn.draw(surf)
        mouse = pygame.mouse.get_pos()
        prof = self.app.profile.data
        cleared = [bool(prof.get("chiefs")), bool(prof.get("factory", {}).get("clear")), bool(prof.get("agency", {}).get("clear"))]
        for i, d in enumerate(DOORS):
            r = self._door(i)
            ready = True
            hot = ready and r.collidepoint(mouse)
            r = r.move(0, -8 if hot else 0)
            card(surf, r, 26)
            col = d["color"]
            head = pygame.Rect(r.x, r.y, r.w, 170)
            pygame.draw.rect(surf, shade(col, 1.0), head, border_top_left_radius=26, border_top_right_radius=26)
            pygame.draw.circle(surf, shade(col, 1.12), (head.centerx, head.bottom - 20), 92)
            clip = surf.get_clip()
            surf.set_clip(head)
            self.cast[i].draw(surf, (head.centerx, head.y + 34), scale=0.62)
            surf.set_clip(clip)
            if not ready:
                veil = pygame.Surface(head.size, pygame.SRCALPHA)
                pygame.draw.rect(veil, (236, 240, 242, 170), veil.get_rect(), border_top_left_radius=26, border_top_right_radius=26)
                surf.blit(veil, head)
                chip(surf, (head.centerx - 54, head.centery - 16, 108, 32), "준비 중", (120, 128, 134), size=15)
            chip(surf, (r.x + 20, r.y + 186, ui.fonts.get(13, True).size(d["role"])[0] + 24, 26), d["role"], col if ready else (150, 158, 164))
            ui.draw_text(surf, d["title"], (r.x + 20, r.y + 222), 25, INK if ready else (140, 148, 154), "heavy")
            ui.draw_wrapped(surf, d["desc"], (r.x + 20, r.y + 262, r.w - 40, 70), 14, SOFT, True)
            if ready:
                chip(surf, (r.right - 124, r.bottom - 50, 104, 34), "시작하기", col, size=15)
                ui.draw_text(surf, f"{i + 1}", (r.x + 22, r.bottom - 44), 20, (206, 214, 218), "heavy")
            if cleared[i]:
                chip(surf, (r.x + 50, r.bottom - 46, 76, 26), "클리어", GREEN, size=12)
        done = sum(cleared)
        ui.draw_text(surf, f"조달 한 바퀴  {done} / 3", (WIDTH // 2, 664), 15, INK, True, center=True)
        for i in range(3):
            pygame.draw.circle(surf, GREEN if cleared[i] else (206, 214, 218), (WIDTH // 2 - 26 + i * 26, 690), 8)
        ui.pps_logo(surf, (24, HEIGHT - 52), 32)
        ui.draw_text(surf, "2026 조달청 AI 게임·콘텐츠 공모전 출품작", (WIDTH - 20, HEIGHT - 26), 13, SOFT, True, anchor="midright")
        if self.web:
            ui.draw_text(surf, device.label(self.app.device), (WIDTH - 20, 20), 12, SOFT, True, anchor="topright")
        if self.toast > 0:
            chip(surf, (WIDTH // 2 - 170, 214, 340, 32), "이 자리는 아직 준비 중이에요!", BLUE, size=14)
        # ---- 폭죽 단추: 도감을 다 채우면 열린다
        r = self.fire_btn
        on = self.album_done
        hot = r.collidepoint(pygame.mouse.get_pos())
        pygame.draw.circle(surf, shade(ORANGE, 0.72) if on else (170, 178, 184), (r.centerx, r.centery + 4), 30)
        pygame.draw.circle(surf, (shade(ORANGE, 1.08) if hot else ORANGE) if on else (206, 214, 218), r.center, 30)
        for k in range(8):                                       # 폭죽 그림: 사방으로 퍼지는 불꽃
            a = k * math.tau / 8 + (self.t * 0.8 if on else 0)
            x0, y0 = r.centerx + math.cos(a) * 8, r.centery + math.sin(a) * 8
            x1, y1 = r.centerx + math.cos(a) * 20, r.centery + math.sin(a) * 20
            pygame.draw.line(surf, PAPER, (x0, y0), (x1, y1), 4)
            pygame.draw.circle(surf, (255, 236, 150) if on else PAPER, (int(x1), int(y1)), 3)
        pygame.draw.circle(surf, PAPER, r.center, 5)
        ui.draw_text(surf, "폭죽!" if on else f"도감 {self.album_pct}%", (r.centerx, r.bottom + 12), 12, INK if on else SOFT, True,
                     center=True)
        if self.lock_toast > 0:
            chip(surf, (r.x, r.bottom + 28, 330, 30), f"도감을 모두 채우면 폭죽이 열려요 (지금 {self.album_pct}%)", INK, size=13)
        self.fireworks.draw(surf)
        if self.party > 0:                                       # 도감 완성 축하 글귀
            k = min(1.0, (5.0 - self.party) / 0.3)
            w = int(560 * k)
            if w > 60:
                chip(surf, (WIDTH // 2 - w // 2, 206, w, 40), "도감 완성! 세 자리의 모든 것을 다 모았어요" if k >= 1 else "", ORANGE, size=18)
