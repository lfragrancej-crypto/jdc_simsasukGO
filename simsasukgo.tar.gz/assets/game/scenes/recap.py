import pygame

from .. import props, sfx, sticker, ui
from ..anim import ease_out_back
from ..config import C_ACCENT, C_GOOD, C_INK, C_INK_SOFT, WIDTH
from .base import Scene

# 2026년 조달청 업무 방향 (업무보고 보도 기준): 공공조달로 기술선도 · 균형 · 공정 성장을 뒷받침
FOOTER = "조달청은 공공조달로 기술선도 · 균형 · 공정 성장을 뒷받침합니다"


class RecapScene(Scene):
    """엔딩 직전 — 조달 수첩 한 장. 닷새 동안 지킨 정책과 그 결과를 정리해 보여 준다 (교육 요약)."""

    def __init__(self, app):
        super().__init__(app)
        self.t = 0.0
        self.rows = []
        for day, stats in zip(app.data.days, app.state.history):
            pol = day.get("policy")
            if not pol:
                continue
            caught = sum(stats.caught.values())
            done = f"위반 {caught}건을 걸러내고, 성실한 업체 {stats.fair}곳에 기회를 줬어요"
            self.rows.append((day["day"], pol["name"], pol["why"], done))
        self.btn = ui.Button((WIDTH - 340, 646, 300, 56), "", C_ACCENT, size=22,
                             parts=[("최종 평가 ", sticker.WHITE), ("GO!", sticker.YELLOW)])
        sfx.play("paper", 0.6)

    def done(self):
        self.app.proceed()

    def handle_event(self, event):
        if self.t > 0.8 and (self.btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN)):
            self.done()

    def update(self, dt):
        self.t += dt
        self.btn.update(dt)

    def draw(self, surf):
        props.draw_desk(surf, 0)
        page = pygame.Rect(120, 16, 1040, 618)
        for o in (8, 4):
            pygame.draw.rect(surf, (238, 230, 212), page.move(o, o), border_radius=6)
            pygame.draw.rect(surf, C_INK, page.move(o, o), 2, border_radius=6)
        pygame.draw.rect(surf, (255, 253, 247), page, border_radius=6)
        pygame.draw.rect(surf, C_INK, page, 3, border_radius=6)
        for i in range(9):                                        # 스프링
            y = page.y + 40 + i * 66
            pygame.draw.circle(surf, (120, 124, 140), (page.x + 4, y), 9, 4)
        ui.draw_text(surf, "조달 수첩 — 이번 주에 배운 것", (page.x + 60, page.y + 18), 28, C_INK, "heavy")
        pygame.draw.line(surf, C_INK, (page.x + 56, page.y + 60), (page.right - 40, page.y + 60), 3)
        for i, (day, name, why, done) in enumerate(self.rows):
            k = ease_out_back((self.t - 0.3 - i * 0.18) / 0.35, 1.2)
            if k <= 0:
                continue
            y = page.y + 72 + i * 106 + int((1 - min(1.0, k)) * 16)
            tag = pygame.Rect(page.x + 56, y + 4, 64, 28)
            ui.pill(surf, tag, f"{day}일차", C_ACCENT, (255, 255, 255), 14)
            ui.draw_text(surf, name, (tag.right + 12, y + 2), 21, C_INK, True)
            ui.draw_wrapped(surf, why, (page.x + 60, y + 36, page.w - 110, 44), 15, C_INK_SOFT, True)
            pygame.draw.circle(surf, C_GOOD, (page.x + 68, y + 86), 5)
            ui.draw_text(surf, done, (page.x + 82, y + 75), 15, (40, 130, 70), True)
            pygame.draw.line(surf, (224, 232, 240), (page.x + 56, y + 102), (page.right - 40, y + 102), 2)
        ui.draw_text(surf, FOOTER, (40, 664), 17, (120, 80, 50), True)
        self.btn.draw(surf)
