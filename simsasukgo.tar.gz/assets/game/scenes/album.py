"""도감 — 인재(동료+직원 사원증) / 난이도(팀장+사장) / 추억(이벤트 CG) / 규정 / 우리 공장(납품 기록).

묶음(다함께! 조달 한바퀴)의 모든 편이 이 도감 하나를 같이 쓴다. 어디서 열었는지(back)에 따라 그곳으로 돌아간다.

인재  심사숙GO의 동료와 납품하GO의 직원을 한데 모았다 (카드마다 어느 편인지 태그).
      만난 적 없는 사람은 검은 ??? 카드. 사원증을 누르면 능력과 성격 1~3 이 보인다.
      성격1 = 뽑으면 공개 / 성격2 = 함께 엔딩 / 성격3 = 함께 '지옥' 난이도 엔딩
난이도  심사숙GO의 팀장 3명 + 납품하GO의 사장 3단계. 그 난이도를 클리어하면 공개.
추억  게임 중에 본 CG. 눌러서 다시 본다 — 동료 자리에는 해금한 동료가 무작위로 선다.
"""
import math
import random

import pygame

from .. import cg, gacha, props, sfx, sticker, ui
from ..anim import ease_out_back
from ..character import Character, hex2rgb
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_REJECT, C_WHITE, HEIGHT, WIDTH
from .base import Scene
from .cgscene import CGScene

TABS = [("mates", "인재"), ("chiefs", "난이도"), ("cgs", "추억"), ("rules", "규정"), ("factory", "우리 공장")]
GAME_TAG = {"review": ("심사숙GO", (255, 138, 92)), "factory": ("납품하GO", (72, 170, 196)),
            "agency": ("요청하GO", (140, 110, 200))}                 # 어느 편의 기록인가
MINI = 0.66              # 인재 카드는 사원증을 줄여서 한 화면에 40장
BACK_HOME = {"title": "title", "hub": "hub", "factory": "factory_title", "agency": "agency_title"}
SWIPE = 70                # 이만큼 옆으로 밀면 한 장 넘어간다
CARD_W, CARD_H = 172, 184
GRID_X, GRID_Y, GRID_DX, GRID_DY = 62, 112, 196, 198
THUMB_W, THUMB_H = 124, 70
LOCK_TEXT = {2: "이 동료와 함께 엔딩을 보면 공개됩니다.", 3: "이 동료와 함께 '지옥에서내가돌아왔다'를 클리어하면 공개됩니다."}


def _face(look, size, expr="happy", dark=False) -> pygame.Surface:
    ch = Character(look, seed=3)
    ch.expression = expr
    ch.blink = 0
    img = pygame.transform.smoothscale(ch.render(), size)
    if dark:                                                    # 미해금: 그림자 실루엣만
        img = pygame.mask.from_surface(img, 40).to_surface(setcolor=(34, 30, 44, 255), unsetcolor=(0, 0, 0, 0))
    return img


def _id_card(person, unlocked: bool) -> pygame.Surface:
    """공무원증 모양 카드 (앨범 한 칸)."""
    s = pygame.Surface((CARD_W, CARD_H), pygame.SRCALPHA)
    r = pygame.Rect(2, 2, CARD_W - 4, CARD_H - 4)
    base = (255, 253, 247) if unlocked else (58, 52, 70)
    pygame.draw.rect(s, base, r, border_radius=12)
    head = gacha.RARITY_COLOR[person["rarity"]] if unlocked else (44, 40, 56)
    pygame.draw.rect(s, head, (r.x, r.y, r.w, 30), border_top_left_radius=12, border_top_right_radius=12)
    pygame.draw.rect(s, C_INK, (CARD_W // 2 - 20, 9, 40, 9), border_radius=4)       # 목걸이 구멍
    pygame.draw.rect(s, base, (CARD_W // 2 - 16, 11, 32, 5), border_radius=2)
    frame = pygame.Rect(CARD_W // 2 - 46, 38, 92, 86)
    pygame.draw.rect(s, (226, 236, 246) if unlocked else (44, 40, 56), frame, border_radius=6)
    face = _face(person["look"], (100, 118), dark=not unlocked)
    s.set_clip(frame)
    s.blit(face, face.get_rect(midtop=(frame.centerx, frame.y - 8)))
    s.set_clip(None)
    pygame.draw.rect(s, C_INK, frame, 3, border_radius=6)
    if unlocked:
        ui.draw_text(s, person["name"], (CARD_W // 2, 140), 15, C_INK, True, center=True)
        ui.draw_text(s, person["role"], (CARD_W // 2, 160), 12, C_INK_SOFT, True, center=True)
        ui.draw_text(s, gacha.RARITY_LABEL[person["rarity"]], (r.right - 10, r.y + 6), 13, C_WHITE, True, anchor="topright")
    else:
        ui.draw_text(s, "? ? ?", (CARD_W // 2, 148), 20, (130, 124, 150), "heavy", center=True)
        ui.draw_text(s, "?", frame.center, 40, (90, 84, 110), "heavy", center=True)
    pygame.draw.rect(s, C_INK, r, 4, border_radius=12)
    return s


class AlbumScene(Scene):
    def __init__(self, app, tab="mates", back="title"):
        super().__init__(app)
        self.tab = tab
        self.back_to = back
        from . import hidden                                # 히든 엔딩을 한 번이라도 봤으면 '엔딩' 탭이 생긴다
        self.h_seen = hidden.seen(app)
        self.tabs = TABS + ([("ending", "엔딩")] if any(self.h_seen.values()) else [])
        self.h_thumbs: dict = {}
        self.HOME = BACK_HOME.get(back, "title")              # Esc·돌아가기: 도감을 연 곳으로
        from ..factory import scene as factory             # (납품하GO! 기록)
        self.f_rec = factory.record(app)
        from ..agency import scene as agency                # (요청하GO! 기록)
        self.a_rec = agency.record(app)
        self.f_clients = factory.clients(app.data)
        self.f_faces: dict = {}
        self.f_boss = Character(app.data.factory["company"]["look"])
        self.f_boss.expression = "happy"
        self.f_boss.set_pose("hip")
        self.t = 0.0
        self.detail = None            # 상세 보기 중인 동료
        self.info = None              # 상세 보기 중인 그 밖의 항목 (난이도·규정·납품처·잠긴 항목)
        self.info_t = 0.0
        self.detail_t = 0.0
        self.detail_char = None
        self.press = None             # 누르고 있는 자리 (옆으로 밀어 넘기기용)
        self.drag_dx = 0              # 누른 채 옆으로 민 거리
        self.slide = 0.0              # 넘긴 직후 미끄러져 들어오는 중인 거리
        prof = app.profile
        self.roster = app.data.roster
        met = self.f_rec["staff"]
        self.people = ([dict(p, kind="review", level=prof.bio_level(p["id"])) for p in self.roster]
                       + [dict(p, kind="factory", level=1 if p["id"] in met else 0) for p in app.data.staff["roster"]]
                       + [dict(p, kind="agency", level=1 if p["id"] in self.a_rec["helpers"] else 0)
                          for p in app.data.agency["helpers"]["roster"]])
        size = (int(CARD_W * MINI), int(CARD_H * MINI))
        self.cards = [(pygame.transform.smoothscale(_id_card(p, p["level"] > 0), size), p["level"]) for p in self.people]
        self.unlocked = [p for p in self.people if p["level"] > 0]               # 상세 보기에서 넘겨 볼 수 있는 사람
        self.mates = [p for p in self.people if p["kind"] == "review" and p["level"] > 0]   # 추억(CG)에 서는 동료
        levels = app.data.factory["levels"]
        self.boss_chars = [Character(lv["look"]) for lv in levels]          # 난이도마다 사장의 생김새가 다르다
        self.agency_chars = [Character(lv["look"]) for lv in app.data.agency["levels"]]
        for ch in self.agency_chars:
            ch.expression = "happy"
        for ch, expr, pose in zip(self.boss_chars, ("happy", "neutral", "nervous"), ("cheer", "hip", "shrug")):
            ch.expression = expr
            ch.set_pose(pose)
        self.chief_chars = [Character(c["look"]) for c in app.data.chiefs]
        for ch, c in zip(self.chief_chars, app.data.chiefs):
            ch.expression = c.get("expression", "neutral")
        self.cg_list = list(cg.CGS.values())
        self.thumbs: dict[str, pygame.Surface] = {}
        self.back = ui.Button((WIDTH - 210, 20, 180, 50), "돌아가기", (190, 170, 150), size=18)
        self.layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    # ------------------------------------------------------------ 위치
    def _tab_rect(self, i):
        return pygame.Rect(40 + i * 146, 22, 134, 54)

    def _card_rect(self, i):
        return pygame.Rect(40 + (i % 10) * 121, 104 + (i // 10) * 148, int(CARD_W * MINI), int(CARD_H * MINI))

    def _thumb_rect(self, i):
        return pygame.Rect(40 + (i % 9) * 134, 112 + (i // 9) * 116, THUMB_W, THUMB_H)

    def _chief_rect(self, i):
        return pygame.Rect(46 + (i % 3) * 400, 98 + (i // 3) * 198, 384, 186)      # 줄마다 한 편: 심사숙GO / 납품하GO / 요청하GO

    def _cg_cast(self, spec):
        """(팀장 자리, 동료 자리의 사람들, 주인공) — 납품하GO의 CG 는 사장과 만나 본 직원들이 선다."""
        if spec["game"] == "agency":
            data = self.app.data
            off = data.case_of(1)["officer"]
            chief = {"look": off["look"], "name": off["name"], "difficulty": "요청하GO"}
            pool = [p["look"] for p in self.people if p["kind"] == "agency" and p["level"] > 0]
            random.shuffle(pool)
            cleared = [lv for lv in data.agency["levels"] if lv["id"] in self.a_rec["levels"]]
            me = random.choice(cleared or [data.agency["levels"][1]])["look"]
            return chief, pool[:spec["slots"]], me
        if spec["game"] == "factory":
            data = self.app.data
            chief = {"look": data.dialogue["hero"]["look"], "name": "조달청 심사관", "difficulty": "납품하GO"}
            pool = [p["look"] for p in self.people if p["kind"] == "factory" and p["level"] > 0]
            random.shuffle(pool)
            cleared = [lv for lv in data.factory["levels"] if lv["id"] in self.f_rec["levels"]]
            boss = random.choice(cleared or [data.factory["levels"][1]])["look"]
            return chief, pool[:spec["slots"]], boss
        return self._cg_chief(spec), self._random_mates(spec["slots"]), None

    def _cg_chief(self, spec):
        chiefs = self.app.data.chiefs
        if spec["chiefs"]:
            return next(c for c in chiefs if c["id"] == spec["chiefs"][0])
        cleared = [c for c in chiefs if self.app.profile.chief_cleared(c["id"])]
        return random.choice(cleared or [chiefs[1]])

    def _random_mates(self, n):
        pool = [p["look"] for p in self.mates]
        random.shuffle(pool)
        return pool[:n]

    def _thumb(self, spec) -> pygame.Surface:
        if spec["id"] not in self.thumbs:
            chief, mates, hero = self._cg_cast(spec)
            img = cg.render(spec["id"], self.app.data, chief, mates, with_caption=False, hero_look=hero)
            self.thumbs[spec["id"]] = pygame.transform.smoothscale(img, (THUMB_W, THUMB_H))
        return self.thumbs[spec["id"]]

    # ------------------------------------------------------------ 입력
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_LEFT, pygame.K_RIGHT):
            self._flip(1 if event.key == pygame.K_RIGHT else -1)
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.detail and not self.info and self.back.clicked(event):
                self.app.to_home()
                return
            self.press = event.pos
            self.drag_dx = 0
        elif event.type == pygame.MOUSEMOTION and self.press:
            self.drag_dx = event.pos[0] - self.press[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and not self.press:
            if self.t > 0.6:                                      # 누름 신호 없이 뗌만 온 경우 (도감을 막 연 직후의 뗌은 무시)
                self._tap(event.pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.press:
            dx, dy = event.pos[0] - self.press[0], event.pos[1] - self.press[1]
            start, self.press, self.drag_dx = self.press, None, 0
            if abs(dx) > SWIPE and abs(dx) > abs(dy) * 1.5:
                self._flip(-1 if dx > 0 else 1, from_dx=dx)       # 왼쪽으로 밀면 다음 장
            elif abs(dx) + abs(dy) < 16:
                self._tap(start)

    def _flip(self, step, from_dx=0):
        """옆으로 한 장 넘기기. 상세 보기 중이면 만난 동료 사이를, 아니면 탭(동료·팀장·추억) 사이를 넘긴다."""
        if self.info:
            return
        if self.detail:
            if len(self.unlocked) < 2:
                return
            i = (self.unlocked.index(self.detail) + step) % len(self.unlocked)
            self._open_detail(self.unlocked[i])
        else:
            keys = [k for k, _ in self.tabs]
            i = keys.index(self.tab) + step
            if not 0 <= i < len(keys):
                self.slide = from_dx / 3                           # 끝이라 더 못 넘김: 살짝 튕겨 돌아온다
                return
            self.tab = keys[i]
        self.slide = step * 260                                    # 새 장이 넘어온 쪽에서 미끄러져 들어온다
        sfx.play("paper", 0.5)

    def _open_detail(self, p):
        self.detail, self.detail_t = p, 0.0
        self.detail_char = Character(p["look"])
        self.detail_char.expression = "happy"
        self.detail_char.set_pose("wave")
        sfx.play("pop", 0.5)

    def _tap(self, pos):
        if self.detail or self.info:
            self.detail = self.info = None
            sfx.play("paper", 0.4)
            return
        for i, (key, _) in enumerate(self.tabs):
            if self._tab_rect(i).collidepoint(pos) and key != self.tab:
                self.slide = (1 if i > [k for k, _ in self.tabs].index(self.tab) else -1) * 260
                self.tab = key
                sfx.play("paper", 0.5)
                return
        if self._tap_item(pos):
            return
        if self.tab == "cgs":
            seen = self.app.profile.data["cgs"]
            for i, spec in enumerate(self.cg_list):
                if self._thumb_rect(i).collidepoint(pos) and spec["id"] in seen:
                    chief, mates, hero = self._cg_cast(spec)
                    back = lambda: self.app.change(lambda: AlbumScene(self.app, "cgs", self.back_to))      # noqa: E731
                    self.app.change(lambda: CGScene(self.app, spec["id"], chief=chief, mates=mates, viewer=True,
                                                    on_done=back, hero_look=hero))
                    return

    # ------------------------------------------------------------ 눌러서 자세히 보기 (모든 탭)
    def _open_info(self, title, kind=None, sub="", parts=(), locked=False):
        """항목 하나를 크게 보여 준다. parts = [(소제목, 글), ...]"""
        self.info = {"title": title, "kind": kind, "sub": sub, "parts": list(parts), "locked": locked}
        self.info_t = 0.0
        sfx.play("wrong" if locked else "pop", 0.4 if locked else 0.5)

    def _tap_item(self, pos) -> bool:
        """지금 탭에서 pos 에 있는 항목의 상세를 연다."""
        data, tab = self.app.data, self.tab
        if tab == "mates":
            for i, p in enumerate(self.people):
                if self._card_rect(i).collidepoint(pos):
                    if self.cards[i][1] > 0:
                        self._open_detail(p)
                    else:
                        how = {"review": "심사숙GO에서 승진하면 열리는 인사 발령 봉투에서 만날 수 있어요.",
                               "factory": "납품하GO에서 불량 없이 납기 안에 납품하면 열리는 채용 봉투에서 만날 수 있어요.",
                               "agency": "요청하GO에서 하루를 별 셋으로 끝내면 열리는 응원 편지에서 만날 수 있어요."}[p["kind"]]
                        self._open_info("아직 만나지 못한 인재", p["kind"], gacha.RARITY_LABEL[p["rarity"]] + " 등급",
                                        [("만나는 방법", how)], locked=True)
                    return True
        elif tab == "chiefs":
            for i, e in enumerate(getattr(self, "_entries", [])):
                if self._chief_rect(i).collidepoint(pos):
                    if e["best"] is None:
                        self._open_info(e["title"], e["kind"], "아직 클리어하지 못한 난이도", [("여는 방법", e["lock"])], locked=True)
                    else:
                        self._open_info(e["title"], e["kind"], f"{e['name']}  ·  “{e['tag']}”",
                                        [("최고 등급", f"{e['best']} 등급")] + [("" if k else "이런 사람", line) for k, line in enumerate(e["bio"])])
                    return True
        elif tab == "rules":
            known = self.app.profile.data["rules"]
            for i, r in enumerate(data.rules):
                if pygame.Rect(46 + (i % 3) * 400, 104 + (i // 3) * 196, 384, 182).collidepoint(pos):
                    if r["id"] not in known:
                        self._open_info("아직 배우지 않은 규정", "review", f"{r['day']}일차", [("배우는 때", f"심사숙GO {r['day']}일차 근무에서 배워요.")],
                                        locked=True)
                    else:
                        self._open_info(r["short"], "review", f"{r['day']}일차에 배움  ·  {r['policy']}",
                                        [("반려 기준", r["text"]), ("왜 필요할까", r["explain"]),
                                         ("이런 말이 들리면 의심", "“" + r["hint"][0] + "”"), ("걸러냈을 때", "“" + r["caught"][0] + "”")])
                    return True
        elif tab == "factory":
            for i, c in enumerate(self.f_clients):
                if pygame.Rect(402 + (i % 4) * 214, 128 + (i // 4) * 282, 200, 268).collidepoint(pos):
                    n = self.f_rec["delivered"].get(c["key"], 0)
                    when = f"납품하GO {c['day']}일차의 공통 공고" if c["day"] else "가끔 올라오는 일반 공고"
                    if not n:
                        self._open_info("아직 납품하지 못한 곳", "factory", c["item"],
                                        [("공고", when), ("여는 방법", "이 공고를 낙찰받아 불량 없이, 물량을 다 채워 납품하면 도장이 찍혀요.")], locked=True)
                    else:
                        who = f"{c['officer']['name']} {c['officer']['role']}" if c["officer"] else "검수 담당자"
                        parts = [("납품 품목", c["item"]), ("공고", when), ("완벽 납품", f"{n}회"), ("검수", who)]
                        if c["thanks"]:
                            parts.append(("받은 인사", "“" + c["thanks"] + "”"))
                        self._open_info(c["agency"], "factory", "납품처 도장판", parts)
                    return True
        elif tab == "ending":
            from . import hidden
            for i, tier in enumerate(("mid", "hard")):
                if self._ending_rect(i).collidepoint(pos):
                    if self.h_seen.get(tier):                    # 처음부터 다시 본다 → 끝나면 이 탭으로
                        back = lambda: self.app.change(lambda: AlbumScene(self.app, "ending", self.back_to))      # noqa: E731
                        self.app.change(lambda: hidden.HiddenEndingScene(self.app, tier, viewer=True, on_done=back))
                    else:
                        self._open_info("아직 못 본 엔딩", None, "? ? ?", [("여는 방법", hidden.TIERS[tier]["need"] + "하면, 첫 화면으로 돌아왔을 때 저절로 시작돼요.")],
                                        locked=True)
                    return True
        elif tab == "cgs":
            seen = self.app.profile.data["cgs"]
            for i, spec in enumerate(self.cg_list):
                if self._thumb_rect(i).collidepoint(pos) and spec["id"] not in seen:
                    game = GAME_TAG[spec["game"]][0]
                    self._open_info("아직 못 본 추억", spec["game"], "? ? ?", [("보는 방법", f"{game}를 플레이하다 보면 만날 수 있어요.")],
                                    locked=True)
                    return True
        return False

    def _draw_info(self, surf):
        inf = self.info
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 22, 170))
        surf.blit(dim, (0, 0))
        k = ease_out_back(self.info_t / 0.28, 1.2)
        panel = pygame.Rect(0, 0, 780, 500)
        panel.center = (WIDTH // 2, HEIGHT // 2 + (1 - k) * 50)
        props.box(surf, panel, (255, 250, 236) if not inf["locked"] else (236, 230, 240), radius=16, offset=(8, 10))
        x, y = panel.x + 36, panel.y + 30
        if inf["kind"]:
            y = self._tag(surf, inf["kind"], (x, y), 12).bottom + 10
        ui.draw_text(surf, inf["title"], (x, y), 34, C_INK, "heavy")
        y += 50
        if inf["sub"]:
            ui.draw_text(surf, inf["sub"], (x, y), 16, C_INK_SOFT, True)
            y += 30
        pygame.draw.line(surf, C_INK, (x, y), (panel.right - 36, y), 3)
        y += 16
        for head, text in inf["parts"]:
            if head:
                w = ui.fonts.get(13, True).size(head)[0] + 24
                ui.pill(surf, (x, y, w, 26), head, C_ACCENT if not inf["locked"] else (150, 142, 166), C_WHITE, 13)
                y += 32
            y = ui.draw_wrapped(surf, text, (x + 4, y, panel.w - 80, 200), 17, C_INK) + 10
            if y > panel.bottom - 60:
                break
        ui.draw_text(surf, "아무 곳이나 눌러 닫기", (panel.right - 24, panel.bottom - 30), 13, C_INK_SOFT, True, anchor="topright")

    def update(self, dt):
        self.t += dt
        self.info_t += dt
        self.slide += (0 - self.slide) * min(1.0, dt * 12)
        self.back.update(dt)
        for ch in self.chief_chars + self.boss_chars + self.agency_chars:
            ch.update(dt)
        self.f_boss.update(dt)
        if self.detail:
            self.detail_t += dt
            self.detail_char.update(dt)

    # ------------------------------------------------------------ 그리기
    def _draw_tabs(self, surf):
        prof = self.app.profile
        n_diff = len(self.app.data.chiefs) + len(self.app.data.factory["levels"]) + len(self.app.data.agency["levels"])
        counts = {"mates": f"{len(self.unlocked)}/{len(self.people)}",
                  "chiefs": f"{sum(prof.chief_cleared(c['id']) for c in self.app.data.chiefs) + len(self.f_rec['levels']) + len(self.a_rec['levels'])}/{n_diff}",
                  "cgs": f"{sum(1 for c in self.cg_list if c['id'] in prof.data['cgs'])}/{len(self.cg_list)}",
                  "rules": f"{sum(1 for r in self.app.data.rules if r['id'] in prof.data['rules'])}/{len(self.app.data.rules)}",
                  "factory": f"{sum(1 for c in self.f_clients if c['key'] in self.f_rec['delivered'])}/{len(self.f_clients)}",
                  "ending": f"{sum(1 for v in self.h_seen.values() if v)}/2"}
        for i, (key, label) in enumerate(self.tabs):
            r = self._tab_rect(i)
            on = key == self.tab
            if on:
                r = r.inflate(0, 10).move(0, 5)
            props.box(surf, r, (255, 214, 120) if on else (255, 250, 236), radius=12, offset=(4, 5))
            ui.draw_text(surf, label, (r.centerx, r.y + 18), 20, C_INK, "heavy" if on else True, center=True)
            ui.draw_text(surf, counts[key], (r.centerx, r.y + 40), 12, C_INK_SOFT, True, center=True)

    def _tag(self, surf, kind, topleft, size=10):
        """어느 편의 기록인지 알려 주는 작은 태그."""
        text, color = GAME_TAG[kind]
        w = ui.fonts.get(size, True).size(text)[0] + 14
        r = pygame.Rect(topleft[0], topleft[1], w, size + 8)
        pygame.draw.rect(surf, color, r, border_radius=r.h // 2)
        pygame.draw.rect(surf, C_INK, r, 2, border_radius=r.h // 2)
        ui.draw_text(surf, text, r.center, size, C_WHITE, True, center=True)
        return r

    def _draw_mates(self, surf):
        """인재: 심사숙GO의 동료 + 납품하GO의 직원."""
        mouse = pygame.mouse.get_pos()
        for i, ((card, level), p) in enumerate(zip(self.cards, self.people)):
            r = self._card_rect(i)
            hot = r.collidepoint(mouse) and level > 0 and not self.detail
            pos = r.move(0, -6 if hot else 0)
            surf.blit(props.silhouette_shadow(card, 60), pos.move(4, 6 + (4 if hot else 0)))
            surf.blit(card, pos)
            self._tag(surf, p["kind"], (pos.x - 4, pos.y - 7), 9)
            if p["kind"] == "review":
                for k in range(3):                               # 성격 공개 단계 점 3개
                    c = (pos.x + 12 + k * 10, pos.bottom - 9)
                    pygame.draw.circle(surf, C_ACCENT if level > k else (120, 112, 130), c, 3)
                    pygame.draw.circle(surf, C_INK, c, 3, 1)

    def _draw_chiefs(self, surf):
        """난이도: 심사숙GO의 팀장 3명(윗줄) + 납품하GO의 사장 3단계(아랫줄). 클리어하면 열린다."""
        prof, data = self.app.profile, self.app.data
        entries = []
        for c, ch in zip(data.chiefs, self.chief_chars):
            entries.append({"kind": "review", "title": c["difficulty"], "name": c["name"], "tag": c["tagline"],
                            "bio": c.get("bio", []), "color": hex2rgb(c["color"]), "look": c["look"], "char": ch,
                            "best": prof.data["chiefs"].get(c["id"]) if prof.chief_cleared(c["id"]) else None,
                            "lock": "이 팀장과 함께 5일을 끝까지 일하면 공개됩니다."})
        fac = data.factory
        for lv, ch in zip(fac["levels"], self.boss_chars):
            bpms = [fac["produce"]["tracks"][t] for t in lv["rhythm"]["tracks"]]
            bio = [lv["desc"], f"서류 마감 {int(fac['deadline_sec'] * lv['deadline'])}초 · 반려되면 다시 내기 {lv['retries']}번",
                   "상자 박자 " + "~".join(str(b) for b in sorted({min(bpms), max(bpms)})) + " BPM"
                   + (" · 튜토리얼로 시작" if lv.get("tutorial") else f" · 운영비 {int(lv['fixed'] * 100)}%")]
            entries.append({"kind": "factory", "title": lv["name"], "name": fac["company"]["name"], "tag": lv["tag"], "bio": bio,
                            "color": tuple(lv["color"]), "look": lv["look"], "char": ch,
                            "best": self.f_rec["levels"].get(lv["id"]), "lock": "이 난이도로 공장을 닷새 동안 끝까지 운영하면 공개됩니다."})
        ag = data.agency
        for lv, ch in zip(ag["levels"], self.agency_chars):
            bio = [lv["desc"], f"칠판 {lv['grid'][0]}×{lv['grid'][1]}칸 · 미끼 블록 {lv['decoys']}개 · 예산 여유 {int(lv['slack'] * 100)}% · 제한 {lv['time']}초"]
            entries.append({"kind": "agency", "title": lv["name"], "name": "수요기관 담당자", "tag": lv["tag"], "bio": bio,
                            "color": tuple(lv["color"]), "look": lv["look"], "char": ch,
                            "best": self.a_rec["levels"].get(lv["id"]), "lock": "이 난이도로 닷새의 요청서를 모두 보내면 공개됩니다."})
        self._entries = entries
        for i, e in enumerate(entries):
            r = self._chief_rect(i)
            open_ = e["best"] is not None
            props.box(surf, r, (255, 253, 247) if open_ else (58, 52, 70), radius=14, offset=(6, 8))
            pygame.draw.rect(surf, e["color"] if open_ else (44, 40, 56), (r.x + 4, r.y + 4, r.w - 8, 34),
                             border_top_left_radius=11, border_top_right_radius=11)
            label = sticker.fit(sticker.sticker_text(e["title"], 19, sticker.WHITE), r.w - 150)
            surf.blit(label, label.get_rect(midleft=(r.x + 104, r.y + 21)))
            self._tag(surf, e["kind"], (r.x + 12, r.y + 11), 11)
            frame = pygame.Rect(r.x + 12, r.y + 46, 108, 128)
            pygame.draw.rect(surf, (226, 236, 246) if open_ else (44, 40, 56), frame, border_radius=10)
            surf.set_clip(frame)
            if open_:
                e["char"].draw(surf, (frame.centerx, frame.y + 14), scale=0.44)
            else:
                key = ("dark", i)
                if key not in self.f_faces:
                    self.f_faces[key] = _face(e["look"], (106, 125), dark=True)
                surf.blit(self.f_faces[key], self.f_faces[key].get_rect(midtop=(frame.centerx, frame.y + 14)))
            surf.set_clip(None)
            pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
            x, w = frame.right + 12, r.right - frame.right - 22
            if not open_:
                ui.draw_text(surf, "? ? ?", (x + w // 2, r.y + 78), 24, (130, 124, 150), "heavy", center=True)
                ui.draw_wrapped(surf, e["lock"], (x, r.y + 106, w, 70), 12, (150, 144, 170), True)
                continue
            ui.draw_text(surf, e["name"], (x, r.y + 46), 17, C_INK, "heavy")
            ui.draw_text(surf, f"“{e['tag']}”", (x, r.y + 68), 11, C_INK_SOFT, True)
            y = r.y + 88
            for line in e["bio"]:                                 # (다 못 적은 내용은 눌러서 자세히)
                rows = ui.wrap(line, 11, w - 12)
                if y + len(rows) * 14 > r.bottom - 6:
                    break
                pygame.draw.circle(surf, e["color"], (x + 4, y + 7), 3)
                for row in rows:
                    ui.draw_text(surf, row, (x + 12, y), 11, C_INK)
                    y += 14
                y += 3
            st = pygame.Surface((56, 56), pygame.SRCALPHA)
            pygame.draw.circle(st, (*C_REJECT, 220), (28, 28), 24, 4)
            ui.draw_text(st, e["best"], (28, 28), 26, C_REJECT, "heavy", center=True)
            st = pygame.transform.rotozoom(st, 12, 1.0)
            surf.blit(st, st.get_rect(center=(frame.right - 16, frame.bottom - 18)))

    def _draw_rules(self, surf):
        """규정 카드 9장: 어떤 정책에 속하는지, 무엇을 보는지, 왜 있는지. 아직 안 배운 규정은 잠겨 있다."""
        known = self.app.profile.data["rules"]
        for i, r in enumerate(self.app.data.rules):
            card = pygame.Rect(46 + (i % 3) * 400, 104 + (i // 3) * 196, 384, 182)
            open_ = r["id"] in known
            props.box(surf, card, (255, 253, 247) if open_ else (72, 66, 86), radius=10, offset=(5, 6))
            if not open_:
                ui.draw_text(surf, "???", (card.centerx, card.centery - 14), 34, (120, 112, 136), "heavy", center=True)
                ui.draw_text(surf, f"{r['day']}일차 근무에서 배워요", (card.centerx, card.centery + 28), 14,
                             (150, 142, 166), True, center=True)
                continue
            w = ui.fonts.get(12, True).size(r["policy"])[0] + 22
            ui.pill(surf, (card.x + 14, card.y + 12, w, 24), r["policy"], C_ACCENT, C_WHITE, 12)
            ui.draw_text(surf, f"{r['day']}일차", (card.right - 16, card.y + 16), 12, C_INK_SOFT, True, anchor="topright")
            ui.draw_text(surf, r["short"], (card.x + 16, card.y + 44), 19, C_INK, "heavy")
            y = ui.draw_wrapped(surf, r["text"], (card.x + 16, card.y + 72, card.w - 32, 40), 13, C_REJECT, True)
            pygame.draw.line(surf, (236, 224, 204), (card.x + 14, y + 3), (card.right - 14, y + 3), 2)
            ui.draw_wrapped(surf, r["explain"], (card.x + 16, y + 9, card.w - 32, 70), 13, C_INK_SOFT, True)

    def _draw_factory(self, surf):
        """납품하GO! 우리 공장: 회사 기록 + 납품처 도장판 (완벽하게 납품한 곳이 열린다)."""
        rec, data = self.f_rec, self.app.data
        co = data.factory["company"]
        left = pygame.Rect(46, 104, 330, 580)
        props.box(surf, left, (255, 253, 247), radius=12, offset=(5, 6))
        pygame.draw.rect(surf, (72, 170, 196), (left.x, left.y, left.w, 44), border_top_left_radius=12, border_top_right_radius=12)
        pygame.draw.rect(surf, C_INK, left, 3, border_radius=12)
        ui.draw_text(surf, "납품하GO! 우리 공장", (left.centerx, left.y + 22), 17, C_WHITE, True, center=True)
        clip = surf.get_clip()
        surf.set_clip(pygame.Rect(left.x + 3, left.y + 46, left.w - 6, 250))
        self.f_boss.draw(surf, (left.centerx, left.y + 70), scale=0.9)
        surf.set_clip(clip)
        ui.draw_text(surf, co["name"], (left.centerx, left.y + 318), 21, C_INK, "heavy", center=True)
        ui.draw_text(surf, f"대표 {co['ceo']}  ·  {' · '.join(co['can_make'])}", (left.centerx, left.y + 344), 11, C_INK_SOFT, True,
                     center=True)
        y = left.y + 366
        rej = sum(rec["rejects"].values())
        worst = max(rec["rejects"], key=rec["rejects"].get) if rej else None
        rows = [("가장 두둑했던 통장", ui.won(rec["best"]) if rec.get("clear") else "-"),
                ("공공 납품", f"{rec['wins']}건 (완벽 {rec['perfect']}건)"),
                ("서류 반려", f"{rej}번" + (f" · 최다 {data.rules_by_id[worst]['short']}" if worst else "")),
                ("담합 제안", "단호하게 거절함" if rec.get("refused") else "아직 겪지 않음")]
        y += 6
        for name, value in rows:
            ui.draw_text(surf, name, (left.x + 22, y), 13, C_INK_SOFT, True)
            ui.draw_text(surf, value, (left.right - 22, y + 18), 15 if len(value) < 16 else 12, C_INK, True, anchor="topright")
            pygame.draw.line(surf, (236, 224, 204), (left.x + 20, y + 40), (left.right - 20, y + 40), 2)
            y += 46
        ui.draw_text(surf, "납품처 도장판 — 불량 없이, 납기 안에 납품한 곳", (402, 100), 15, C_INK, True)
        for i, c in enumerate(self.f_clients):
            card = pygame.Rect(402 + (i % 4) * 214, 128 + (i // 4) * 282, 200, 268)
            n = rec["delivered"].get(c["key"], 0)
            props.box(surf, card, (255, 253, 247) if n else (72, 66, 86), radius=10, offset=(5, 6))
            frame = pygame.Rect(card.centerx - 50, card.y + 16, 100, 92)
            pygame.draw.rect(surf, (226, 240, 244) if n else (58, 52, 70), frame, border_radius=8)
            look = (c["officer"] or {}).get("look") or {"body": "#D8E6F0", "shape": "bean", "ears": "none", "acc": ["idcard"]}
            fk = (c["key"], bool(n))
            if fk not in self.f_faces:
                self.f_faces[fk] = _face(look, (104, 122), dark=not n)
            clip = surf.get_clip()
            surf.set_clip(frame)
            surf.blit(self.f_faces[fk], self.f_faces[fk].get_rect(midtop=(frame.centerx, frame.y - 6)))
            surf.set_clip(clip)
            pygame.draw.rect(surf, C_INK, frame, 3, border_radius=8)
            if not n:
                ui.draw_text(surf, "? ? ?", (card.centerx, card.y + 136), 20, (130, 124, 150), "heavy", center=True)
                hint = f"{c['day']}일차 공고" if c["day"] else "가끔 올라오는 공고"
                ui.draw_text(surf, hint, (card.centerx, card.y + 170), 12, (150, 142, 166), True, center=True)
                ui.draw_text(surf, c["item"], (card.centerx, card.y + 190), 12, (150, 142, 166), True, center=True)
                continue
            ui.draw_text(surf, c["agency"], (card.centerx, card.y + 124), 16, C_INK, "heavy", center=True)
            ui.draw_text(surf, c["item"], (card.centerx, card.y + 146), 12, C_INK_SOFT, True, center=True)
            who = f"{c['officer']['name']} {c['officer']['role']}" if c["officer"] else "검수 담당자"
            ui.draw_text(surf, who, (card.centerx, card.y + 164), 11, C_ACCENT, True, center=True)
            if c["thanks"]:
                ui.draw_wrapped(surf, f"“{c['thanks']}”", (card.x + 14, card.y + 184, card.w - 28, 60), 12, C_INK, True)
            sc = (card.right - 34, card.y + 34)                  # 납품 도장
            pygame.draw.circle(surf, C_REJECT, sc, 24, 3)
            ui.draw_text(surf, "납품", (sc[0], sc[1] - 6), 12, C_REJECT, True, center=True)
            ui.draw_text(surf, f"{n}회", (sc[0], sc[1] + 9), 11, C_REJECT, True, center=True)

    def _ending_rect(self, i):
        return pygame.Rect(46 + i * 600, 104, 584, 570)

    def _draw_endings(self, surf):
        """히든 엔딩 두 편. 본 엔딩은 장면들이 줄지어 보이고, 눌러서 처음부터 다시 본다."""
        from . import hidden
        for i, tier in enumerate(("mid", "hard")):
            r = self._ending_rect(i)
            open_ = bool(self.h_seen.get(tier))
            info = hidden.TIERS[tier]
            props.box(surf, r, (255, 253, 247) if open_ else (58, 52, 70), radius=14, offset=(6, 8))
            pygame.draw.rect(surf, (140, 110, 200) if open_ else (44, 40, 56), (r.x + 4, r.y + 4, r.w - 8, 50),
                             border_top_left_radius=11, border_top_right_radius=11)
            label = sticker.sticker_text(info["title"] if open_ else "? ? ?", 26, sticker.WHITE)
            surf.blit(label, label.get_rect(center=(r.centerx, r.y + 30)))
            sl = hidden.slides(tier)
            if not open_:
                ui.draw_text(surf, "아직 못 본 엔딩", (r.centerx, r.y + 230), 26, (130, 124, 150), "heavy", center=True)
                ui.draw_wrapped(surf, f"여는 방법: {info['need']}", (r.x + 60, r.y + 280, r.w - 120, 80), 16, (150, 144, 170), True)
                continue
            for k, slide in enumerate(sl):
                key = (tier, slide["id"])
                if key not in self.h_thumbs:
                    img = hidden.render(slide, self.app.data, tier == "hard")
                    self.h_thumbs[key] = pygame.transform.smoothscale(img, (170, 96))
                t = pygame.Rect(r.x + 22 + (k % 3) * 182, r.y + 70 + (k // 3) * 138, 170, 96)
                surf.blit(self.h_thumbs[key], t)
                pygame.draw.rect(surf, C_INK, t, 3)
                ui.draw_text(surf, f"{k + 1}. {slide['title']}", (t.centerx, t.bottom + 6), 12, C_INK, True, anchor="midtop")
            ui.pill(surf, (r.centerx - 110, r.bottom - 52, 220, 36), f"눌러서 다시 보기 · {len(sl)}장", C_ACCENT, C_WHITE, 15)

    def _draw_cgs(self, surf):
        seen = self.app.profile.data["cgs"]
        mouse = pygame.mouse.get_pos()
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        for i, spec in enumerate(self.cg_list):
            r = self._thumb_rect(i)
            open_ = spec["id"] in seen
            hot = open_ and r.collidepoint(mouse)
            pos = r.move(0, -5 if hot else 0)
            props.hard_shadow(surf, pos, 6, (5, 7 + (4 if hot else 0)))
            if open_:
                surf.blit(self._thumb(spec), pos)
            else:
                pygame.draw.rect(surf, (58, 52, 70), pos)
                ui.draw_text(surf, "?", pos.center, 36, (110, 104, 130), "heavy", center=True)
            pygame.draw.rect(surf, C_INK, pos, 4)
            ui.draw_text(surf, spec["title"] if open_ else "? ? ?", (pos.centerx, pos.bottom + 6), 13,
                         C_INK if open_ else C_INK_SOFT, True, anchor="midtop")
            where = " · ".join(names[c][:5] for c in spec["chiefs"]) if spec["chiefs"] else "모든 난이도"
            self._tag(surf, spec["game"], (pos.x - 4, pos.y - 7), 9)
            ui.draw_text(surf, where, (pos.centerx, pos.bottom + 24), 10, C_INK_SOFT, True, anchor="midtop")

    def _draw_detail(self, surf):
        p = self.detail
        prof = self.app.profile
        staff = p["kind"] != "review"                            # 납품하GO 직원 · 요청하GO 도우미
        from ..factory import staff as staffmod
        if p["kind"] == "agency":
            from ..agency import helpers as staffmod                # noqa: F811 (같은 모양의 기술 표)
        level = p["level"]
        rec = prof.data["members"].get(p["id"], {})
        if staff:
            src = self.f_rec["staff"] if p["kind"] == "factory" else self.a_rec["helpers"]
            rec = {"pulled": src.get(p["id"], 0)}
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 22, 170))
        surf.blit(dim, (0, 0))
        k = ease_out_back(self.detail_t / 0.3, 1.2)
        panel = pygame.Rect(0, 0, 1100, 640)
        panel.center = (WIDTH // 2, HEIGHT // 2 + (1 - k) * 60)
        props.box(surf, panel, (255, 250, 236), radius=16, offset=(8, 10))

        # 왼쪽: 큰 사원증
        color = gacha.RARITY_COLOR[p["rarity"]]
        card = pygame.Rect(panel.x + 28, panel.y + 28, 320, 584)
        props.box(surf, card, (255, 253, 247), radius=14, offset=(4, 5))
        pygame.draw.rect(surf, color, (card.x + 4, card.y + 4, card.w - 8, 50), border_top_left_radius=11,
                         border_top_right_radius=11)
        org = {"review": "조달청 계약심사과", "factory": self.app.data.factory["company"]["name"], "agency": "든든한 도우미"}[p["kind"]]
        ui.draw_text(surf, org, (card.x + 20, card.y + 18), 16,
                     C_WHITE, True)
        self._tag(surf, p["kind"], (panel.right - 104, panel.y + 28), 12)
        ui.draw_text(surf, gacha.RARITY_LABEL[p["rarity"]], (card.right - 18, card.y + 12), 24, C_WHITE, "heavy",
                     anchor="topright")
        frame = pygame.Rect(card.x + 40, card.y + 70, 240, 240)
        pygame.draw.rect(surf, (226, 236, 246), frame, border_radius=10)
        surf.set_clip(frame)
        self.detail_char.draw(surf, (frame.centerx, frame.y + 14), scale=1.12)
        surf.set_clip(None)
        pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
        ui.draw_text(surf, p["name"], (card.centerx, card.y + 340), 30, C_INK, "heavy", center=True)
        ui.draw_text(surf, f"{p['age']}세  ·  {p['role']}", (card.centerx, card.y + 372), 17, C_INK_SOFT, True, center=True)
        y = card.y + 402
        for sk in p["skills"]:
            c = (card.x + 44, y + 22)
            pygame.draw.circle(surf, gacha.GRADE_COLOR[sk["grade"]], c, 20)
            pygame.draw.circle(surf, C_INK, c, 20, 3)
            ui.draw_text(surf, sk["grade"], c, 22, C_WHITE, "heavy", center=True)
            table, describe = (staffmod.SKILLS, staffmod.describe) if staff else (gacha.SKILLS, gacha.describe)
            ui.draw_text(surf, table[sk["type"]]["name"], (card.x + 74, y + 2), 17, C_INK, True)
            ui.draw_text(surf, describe(sk["type"], sk["grade"]), (card.x + 74, y + 24), 12, C_INK_SOFT, True)
            y += 52
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        cleared = " · ".join(names[c] for c in rec.get("cleared", [])) or "아직 없음"
        if staff:
            env = "채용 봉투" if p["kind"] == "factory" else "응원 편지"
            ui.draw_text(surf, f"{env}에서 만난 횟수  {rec.get('pulled', 0)}회", (card.x + 22, card.bottom - 26), 12, C_INK_SOFT, True)
        else:
            ui.draw_text(surf, f"첫 합류  {rec.get('first', '-')}   (만난 횟수 {rec.get('pulled', 0)}회)",
                         (card.x + 22, card.bottom - 62), 12, C_INK_SOFT, True)
            ui.draw_text(surf, f"마지막 클리어  {rec.get('last_clear', '-')}", (card.x + 22, card.bottom - 44), 12, C_INK_SOFT, True)
            ui.draw_text(surf, f"함께 클리어  {cleared}", (card.x + 22, card.bottom - 26), 12, C_INK_SOFT, True)

        # 오른쪽: 성격 1~3
        x, w = card.right + 28, panel.right - card.right - 56
        y = panel.y + 30
        ui.draw_text(surf, f"“{p['line']}”", (x, y), 18, C_INK, True)
        y += 40
        sections = [(1, "성격 1", [p["bio1"]]), (2, "성격 2  ·  이런 사람", p.get("bio2", [])),
                    (3, "성격 3  ·  속 이야기", p.get("bio3", []))]
        if staff:
            sections = [(1, "이런 사람", [p["bio1"]])]
        for need, title, lines in sections:
            open_ = level >= need
            tag = pygame.Rect(x, y, 190, 28)
            pygame.draw.rect(surf, color if open_ else (170, 164, 180), tag, border_radius=14)
            pygame.draw.rect(surf, C_INK, tag, 2, border_radius=14)
            ui.draw_text(surf, title, tag.center, 14, C_WHITE, True, center=True)
            y += 36
            if open_:
                for line in lines:
                    y = ui.draw_wrapped(surf, line, (x + 6, y, w - 6, 200), 15) + 3
            else:
                box = pygame.Rect(x, y, w, 46)
                pygame.draw.rect(surf, (226, 220, 232), box, border_radius=8)
                pygame.draw.rect(surf, (170, 164, 180), box, 2, border_radius=8)
                ui.draw_text(surf, LOCK_TEXT[need], box.center, 14, (120, 112, 136), True, center=True)
                y += 50
            y += 12
        ui.draw_text(surf, "아무 곳이나 눌러 닫기", (panel.right - 24, panel.bottom - 30), 13, C_INK_SOFT, True,
                     anchor="topright")

    def draw(self, surf):
        props.draw_desk(surf, 0)
        self._draw_tabs(surf)
        self.back.draw(surf)
        off = 0 if self.detail else int(self.slide + self.drag_dx * 0.6)
        page = surf
        if abs(off) > 1:                                      # 넘기는 중: 내용만 따로 그려서 옆으로 옮긴다
            page = self.layer
            page.fill((0, 0, 0, 0))
        if self.tab == "mates":
            self._draw_mates(page)
        elif self.tab == "chiefs":
            self._draw_chiefs(page)
        elif self.tab == "rules":
            self._draw_rules(page)
        elif self.tab == "factory":
            self._draw_factory(page)
        elif self.tab == "ending":
            self._draw_endings(page)
        else:
            self._draw_cgs(page)
        if page is not surf:
            surf.blit(page, (off, 0))
        keys = [k for k, _ in self.tabs]                              # 쪽 표시 점 + 안내
        for i in range(len(keys)):
            c = (WIDTH // 2 - len(keys) * 11 + i * 22, HEIGHT - 16)
            pygame.draw.circle(surf, C_ACCENT if keys[i] == self.tab else (214, 190, 160), c, 6)
            pygame.draw.circle(surf, C_INK, c, 6, 2)
        ui.draw_text(surf, "눌러서 자세히 · 옆으로 밀어서 넘기기", (WIDTH // 2 + 82, HEIGHT - 25), 13, C_INK_SOFT, True)
        if self.detail:
            self._draw_detail(surf)
        if self.info:
            self._draw_info(surf)
