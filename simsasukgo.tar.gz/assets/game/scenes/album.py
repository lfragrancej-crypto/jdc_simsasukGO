"""도감 — 동료 사원증 앨범 / 팀장 / 추억(이벤트 CG).

동료  만난 적 없는 사람은 검은 ??? 카드. 사원증을 누르면 능력과 성격 1~3 이 보인다.
      성격1 = 뽑으면 공개 / 성격2 = 함께 엔딩 / 성격3 = 함께 '지옥' 난이도 엔딩
팀장  그 난이도를 클리어하면 공개.
추억  게임 중에 본 CG. 눌러서 다시 본다 — 동료 자리에는 해금한 동료가 무작위로 선다.
"""
import math
import random

import pygame

from .. import cg, gacha, props, sfx, sticker, ui
from ..anim import ease_out_back
from ..character import Character, hex2rgb
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_REJECT, C_WHITE, HEIGHT, WIDTH
from .base import Scene
from .cgscene import CGScene

TABS = [("mates", "동료"), ("chiefs", "팀장"), ("cgs", "추억")]
SWIPE = 70                # 이만큼 옆으로 밀면 한 장 넘어간다
CARD_W, CARD_H = 172, 184
GRID_X, GRID_Y, GRID_DX, GRID_DY = 62, 112, 196, 198
THUMB_W, THUMB_H = 140, 79
LOCK_TEXT = {2: "이 동료와 함께 엔딩을 보면 공개됩니다.", 3: "이 동료와 함께 '지옥에서내가돌아왔다'를 클리어하면 공개됩니다."}


def _face(look, size, expr="happy", dark=False) -> pygame.Surface:
    ch = Character(look, seed=3)
    ch.expression = expr
    ch.blink = 0
    img = pygame.transform.smoothscale(ch.render(), size)
    if dark:                                                    # 미해금: 그림자 실루엣만
        img = pygame.mask.from_surface(img, 40).to_surface(setcolor=(34, 30, 44, 255), unsetcolor=(0, 0, 0, 0))
    return img


def _id_card(person, unlocked: bool) -> pygame.Surface:
    """공무원증 모양 카드 (앨범 한 칸)."""
    s = pygame.Surface((CARD_W, CARD_H), pygame.SRCALPHA)
    r = pygame.Rect(2, 2, CARD_W - 4, CARD_H - 4)
    base = (255, 253, 247) if unlocked else (58, 52, 70)
    pygame.draw.rect(s, base, r, border_radius=12)
    head = gacha.RARITY_COLOR[person["rarity"]] if unlocked else (44, 40, 56)
    pygame.draw.rect(s, head, (r.x, r.y, r.w, 30), border_top_left_radius=12, border_top_right_radius=12)
    pygame.draw.rect(s, C_INK, (CARD_W // 2 - 20, 9, 40, 9), border_radius=4)       # 목걸이 구멍
    pygame.draw.rect(s, base, (CARD_W // 2 - 16, 11, 32, 5), border_radius=2)
    frame = pygame.Rect(CARD_W // 2 - 46, 38, 92, 86)
    pygame.draw.rect(s, (226, 236, 246) if unlocked else (44, 40, 56), frame, border_radius=6)
    face = _face(person["look"], (100, 118), dark=not unlocked)
    s.set_clip(frame)
    s.blit(face, face.get_rect(midtop=(frame.centerx, frame.y - 8)))
    s.set_clip(None)
    pygame.draw.rect(s, C_INK, frame, 3, border_radius=6)
    if unlocked:
        ui.draw_text(s, person["name"], (CARD_W // 2, 140), 15, C_INK, True, center=True)
        ui.draw_text(s, person["role"], (CARD_W // 2, 160), 12, C_INK_SOFT, True, center=True)
        ui.draw_text(s, gacha.RARITY_LABEL[person["rarity"]], (r.right - 10, r.y + 6), 13, C_WHITE, True, anchor="topright")
    else:
        ui.draw_text(s, "? ? ?", (CARD_W // 2, 148), 20, (130, 124, 150), "heavy", center=True)
        ui.draw_text(s, "?", frame.center, 40, (90, 84, 110), "heavy", center=True)
    pygame.draw.rect(s, C_INK, r, 4, border_radius=12)
    return s


class AlbumScene(Scene):
    def __init__(self, app, tab="mates"):
        super().__init__(app)
        self.tab = tab
        self.t = 0.0
        self.detail = None            # 상세 보기 중인 동료
        self.detail_t = 0.0
        self.detail_char = None
        self.press = None             # 누르고 있는 자리 (옆으로 밀어 넘기기용)
        self.drag_dx = 0              # 누른 채 옆으로 민 거리
        self.slide = 0.0              # 넘긴 직후 미끄러져 들어오는 중인 거리
        prof = app.profile
        self.roster = app.data.roster
        self.cards = [(_id_card(p, prof.bio_level(p["id"]) > 0), prof.bio_level(p["id"])) for p in self.roster]
        self.unlocked = [p for p in self.roster if prof.bio_level(p["id"]) > 0]
        self.chief_chars = [Character(c["look"]) for c in app.data.chiefs]
        for ch, c in zip(self.chief_chars, app.data.chiefs):
            ch.expression = c.get("expression", "neutral")
        self.cg_list = list(cg.CGS.values())
        self.thumbs: dict[str, pygame.Surface] = {}
        self.back = ui.Button((WIDTH - 210, 20, 180, 50), "돌아가기", (190, 170, 150), size=18)
        self.layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    # ------------------------------------------------------------ 위치
    def _tab_rect(self, i):
        return pygame.Rect(60 + i * 150, 22, 136, 54)

    def _card_rect(self, i):
        return pygame.Rect(GRID_X + (i % 6) * GRID_DX, GRID_Y + (i // 6) * GRID_DY, CARD_W, CARD_H)

    def _thumb_rect(self, i):
        return pygame.Rect(50 + (i % 8) * 150, 116 + (i // 8) * 146, THUMB_W, THUMB_H)

    def _chief_rect(self, i):
        return pygame.Rect(70 + i * 392, 108, 356, 580)

    def _cg_chief(self, spec):
        chiefs = self.app.data.chiefs
        if spec["chiefs"]:
            return next(c for c in chiefs if c["id"] == spec["chiefs"][0])
        cleared = [c for c in chiefs if self.app.profile.chief_cleared(c["id"])]
        return random.choice(cleared or [chiefs[1]])

    def _random_mates(self, n):
        pool = [p["look"] for p in self.unlocked]
        random.shuffle(pool)
        return pool[:n]

    def _thumb(self, spec) -> pygame.Surface:
        if spec["id"] not in self.thumbs:
            img = cg.render(spec["id"], self.app.data, self._cg_chief(spec), self._random_mates(spec["slots"]),
                            with_caption=False)
            self.thumbs[spec["id"]] = pygame.transform.smoothscale(img, (THUMB_W, THUMB_H))
        return self.thumbs[spec["id"]]

    # ------------------------------------------------------------ 입력
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_LEFT, pygame.K_RIGHT):
            self._flip(1 if event.key == pygame.K_RIGHT else -1)
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.detail and self.back.clicked(event):
                self.app.to_title()
                return
            self.press = event.pos
            self.drag_dx = 0
        elif event.type == pygame.MOUSEMOTION and self.press:
            self.drag_dx = event.pos[0] - self.press[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.press:
            dx, dy = event.pos[0] - self.press[0], event.pos[1] - self.press[1]
            start, self.press, self.drag_dx = self.press, None, 0
            if abs(dx) > SWIPE and abs(dx) > abs(dy) * 1.5:
                self._flip(-1 if dx > 0 else 1, from_dx=dx)       # 왼쪽으로 밀면 다음 장
            elif abs(dx) + abs(dy) < 16:
                self._tap(start)

    def _flip(self, step, from_dx=0):
        """옆으로 한 장 넘기기. 상세 보기 중이면 만난 동료 사이를, 아니면 탭(동료·팀장·추억) 사이를 넘긴다."""
        if self.detail:
            if len(self.unlocked) < 2:
                return
            i = (self.unlocked.index(self.detail) + step) % len(self.unlocked)
            self._open_detail(self.unlocked[i])
        else:
            keys = [k for k, _ in TABS]
            i = keys.index(self.tab) + step
            if not 0 <= i < len(keys):
                self.slide = from_dx / 3                           # 끝이라 더 못 넘김: 살짝 튕겨 돌아온다
                return
            self.tab = keys[i]
        self.slide = step * 260                                    # 새 장이 넘어온 쪽에서 미끄러져 들어온다
        sfx.play("paper", 0.5)

    def _open_detail(self, p):
        self.detail, self.detail_t = p, 0.0
        self.detail_char = Character(p["look"])
        self.detail_char.expression = "happy"
        self.detail_char.set_pose("wave")
        sfx.play("pop", 0.5)

    def _tap(self, pos):
        if self.detail:
            self.detail = None
            sfx.play("paper", 0.4)
            return
        for i, (key, _) in enumerate(TABS):
            if self._tab_rect(i).collidepoint(pos) and key != self.tab:
                self.slide = (1 if i > [k for k, _ in TABS].index(self.tab) else -1) * 260
                self.tab = key
                sfx.play("paper", 0.5)
                return
        if self.tab == "mates":
            for i, p in enumerate(self.roster):
                if self._card_rect(i).collidepoint(pos):
                    if self.cards[i][1] > 0:
                        self._open_detail(p)
                    else:
                        sfx.play("wrong", 0.3)
                    return
        elif self.tab == "cgs":
            seen = self.app.profile.data["cgs"]
            for i, spec in enumerate(self.cg_list):
                if self._thumb_rect(i).collidepoint(pos) and spec["id"] in seen:
                    chief = self._cg_chief(spec)
                    mates = self._random_mates(spec["slots"])
                    back = lambda: self.app.change(lambda: AlbumScene(self.app, "cgs"))      # noqa: E731
                    self.app.change(lambda: CGScene(self.app, spec["id"], chief=chief, mates=mates, viewer=True,
                                                    on_done=back))
                    return

    def update(self, dt):
        self.t += dt
        self.slide += (0 - self.slide) * min(1.0, dt * 12)
        self.back.update(dt)
        for ch in self.chief_chars:
            ch.update(dt)
        if self.detail:
            self.detail_t += dt
            self.detail_char.update(dt)

    # ------------------------------------------------------------ 그리기
    def _draw_tabs(self, surf):
        prof = self.app.profile
        counts = {"mates": f"{len(self.unlocked)}/{len(self.roster)}",
                  "chiefs": f"{sum(prof.chief_cleared(c['id']) for c in self.app.data.chiefs)}/{len(self.app.data.chiefs)}",
                  "cgs": f"{sum(1 for c in self.cg_list if c['id'] in prof.data['cgs'])}/{len(self.cg_list)}"}
        for i, (key, label) in enumerate(TABS):
            r = self._tab_rect(i)
            on = key == self.tab
            if on:
                r = r.inflate(0, 10).move(0, 5)
            props.box(surf, r, (255, 214, 120) if on else (255, 250, 236), radius=12, offset=(4, 5))
            ui.draw_text(surf, label, (r.centerx, r.y + 18), 20, C_INK, "heavy" if on else True, center=True)
            ui.draw_text(surf, counts[key], (r.centerx, r.y + 40), 12, C_INK_SOFT, True, center=True)

    def _draw_mates(self, surf):
        mouse = pygame.mouse.get_pos()
        for i, (card, level) in enumerate(self.cards):
            r = self._card_rect(i)
            hot = r.collidepoint(mouse) and level > 0 and not self.detail
            pos = r.move(0, -6 if hot else 0)
            surf.blit(props.silhouette_shadow(card, 60), pos.move(5, 7 + (4 if hot else 0)))
            surf.blit(card, pos)
            for k in range(3):                                   # 성격 공개 단계 점 3개
                c = (pos.x + 18 + k * 14, pos.bottom - 14)
                pygame.draw.circle(surf, C_ACCENT if level > k else (120, 112, 130), c, 5)
                pygame.draw.circle(surf, C_INK, c, 5, 2)

    def _draw_chiefs(self, surf):
        prof = self.app.profile
        for i, (c, ch) in enumerate(zip(self.app.data.chiefs, self.chief_chars)):
            r = self._chief_rect(i)
            open_ = prof.chief_cleared(c["id"])
            color = hex2rgb(c["color"])
            props.box(surf, r, (255, 253, 247) if open_ else (58, 52, 70), radius=14, offset=(6, 8))
            pygame.draw.rect(surf, color if open_ else (44, 40, 56), (r.x + 4, r.y + 4, r.w - 8, 46),
                             border_top_left_radius=11, border_top_right_radius=11)
            label = sticker.fit(sticker.sticker_text(c["difficulty"], 26, sticker.WHITE), r.w - 40)
            surf.blit(label, label.get_rect(center=(r.centerx, r.y + 28)))
            frame = pygame.Rect(r.centerx - 110, r.y + 64, 220, 190)
            pygame.draw.rect(surf, (226, 236, 246) if open_ else (44, 40, 56), frame, border_radius=10)
            surf.set_clip(frame)
            if open_:
                ch.draw(surf, (frame.centerx, frame.y + 8), scale=0.95)
            else:
                dark = _face(c["look"], (210, 248), dark=True)
                surf.blit(dark, dark.get_rect(midtop=(frame.centerx, frame.y + 8)))
            surf.set_clip(None)
            pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
            if not open_:
                ui.draw_text(surf, "? ? ?", (r.centerx, r.y + 290), 28, (130, 124, 150), "heavy", center=True)
                ui.draw_wrapped(surf, "이 팀장과 함께 5일을 끝까지 일하면 공개됩니다.", (r.x + 40, r.y + 340, r.w - 80, 80),
                                15, (150, 144, 170), True)
                continue
            ui.draw_text(surf, c["name"], (r.centerx, r.y + 282), 26, C_INK, "heavy", center=True)
            ui.draw_text(surf, f"“{c['tagline']}”", (r.centerx, r.y + 312), 14, C_INK_SOFT, True, center=True)
            y = r.y + 342
            for line in c.get("bio", []):
                pygame.draw.circle(surf, color, (r.x + 28, y + 9), 4)
                y = ui.draw_wrapped(surf, line, (r.x + 40, y, r.w - 64, 80), 14) + 6
            best = prof.data["chiefs"][c["id"]]
            st = pygame.Surface((90, 90), pygame.SRCALPHA)
            pygame.draw.circle(st, (*C_REJECT, 220), (45, 45), 40, 5)
            ui.draw_text(st, best, (45, 45), 44, C_REJECT, "heavy", center=True)
            st = pygame.transform.rotozoom(st, 12, 1.0)
            surf.blit(st, st.get_rect(center=(r.right - 54, r.y + 110)))

    def _draw_cgs(self, surf):
        seen = self.app.profile.data["cgs"]
        mouse = pygame.mouse.get_pos()
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        for i, spec in enumerate(self.cg_list):
            r = self._thumb_rect(i)
            open_ = spec["id"] in seen
            hot = open_ and r.collidepoint(mouse)
            pos = r.move(0, -5 if hot else 0)
            props.hard_shadow(surf, pos, 6, (5, 7 + (4 if hot else 0)))
            if open_:
                surf.blit(self._thumb(spec), pos)
            else:
                pygame.draw.rect(surf, (58, 52, 70), pos)
                ui.draw_text(surf, "?", pos.center, 36, (110, 104, 130), "heavy", center=True)
            pygame.draw.rect(surf, C_INK, pos, 4)
            ui.draw_text(surf, spec["title"] if open_ else "? ? ?", (pos.centerx, pos.bottom + 6), 13,
                         C_INK if open_ else C_INK_SOFT, True, anchor="midtop")
            where = " · ".join(names[c][:5] for c in spec["chiefs"]) if spec["chiefs"] else "모든 난이도"
            ui.draw_text(surf, where, (pos.centerx, pos.bottom + 24), 10, C_INK_SOFT, True, anchor="midtop")

    def _draw_detail(self, surf):
        p = self.detail
        prof = self.app.profile
        level = prof.bio_level(p["id"])
        rec = prof.data["members"].get(p["id"], {})
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 22, 170))
        surf.blit(dim, (0, 0))
        k = ease_out_back(self.detail_t / 0.3, 1.2)
        panel = pygame.Rect(0, 0, 1100, 640)
        panel.center = (WIDTH // 2, HEIGHT // 2 + (1 - k) * 60)
        props.box(surf, panel, (255, 250, 236), radius=16, offset=(8, 10))

        # 왼쪽: 큰 사원증
        color = gacha.RARITY_COLOR[p["rarity"]]
        card = pygame.Rect(panel.x + 28, panel.y + 28, 320, 584)
        props.box(surf, card, (255, 253, 247), radius=14, offset=(4, 5))
        pygame.draw.rect(surf, color, (card.x + 4, card.y + 4, card.w - 8, 50), border_top_left_radius=11,
                         border_top_right_radius=11)
        ui.draw_text(surf, "조달청 계약심사과", (card.x + 20, card.y + 18), 16, C_WHITE, True)
        ui.draw_text(surf, gacha.RARITY_LABEL[p["rarity"]], (card.right - 18, card.y + 12), 24, C_WHITE, "heavy",
                     anchor="topright")
        frame = pygame.Rect(card.x + 40, card.y + 70, 240, 240)
        pygame.draw.rect(surf, (226, 236, 246), frame, border_radius=10)
        surf.set_clip(frame)
        self.detail_char.draw(surf, (frame.centerx, frame.y + 14), scale=1.12)
        surf.set_clip(None)
        pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
        ui.draw_text(surf, p["name"], (card.centerx, card.y + 340), 30, C_INK, "heavy", center=True)
        ui.draw_text(surf, f"{p['age']}세  ·  {p['role']}", (card.centerx, card.y + 372), 17, C_INK_SOFT, True, center=True)
        y = card.y + 402
        for sk in p["skills"]:
            c = (card.x + 44, y + 22)
            pygame.draw.circle(surf, gacha.GRADE_COLOR[sk["grade"]], c, 20)
            pygame.draw.circle(surf, C_INK, c, 20, 3)
            ui.draw_text(surf, sk["grade"], c, 22, C_WHITE, "heavy", center=True)
            ui.draw_text(surf, gacha.SKILLS[sk["type"]]["name"], (card.x + 74, y + 2), 17, C_INK, True)
            ui.draw_text(surf, gacha.describe(sk["type"], sk["grade"]), (card.x + 74, y + 24), 12, C_INK_SOFT, True)
            y += 52
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        cleared = " · ".join(names[c] for c in rec.get("cleared", [])) or "아직 없음"
        ui.draw_text(surf, f"첫 합류  {rec.get('first', '-')}   (만난 횟수 {rec.get('pulled', 0)}회)", (card.x + 22, card.bottom - 62),
                     12, C_INK_SOFT, True)
        ui.draw_text(surf, f"마지막 클리어  {rec.get('last_clear', '-')}", (card.x + 22, card.bottom - 44), 12, C_INK_SOFT, True)
        ui.draw_text(surf, f"함께 클리어  {cleared}", (card.x + 22, card.bottom - 26), 12, C_INK_SOFT, True)

        # 오른쪽: 성격 1~3
        x, w = card.right + 28, panel.right - card.right - 56
        y = panel.y + 30
        ui.draw_text(surf, f"“{p['line']}”", (x, y), 18, C_INK, True)
        y += 40
        sections = [(1, "성격 1", [p["bio1"]]), (2, "성격 2  ·  이런 사람", p["bio2"]), (3, "성격 3  ·  속 이야기", p["bio3"])]
        for need, title, lines in sections:
            open_ = level >= need
            tag = pygame.Rect(x, y, 190, 28)
            pygame.draw.rect(surf, color if open_ else (170, 164, 180), tag, border_radius=14)
            pygame.draw.rect(surf, C_INK, tag, 2, border_radius=14)
            ui.draw_text(surf, title, tag.center, 14, C_WHITE, True, center=True)
            y += 36
            if open_:
                for line in lines:
                    y = ui.draw_wrapped(surf, line, (x + 6, y, w - 6, 200), 15) + 3
            else:
                box = pygame.Rect(x, y, w, 46)
                pygame.draw.rect(surf, (226, 220, 232), box, border_radius=8)
                pygame.draw.rect(surf, (170, 164, 180), box, 2, border_radius=8)
                ui.draw_text(surf, LOCK_TEXT[need], box.center, 14, (120, 112, 136), True, center=True)
                y += 50
            y += 12
        ui.draw_text(surf, "아무 곳이나 눌러 닫기", (panel.right - 24, panel.bottom - 30), 13, C_INK_SOFT, True,
                     anchor="topright")

    def draw(self, surf):
        props.draw_desk(surf, 0)
        self._draw_tabs(surf)
        self.back.draw(surf)
        off = 0 if self.detail else int(self.slide + self.drag_dx * 0.6)
        page = surf
        if abs(off) > 1:                                      # 넘기는 중: 내용만 따로 그려서 옆으로 옮긴다
            page = self.layer
            page.fill((0, 0, 0, 0))
        if self.tab == "mates":
            self._draw_mates(page)
        elif self.tab == "chiefs":
            self._draw_chiefs(page)
        else:
            self._draw_cgs(page)
        if page is not surf:
            surf.blit(page, (off, 0))
        keys = [k for k, _ in TABS]                              # 쪽 표시 점 + 안내
        for i in range(len(keys)):
            c = (WIDTH // 2 - 22 + i * 22, HEIGHT - 16)
            pygame.draw.circle(surf, C_ACCENT if keys[i] == self.tab else (214, 190, 160), c, 6)
            pygame.draw.circle(surf, C_INK, c, 6, 2)
        ui.draw_text(surf, "옆으로 밀어서 넘기기", (WIDTH // 2 + 60, HEIGHT - 25), 13, C_INK_SOFT, True)
        if self.detail:
            self._draw_detail(surf)
