"""도감 — 인재(동료+직원 사원증) / 난이도(팀장+사장) / 추억(이벤트 CG) / 규정 / 우리 공장(납품 기록).

묶음(다함께! 조달 한바퀴)의 모든 편이 이 도감 하나를 같이 쓴다. 어디서 열었는지(back)에 따라 그곳으로 돌아간다.

인재  심사숙GO의 동료와 납품하GO의 직원을 한데 모았다 (카드마다 어느 편인지 태그).
      만난 적 없는 사람은 검은 ??? 카드. 사원증을 누르면 능력과 성격 1~3 이 보인다.
      성격1 = 뽑으면 공개 / 성격2 = 함께 엔딩 / 성격3 = 함께 '지옥' 난이도 엔딩
난이도  심사숙GO의 팀장 3명 + 납품하GO의 사장 3단계. 그 난이도를 클리어하면 공개.
추억  게임 중에 본 CG. 눌러서 다시 본다 — 동료 자리에는 해금한 동료가 무작위로 선다.
"""
import math
import random

import pygame

from .. import cg, gacha, props, sfx, sticker, ui
from ..anim import ease_out_back
from ..character import Character, hex2rgb
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_REJECT, C_WHITE, HEIGHT, WIDTH
from .base import Scene
from .cgscene import CGScene

TABS = [("mates", "인재"), ("chiefs", "난이도"), ("cgs", "추억"), ("rules", "규정"), ("factory", "우리 공장")]
GAME_TAG = {"review": ("심사숙GO", (255, 138, 92)), "factory": ("납품하GO", (72, 170, 196))}     # 어느 편의 기록인가
MINI = 0.8               # 인재 카드는 사원증을 줄여서 한 화면에 30장
BACK_HOME = {"title": "title", "hub": "hub", "factory": "factory_title"}
SWIPE = 70                # 이만큼 옆으로 밀면 한 장 넘어간다
CARD_W, CARD_H = 172, 184
GRID_X, GRID_Y, GRID_DX, GRID_DY = 62, 112, 196, 198
THUMB_W, THUMB_H = 140, 79
LOCK_TEXT = {2: "이 동료와 함께 엔딩을 보면 공개됩니다.", 3: "이 동료와 함께 '지옥에서내가돌아왔다'를 클리어하면 공개됩니다."}


def _face(look, size, expr="happy", dark=False) -> pygame.Surface:
    ch = Character(look, seed=3)
    ch.expression = expr
    ch.blink = 0
    img = pygame.transform.smoothscale(ch.render(), size)
    if dark:                                                    # 미해금: 그림자 실루엣만
        img = pygame.mask.from_surface(img, 40).to_surface(setcolor=(34, 30, 44, 255), unsetcolor=(0, 0, 0, 0))
    return img


def _id_card(person, unlocked: bool) -> pygame.Surface:
    """공무원증 모양 카드 (앨범 한 칸)."""
    s = pygame.Surface((CARD_W, CARD_H), pygame.SRCALPHA)
    r = pygame.Rect(2, 2, CARD_W - 4, CARD_H - 4)
    base = (255, 253, 247) if unlocked else (58, 52, 70)
    pygame.draw.rect(s, base, r, border_radius=12)
    head = gacha.RARITY_COLOR[person["rarity"]] if unlocked else (44, 40, 56)
    pygame.draw.rect(s, head, (r.x, r.y, r.w, 30), border_top_left_radius=12, border_top_right_radius=12)
    pygame.draw.rect(s, C_INK, (CARD_W // 2 - 20, 9, 40, 9), border_radius=4)       # 목걸이 구멍
    pygame.draw.rect(s, base, (CARD_W // 2 - 16, 11, 32, 5), border_radius=2)
    frame = pygame.Rect(CARD_W // 2 - 46, 38, 92, 86)
    pygame.draw.rect(s, (226, 236, 246) if unlocked else (44, 40, 56), frame, border_radius=6)
    face = _face(person["look"], (100, 118), dark=not unlocked)
    s.set_clip(frame)
    s.blit(face, face.get_rect(midtop=(frame.centerx, frame.y - 8)))
    s.set_clip(None)
    pygame.draw.rect(s, C_INK, frame, 3, border_radius=6)
    if unlocked:
        ui.draw_text(s, person["name"], (CARD_W // 2, 140), 15, C_INK, True, center=True)
        ui.draw_text(s, person["role"], (CARD_W // 2, 160), 12, C_INK_SOFT, True, center=True)
        ui.draw_text(s, gacha.RARITY_LABEL[person["rarity"]], (r.right - 10, r.y + 6), 13, C_WHITE, True, anchor="topright")
    else:
        ui.draw_text(s, "? ? ?", (CARD_W // 2, 148), 20, (130, 124, 150), "heavy", center=True)
        ui.draw_text(s, "?", frame.center, 40, (90, 84, 110), "heavy", center=True)
    pygame.draw.rect(s, C_INK, r, 4, border_radius=12)
    return s


class AlbumScene(Scene):
    def __init__(self, app, tab="mates", back="title"):
        super().__init__(app)
        self.tab = tab
        self.back_to = back
        self.HOME = BACK_HOME.get(back, "title")              # Esc·돌아가기: 도감을 연 곳으로
        from ..factory import scene as factory             # (납품하GO! 기록)
        self.f_rec = factory.record(app)
        self.f_clients = factory.clients(app.data)
        self.f_faces: dict = {}
        self.f_boss = Character(app.data.factory["company"]["look"])
        self.f_boss.expression = "happy"
        self.f_boss.set_pose("hip")
        self.t = 0.0
        self.detail = None            # 상세 보기 중인 동료
        self.detail_t = 0.0
        self.detail_char = None
        self.press = None             # 누르고 있는 자리 (옆으로 밀어 넘기기용)
        self.drag_dx = 0              # 누른 채 옆으로 민 거리
        self.slide = 0.0              # 넘긴 직후 미끄러져 들어오는 중인 거리
        prof = app.profile
        self.roster = app.data.roster
        met = self.f_rec["staff"]
        self.people = ([dict(p, kind="review", level=prof.bio_level(p["id"])) for p in self.roster]
                       + [dict(p, kind="factory", level=1 if p["id"] in met else 0) for p in app.data.staff["roster"]])
        size = (int(CARD_W * MINI), int(CARD_H * MINI))
        self.cards = [(pygame.transform.smoothscale(_id_card(p, p["level"] > 0), size), p["level"]) for p in self.people]
        self.unlocked = [p for p in self.people if p["level"] > 0]               # 상세 보기에서 넘겨 볼 수 있는 사람
        self.mates = [p for p in self.people if p["kind"] == "review" and p["level"] > 0]   # 추억(CG)에 서는 동료
        levels = app.data.factory["levels"]
        self.boss_chars = [Character(lv["look"]) for lv in levels]          # 난이도마다 사장의 생김새가 다르다
        for ch, expr, pose in zip(self.boss_chars, ("happy", "neutral", "nervous"), ("cheer", "hip", "shrug")):
            ch.expression = expr
            ch.set_pose(pose)
        self.chief_chars = [Character(c["look"]) for c in app.data.chiefs]
        for ch, c in zip(self.chief_chars, app.data.chiefs):
            ch.expression = c.get("expression", "neutral")
        self.cg_list = list(cg.CGS.values())
        self.thumbs: dict[str, pygame.Surface] = {}
        self.back = ui.Button((WIDTH - 210, 20, 180, 50), "돌아가기", (190, 170, 150), size=18)
        self.layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    # ------------------------------------------------------------ 위치
    def _tab_rect(self, i):
        return pygame.Rect(60 + i * 150, 22, 136, 54)

    def _card_rect(self, i):
        return pygame.Rect(48 + (i % 8) * 149, 100 + (i // 8) * 149, int(CARD_W * MINI), int(CARD_H * MINI))

    def _thumb_rect(self, i):
        return pygame.Rect(50 + (i % 8) * 150, 112 + (i // 8) * 118, THUMB_W, THUMB_H)

    def _chief_rect(self, i):
        return pygame.Rect(46 + (i % 3) * 400, 100 + (i // 3) * 294, 384, 280)     # 윗줄 심사숙GO, 아랫줄 납품하GO

    def _cg_cast(self, spec):
        """(팀장 자리, 동료 자리의 사람들, 주인공) — 납품하GO의 CG 는 사장과 만나 본 직원들이 선다."""
        if spec["game"] == "factory":
            data = self.app.data
            chief = {"look": data.dialogue["hero"]["look"], "name": "조달청 심사관", "difficulty": "납품하GO"}
            pool = [p["look"] for p in self.people if p["kind"] == "factory" and p["level"] > 0]
            random.shuffle(pool)
            cleared = [lv for lv in data.factory["levels"] if lv["id"] in self.f_rec["levels"]]
            boss = random.choice(cleared or [data.factory["levels"][1]])["look"]
            return chief, pool[:spec["slots"]], boss
        return self._cg_chief(spec), self._random_mates(spec["slots"]), None

    def _cg_chief(self, spec):
        chiefs = self.app.data.chiefs
        if spec["chiefs"]:
            return next(c for c in chiefs if c["id"] == spec["chiefs"][0])
        cleared = [c for c in chiefs if self.app.profile.chief_cleared(c["id"])]
        return random.choice(cleared or [chiefs[1]])

    def _random_mates(self, n):
        pool = [p["look"] for p in self.mates]
        random.shuffle(pool)
        return pool[:n]

    def _thumb(self, spec) -> pygame.Surface:
        if spec["id"] not in self.thumbs:
            chief, mates, hero = self._cg_cast(spec)
            img = cg.render(spec["id"], self.app.data, chief, mates, with_caption=False, hero_look=hero)
            self.thumbs[spec["id"]] = pygame.transform.smoothscale(img, (THUMB_W, THUMB_H))
        return self.thumbs[spec["id"]]

    # ------------------------------------------------------------ 입력
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_LEFT, pygame.K_RIGHT):
            self._flip(1 if event.key == pygame.K_RIGHT else -1)
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.detail and self.back.clicked(event):
                self.app.to_home()
                return
            self.press = event.pos
            self.drag_dx = 0
        elif event.type == pygame.MOUSEMOTION and self.press:
            self.drag_dx = event.pos[0] - self.press[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.press:
            dx, dy = event.pos[0] - self.press[0], event.pos[1] - self.press[1]
            start, self.press, self.drag_dx = self.press, None, 0
            if abs(dx) > SWIPE and abs(dx) > abs(dy) * 1.5:
                self._flip(-1 if dx > 0 else 1, from_dx=dx)       # 왼쪽으로 밀면 다음 장
            elif abs(dx) + abs(dy) < 16:
                self._tap(start)

    def _flip(self, step, from_dx=0):
        """옆으로 한 장 넘기기. 상세 보기 중이면 만난 동료 사이를, 아니면 탭(동료·팀장·추억) 사이를 넘긴다."""
        if self.detail:
            if len(self.unlocked) < 2:
                return
            i = (self.unlocked.index(self.detail) + step) % len(self.unlocked)
            self._open_detail(self.unlocked[i])
        else:
            keys = [k for k, _ in TABS]
            i = keys.index(self.tab) + step
            if not 0 <= i < len(keys):
                self.slide = from_dx / 3                           # 끝이라 더 못 넘김: 살짝 튕겨 돌아온다
                return
            self.tab = keys[i]
        self.slide = step * 260                                    # 새 장이 넘어온 쪽에서 미끄러져 들어온다
        sfx.play("paper", 0.5)

    def _open_detail(self, p):
        self.detail, self.detail_t = p, 0.0
        self.detail_char = Character(p["look"])
        self.detail_char.expression = "happy"
        self.detail_char.set_pose("wave")
        sfx.play("pop", 0.5)

    def _tap(self, pos):
        if self.detail:
            self.detail = None
            sfx.play("paper", 0.4)
            return
        for i, (key, _) in enumerate(TABS):
            if self._tab_rect(i).collidepoint(pos) and key != self.tab:
                self.slide = (1 if i > [k for k, _ in TABS].index(self.tab) else -1) * 260
                self.tab = key
                sfx.play("paper", 0.5)
                return
        if self.tab == "mates":
            for i, p in enumerate(self.people):
                if self._card_rect(i).collidepoint(pos):
                    if self.cards[i][1] > 0:
                        self._open_detail(p)
                    else:
                        sfx.play("wrong", 0.3)
                    return
        elif self.tab == "cgs":
            seen = self.app.profile.data["cgs"]
            for i, spec in enumerate(self.cg_list):
                if self._thumb_rect(i).collidepoint(pos) and spec["id"] in seen:
                    chief, mates, hero = self._cg_cast(spec)
                    back = lambda: self.app.change(lambda: AlbumScene(self.app, "cgs", self.back_to))      # noqa: E731
                    self.app.change(lambda: CGScene(self.app, spec["id"], chief=chief, mates=mates, viewer=True,
                                                    on_done=back, hero_look=hero))
                    return

    def update(self, dt):
        self.t += dt
        self.slide += (0 - self.slide) * min(1.0, dt * 12)
        self.back.update(dt)
        for ch in self.chief_chars + self.boss_chars:
            ch.update(dt)
        self.f_boss.update(dt)
        if self.detail:
            self.detail_t += dt
            self.detail_char.update(dt)

    # ------------------------------------------------------------ 그리기
    def _draw_tabs(self, surf):
        prof = self.app.profile
        n_diff = len(self.app.data.chiefs) + len(self.app.data.factory["levels"])
        counts = {"mates": f"{len(self.unlocked)}/{len(self.people)}",
                  "chiefs": f"{sum(prof.chief_cleared(c['id']) for c in self.app.data.chiefs) + len(self.f_rec['levels'])}/{n_diff}",
                  "cgs": f"{sum(1 for c in self.cg_list if c['id'] in prof.data['cgs'])}/{len(self.cg_list)}",
                  "rules": f"{sum(1 for r in self.app.data.rules if r['id'] in prof.data['rules'])}/{len(self.app.data.rules)}",
                  "factory": f"{sum(1 for c in self.f_clients if c['key'] in self.f_rec['delivered'])}/{len(self.f_clients)}"}
        for i, (key, label) in enumerate(TABS):
            r = self._tab_rect(i)
            on = key == self.tab
            if on:
                r = r.inflate(0, 10).move(0, 5)
            props.box(surf, r, (255, 214, 120) if on else (255, 250, 236), radius=12, offset=(4, 5))
            ui.draw_text(surf, label, (r.centerx, r.y + 18), 20, C_INK, "heavy" if on else True, center=True)
            ui.draw_text(surf, counts[key], (r.centerx, r.y + 40), 12, C_INK_SOFT, True, center=True)

    def _tag(self, surf, kind, topleft, size=10):
        """어느 편의 기록인지 알려 주는 작은 태그."""
        text, color = GAME_TAG[kind]
        w = ui.fonts.get(size, True).size(text)[0] + 14
        r = pygame.Rect(topleft[0], topleft[1], w, size + 8)
        pygame.draw.rect(surf, color, r, border_radius=r.h // 2)
        pygame.draw.rect(surf, C_INK, r, 2, border_radius=r.h // 2)
        ui.draw_text(surf, text, r.center, size, C_WHITE, True, center=True)
        return r

    def _draw_mates(self, surf):
        """인재: 심사숙GO의 동료 + 납품하GO의 직원."""
        mouse = pygame.mouse.get_pos()
        for i, ((card, level), p) in enumerate(zip(self.cards, self.people)):
            r = self._card_rect(i)
            hot = r.collidepoint(mouse) and level > 0 and not self.detail
            pos = r.move(0, -6 if hot else 0)
            surf.blit(props.silhouette_shadow(card, 60), pos.move(4, 6 + (4 if hot else 0)))
            surf.blit(card, pos)
            self._tag(surf, p["kind"], (pos.x - 4, pos.y - 6))
            if p["kind"] == "review":
                for k in range(3):                               # 성격 공개 단계 점 3개
                    c = (pos.x + 14 + k * 12, pos.bottom - 11)
                    pygame.draw.circle(surf, C_ACCENT if level > k else (120, 112, 130), c, 4)
                    pygame.draw.circle(surf, C_INK, c, 4, 2)

    def _draw_chiefs(self, surf):
        """난이도: 심사숙GO의 팀장 3명(윗줄) + 납품하GO의 사장 3단계(아랫줄). 클리어하면 열린다."""
        prof, data = self.app.profile, self.app.data
        entries = []
        for c, ch in zip(data.chiefs, self.chief_chars):
            entries.append({"kind": "review", "title": c["difficulty"], "name": c["name"], "tag": c["tagline"],
                            "bio": c.get("bio", []), "color": hex2rgb(c["color"]), "look": c["look"], "char": ch,
                            "best": prof.data["chiefs"].get(c["id"]) if prof.chief_cleared(c["id"]) else None,
                            "lock": "이 팀장과 함께 5일을 끝까지 일하면 공개됩니다."})
        fac = data.factory
        for lv, ch in zip(fac["levels"], self.boss_chars):
            bio = [lv["desc"], f"서류 마감 {int(fac['deadline_sec'] * lv['deadline'])}초 · 반려되면 다시 내기 {lv['retries']}번",
                   "튜토리얼로 시작" if lv.get("tutorial") else f"불량 {int(lv['defect'] * 100)}% · 운영비 {int(lv['fixed'] * 100)}%"]
            entries.append({"kind": "factory", "title": lv["name"], "name": fac["company"]["name"], "tag": lv["tag"], "bio": bio,
                            "color": tuple(lv["color"]), "look": lv["look"], "char": ch,
                            "best": self.f_rec["levels"].get(lv["id"]), "lock": "이 난이도로 공장을 닷새 동안 끝까지 운영하면 공개됩니다."})
        for i, e in enumerate(entries):
            r = self._chief_rect(i)
            open_ = e["best"] is not None
            props.box(surf, r, (255, 253, 247) if open_ else (58, 52, 70), radius=14, offset=(6, 8))
            pygame.draw.rect(surf, e["color"] if open_ else (44, 40, 56), (r.x + 4, r.y + 4, r.w - 8, 40),
                             border_top_left_radius=11, border_top_right_radius=11)
            label = sticker.fit(sticker.sticker_text(e["title"], 22, sticker.WHITE), r.w - 150)
            surf.blit(label, label.get_rect(midleft=(r.x + 104, r.y + 25)))
            self._tag(surf, e["kind"], (r.x + 12, r.y + 14), 11)
            frame = pygame.Rect(r.x + 14, r.y + 56, 136, 208)
            pygame.draw.rect(surf, (226, 236, 246) if open_ else (44, 40, 56), frame, border_radius=10)
            surf.set_clip(frame)
            if open_:
                e["char"].draw(surf, (frame.centerx, frame.y + 22), scale=0.62)
            else:
                key = ("dark", i)
                if key not in self.f_faces:
                    self.f_faces[key] = _face(e["look"], (150, 177), dark=True)
                surf.blit(self.f_faces[key], self.f_faces[key].get_rect(midtop=(frame.centerx, frame.y + 22)))
            surf.set_clip(None)
            pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
            x, w = frame.right + 14, r.right - frame.right - 28
            if not open_:
                ui.draw_text(surf, "? ? ?", (x + w // 2, r.y + 110), 26, (130, 124, 150), "heavy", center=True)
                ui.draw_wrapped(surf, e["lock"], (x, r.y + 150, w, 80), 13, (150, 144, 170), True)
                continue
            ui.draw_text(surf, e["name"], (x, r.y + 56), 19, C_INK, "heavy")
            ui.draw_text(surf, f"“{e['tag']}”", (x, r.y + 82), 12, C_INK_SOFT, True)
            y = r.y + 106
            for line in e["bio"]:
                if y > r.bottom - 34:
                    break
                pygame.draw.circle(surf, e["color"], (x + 4, y + 8), 3)
                y = ui.draw_wrapped(surf, line, (x + 12, y, w - 12, 80), 12) + 4
            st = pygame.Surface((70, 70), pygame.SRCALPHA)
            pygame.draw.circle(st, (*C_REJECT, 220), (35, 35), 31, 4)
            ui.draw_text(st, e["best"], (35, 35), 34, C_REJECT, "heavy", center=True)
            st = pygame.transform.rotozoom(st, 12, 1.0)
            surf.blit(st, st.get_rect(center=(frame.right - 26, frame.bottom - 30)))

    def _draw_rules(self, surf):
        """규정 카드 9장: 어떤 정책에 속하는지, 무엇을 보는지, 왜 있는지. 아직 안 배운 규정은 잠겨 있다."""
        known = self.app.profile.data["rules"]
        for i, r in enumerate(self.app.data.rules):
            card = pygame.Rect(46 + (i % 3) * 400, 104 + (i // 3) * 196, 384, 182)
            open_ = r["id"] in known
            props.box(surf, card, (255, 253, 247) if open_ else (72, 66, 86), radius=10, offset=(5, 6))
            if not open_:
                ui.draw_text(surf, "???", (card.centerx, card.centery - 14), 34, (120, 112, 136), "heavy", center=True)
                ui.draw_text(surf, f"{r['day']}일차 근무에서 배워요", (card.centerx, card.centery + 28), 14,
                             (150, 142, 166), True, center=True)
                continue
            w = ui.fonts.get(12, True).size(r["policy"])[0] + 22
            ui.pill(surf, (card.x + 14, card.y + 12, w, 24), r["policy"], C_ACCENT, C_WHITE, 12)
            ui.draw_text(surf, f"{r['day']}일차", (card.right - 16, card.y + 16), 12, C_INK_SOFT, True, anchor="topright")
            ui.draw_text(surf, r["short"], (card.x + 16, card.y + 44), 19, C_INK, "heavy")
            y = ui.draw_wrapped(surf, r["text"], (card.x + 16, card.y + 72, card.w - 32, 40), 13, C_REJECT, True)
            pygame.draw.line(surf, (236, 224, 204), (card.x + 14, y + 3), (card.right - 14, y + 3), 2)
            ui.draw_wrapped(surf, r["explain"], (card.x + 16, y + 9, card.w - 32, 70), 13, C_INK_SOFT, True)

    def _draw_factory(self, surf):
        """납품하GO! 우리 공장: 회사 기록 + 납품처 도장판 (완벽하게 납품한 곳이 열린다)."""
        rec, data = self.f_rec, self.app.data
        co = data.factory["company"]
        left = pygame.Rect(46, 104, 330, 580)
        props.box(surf, left, (255, 253, 247), radius=12, offset=(5, 6))
        pygame.draw.rect(surf, (72, 170, 196), (left.x, left.y, left.w, 44), border_top_left_radius=12, border_top_right_radius=12)
        pygame.draw.rect(surf, C_INK, left, 3, border_radius=12)
        ui.draw_text(surf, "납품하GO! 우리 공장", (left.centerx, left.y + 22), 17, C_WHITE, True, center=True)
        clip = surf.get_clip()
        surf.set_clip(pygame.Rect(left.x + 3, left.y + 46, left.w - 6, 250))
        self.f_boss.draw(surf, (left.centerx, left.y + 70), scale=0.9)
        surf.set_clip(clip)
        ui.draw_text(surf, co["name"], (left.centerx, left.y + 318), 21, C_INK, "heavy", center=True)
        ui.draw_text(surf, f"대표 {co['ceo']}  ·  {' · '.join(co['can_make'])}", (left.centerx, left.y + 344), 11, C_INK_SOFT, True,
                     center=True)
        y = left.y + 366
        rej = sum(rec["rejects"].values())
        worst = max(rec["rejects"], key=rec["rejects"].get) if rej else None
        rows = [("가장 두둑했던 통장", ui.won(rec["best"]) if rec.get("clear") else "-"),
                ("공공 납품", f"{rec['wins']}건 (완벽 {rec['perfect']}건)"),
                ("서류 반려", f"{rej}번" + (f" · 최다 {data.rules_by_id[worst]['short']}" if worst else "")),
                ("담합 제안", "단호하게 거절함" if rec.get("refused") else "아직 겪지 않음")]
        y += 6
        for name, value in rows:
            ui.draw_text(surf, name, (left.x + 22, y), 13, C_INK_SOFT, True)
            ui.draw_text(surf, value, (left.right - 22, y + 18), 15 if len(value) < 16 else 12, C_INK, True, anchor="topright")
            pygame.draw.line(surf, (236, 224, 204), (left.x + 20, y + 40), (left.right - 20, y + 40), 2)
            y += 46
        ui.draw_text(surf, "납품처 도장판 — 불량 없이, 납기 안에 납품한 곳", (402, 100), 15, C_INK, True)
        for i, c in enumerate(self.f_clients):
            card = pygame.Rect(402 + (i % 4) * 214, 128 + (i // 4) * 282, 200, 268)
            n = rec["delivered"].get(c["key"], 0)
            props.box(surf, card, (255, 253, 247) if n else (72, 66, 86), radius=10, offset=(5, 6))
            frame = pygame.Rect(card.centerx - 50, card.y + 16, 100, 92)
            pygame.draw.rect(surf, (226, 240, 244) if n else (58, 52, 70), frame, border_radius=8)
            look = (c["officer"] or {}).get("look") or {"body": "#D8E6F0", "shape": "bean", "ears": "none", "acc": ["idcard"]}
            fk = (c["key"], bool(n))
            if fk not in self.f_faces:
                self.f_faces[fk] = _face(look, (104, 122), dark=not n)
            clip = surf.get_clip()
            surf.set_clip(frame)
            surf.blit(self.f_faces[fk], self.f_faces[fk].get_rect(midtop=(frame.centerx, frame.y - 6)))
            surf.set_clip(clip)
            pygame.draw.rect(surf, C_INK, frame, 3, border_radius=8)
            if not n:
                ui.draw_text(surf, "? ? ?", (card.centerx, card.y + 136), 20, (130, 124, 150), "heavy", center=True)
                hint = f"{c['day']}일차 공고" if c["day"] else "가끔 올라오는 공고"
                ui.draw_text(surf, hint, (card.centerx, card.y + 170), 12, (150, 142, 166), True, center=True)
                ui.draw_text(surf, c["item"], (card.centerx, card.y + 190), 12, (150, 142, 166), True, center=True)
                continue
            ui.draw_text(surf, c["agency"], (card.centerx, card.y + 124), 16, C_INK, "heavy", center=True)
            ui.draw_text(surf, c["item"], (card.centerx, card.y + 146), 12, C_INK_SOFT, True, center=True)
            who = f"{c['officer']['name']} {c['officer']['role']}" if c["officer"] else "검수 담당자"
            ui.draw_text(surf, who, (card.centerx, card.y + 164), 11, C_ACCENT, True, center=True)
            if c["thanks"]:
                ui.draw_wrapped(surf, f"“{c['thanks']}”", (card.x + 14, card.y + 184, card.w - 28, 60), 12, C_INK, True)
            sc = (card.right - 34, card.y + 34)                  # 납품 도장
            pygame.draw.circle(surf, C_REJECT, sc, 24, 3)
            ui.draw_text(surf, "납품", (sc[0], sc[1] - 6), 12, C_REJECT, True, center=True)
            ui.draw_text(surf, f"{n}회", (sc[0], sc[1] + 9), 11, C_REJECT, True, center=True)

    def _draw_cgs(self, surf):
        seen = self.app.profile.data["cgs"]
        mouse = pygame.mouse.get_pos()
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        for i, spec in enumerate(self.cg_list):
            r = self._thumb_rect(i)
            open_ = spec["id"] in seen
            hot = open_ and r.collidepoint(mouse)
            pos = r.move(0, -5 if hot else 0)
            props.hard_shadow(surf, pos, 6, (5, 7 + (4 if hot else 0)))
            if open_:
                surf.blit(self._thumb(spec), pos)
            else:
                pygame.draw.rect(surf, (58, 52, 70), pos)
                ui.draw_text(surf, "?", pos.center, 36, (110, 104, 130), "heavy", center=True)
            pygame.draw.rect(surf, C_INK, pos, 4)
            ui.draw_text(surf, spec["title"] if open_ else "? ? ?", (pos.centerx, pos.bottom + 6), 13,
                         C_INK if open_ else C_INK_SOFT, True, anchor="midtop")
            where = " · ".join(names[c][:5] for c in spec["chiefs"]) if spec["chiefs"] else "모든 난이도"
            self._tag(surf, spec["game"], (pos.x - 4, pos.y - 7), 9)
            ui.draw_text(surf, where, (pos.centerx, pos.bottom + 24), 10, C_INK_SOFT, True, anchor="midtop")

    def _draw_detail(self, surf):
        p = self.detail
        prof = self.app.profile
        staff = p["kind"] == "factory"
        from ..factory import staff as staffmod
        level = p["level"]
        rec = {"pulled": self.f_rec["staff"].get(p["id"], 0)} if staff else prof.data["members"].get(p["id"], {})
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((40, 28, 22, 170))
        surf.blit(dim, (0, 0))
        k = ease_out_back(self.detail_t / 0.3, 1.2)
        panel = pygame.Rect(0, 0, 1100, 640)
        panel.center = (WIDTH // 2, HEIGHT // 2 + (1 - k) * 60)
        props.box(surf, panel, (255, 250, 236), radius=16, offset=(8, 10))

        # 왼쪽: 큰 사원증
        color = gacha.RARITY_COLOR[p["rarity"]]
        card = pygame.Rect(panel.x + 28, panel.y + 28, 320, 584)
        props.box(surf, card, (255, 253, 247), radius=14, offset=(4, 5))
        pygame.draw.rect(surf, color, (card.x + 4, card.y + 4, card.w - 8, 50), border_top_left_radius=11,
                         border_top_right_radius=11)
        ui.draw_text(surf, self.app.data.factory["company"]["name"] if staff else "조달청 계약심사과", (card.x + 20, card.y + 18), 16,
                     C_WHITE, True)
        self._tag(surf, p["kind"], (panel.right - 104, panel.y + 28), 12)
        ui.draw_text(surf, gacha.RARITY_LABEL[p["rarity"]], (card.right - 18, card.y + 12), 24, C_WHITE, "heavy",
                     anchor="topright")
        frame = pygame.Rect(card.x + 40, card.y + 70, 240, 240)
        pygame.draw.rect(surf, (226, 236, 246), frame, border_radius=10)
        surf.set_clip(frame)
        self.detail_char.draw(surf, (frame.centerx, frame.y + 14), scale=1.12)
        surf.set_clip(None)
        pygame.draw.rect(surf, C_INK, frame, 3, border_radius=10)
        ui.draw_text(surf, p["name"], (card.centerx, card.y + 340), 30, C_INK, "heavy", center=True)
        ui.draw_text(surf, f"{p['age']}세  ·  {p['role']}", (card.centerx, card.y + 372), 17, C_INK_SOFT, True, center=True)
        y = card.y + 402
        for sk in p["skills"]:
            c = (card.x + 44, y + 22)
            pygame.draw.circle(surf, gacha.GRADE_COLOR[sk["grade"]], c, 20)
            pygame.draw.circle(surf, C_INK, c, 20, 3)
            ui.draw_text(surf, sk["grade"], c, 22, C_WHITE, "heavy", center=True)
            table, describe = (staffmod.SKILLS, staffmod.describe) if staff else (gacha.SKILLS, gacha.describe)
            ui.draw_text(surf, table[sk["type"]]["name"], (card.x + 74, y + 2), 17, C_INK, True)
            ui.draw_text(surf, describe(sk["type"], sk["grade"]), (card.x + 74, y + 24), 12, C_INK_SOFT, True)
            y += 52
        names = {c["id"]: c["difficulty"] for c in self.app.data.chiefs}
        cleared = " · ".join(names[c] for c in rec.get("cleared", [])) or "아직 없음"
        if staff:
            ui.draw_text(surf, f"채용 봉투에서 만난 횟수  {rec.get('pulled', 0)}회", (card.x + 22, card.bottom - 26), 12, C_INK_SOFT, True)
        else:
            ui.draw_text(surf, f"첫 합류  {rec.get('first', '-')}   (만난 횟수 {rec.get('pulled', 0)}회)",
                         (card.x + 22, card.bottom - 62), 12, C_INK_SOFT, True)
            ui.draw_text(surf, f"마지막 클리어  {rec.get('last_clear', '-')}", (card.x + 22, card.bottom - 44), 12, C_INK_SOFT, True)
            ui.draw_text(surf, f"함께 클리어  {cleared}", (card.x + 22, card.bottom - 26), 12, C_INK_SOFT, True)

        # 오른쪽: 성격 1~3
        x, w = card.right + 28, panel.right - card.right - 56
        y = panel.y + 30
        ui.draw_text(surf, f"“{p['line']}”", (x, y), 18, C_INK, True)
        y += 40
        sections = [(1, "성격 1", [p["bio1"]]), (2, "성격 2  ·  이런 사람", p.get("bio2", [])),
                    (3, "성격 3  ·  속 이야기", p.get("bio3", []))]
        if staff:
            sections = [(1, "이런 사람", [p["bio1"]])]
        for need, title, lines in sections:
            open_ = level >= need
            tag = pygame.Rect(x, y, 190, 28)
            pygame.draw.rect(surf, color if open_ else (170, 164, 180), tag, border_radius=14)
            pygame.draw.rect(surf, C_INK, tag, 2, border_radius=14)
            ui.draw_text(surf, title, tag.center, 14, C_WHITE, True, center=True)
            y += 36
            if open_:
                for line in lines:
                    y = ui.draw_wrapped(surf, line, (x + 6, y, w - 6, 200), 15) + 3
            else:
                box = pygame.Rect(x, y, w, 46)
                pygame.draw.rect(surf, (226, 220, 232), box, border_radius=8)
                pygame.draw.rect(surf, (170, 164, 180), box, 2, border_radius=8)
                ui.draw_text(surf, LOCK_TEXT[need], box.center, 14, (120, 112, 136), True, center=True)
                y += 50
            y += 12
        ui.draw_text(surf, "아무 곳이나 눌러 닫기", (panel.right - 24, panel.bottom - 30), 13, C_INK_SOFT, True,
                     anchor="topright")

    def draw(self, surf):
        props.draw_desk(surf, 0)
        self._draw_tabs(surf)
        self.back.draw(surf)
        off = 0 if self.detail else int(self.slide + self.drag_dx * 0.6)
        page = surf
        if abs(off) > 1:                                      # 넘기는 중: 내용만 따로 그려서 옆으로 옮긴다
            page = self.layer
            page.fill((0, 0, 0, 0))
        if self.tab == "mates":
            self._draw_mates(page)
        elif self.tab == "chiefs":
            self._draw_chiefs(page)
        elif self.tab == "rules":
            self._draw_rules(page)
        elif self.tab == "factory":
            self._draw_factory(page)
        else:
            self._draw_cgs(page)
        if page is not surf:
            surf.blit(page, (off, 0))
        keys = [k for k, _ in TABS]                              # 쪽 표시 점 + 안내
        for i in range(len(keys)):
            c = (WIDTH // 2 - 44 + i * 22, HEIGHT - 16)
            pygame.draw.circle(surf, C_ACCENT if keys[i] == self.tab else (214, 190, 160), c, 6)
            pygame.draw.circle(surf, C_INK, c, 6, 2)
        ui.draw_text(surf, "옆으로 밀어서 넘기기", (WIDTH // 2 + 82, HEIGHT - 25), 13, C_INK_SOFT, True)
        if self.detail:
            self._draw_detail(surf)
