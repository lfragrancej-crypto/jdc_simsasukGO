import pygame

from .. import paper, props, sfx, sticker, ui
from ..anim import ease_out_back
from ..character import Character
from ..config import C_ACCENT, C_INK, C_INK_SOFT, C_WHITE, WIDTH
from .base import Scene

WALL_H = 430
NOTE_SIZE = (250, 150)
NOTE_ANGLES = (-2.4, 1.8, -1.2, 2.2)


class BriefingScene(Scene):
    """아침 브리핑: 사무실에서 과장님이 한 줄씩 말하고, 다 듣고 나면 새 규정 쪽지를 책상에 탁탁 내려놓는다."""

    def __init__(self, app):
        super().__init__(app)
        self.cfg = app.day_cfg()
        chief = app.chief
        self.chief_name = chief["name"]
        self.chief = Character(chief["look"])
        self.chief.expression = "happy"
        self.chief.set_pose("wave")
        self.lines = chief["briefing"][self.cfg["day"] - 1]
        self.line = 0
        self.tw = ui.Typewriter(self.lines[0], 38, self.chief.voice)
        self.new_rules = [r for r in app.data.rules if r["day"] == self.cfg["day"]]
        self.notes = [paper.render_note(r["short"], r["text"], NOTE_SIZE, tag="NEW") for r in self.new_rules]
        self.cards_t = -1.0
        self.t = 0.0
        self.go = ui.Button((WIDTH - 310, 652, 280, 56), "", C_ACCENT, size=24,
                            parts=[("심사 시작 ", sticker.WHITE), ("GO!", sticker.YELLOW)])
        sfx.play("pop", 0.5)

    def _advance(self):
        if not self.tw.done:
            self.tw.skip()
        elif self.line < len(self.lines) - 1:
            self.line += 1
            self.tw.set(self.lines[self.line], 38)
            self.chief.expression = "neutral" if self.line % 2 else "happy"
            self.chief.set_pose("point" if self.line % 2 else "hip")
            sfx.play("pop", 0.5)
        elif self.cards_t < 0:
            self._show_cards()

    def _show_cards(self):
        self.cards_t = 0.0
        self.chief.set_pose("point")
        sfx.play("paper", 0.6)

    def handle_event(self, event):
        if self.cards_t >= 0 and self.go.clicked(event):
            self.app.start_day()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._advance()
        elif event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_RETURN):
            if self.cards_t >= 0:
                self.app.start_day()
            else:
                self._advance()

    def update(self, dt):
        self.t += dt
        self.chief.update(dt)
        self.tw.update(dt)
        self.go.update(dt)
        if self.tw.done and self.line == len(self.lines) - 1 and self.cards_t < 0 and self.tw.age > 0.8:
            self._show_cards()
        if self.cards_t >= 0:
            self.cards_t += dt

    def draw(self, surf):
        month, day = int(self.cfg["date"][5:7]), int(self.cfg["date"][8:10])
        props.draw_wall(surf, WALL_H, self.t, 0.0)
        props.draw_window(surf, (60, 60, 230, 180), self.t, 0.0)
        props.draw_calendar(surf, (1010, 44, 120, 136), month, day, f"{self.cfg['day']}일차")
        props.draw_clock(surf, (1200, 112), 52, 530 + min(10, self.t), 0, self.t)
        pol = self.cfg.get("policy")
        if pol:                                                  # 벽에 건 '오늘의 정책' 현수막
            ban = pygame.Rect(376, 44, 600, 124)
            for dx in (60, ban.w - 60):
                pygame.draw.line(surf, C_INK, (ban.x + dx, 0), (ban.x + dx, ban.y + 4), 4)
            props.box(surf, ban, (255, 250, 236), radius=12, offset=(5, 6))
            pygame.draw.rect(surf, C_ACCENT, (ban.x, ban.y, ban.w, 34), border_top_left_radius=12, border_top_right_radius=12)
            pygame.draw.rect(surf, C_INK, ban, 3, border_radius=12)
            ui.draw_text(surf, "오늘의 조달 정책", (ban.centerx, ban.y + 17), 16, C_WHITE, True, center=True)
            ui.draw_text(surf, pol["name"], (ban.centerx, ban.y + 62), 27, C_INK, "heavy", center=True)
            ui.draw_text(surf, pol["slogan"], (ban.centerx, ban.y + 98), 16, C_INK_SOFT, True, center=True)
        self.chief.draw(surf, (250, 178), scale=1.15)
        props.draw_counter(surf, WALL_H)
        props.draw_plant(surf, 470, WALL_H + 4, self.t)
        props.draw_desk(surf, WALL_H + 34)

        plate = pygame.Rect(0, 0, 190, 34)                       # 과장님 명패
        plate.midbottom = (250, WALL_H + 14)
        props.box(surf, plate, (255, 214, 120), radius=5, offset=(3, 4))
        ui.draw_text(surf, self.chief_name, plate.center, 16, C_INK, True, center=True)

        ui.speech_bubble(surf, (420, 214, 820, 150), self.tw, tail=(384, 312), size=22)
        if not self.tw.done or self.cards_t < 0:
            ui.draw_text(surf, "클릭해서 계속", (1218, 334), 14, C_INK_SOFT, True, anchor="topright")

        # 책상에 내려놓는 새 규정 쪽지
        if self.cards_t >= 0:
            sign = pygame.Rect(40, 500, 336, 60)
            props.box(surf, sign, (255, 253, 247), radius=8)
            text = "오늘 새로 생긴 규정이에요 →" if self.new_rules else "오늘은 모든 규정이 적용돼요!"
            ui.draw_text(surf, text, sign.center, 19, C_INK, True, center=True)
            n = max(1, len(self.notes))
            for i, img in enumerate(self.notes):
                k = ease_out_back((self.cards_t - i * 0.18) / 0.4, 1.5)
                if k <= 0.02:
                    continue
                cx = 420 + (820 / n) * (i + 0.5)
                rot = pygame.transform.rotozoom(img, NOTE_ANGLES[i % 4] + (1 - k) * 14, k / paper.SS)
                r = rot.get_rect(center=(cx, 556 + (1 - k) * -60))
                surf.blit(props.silhouette_shadow(rot, 60), r.move(5, 7))
                surf.blit(rot, r)
                if k > 0.95:
                    props.tape(surf, (r.centerx, r.y + 1), NOTE_ANGLES[i % 4] * 2, 50, 16)
            self.go.draw(surf)
