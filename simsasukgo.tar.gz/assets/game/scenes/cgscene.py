import math

import pygame

from .. import cg, sfx, sticker, ui
from ..anim import ease_out_back
from ..config import HEIGHT, WIDTH
from .base import Scene


class CGScene(Scene):
    """이벤트 CG 한 장을 보여 준다. 천천히 확대되고, 아래에 제목과 한 줄 설명.

    플레이 중: 지금 내 팀원이 동료 자리에 선다. 처음 본 CG 는 앨범(프로필)에 저장.
    앨범에서 볼 때(viewer=True): 넘겨받은 mates(해금한 동료 중 무작위)로 그리고 기록은 건드리지 않는다.
    """

    def __init__(self, app, cg_id, chief=None, mates=None, viewer=False, on_done=None, hero_look=None):
        super().__init__(app)
        self.spec = cg.CGS[cg_id]
        self.chief = chief or app.chief
        looks = mates if mates is not None else [m["look"] for m in app.state.team]
        self.img = cg.render(cg_id, app.data, self.chief, looks, with_caption=False, hero_look=hero_look)
        factory = self.spec["game"] == "factory"
        if factory:
            self.BGM = "factory"                             # 납품하GO의 CG 는 공장 음악 그대로
        self.viewer = viewer
        self.on_done = on_done
        self.new = False
        if not viewer:
            self.new = app.profile.mark_cg(cg_id)
            if not factory and cg_id not in app.state.run_cgs:
                app.state.run_cgs.append(cg_id)
        self.t = 0.0
        sfx.play("fanfare" if self.new else "pop", 0.6)

    def handle_event(self, event):
        click = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        key = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE)
        if (click or key) and self.t > 0.7:
            if self.on_done:
                self.on_done()
            else:
                self.app.proceed()

    def update(self, dt):
        self.t += dt

    def draw(self, surf):
        k = 1.0 + 0.035 * min(1.0, self.t / 7.0)                      # 아주 천천히 다가가는 화면
        img = self.img if k <= 1.001 else pygame.transform.smoothscale(self.img, (int(WIDTH * k), int(HEIGHT * k)))
        surf.blit(img, img.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20)))
        cg.caption(surf, self.spec["title"], self.spec["text"], None)
        if self.new:
            kk = ease_out_back((self.t - 0.3) / 0.35, 2.0)
            if kk > 0.05:
                badge = sticker.sticker_text("새 추억!", 40, sticker.YELLOW)
                badge = pygame.transform.rotozoom(badge, -8, min(1.0, kk))
                surf.blit(badge, badge.get_rect(center=(WIDTH - 130, 60)))
        if self.t > 0.9:
            a = (math.sin(self.t * 4) + 1) / 2
            ui.draw_text(surf, "클릭해서 계속 →", (WIDTH - 40, HEIGHT - 36), 16,
                         tuple(int(170 + 80 * a) for _ in range(3)), True, anchor="topright")
