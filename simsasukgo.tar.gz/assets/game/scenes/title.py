import math
import random

import pygame

from .. import device, fonts, props, save, sfx, sticker, ui
from ..character import Character
from ..config import C_ACCENT, C_BG, C_INK, C_INK_SOFT, C_REJECT, C_WALL_STRIPE, HEIGHT, WIDTH
from .base import Scene


class TitleScene(Scene):
    HOME = "hub"
    def __init__(self, app):
        super().__init__(app)
        lx, rx, w, h = WIDTH // 2 - 276, WIDTH // 2 + 16, 260, 58
        self.menu = {
            "new": ui.Button((lx, 304, w, h), "", C_ACCENT, size=24, parts=[("새로 시작 ", sticker.WHITE), ("GO!", sticker.YELLOW)]),
            "continue": ui.Button((rx, 304, w, h), "이어하기", (72, 142, 232), size=24),
            "album": ui.Button((lx, 380, w, h), "도감 보기", (84, 180, 110), size=24),
            "settings": ui.Button((rx, 380, w, h), "설정", (160, 140, 120), size=24),
        }
        self.quit = ui.Button((WIDTH - 150, 22, 120, 42), "처음으로", (190, 170, 150), size=16, float_amp=0)
        self.menu["continue"].enabled = app.has_save()
        self.web = app.device["web"]            # 웹에서는 '종료' 버튼이 없다
        self.save_info = save.summary(app.profile.dir, app.data.chiefs, app.data.levels) if app.has_save() else None
        comps = app.data.companies
        picks = random.sample([c for c in comps if not c["debarred"]], 2) + random.sample(app.data.debarred, 1)
        random.shuffle(picks)
        mascots = app.data.dialogue["mascots"]                 # 조달청 마스코트 나르미·달이가 양 끝에 선다
        self.cast = ([Character(mascots["narmi"]["look"])] + [Character(c["look"]) for c in picks]
                     + [Character(mascots["dali"]["look"])])
        exprs = ["happy", "neutral", "nervous", "sly", "happy"]
        self.moods = ["narmi", "neutral", "nervous", "sly", "dali"]       # 성격 → 누르면 하는 말이 다르다
        self.poses = ["wave", "idle", "shrug", "hip", "cheer"]
        for ch, e, pose in zip(self.cast, exprs, self.poses):
            ch.expression = e
            ch.set_pose(pose)
        self.chat = ui.Typewriter()
        self.chat_i = -1                # 지금 말하는 캐릭터
        self.chat_left = 0.0
        self.chat_last = {}
        self.t = 0.0

    def handle_event(self, event):
        m = self.menu
        if m["new"].clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self.app.to_select()
        elif m["continue"].clicked(event):
            self.app.continue_game()
        elif m["album"].clicked(event):
            self.app.to_album()
        elif m["settings"].clicked(event):
            self.app.to_settings()
        elif self.quit.clicked(event):
            self.app.to_hub()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(self.cast)):
                if self._cast_rect(i).collidepoint(event.pos):
                    self._talk(i)
                    break

    def _cast_rect(self, i):
        return pygame.Rect(190 + i * 225 - 92, 404, 184, 196)

    def _talk(self, i):
        pool = self.app.data.dialogue["title_chat"][self.moods[i]]
        line = random.choice([s for s in pool if s != self.chat_last.get(i)] or pool)
        self.chat_last[i] = line
        if self.chat_i >= 0 and self.chat_i != i:
            self.cast[self.chat_i].set_pose(self.poses[self.chat_i])
        self.chat_i = i
        self.chat.voice = self.cast[i].voice
        self.chat.set(line, 34)
        self.chat_left = 1.6 + len(line) * 0.07
        self.cast[i].set_pose({"narmi": "hi", "neutral": "point", "nervous": "shock", "sly": "hip", "dali": "clap"}[self.moods[i]])
        sfx.play("pop", 0.5)

    def update(self, dt):
        self.t += dt
        for ch in self.cast:
            ch.update(dt)
        for btn in self.menu.values():
            btn.update(dt)
        self.quit.update(dt)
        self.chat.update(dt)
        if self.chat_i >= 0 and self.chat.done:
            self.chat_left -= dt
            if self.chat_left <= 0:
                self.cast[self.chat_i].set_pose(self.poses[self.chat_i])
                self.chat_i = -1
                self.chat.set("")

    def _draw_logo(self, surf, cx, cy):
        """'심사숙GO!' — GO! 는 코랄색으로 통통 튀고, 아래에 '조달청' 리본."""
        f = fonts.get(92, "heavy")
        head = f.render("심사숙", True, C_INK)
        head_sh = f.render("심사숙", True, (230, 200, 160))
        go = f.render("GO!", True, C_ACCENT)
        go_sh = f.render("GO!", True, (214, 104, 66))
        total = head.get_width() + 6 + go.get_width()
        x0 = cx - total // 2
        top = cy - head.get_height() // 2
        surf.blit(head_sh, (x0 + 4, top + 6))
        surf.blit(head, (x0, top))
        # GO! 바운스 + 살짝 기울기
        bounce = abs(math.sin(self.t * 3.2)) * -10
        tilt = math.sin(self.t * 3.2) * 4
        gx = x0 + head.get_width() + 6
        for img, off in ((go_sh, (4, 6)), (go, (0, 0))):
            r = pygame.transform.rotozoom(img, tilt, 1.0)
            surf.blit(r, r.get_rect(center=(gx + go.get_width() // 2 + off[0], cy + bounce + off[1])))

        # 조달청 리본
        rib = pygame.Rect(0, 0, 170, 44)
        rib.center = (cx, cy + 72)
        ui.pill(surf, rib, "조달청", C_ACCENT, (255, 255, 255), 24)
        ui.draw_text(surf, "계약심사과 신임 심사관 근무 일지", (cx, cy - 66), 18, C_INK_SOFT, True, center=True)

        # '공정' 도장
        stamp_c = (cx + total // 2 + 58, cy - 34)
        pygame.draw.circle(surf, C_REJECT, stamp_c, 40, 5)
        pygame.draw.circle(surf, C_REJECT, stamp_c, 31, 2)
        ui.draw_text(surf, "공정", stamp_c, 21, C_REJECT, True, center=True)

    def draw(self, surf):
        # 조달청 로비: 벽 + 창문 + 시계, 카운터 뒤에 줄 선 업체들
        props.draw_wall(surf, 600, self.t, 0.0)
        props.draw_window(surf, (64, 96, 210, 150), self.t, 0.0)
        props.draw_clock(surf, (1160, 150), 52, 540 + (self.t * 2) % 60, 0, self.t)
        for i, ch in enumerate(self.cast):
            ch.draw(surf, (190 + i * 225, 408 + int(math.sin(self.t * 2 + i) * 3)), scale=0.95)
        props.draw_counter(surf, 600)
        props.draw_plant(surf, 1232, 604, self.t)
        props.draw_desk(surf, 634)

        # 천장에 매단 간판
        board = pygame.Rect(WIDTH // 2 - 330, 22, 660, 262)
        for dx in (-240, 240):
            pygame.draw.line(surf, C_INK, (WIDTH // 2 + dx, 0), (WIDTH // 2 + dx, board.y + 4), 5)
        props.box(surf, board, (255, 250, 238), radius=18, shade=(244, 230, 206), offset=(7, 9))

        # 로고
        k = min(1.0, self.t / 0.6)
        y = 112 - (1 - k) * 12
        self._draw_logo(surf, WIDTH // 2, int(y))
        ui.draw_text(surf, "공정한 도장 하나가 국민의 세금을 지킨다", (WIDTH // 2, y + 128), 22, C_INK, center=True)
        for btn in self.menu.values():
            btn.draw(surf)
        self.quit.draw(surf)
        if self.save_info:
            c = self.menu["continue"].rect
            ui.pill(surf, (c.centerx - 150, 446, 300, 24), f"이어하기: {self.save_info}", (255, 250, 236), C_INK, 12)
        ui.draw_text(surf, "M 키: 소리 끄기/켜기   ·   Esc: 처음으로", (WIDTH - 16, HEIGHT - 26), 13,
                     (120, 80, 50), anchor="midright")
        ui.pps_logo(surf, (24, 22), 36)
        ui.draw_text(surf, "2026 조달청 AI 게임·콘텐츠 공모전 출품작", (WIDTH // 2, HEIGHT - 26), 14,
                     (120, 80, 50), center=True)
        if self.chat_i >= 0:                                  # 누른 캐릭터의 한마디 (책상 위에 말풍선)
            x = 190 + self.chat_i * 225
            bx = max(16, min(WIDTH - 396, x - 190))
            ui.speech_bubble(surf, (bx, 608, 380, 74), self.chat, tail=(x, 588), size=16)
