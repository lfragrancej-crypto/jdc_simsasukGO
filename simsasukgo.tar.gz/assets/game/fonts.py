"""한글 폰트 로더.

우선순위: assets/fonts 의 나눔스퀘어라운드(번들됨) → 나눔고딕 → Windows 맑은 고딕
제출 빌드에는 반드시 assets/fonts 에 재배포 가능한 폰트를 넣을 것.
"""
import os

import pygame

from .config import ASSET_DIR

_CANDIDATES = {
    False: [
        os.path.join(ASSET_DIR, "fonts", "NanumSquareRoundR.ttf"),
        os.path.join(ASSET_DIR, "fonts", "NanumGothic.ttf"),
        r"C:\Windows\Fonts\malgun.ttf",
    ],
    True: [
        os.path.join(ASSET_DIR, "fonts", "NanumSquareRoundB.ttf"),
        os.path.join(ASSET_DIR, "fonts", "NanumGothicBold.ttf"),
        os.path.join(ASSET_DIR, "fonts", "NanumGothic.ttf"),
        r"C:\Windows\Fonts\malgunbd.ttf",
        r"C:\Windows\Fonts\malgun.ttf",
    ],
    "heavy": [   # 타이틀 로고 등 아주 굵은 글씨
        os.path.join(ASSET_DIR, "fonts", "NanumSquareRoundEB.ttf"),
        os.path.join(ASSET_DIR, "fonts", "NanumSquareRoundB.ttf"),
        r"C:\Windows\Fonts\malgunbd.ttf",
    ],
}
_cache: dict[tuple, pygame.font.Font] = {}


def get(size: int, bold: "bool | str" = False) -> pygame.font.Font:
    """bold: False=보통, True=굵게, 'heavy'=아주 굵게."""
    key = (size, bold)
    if key not in _cache:
        path = next((p for p in _CANDIDATES[bold] if os.path.exists(p)), None)
        _cache[key] = pygame.font.Font(path, size)
    return _cache[key]
