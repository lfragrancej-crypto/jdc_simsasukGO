"""이어하기용 저장 — 하루를 시작할 때마다 자동 저장한다 (그 날 아침 브리핑부터 다시 시작).

저장 위치: 플레이 기록(profile.json)과 같은 곳의 save.json (웹은 브라우저 localStorage). 엔딩을 보면 지운다.
"""
import json

from . import storage
from .state import DayStats, GameState


NAME = "save.json"


def exists(directory: str) -> bool:
    return storage.exists(directory, NAME)


def delete(directory: str):
    storage.delete(directory, NAME)


def write(directory: str, state: GameState, chief_id: str):
    data = {
        "chief": chief_id,
        "day_index": state.day_index,
        "level": state.level,
        "team": state.team,
        "run_cgs": state.run_cgs,
        "money": state.money,
        "stress": state.stress,
        "life_seen": state.life_seen,
        "health": state.health,
        "bond": state.bond,
        "fixed": state.fixed,
        "buff": state.buff,
        "history": [vars(d) for d in state.history],
    }
    storage.write(directory, NAME, json.dumps(data, ensure_ascii=False))


def read(directory: str, chiefs: list[dict]) -> GameState | None:
    text = storage.read(directory, NAME)
    if not text:
        return None
    try:
        data = json.loads(text)
        chief = next(c for c in chiefs if c["id"] == data["chief"])
        return GameState(day_index=data["day_index"], level=data["level"], team=data["team"], chief=chief,
                         run_cgs=data.get("run_cgs", []), money=data.get("money", 50), stress=data.get("stress", 20),
                         life_seen=data.get("life_seen", []), health=data.get("health", 70), bond=data.get("bond", 50),
                         fixed=data.get("fixed", {}), buff=data.get("buff"), history=[DayStats(**d) for d in data["history"]])
    except (ValueError, KeyError, StopIteration, TypeError):
        return None


def summary(directory: str, chiefs: list[dict], levels: list[dict]) -> str | None:
    """이어하기 버튼 아래에 보여 줄 한 줄 요약."""
    st = read(directory, chiefs)
    if st is None:
        return None
    return f"{st.chief['difficulty']} · {st.day_index + 1}일차 · {st.level_info(levels)['title']}"
