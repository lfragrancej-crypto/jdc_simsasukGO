"""진짜 종이 같은 서류.

- render_doc(): 서류 종류마다 다른 양식(색, 테두리, 직인, 서명 낙서)으로 그린 종이 한 장
- Paper: 책상 위에 살짝 비뚤게 놓이고, 마우스로 집어 옮길 수 있는 종이 (스프링처럼 부드럽게 따라옴)
- render_notice / render_debarred / render_howto: 클립보드에 끼우는 종이들

종이는 2배 해상도로 그려 두고 회전할 때 줄여서, 기울어져도 글씨가 덜 뭉개진다.
"""
import math
import random
from datetime import date, time

import pygame

from . import fonts, ui
from .character import Character
from .config import C_APPROVE, C_REJECT, HEIGHT, WIDTH
from .props import INK, INK_SOFT, RED, silhouette_shadow

SS = 2
PW, PH = 224, 196            # 서류 한 장의 화면 크기

STYLE = {
    "bid_form":          {"title": "입  찰  서",         "tint": (255, 253, 247), "accent": (74, 52, 40)},
    "registration":      {"title": "입찰참가자격 등록증", "tint": (240, 250, 236), "accent": (64, 140, 88),
                          "frame": True, "seal": "조달", "foot": "국가종합전자조달 나라장터"},
    "guarantee":         {"title": "입 찰 보 증 서",     "tint": (236, 245, 255), "accent": (62, 112, 196),
                          "seal": "보증", "foot": "튼튼보증(주)"},
    "direct_production": {"title": "직접생산확인증명서",  "tint": (255, 248, 224), "accent": (196, 132, 30),
                          "frame": True, "seal": "확인", "foot": "중소기업 직접생산 확인"},
    "integrity":         {"title": "청렴계약 이행서약서", "tint": (255, 241, 243), "accent": (206, 84, 108)},
}


def fmt(value) -> str:
    if isinstance(value, bool):
        return "서명함" if value else "(서명 없음)"
    if isinstance(value, int):
        return ui.won(value)
    if isinstance(value, date):
        return value.strftime("%Y.%m.%d")
    if isinstance(value, time):
        return value.strftime("%H:%M")
    return str(value)


def _t(s, text, x, y, size, color=INK, bold=False, anchor="topleft", k=SS):
    img = fonts.get(int(size * k), bold).render(str(text), True, color)
    r = img.get_rect()
    setattr(r, anchor, (int(x * k), int(y * k)))
    s.blit(img, r)
    return r


def _seal(text, radius=20, k=SS, angle=-12, color=RED, alpha=200):
    d = (radius * 2 + 8) * k
    s = pygame.Surface((d, d), pygame.SRCALPHA)
    c = (d // 2, d // 2)
    pygame.draw.circle(s, (*color, alpha), c, radius * k, 3 * k)
    pygame.draw.circle(s, (*color, alpha // 2), c, int(radius * k * 0.78), k)
    img = fonts.get(int(radius * 0.72 * k), True).render(text, True, color)
    img.set_alpha(alpha)
    s.blit(img, img.get_rect(center=c))
    return pygame.transform.rotozoom(s, angle, 1.0)


def stamp_mark(approved: bool, k=1.0) -> pygame.Surface:
    """심사 도장 자국 — '적 격' 파랑 / '부적격' 빨강."""
    text, color = ("적 격", C_APPROVE) if approved else ("부적격", C_REJECT)
    s = pygame.Surface((220, 110), pygame.SRCALPHA)
    pygame.draw.rect(s, (*color, 230), (4, 4, 212, 102), 8, border_radius=30)
    pygame.draw.rect(s, (*color, 160), (17, 17, 186, 76), 3, border_radius=22)
    img = fonts.get(46, "heavy").render(text, True, color)
    s.blit(img, img.get_rect(center=(110, 56)))
    return pygame.transform.rotozoom(s, 12, k)


def _signature(s, x, y, seed):
    """파란 펜으로 휘갈긴 서명."""
    rng = random.Random(seed)
    pts, px = [], x
    amp = rng.uniform(7, 10)
    for i in range(26):
        px += rng.uniform(2.2, 4.2)
        py = y + math.sin(i * rng.uniform(0.8, 1.3)) * amp * (1 - i / 40) - (4 if i % 5 == 0 else 0)
        pts.append((px * SS, py * SS))
    pygame.draw.lines(s, (52, 78, 170), False, pts, 2 * SS)
    pygame.draw.line(s, (52, 78, 170), (x * SS, (y + 9) * SS), ((px + 6) * SS, (y + 5) * SS), SS + 1)


def render_doc(key: str, fields: dict, mark: bool | None = None) -> pygame.Surface:
    st = STYLE[key]
    w, h = PW * SS, PH * SS
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    tint, accent = st["tint"], st["accent"]
    ear = 15 * SS
    body = [(1, 1), (w - ear, 1), (w - 2, ear), (w - 2, h - 2), (1, h - 2)]
    pygame.draw.polygon(s, tint, body)
    # 아래쪽 셀 셰이딩 띠
    pygame.draw.rect(s, tuple(max(0, c - 14) for c in tint), (3, h - 20 * SS, w - 6, 18 * SS))
    if st.get("frame"):
        fr = pygame.Rect(6 * SS, 6 * SS, w - 12 * SS, h - 12 * SS)
        pygame.draw.rect(s, accent, fr, SS, border_radius=4 * SS)
        pygame.draw.rect(s, tuple(min(255, c + 70) for c in accent), fr.inflate(-5 * SS, -5 * SS), SS, border_radius=3 * SS)
    # 접힌 귀퉁이
    tri = [(w - ear, 1), (w - ear, ear), (w - 2, ear)]
    pygame.draw.polygon(s, tuple(max(0, c - 34) for c in tint), tri)
    pygame.draw.polygon(s, INK, body, 5)
    pygame.draw.lines(s, INK, False, tri, 4)

    _t(s, st["title"], PW / 2, 11, 15, accent, True, "midtop")
    pygame.draw.line(s, accent, (16 * SS, 33 * SS), ((PW - 16) * SS, 33 * SS), 2 * SS)
    pygame.draw.line(s, accent, (16 * SS, 36 * SS), ((PW - 16) * SS, 36 * SS), 1)

    y = 43
    row_h = 24
    hair = tuple(max(0, c - 26) for c in tint)
    for name, value in fields.items():
        if key == "integrity" and name == "서명":
            continue
        _t(s, name, 14, y + 3, 12.5, INK_SOFT)
        if name == "제출시각":                                   # 접수 도장 느낌의 파란 네모
            r = _t(s, f"접수 {fmt(value)}", 92, y + 2, 13.5, (52, 96, 190), True)
            pygame.draw.rect(s, (52, 96, 190), r.inflate(8 * SS, 3 * SS), SS + 1, border_radius=3 * SS)
        else:
            _t(s, fmt(value), 86, y + 1, 14, INK, True)
        pygame.draw.line(s, hair, (12 * SS, (y + row_h - 2) * SS), ((PW - 12) * SS, (y + row_h - 2) * SS), 1)
        y += row_h

    if key == "integrity":
        for i, line in enumerate(("입찰·계약 과정에서 금품·향응을", "주고받지 않을 것을 서약합니다.")):
            _t(s, line, PW / 2, y + 6 + i * 17, 12, INK, False, "midtop")
        ly = PH - 34
        _t(s, "서약자", 16, ly - 14, 12.5, INK_SOFT)
        for x in range(74, PW - 46, 7):                           # 서명란 점선
            pygame.draw.line(s, INK_SOFT, (x * SS, (ly + 6) * SS), ((x + 3) * SS, (ly + 6) * SS), SS)
        if fields.get("서명"):
            _signature(s, 78, ly - 4, fields.get("상호", ""))
            seal = _seal("인", 11, angle=8)
            s.blit(seal, seal.get_rect(center=((PW - 28) * SS, (ly - 2) * SS)))
        else:
            _t(s, "(서명)", PW - 30, ly - 12, 11, tuple(min(255, c + 60) for c in INK_SOFT), False, "midtop")
    else:
        if st.get("foot"):
            _t(s, st["foot"], 14, PH - 24, 11, accent, True)
        if st.get("seal"):
            seal = _seal(st["seal"], 19)
            s.blit(seal, seal.get_rect(center=((PW - 34) * SS, (PH - 36) * SS)))
    if key == "bid_form":                                       # 클립
        pygame.draw.rect(s, (150, 156, 170), (16 * SS, 0, 9 * SS, 26 * SS), 2 * SS, border_radius=5 * SS)
        pygame.draw.rect(s, (150, 156, 170), (19 * SS, 0, 4 * SS, 18 * SS), SS + 1, border_radius=3 * SS)

    if mark is not None:
        m = stamp_mark(mark, 0.62 * SS)
        s.blit(m, m.get_rect(center=((PW - 76) * SS, (PH - 46) * SS)))
    return s


def render_note(title: str, body: str, size=(250, 150), tint=(255, 253, 247), tag: str | None = None) -> pygame.Surface:
    """브리핑 화면의 새 규정 쪽지 등 범용 종이 (2배 해상도)."""
    w, h = size[0] * SS, size[1] * SS
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(s, tint, (1, 1, w - 2, h - 2), border_radius=5 * SS)
    pygame.draw.rect(s, tuple(max(0, c - 14) for c in tint), (3, h - 16 * SS, w - 6, 14 * SS),
                     border_bottom_left_radius=5 * SS, border_bottom_right_radius=5 * SS)
    pygame.draw.rect(s, INK, (1, 1, w - 2, h - 2), 5, border_radius=5 * SS)
    x = 14
    if tag:
        tr = pygame.Rect(12 * SS, 12 * SS, 46 * SS, 20 * SS)
        pygame.draw.rect(s, (255, 138, 92), tr, border_radius=10 * SS)
        pygame.draw.rect(s, INK, tr, SS + 1, border_radius=10 * SS)
        _t(s, tag, 35, 22, 11, (255, 255, 255), True, "center")
        x = 64
    _t(s, title, x, 12, 15.5, INK, True)
    pygame.draw.line(s, (236, 224, 204), (12 * SS, 40 * SS), ((size[0] - 12) * SS, 40 * SS), 2 * SS)
    yy = 48
    for line in ui.wrap(body, int(13.5 * SS), (size[0] - 28) * SS):
        _t(s, line, 14, yy, 13.5)
        yy += 19
    return s


def flag_doc(surf: pygame.Surface) -> pygame.Surface:
    """눈썰미 좋은 동료가 붙여 둔 '?' 포스트잇 깃발."""
    out = surf.copy()
    tab = pygame.Rect(out.get_width() - 62 * SS, 2 * SS, 40 * SS, 30 * SS)
    pygame.draw.rect(out, (255, 150, 60), tab, border_radius=5 * SS)
    pygame.draw.rect(out, INK, tab, SS + 2, border_radius=5 * SS)
    img = fonts.get(22 * SS, "heavy").render("?", True, (255, 255, 255))
    out.blit(img, img.get_rect(center=tab.center))
    return out


DECOY_SIZE = (156, 168)


def render_decoy(decoy: dict) -> pygame.Surface:
    """심사와 상관없는 덤 종이 (영수증·쪽지 등). 점선 테두리의 작은 종이."""
    w, h = DECOY_SIZE[0] * SS, DECOY_SIZE[1] * SS
    tint = tuple(int(decoy.get("tint", "#FFFFFF").lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(s, tint, (1, 1, w - 2, h - 2), border_radius=3 * SS)
    pygame.draw.rect(s, tuple(max(0, c - 16) for c in tint), (3, h - 15 * SS, w - 6, 13 * SS))
    for x in range(8 * SS, w - 10 * SS, 9 * SS):                  # 점선 테두리
        for y in (7 * SS, h - 8 * SS):
            pygame.draw.line(s, INK_SOFT, (x, y), (x + 5 * SS, y), SS)
    pygame.draw.rect(s, INK, (1, 1, w - 2, h - 2), 5, border_radius=3 * SS)
    _t(s, decoy["title"], DECOY_SIZE[0] / 2, 16, 15, INK, True, "midtop")
    pygame.draw.line(s, INK_SOFT, (16 * SS, 40 * SS), (w - 16 * SS, 40 * SS), SS)
    y = 50
    for line in decoy["lines"]:
        _t(s, line, DECOY_SIZE[0] / 2, y, 12.5, INK, False, "midtop")
        y += 24
    return s


# ------------------------------------------------------------------ 책상 위 종이 한 장
class Paper:
    def __init__(self, key, surf, home, angle, start, delay=0.0):
        self.key = key
        self.base = surf                     # 2배 해상도 원본
        self.w, self.h = surf.get_width() / SS, surf.get_height() / SS
        self.x, self.y = start
        self.scale = 0.2
        self.angle = angle + random.uniform(-40, 40)
        self.home = list(home)
        self.home_angle = angle
        self.tx, self.ty = home
        self.tangle = angle
        self.tscale = 1.0
        self.lift = 0.0
        self.tlift = 0.0
        self.delay = delay
        self.dragging = False
        self._key = None
        self._img = self._shadow = None

    def set_surface(self, surf):
        self.base = surf
        self._key = None

    def rect(self) -> pygame.Rect:
        r = pygame.Rect(0, 0, int(self.w * self.scale), int(self.h * self.scale))
        r.center = (int(self.x), int(self.y))
        return r

    def hit(self, pos) -> bool:
        return self.delay <= 0 and self.rect().collidepoint(pos)

    def hover(self, on: bool):
        if self.dragging:
            return
        self.tangle = 0.0 if on else self.home_angle
        self.tscale = 1.06 if on else 1.0
        self.tlift = 6.0 if on else 0.0

    def grab(self):
        self.dragging = True
        self.tangle, self.tscale, self.tlift = 0.0, 1.1, 12.0

    def drop(self):
        self.dragging = False
        self.tx = max(130, min(WIDTH - 130, self.tx))
        self.ty = max(340, min(HEIGHT - 60, self.ty))
        self.home = [self.tx, self.ty]
        self.home_angle = random.uniform(-3.0, 3.0)
        self.hover(False)

    def fly_out(self, delay=0.0):
        self.dragging = False
        self.delay = delay
        self.tx += random.uniform(-60, 60)
        self.ty = HEIGHT + 220
        self.tangle = self.angle + random.uniform(-30, 30)
        self.tscale, self.tlift = 1.0, 0.0

    def update(self, dt):
        if self.delay > 0:
            self.delay -= dt
            return
        k = min(1.0, dt * (22 if self.dragging else 11))
        self.x += (self.tx - self.x) * k
        self.y += (self.ty - self.y) * k
        self.angle += (self.tangle - self.angle) * min(1.0, dt * 12)
        self.scale += (self.tscale - self.scale) * min(1.0, dt * 13)
        self.lift += (self.tlift - self.lift) * min(1.0, dt * 14)

    def draw(self, surf):
        if self.delay > 0 and self.scale < 0.25:
            return
        key = (round(self.angle * 3) / 3, round(self.scale * 60) / 60)
        if key != self._key:
            self._img = pygame.transform.rotozoom(self.base, key[0], key[1] / SS)
            self._shadow = silhouette_shadow(self._img, 62)
            self._key = key
        r = self._img.get_rect(center=(int(self.x), int(self.y - self.lift)))
        surf.blit(self._shadow, r.move(4 + self.lift * 0.6, 5 + self.lift * 1.6))
        surf.blit(self._img, r)


# ------------------------------------------------------------------ 클립보드 종이
def _page(size, tint=(255, 253, 247)):
    s = pygame.Surface(size)
    s.fill(tint)
    pygame.draw.rect(s, tuple(max(0, c - 12) for c in tint), (0, size[1] - 26, size[0], 26))
    return s


def render_notice(notice, size) -> pygame.Surface:
    w, h = size
    s = _page(size)
    ui.draw_text(s, "조달청 공고", (w // 2, 16), 12, INK_SOFT, True, center=True)
    ui.draw_text(s, "입 찰 공 고", (w // 2, 40), 22, INK, "heavy", center=True)
    pygame.draw.line(s, INK, (14, 60), (w - 14, 60), 3)
    pygame.draw.line(s, INK, (14, 65), (w - 14, 65), 1)
    rows = [
        ("공고번호", notice.notice_no, INK, False),
        ("품목 · 수량", f"{notice.item} {notice.qty:,}{notice.unit}", INK, False),
        ("예정가격", ui.won(notice.est_price), (196, 60, 50), True),
        ("입찰마감 (접수 종료)", "오늘 " + notice.deadline.strftime("%H:%M") + " 까지", (196, 60, 50), True),
    ]
    y = 76
    for label, value, color, hl in rows:
        ui.draw_text(s, label, (16, y), 12, INK_SOFT, True)
        if hl:                                                  # 형광펜
            tw = fonts.get(16, True).size(value)[0]
            pygame.draw.rect(s, (255, 236, 130), (13, y + 20, tw + 8, 16), border_radius=4)
        ui.draw_text(s, value, (16, y + 16), 16, color, True)
        y += 44
    ui.draw_text(s, "구분", (16, y), 12, INK_SOFT, True)
    for i, (label, on) in enumerate((("중소기업자간 경쟁제품", notice.sme_only), ("일반 경쟁입찰", not notice.sme_only))):
        by = y + 18 + i * 22
        pygame.draw.rect(s, INK, (16, by, 14, 14), 2)
        if on:
            pygame.draw.lines(s, (196, 60, 50), False, [(18, by + 6), (22, by + 11), (31, by - 3)], 3)
        ui.draw_text(s, label, (36, by - 2), 14, INK, on)
    seal = _seal("조달", 19, k=1, angle=-10)                      # 조달청 직인
    s.blit(seal, seal.get_rect(center=(w - 30, 34)))
    return s


def render_debarred(companies, size) -> pygame.Surface:
    """부정당업자 명단 — 귀여운 '수배 전단'."""
    w, h = size
    s = _page(size, (255, 246, 236))
    ui.draw_text(s, "부정당업자 명단", (14, 12), 18, (196, 60, 50), "heavy")
    ui.draw_text(s, "아래 업체는 입찰 금지!", (15, 38), 12, INK, True)
    pygame.draw.line(s, (196, 60, 50), (14, 60), (w - 14, 60), 3)
    y = 72
    for c in companies:
        frame = pygame.Rect(14, y, 66, 66)
        pygame.draw.rect(s, (226, 232, 240), frame)
        for ly in range(frame.y + 12, frame.bottom, 14):         # 키 재는 줄
            pygame.draw.line(s, (196, 204, 216), (frame.x, ly), (frame.right, ly), 2)
        ch = Character(c["look"])
        ch.expression = "sly"
        face = pygame.transform.smoothscale(ch.render(), (74, 88))
        s.set_clip(frame)
        s.blit(face, face.get_rect(midtop=(frame.centerx, frame.y - 6)))
        s.set_clip(None)
        pygame.draw.rect(s, INK, frame, 3)
        ui.draw_text(s, c["name"], (88, y + 2), 15, INK, True)
        ui.draw_text(s, c["biz_no"], (88, y + 23), 13, INK)
        ui.draw_text(s, c.get("ban_reason", "제재 중"), (88, y + 44), 12, (196, 60, 50), True)
        y += 80
    stamp = _seal("제재", 19, k=1, angle=14)
    s.blit(stamp, stamp.get_rect(center=(w - 30, 30)))
    return s


def render_howto(size, has_list: bool) -> pygame.Surface:
    w, h = size
    s = _page(size, (246, 250, 255))
    ui.draw_text(s, "심사 요령", (w // 2, 26), 20, (52, 96, 190), "heavy", center=True)
    pygame.draw.line(s, (52, 96, 190), (14, 46), (w - 14, 46), 3)
    tips = [
        "서류끼리 상호·번호·금액·날짜를 맞대어 본다.",
        "공고문의 예정가격과 마감시각을 확인한다.",
        "이상하면 규정집에서 사유에 동그라미 → [부적격 NO!]",
        "문제가 없으면 [적격 GO!]",
        "서류는 끌어서 옮긴다. 상관없는 종이도 섞여 온다!",
    ]
    if has_list:
        tips.insert(2, "'명단' 탭에서 부정당업자를 확인한다.")
    y = 58
    for i, tip in enumerate(tips, 1):
        pygame.draw.circle(s, (52, 96, 190), (24, y + 9), 10)
        ui.draw_text(s, str(i), (24, y + 9), 13, (255, 255, 255), True, center=True)
        y = ui.draw_wrapped(s, tip, (42, y, w - 54, 80), 14) + 8
    ui.draw_text(s, "A 적격 · R 부적격 · M 소리", (w // 2, h - 14), 12, INK_SOFT, True, center=True)
    return s
