"""배경음악 — 장면마다 곡 이름을 정하면, 바뀔 때만 부드럽게 겹쳐 넘긴다.

음원: assets/music/<이름>.ogg  (tools/make_music.py 가 만든다. 곡 목록·제목은 data/music.json)

  play(name)      곡을 바꾼다 (앞 곡은 서서히 줄이고 새 곡은 서서히 키운다 — 뚝 끊지 않는다)
  gloom(초)       안 좋은 일이 생겼다: 잠깐 '흐린 날' 곡으로 넘어갔다가 돌아온다
  hold(이유, 참)  안 좋은 상황이 이어지는 동안 '흐린 날' 곡에 머문다 (예: 마감이 코앞)
  restart(name)   처음부터 다시 (박자를 맞춰야 하는 리듬 놀이용)

'흐린 날' 곡(<이름>_dark)은 밝은 곡과 빠르기·길이·음계가 같다. 두 곡을 처음부터 함께 틀어 놓고 소리 크기만
천천히 맞바꾸므로, 언제 넘어가도 박자가 어긋나지 않고 자연스럽다.

재생 장치는 두 가지다.
  - 웹: 브라우저의 소리 엔진(Web Audio)에 직접 맡긴다. 게임 화면이 잠깐 버벅여도 음악은 끊기지 않는다.
        (브라우저가 음원을 풀지 못하면 아래 방식으로 물러난다.)
  - PC·그 밖: pygame 믹서의 전용 채널 넷. 곡마다 채널 둘(밝은 곡·흐린 곡)을 쓴다.
"""
import os
import sys

import pygame

from . import sfx
from .config import ASSET_DIR

VOLUME = 0.62
KEEP = "="             # 장면의 BGM 이 이 값이면 지금 흐르는 곡을 그대로 둔다 (도감·설정·CG)
FADE = 0.9             # 곡을 바꿀 때 겹쳐 넘기는 시간(초)
MOOD_FADE = 1.8        # 밝은 곡 ↔ 흐린 곡을 맞바꾸는 시간(초)
master = 0.7           # 설정의 배경음악 크기 (0~1)
on_heard = None        # 곡이 들리기 시작하면 불린다 (도감의 '음악' 탭에 올리려고): on_heard(곡 이름)

_current: str | None = None
_dark: str | None = None       # 지금 곡의 흐린 날 짝 (없으면 None)
_mood = 0.0                    # 0 = 밝은 곡, 1 = 흐린 곡
_gloom = 0.0                   # 흐린 곡에 머물 남은 시간
_holds: set = set()            # 흐린 곡에 머무는 이유들
_paused = False
_backend = None
_check = 0.0


def path(name: str) -> str | None:
    p = os.path.join(ASSET_DIR, "music", f"{name}.ogg")
    return p if os.path.exists(p) else None


def _level() -> float:
    return 0.0 if sfx.muted else VOLUME * master


def _heard(name):
    if on_heard and name:
        try:
            on_heard(name)
        except Exception:
            pass


# ------------------------------------------------------------------ PC: pygame 믹서
class _Mixer:
    """전용 채널 넷(0~3)을 '덱' 둘로 나눠 쓴다. 덱 하나 = 밝은 곡 채널 + 흐린 곡 채널."""
    CHANNELS = 4

    def __init__(self):
        pygame.mixer.set_reserved(self.CHANNELS)               # 효과음이 이 채널을 가져가지 못하게
        self.decks = []                                         # {"name", "ch": [밝은, 흐린|None], "gain", "to", "rate"}
        self.sounds = {}

    def _sound(self, name):
        if name not in self.sounds:
            if len(self.sounds) >= 6:                           # 오래된 것부터 버린다 (지금 틀고 있는 곡은 빼고)
                live = {n for d in self.decks for n in d["names"]}
                for old in [n for n in self.sounds if n not in live][:2]:
                    del self.sounds[old]
            self.sounds[name] = pygame.mixer.Sound(path(name))
        return self.sounds[name]

    def play(self, name, dark, fade, restart=False):
        for d in self.decks:
            d["to"], d["rate"] = 0.0, 1.0 / max(0.04, 0.04 if restart else fade)
        while len(self.decks) >= 2:                             # 덱은 둘뿐: 가장 오래된 것을 바로 비운다
            self._drop(self.decks.pop(0))
        if not name:
            return
        used = {c for d in self.decks for c in d["ids"]}
        ids = [c for c in range(self.CHANNELS) if c not in used][:2]
        deck = {"name": name, "names": [name] + ([dark] if dark else []), "ids": ids, "ch": [],
                "gain": 1.0 if restart or fade <= 0 else 0.0, "to": 1.0, "rate": 1.0 / max(0.04, fade)}
        sounds = [self._sound(n) for n in deck["names"]]
        for cid, snd in zip(ids, sounds):                       # 두 채널을 같은 순간에 시작한다 → 박자가 겹친다
            ch = pygame.mixer.Channel(cid)
            ch.set_volume(0.0)
            ch.play(snd, loops=-1)
            deck["ch"].append(ch)
        self.decks.append(deck)
        self.update(0.0)

    @staticmethod
    def _drop(deck):
        for ch in deck["ch"]:
            ch.fadeout(50)

    def update(self, dt):
        level = _level()
        for d in self.decks[:]:
            step = d["rate"] * dt
            d["gain"] = min(d["to"], d["gain"] + step) if d["gain"] < d["to"] else max(d["to"], d["gain"] - step)
            if d["to"] == 0.0 and d["gain"] <= 0.0:
                for ch in d["ch"]:
                    ch.stop()                                   # 이미 소리가 0 이라 끊겨도 들리지 않는다
                self.decks.remove(d)
                continue
            mood = _mood if len(d["ch"]) > 1 and d["to"] > 0 else d.get("mood", 0.0)
            d["mood"] = mood
            d["ch"][0].set_volume(level * d["gain"] * (1 - mood))
            if len(d["ch"]) > 1:
                d["ch"][1].set_volume(level * d["gain"] * mood)

    def mood(self, value):
        pass                                                    # update 가 매번 _mood 를 읽어 반영한다

    def volume(self):
        self.update(0.0)

    def pause(self, on):
        for d in self.decks:
            for ch in d["ch"]:
                ch.pause() if on else ch.unpause()

    def position(self):
        return None                                             # 정확한 재생 위치는 알 수 없다 → 게임 시계를 쓴다

    def preload(self, name):
        pass

    def healthy(self):
        return True

    def stop(self):
        for d in self.decks:
            self._drop(d)
        self.decks = []


# ------------------------------------------------------------------ 웹: 브라우저의 소리 엔진
WEB_JS = r"""
(function(){
  if (window.jdcMusic) return;
  var AC = window.AudioContext || window.webkitAudioContext;
  var M = {ok: !!AC && !!window.FS, failed: false, ctx: null, out: null, buf: {}, wait: {}, want: null, cur: null,
           vol: 0.4, moodv: 0, paused: false};
  function ctx(){
    if (!M.ctx) {
      try { M.ctx = new AC({sampleRate: 44100, latencyHint: 'interactive'}); } catch (e) { M.ctx = new AC(); }
      M.out = M.ctx.createGain(); M.out.gain.value = M.vol; M.out.connect(M.ctx.destination);
    }
    return M.ctx;
  }
  function wake(){ if (M.ctx && M.ctx.state === 'suspended' && !M.paused && !document.hidden) { try { M.ctx.resume(); } catch (e) {} } }
  ['pointerdown', 'keydown', 'touchend', 'click'].forEach(function(e){ window.addEventListener(e, wake, true); });
  document.addEventListener('visibilitychange', function(){
    if (!M.ctx) return;
    if (document.hidden) { try { M.ctx.suspend(); } catch (e) {} } else wake();
  });
  function level(p){                      // 지금 값 (바뀌는 도중의 값을 브라우저가 알려 주지 않는 경우가 있어 직접 셈한다)
    var a = p._r; if (!a) return p.value;
    var t = M.ctx.currentTime;
    if (t >= a.t1) return a.v1;
    if (t <= a.t0) return a.v0;
    return a.v0 + (a.v1 - a.v0) * (t - a.t0) / (a.t1 - a.t0);
  }
  function ramp(p, to, sec){
    var t = M.ctx.currentTime, v = level(p);
    sec = Math.max(0.02, sec);
    try { p.cancelScheduledValues(t); } catch (e) {}
    p.setValueAtTime(v, t);
    p.linearRampToValueAtTime(to, t + sec);
    p._r = {v0: v, v1: to, t0: t, t1: t + sec};
  }
  function start(id, dark, fade){
    var c = ctx(), t = c.currentTime + 0.04;
    var g = c.createGain(); g.gain.value = fade > 0 ? 0 : 1; g.connect(M.out);
    if (fade > 0) ramp(g.gain, 1, fade);
    var d = {id: id, g: g, src: [], mix: [], t0: t};
    [id, dark].forEach(function(n, i){
      if (!n) return;
      var s = c.createBufferSource(); s.buffer = M.buf[n]; s.loop = true;
      var m = c.createGain(); m.gain.value = i ? M.moodv : (dark ? 1 - M.moodv : 1);
      s.connect(m); m.connect(g); s.start(t);
      d.src.push(s); d.mix.push(m);
    });
    return d;
  }
  function stop(d, fade){
    var t = M.ctx.currentTime; fade = Math.max(0.03, fade);
    ramp(d.g.gain, 0, fade);
    d.src.forEach(function(s){ try { s.stop(t + fade + 0.06); } catch (e) {} });
    setTimeout(function(){ try { d.g.disconnect(); } catch (e) {} }, (fade + 0.4) * 1000);
  }
  function sync(){
    var w = M.want; if (!w) return;
    if (M.cur && M.cur.id === w.id && !w.restart) return;
    if (M.cur) { stop(M.cur, w.restart ? 0.04 : w.fade); M.cur = null; }
    if (!w.id) return;
    if (!M.buf[w.id] || (w.dark && !M.buf[w.dark])) return;      // 아직 푸는 중: 다 풀리면 다시 불린다
    M.cur = start(w.id, w.dark, w.restart ? 0 : w.fade);
    w.restart = false;
  }
  M.load = function(id, path){
    if (M.buf[id] || M.wait[id]) return;
    M.wait[id] = 1;
    try {
      var u = window.FS.readFile(path);
      var ab = u.buffer.slice(u.byteOffset, u.byteOffset + u.byteLength);
      var done = function(b){
        var keep = {}; keep[id] = 1;                          // 풀어 둔 곡이 너무 많으면 지금 안 쓰는 것부터 버린다 (기기 메모리 아끼기)
        if (M.want) { keep[M.want.id] = 1; keep[M.want.dark] = 1; }
        if (M.cur) { keep[M.cur.id] = 1; keep[M.cur.id + '_dark'] = 1; }
        var names = Object.keys(M.buf);
        for (var i = 0; i < names.length && Object.keys(M.buf).length >= 6; i++) if (!keep[names[i]]) delete M.buf[names[i]];
        M.buf[id] = b; delete M.wait[id]; sync();
      };
      var fail = function(){ M.failed = true; delete M.wait[id]; };
      var p = ctx().decodeAudioData(ab, done, fail);
      if (p && p.catch) p.catch(function(){});
    } catch (e) { M.failed = true; delete M.wait[id]; }
  };
  M.play = function(id, dark, fade, restart){
    M.want = {id: id || null, dark: dark || null, fade: fade, restart: !!restart};
    ctx(); wake(); sync();
  };
  M.mood = function(v, sec){
    M.moodv = v;
    var d = M.cur; if (!d || d.mix.length < 2) return;
    ramp(d.mix[0].gain, 1 - v, sec); ramp(d.mix[1].gain, v, sec);
  };
  M.volume = function(v){ M.vol = v; if (M.out) ramp(M.out.gain, v, 0.08); };
  M.pause = function(on){ M.paused = !!on; if (!M.ctx) return; if (on) { try { M.ctx.suspend(); } catch (e) {} } else wake(); };
  M.pos = function(){ return (M.cur && M.ctx) ? M.ctx.currentTime - M.cur.t0 : -1; };
  M.state = function(){
    return (M.ctx ? M.ctx.state : 'none') + '|' + (M.cur ? M.cur.id : '') + '|' + Object.keys(M.buf).length + '|' + (M.failed ? 1 : 0);
  };
  window.jdcMusic = M;
})();
"""


class _Web:
    def __init__(self):
        import platform                                         # pygbag 가 브라우저 window 를 내준다
        self.w = platform.window
        self.w.eval(WEB_JS)
        self.m = self.w.jdcMusic
        if not self.m.ok:
            raise RuntimeError("Web Audio 를 쓸 수 없다")
        self.target = None

    def preload(self, name):
        if name:
            p = path(name)
            if p:
                self.m.load(name, os.path.abspath(p))           # 이미 풀어 둔 곡이면 브라우저 쪽에서 그냥 넘어간다

    def play(self, name, dark, fade, restart=False):
        self.preload(name)
        self.preload(dark)
        self.target = None
        self.m.mood(0, 0.02)
        self.m.play(name or "", dark or "", float(fade), 1 if restart else 0)

    def update(self, dt):
        pass

    def mood(self, value):
        if value != self.target:                                # 바뀔 때만 알린다: 맞바꾸기는 브라우저가 매끄럽게 한다
            self.target = value
            self.m.mood(float(value), MOOD_FADE)

    def volume(self):
        self.m.volume(float(_level()))

    def pause(self, on):
        self.m.pause(1 if on else 0)

    def position(self):
        return float(self.m.pos())

    def healthy(self):
        return not str(self.m.state()).endswith("|1")

    def stop(self):
        self.m.play("", "", 0.05, 0)


def _get():
    """재생 장치 (없으면 만든다). 소리 장치를 못 쓰면 None."""
    global _backend
    if _backend is None and sfx._ready():
        if sys.platform == "emscripten":
            try:
                _backend = _Web()
            except Exception:
                _backend = None
        if _backend is None:
            try:
                _backend = _Mixer()
            except Exception:
                _backend = False
        if _backend:
            _backend.volume()
    return _backend or None


# ------------------------------------------------------------------ 바깥에서 쓰는 것
def current() -> str | None:
    """지금 귀에 들리는 곡 (흐린 곡으로 넘어가 있으면 그 이름)."""
    return _dark if _dark and _mood > 0.5 else _current


def play(name: str | None, fade_ms: int = 900, _restart=False):
    global _current, _dark, _mood, _gloom, _paused
    if name and not path(name):
        name = None
    if name == _current and not _restart:
        _heard(current())                                    # (기록을 지운 뒤에도 지금 곡은 다시 올라가게)
        return
    be = _get()
    _current = name
    _dark = f"{name}_dark" if name and path(f"{name}_dark") else None
    _mood, _gloom, _paused = 0.0, 0.0, False
    _holds.clear()
    if not be:
        return
    try:
        be.play(name, _dark, fade_ms / 1000.0, _restart)
        be.volume()
    except Exception:
        _fallback()
    _heard(name)


def restart(name: str):
    """같은 곡이라도 처음부터 다시 튼다 (박자를 맞춰야 하는 리듬 놀이용, 겹침 없이 바로)."""
    play(name, 0, _restart=True)


def preload(name: str):
    """곧 쓸 곡을 미리 풀어 둔다 (웹에서 곡이 늦게 시작하지 않게)."""
    be = _get()
    if be and name and path(name):
        try:
            be.preload(name)
        except Exception:
            pass


def gloom(seconds: float = 10.0):
    """안 좋은 일이 생겼다 — 흐린 곡으로 잠깐 넘어간다 (짝이 없는 곡이면 아무 일도 없다)."""
    global _gloom
    _gloom = max(_gloom, seconds)


def hold(reason: str, on: bool):
    """안 좋은 상황이 이어지는 동안 흐린 곡에 머문다. 장면이 매 순간 불러도 된다."""
    if on:
        _holds.add(reason)
    else:
        _holds.discard(reason)


def clear_mood():
    global _gloom
    _gloom = 0.0
    _holds.clear()


def update(dt: float):
    """매 화면마다 한 번. 겹쳐 넘기기와 밝은 곡 ↔ 흐린 곡 맞바꾸기를 진행한다."""
    global _mood, _gloom, _check
    be = _backend
    if not be:
        return
    was = current()
    if not _paused:
        _gloom = max(0.0, _gloom - dt)
    want = 1.0 if _dark and (_gloom > 0 or _holds) else 0.0
    step = dt / MOOD_FADE
    _mood = min(want, _mood + step) if _mood < want else max(want, _mood - step)
    try:
        be.mood(want)
        be.update(dt)
        _check += dt
        if _check > 1.0:
            _check = 0.0
            if not be.healthy():
                _fallback()
    except Exception:
        _fallback()
    now = current()
    if now != was:
        _heard(now)


def position() -> float | None:
    """지금 곡이 시작된 뒤 흐른 시간(초). 알 수 없으면 None, 아직 시작 전이면 음수."""
    be = _backend
    if not be:
        return None
    try:
        return be.position()
    except Exception:
        return None


def pause(on: bool = True):
    global _paused
    _paused = on
    if _backend:
        try:
            _backend.pause(on)
        except Exception:
            pass


def apply_mute():
    be = _get()
    if be:
        try:
            be.volume()
        except Exception:
            pass


def _fallback():
    """웹 재생이 안 되면 pygame 믹서로 물러나서 지금 곡을 다시 튼다."""
    global _backend
    if isinstance(_backend, _Mixer):
        return
    try:
        _backend.stop()
    except Exception:
        pass
    try:
        _backend = _Mixer()
        if _current:
            _backend.play(_current, _dark, FADE)
    except Exception:
        _backend = False
