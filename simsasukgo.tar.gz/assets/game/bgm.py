"""배경음악 — 장면마다 BGM 이름을 정하면, 바뀔 때만 부드럽게 교체한다.

파일은 tools/make_bgm.py 로 생성: assets/sounds/bgm_<이름>.ogg|.wav
"""
import os

import pygame

from . import sfx
from .config import ASSET_DIR

VOLUME = 0.55
master = 0.7           # 설정의 배경음악 크기 (0~1)
_current: str | None = None


def _path(name: str) -> str | None:
    for ext in (".ogg", ".wav"):        # 웹(pygbag) 빌드에는 ogg 권장
        p = os.path.join(ASSET_DIR, "sounds", f"bgm_{name}{ext}")
        if os.path.exists(p):
            return p
    return None


def play(name: str | None, fade_ms: int = 900):
    global _current
    if name == _current or not sfx._ready():
        return
    _current = name
    try:
        pygame.mixer.music.stop()
        path = _path(name) if name else None
        if path:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0 if sfx.muted else VOLUME * master)
            pygame.mixer.music.play(-1, fade_ms=fade_ms)
    except Exception:
        pass


def apply_mute():
    if sfx._ready():
        try:
            pygame.mixer.music.set_volume(0 if sfx.muted else VOLUME * master)
        except Exception:
            pass
