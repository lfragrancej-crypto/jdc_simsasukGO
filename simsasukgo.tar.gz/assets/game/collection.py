"""도감을 얼마나 채웠는가 — 세 편의 기록을 한데 모아 센다 (도감 탭의 '몇/몇' 과 같은 기준).

  인재   심사숙GO 동료 + 납품하GO 직원 + 요청하GO 도우미 (한 번이라도 만난 사람)
  난이도 세 편의 난이도 아홉 개 (클리어한 것)
  추억   이벤트 CG 전부 (본 것)
  규정   심사숙GO의 규정 (배운 것)
  공장   납품하GO의 납품처 도장판 (완벽하게 납품한 곳)
  엔딩   히든 엔딩 두 편 (본 것)
모두 채우면 묶음 첫 화면에서 축하 폭죽이 터지고, 폭죽 단추가 열린다.
"""
from . import cg


def progress(app) -> dict[str, tuple[int, int]]:
    """탭마다 (채운 수, 전체 수)."""
    from .factory import scene as factory
    from .scenes import hidden
    prof, data = app.profile, app.data
    f_rec = prof.data.get("factory") or {}
    a_rec = prof.data.get("agency") or {}
    staff, helpers = data.staff["roster"], data.agency["helpers"]["roster"]
    people = (sum(1 for p in data.roster if prof.bio_level(p["id"]) > 0) + sum(1 for p in staff if p["id"] in f_rec.get("staff", {}))
              + sum(1 for p in helpers if p["id"] in a_rec.get("helpers", {})))
    levels = (sum(1 for c in data.chiefs if prof.chief_cleared(c["id"]))
              + sum(1 for lv in data.factory["levels"] if lv["id"] in f_rec.get("levels", {}))
              + sum(1 for lv in data.agency["levels"] if lv["id"] in a_rec.get("levels", {})))
    clients = factory.clients(data)
    seen = hidden.seen(app)
    return {
        "mates": (people, len(data.roster) + len(staff) + len(helpers)),
        "chiefs": (levels, len(data.chiefs) + len(data.factory["levels"]) + len(data.agency["levels"])),
        "cgs": (sum(1 for c in cg.CGS if c in prof.data["cgs"]), len(cg.CGS)),
        "rules": (sum(1 for r in data.rules if r["id"] in prof.data["rules"]), len(data.rules)),
        "factory": (sum(1 for c in clients if c["key"] in f_rec.get("delivered", {})), len(clients)),
        "ending": (sum(1 for t in hidden.TIERS if seen.get(t)), len(hidden.TIERS)),
    }


def percent(app) -> int:
    got = progress(app)
    have, total = sum(a for a, _ in got.values()), sum(b for _, b in got.values())
    return int(100 * have / total) if have < total else 100


def complete(app) -> bool:
    return all(a >= b for a, b in progress(app).values())
