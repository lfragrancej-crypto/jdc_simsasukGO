from dataclasses import dataclass, field
from datetime import date, time


@dataclass
class Notice:
    """입찰공고문 — 하루 동안 고정."""
    notice_no: str
    item: str
    qty: int
    unit: str
    est_price: int        # 예정가격
    deadline: time        # 입찰 마감시각
    today: date
    sme_only: bool        # 중소기업자간 경쟁제품 여부


@dataclass
class Bid:
    """업체 1곳이 제출한 입찰 서류 묶음.

    docs: 서류키 -> {항목명: 값}. 값은 int(금액), date, time, bool, str 중 하나.
    injected: 생성기가 일부러 넣은 위반 규정 ID (정상 서류면 None). 디버그/테스트용.
    """
    docs: dict[str, dict] = field(default_factory=dict)
    injected: str | None = None
    story: str | None = None                            # 공통 사건의 특별 손님 (data/world.json stories 의 키)
    extras: list[dict] = field(default_factory=list)   # 심사와 무관한 덤 종이(영수증, 쪽지 등) — 규정 판정에 영향 없음

    @property
    def form(self) -> dict:
        return self.docs["bid_form"]

    @property
    def company(self) -> str:
        return self.form["상호"]

    @property
    def price(self) -> int:
        return self.form["투찰금액"]
