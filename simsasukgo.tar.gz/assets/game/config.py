import os
import sys

TITLE = "심사숙GO! 조달청"
WIDTH, HEIGHT = 1280, 720
FPS = 60


def resource_path(*parts: str) -> str:
    """PyInstaller(onefile) 실행 시 _MEIPASS 기준으로 경로를 찾는다."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, *parts)


DATA_DIR = resource_path("data")
ASSET_DIR = resource_path("assets")

# 색상 팔레트 — 따뜻한 파스텔 + 진한 갈색 잉크 (둥글둥글 친숙한 톤)
C_BG = (255, 243, 226)          # 크림색 바탕
C_WALL = (255, 230, 200)        # 창구 벽
C_WALL_STRIPE = (252, 220, 186)
C_DESK = (233, 188, 132)        # 나무 책상
C_DESK_GRAIN = (222, 174, 116)
C_DESK_EDGE = (196, 142, 88)
C_PAPER = (255, 253, 247)
C_PAPER_EDGE = (236, 224, 204)
C_INK = (74, 52, 40)            # 본문 글자(진갈색)
C_INK_SOFT = (150, 120, 100)
C_TEXT = C_INK
C_TEXT_DIM = C_INK_SOFT
C_WHITE = (255, 255, 255)
C_PANEL = (255, 250, 240)
C_PANEL_DARK = (236, 222, 200)
C_ACCENT = (255, 138, 92)       # 코랄 오렌지
C_APPROVE = (72, 142, 232)
C_REJECT = (238, 92, 92)
C_GOOD = (76, 178, 108)
C_WARN = (245, 166, 48)
C_SELECT = (255, 208, 84)
C_STICKY = (255, 238, 150)

# 서류 키 → 화면 표시 이름 (표시 순서 = 리스트 순서)
DOC_TITLES = [
    ("bid_form", "입찰서"),
    ("registration", "입찰참가자격 등록증"),
    ("guarantee", "입찰보증서"),
    ("direct_production", "직접생산확인증명서"),
    ("integrity", "청렴계약 이행서약서"),
]

GUARANTEE_RATE = 0.05
