"""실행 환경 확인 — PC 실행파일인지, 웹 브라우저인지, 터치 기기(모바일)인지.

  kind   "desktop"  PC 실행파일
         "web"      PC 브라우저
         "mobile"   휴대폰·태블릿 브라우저
  touch  손가락으로 누르는 기기인가 (마우스를 '올리는' 동작이 없다)
"""
import sys

IS_WEB = sys.platform == "emscripten"
MOBILE_WORDS = ("Android", "iPhone", "iPad", "iPod", "Mobile")


def detect() -> dict:
    info = {"web": IS_WEB, "touch": False, "mobile": False, "kind": "desktop", "ua": ""}
    if not IS_WEB:
        return info
    info["kind"] = "web"
    try:
        import platform
        nav = platform.window.navigator
        info["ua"] = str(nav.userAgent)
        info["touch"] = int(nav.maxTouchPoints or 0) > 0
        info["mobile"] = info["touch"] and any(w in info["ua"] for w in MOBILE_WORDS)
        if info["mobile"]:
            info["kind"] = "mobile"
    except Exception:
        pass
    return info


def is_portrait() -> bool:
    """브라우저 창이 세로로 긴가 (휴대폰을 세워 든 상태)."""
    if not IS_WEB:
        return False
    try:
        import platform
        win = platform.window
        return int(win.innerHeight) > int(win.innerWidth)
    except Exception:
        return False


def label(info: dict) -> str:
    return {"desktop": "PC 버전", "web": "웹 버전", "mobile": "모바일 웹 버전"}[info["kind"]]
