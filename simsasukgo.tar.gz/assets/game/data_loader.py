import json
import os
from dataclasses import dataclass

from .config import DATA_DIR


def load_json(name: str):
    with open(os.path.join(DATA_DIR, name), encoding="utf-8") as f:
        return json.load(f)


@dataclass
class GameData:
    rules: list[dict]
    companies: list[dict]
    items: list[dict]
    days: list[dict]
    dialogue: dict
    levels: list[dict]
    decoys: list[dict]
    team: dict            # 기술별 말투 (data/team.json)
    roster: list[dict]    # 고정 인물 명단 — 뽑기 대상 (data/roster.json)
    chiefs: list[dict]    # 팀장 = 난이도
    life: dict            # 퇴근 후 생활 사건·통장·스트레스 수치
    world: dict           # 닷새치 조달 사건 — 모든 편이 공유 (data/world.json)
    factory: dict         # 납품하GO! 우리 공장 설정 (data/factory.json)

    def case_of(self, day: int) -> dict:
        """day 일차의 조달 사건 (공고번호·품목·수요기관)."""
        return next(c for c in self.world["cases"] if c["day"] == day)

    def item_by_name(self, name: str) -> dict:
        return next(i for i in self.items if i["name"] == name)

    def company_by_biz(self, biz_no: str) -> dict:
        return next(c for c in self.companies if c["biz_no"] == biz_no)

    @property
    def rules_by_id(self) -> dict[str, dict]:
        return {r["id"]: r for r in self.rules}

    def active_rules(self, day: int) -> list[dict]:
        return [r for r in self.rules if r["day"] <= day]

    @property
    def debarred(self) -> list[dict]:
        return [c for c in self.companies if c["debarred"]]

    @property
    def clean_companies(self) -> list[dict]:
        return [c for c in self.companies if not c["debarred"] and not c.get("special")]   # special = 내 공장 (특별 손님)

    @property
    def my_company(self) -> dict:
        """‘납품하GO!’에서 플레이어가 운영하는 공장 (companies.json 의 special 항목)."""
        return next(c for c in self.companies if c.get("special"))


def load_all() -> GameData:
    return GameData(
        rules=load_json("rules.json"),
        companies=load_json("companies.json"),
        items=load_json("items.json"),
        days=load_json("days.json"),
        dialogue=load_json("dialogue.json"),
        levels=load_json("levels.json"),
        decoys=load_json("decoys.json"),
        team=load_json("team.json"),
        roster=load_json("roster.json"),
        chiefs=load_json("chiefs.json"),
        life=load_json("life.json"),
        world=load_json("world.json"),
        factory=load_json("factory.json"),
    )
