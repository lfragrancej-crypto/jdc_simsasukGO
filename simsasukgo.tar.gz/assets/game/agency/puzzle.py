"""요청하GO! 배치 퍼즐 — 판 만들기와 판정.

칠판(격자)의 빈칸을 색종이 블록으로 빠짐없이 채우되, 예산을 넘기지 않고 그날까지 배운 규칙을 모두 지킨다.
판은 '정답을 먼저 만들고(빈칸을 블록으로 쪼갬) 거기에 미끼 블록을 섞는' 식으로 만들기 때문에 반드시 풀린다.

블록 꼬리표(tags):
  premium  고급형 — 모양은 같은데 비싸다 (예산을 넘기기 쉽다)
  fresh    기한 있는 물품 — '먼저 쓸 곳'(칠판 윗줄) 안에만 놓을 수 있다         [2일차부터]
  sme      중소기업 제품 — 정해진 수 이상 써야 한다                         [3일차부터]
  brand    특정 상표 지정 — 싸지만 쓰면 안 된다                             [4일차부터]
  mini     낱개 — 싸지만 여러 개로 쪼개 사면 안 된다 (정해진 수까지만)          [5일차부터]
"""
import random

RULE_ORDER = ("cover", "budget", "fresh", "sme", "brand", "mini")
TETRO = [[(0, 0), (1, 0), (2, 0), (3, 0)], [(0, 0), (0, 1), (0, 2), (0, 3)], [(0, 0), (1, 0), (0, 1), (1, 1)],
         [(0, 0), (1, 0), (2, 0), (1, 1)], [(0, 0), (0, 1), (1, 1), (1, 2)], [(0, 0), (1, 0), (1, 1), (2, 1)],
         [(0, 0), (0, 1), (0, 2), (1, 2)], [(0, 0), (1, 0), (2, 0), (0, 1)]]


def norm(cells):
    mx, my = min(x for x, _ in cells), min(y for _, y in cells)
    return sorted((x - mx, y - my) for x, y in cells)


def _partition(rng, free, w, h):
    """빈칸 전체를 2~4칸짜리 블록으로 쪼갠다 → [(왼쪽 위 좌표, 모양), ...]"""
    left = set(free)
    out = []
    while left:
        def lonely(c):
            return sum(1 for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if (c[0] + dx, c[1] + dy) in left)
        start = min(left, key=lambda c: (lonely(c), rng.random()))    # 외톨이가 될 칸부터 묶는다
        piece = [start]
        left.discard(start)
        for _ in range(rng.choice((1, 2, 2, 3, 3)) ):
            near = [(x + dx, y + dy) for x, y in piece for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if (x + dx, y + dy) in left]
            if not near:
                break
            c = min(near, key=lambda c: (lonely(c), rng.random()))
            piece.append(c)
            left.discard(c)
        home = (min(x for x, _ in piece), min(y for _, y in piece))
        out.append((home, norm(piece)))
    return out


def make(level: dict, day: int, cfg: dict, seed: int, tutorial=False) -> dict:
    """판 하나. level = 난이도 설정, day = 며칠차(규칙이 날마다 하나씩 는다)."""
    rng = random.Random(seed)
    w, h = (4, 3) if tutorial else level["grid"]
    unit = cfg["unit"]
    rules = [r for r in RULE_ORDER if cfg["rules"][r]["day"] <= (1 if tutorial else day)]
    for _ in range(200):
        cells = [(x, y) for y in range(h) for x in range(w)]
        blocked = set(rng.sample(cells, 0 if tutorial else level["blocked"]))
        free = [c for c in cells if c not in blocked]
        parts = _partition(rng, free, w, h)
        singles = sum(1 for _, shape in parts if len(shape) == 1)
        if singles <= (1 if "mini" in rules else 0):
            break
    pieces = []

    def add(shape, cost, tags=(), home=None):
        pieces.append({"cells": list(shape), "cost": int(round(cost)), "tags": set(tags), "home": home, "at": None})
        return pieces[-1]

    zone = 2 if "fresh" in rules else 0                              # '먼저 쓸 곳' = 위에서 몇 줄
    solution = []
    for home, shape in parts:
        tags = {"mini"} if len(shape) == 1 else set()
        solution.append(add(shape, len(shape) * unit, tags, home))
    inside = [p for p in solution if all(p["home"][1] + dy < zone for _, dy in p["cells"])]
    outside = [p for p in solution if p not in inside and len(p["cells"]) > 1]
    if "fresh" in rules:
        for p in inside[:max(1, len(inside) // 2)]:
            p["tags"].add("fresh")
    sme_need = 0
    if "sme" in rules:
        pool = [p for p in solution if len(p["cells"]) > 1]
        rng.shuffle(pool)
        sme_need = min(len(pool), cfg["sme_need"][level["id"]])
        for p in pool[:sme_need]:
            p["tags"].add("sme")
    cost = sum(p["cost"] for p in solution)
    budget = int(cost * (1 + (0.3 if tutorial else level["slack"])) // 5 * 5)
    budget = max(budget, cost)

    # ---- 미끼 블록
    multi = [p for p in solution if len(p["cells"]) > 1]
    n_decoy = 1 if tutorial else level["decoys"]
    for i in range(n_decoy):
        if i % 2 == 0 and multi:                                    # 고급형: 모양은 같은데 비싸다
            src = rng.choice(multi)
            add(src["cells"], src["cost"] * 1.6, {"premium"})
        else:                                                       # 판에 안 맞는 엉뚱한 모양
            add(rng.choice(TETRO), 4 * unit)
    if "fresh" in rules and outside:                                # 기한 있는 물품인데 안쪽 자리에만 맞는 모양
        add(rng.choice(outside)["cells"], len(outside[0]["cells"]) * unit, {"fresh"})
    if "sme" in rules:                                              # 중소기업 제품과 모양이 같고 더 싼 블록 (쓰면 수가 모자란다)
        for p in [p for p in solution if "sme" in p["tags"]][:2]:
            add(p["cells"], p["cost"] * 0.8)
    if "brand" in rules and multi:                                  # 특정 상표: 싸지만 금지
        for src in rng.sample(multi, min(2, len(multi))):
            add(src["cells"], src["cost"] * 0.7, {"brand"})
    if "mini" in rules:                                             # 낱개: 싸지만 쪼개 사기
        for _ in range(4):
            add([(0, 0)], unit * 0.6, {"mini"})
    del pieces[25:]                                                 # 쟁반에 놓을 수 있는 만큼만
    order = list(range(len(pieces)))
    rng.shuffle(order)
    pieces = [pieces[i] for i in order]
    return {"w": w, "h": h, "blocked": blocked, "free": set(free), "pieces": pieces, "budget": budget, "best": cost,
            "rules": rules, "zone": zone, "sme_need": sme_need, "mini_max": cfg["mini_max"]}


def cells_of(piece, at=None):
    ax, ay = at if at is not None else piece["at"]
    return [(ax + dx, ay + dy) for dx, dy in piece["cells"]]


def can_place(pz, piece, at) -> bool:
    taken = {c for p in pz["pieces"] if p["at"] is not None and p is not piece for c in cells_of(p)}
    return all(c in pz["free"] and c not in taken for c in cells_of(piece, at))


def spent(pz) -> int:
    return sum(p["cost"] for p in pz["pieces"] if p["at"] is not None)


def check(pz) -> list[tuple[str, bool, str]]:
    """조건마다 (규칙, 지켰는가, 지금 상태 한 줄)."""
    placed = [p for p in pz["pieces"] if p["at"] is not None]
    covered = {c for p in placed for c in cells_of(p)}
    out = []
    for r in pz["rules"]:
        if r == "cover":
            out.append((r, covered == pz["free"], f"{len(covered)} / {len(pz['free'])}칸"))
        elif r == "budget":
            out.append((r, spent(pz) <= pz["budget"], f"{spent(pz)} / {pz['budget']}만원"))
        elif r == "fresh":
            bad = [p for p in placed if "fresh" in p["tags"] and any(y >= pz["zone"] for _, y in cells_of(p))]
            out.append((r, not bad, "모두 제자리" if not bad else f"{len(bad)}개가 안쪽에"))
        elif r == "sme":
            n = sum(1 for p in placed if "sme" in p["tags"])
            out.append((r, n >= pz["sme_need"], f"{n} / {pz['sme_need']}개"))
        elif r == "brand":
            n = sum(1 for p in placed if "brand" in p["tags"])
            out.append((r, n == 0, "없음" if n == 0 else f"{n}개 사용"))
        elif r == "mini":
            n = sum(1 for p in placed if "mini" in p["tags"])
            out.append((r, n <= pz["mini_max"], f"{n} / {pz['mini_max']}개까지"))
    return out


def solved(pz) -> bool:
    return all(ok for _, ok, _ in check(pz))


def solve(pz):
    """정답대로 놓는다 (테스트·힌트용)."""
    for p in pz["pieces"]:
        p["at"] = p["home"]
