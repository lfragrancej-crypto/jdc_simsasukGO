"""요청하GO! 도우미 뽑기 — 하루를 별 셋으로 끝내면 '응원 편지'에서 도우미 한 명이 온다 (최대 3명).

봉투 연출과 뽑기 규칙은 심사숙GO·납품하GO와 같은 것을 쓴다 (game/gacha.py, scenes/gacha.py).
  hint    길잡이      막힐 때 정답 블록 하나를 제자리에 놓아 준다 (하루 몇 번)
  budget  예산 따오기  예산이 늘어난다
  sort    정리 반장    쓸모없는 미끼 블록을 미리 치워 준다
  warn    규칙 지킴이  규칙에 어긋나거나 비싼 블록을 집으면 알려 준다
"""
from .. import gacha

MAX_HELPERS = 3
SKILLS = {
    "hint": {"name": "길잡이", "C": {"n": 1}, "B": {"n": 1}, "A": {"n": 2}, "S": {"n": 3}},
    "budget": {"name": "예산 따오기", "C": {"up": 0.03}, "B": {"up": 0.05}, "A": {"up": 0.07}, "S": {"up": 0.10}},
    "sort": {"name": "정리 반장", "C": {"n": 1}, "B": {"n": 2}, "A": {"n": 3}, "S": {"n": 5}},
    "warn": {"name": "규칙 지킴이", "C": {"chance": 0.5}, "B": {"chance": 0.7}, "A": {"chance": 0.85}, "S": {"chance": 1.0}},
}
RARITY_TITLE = {"R": "새 도우미", "SR": "든든한 도우미", "SSR": "전설의 도우미"}


def describe(skill: str, grade: str) -> str:
    p = SKILLS[skill][grade]
    if skill == "hint":
        return f"정답 블록 하나를 제자리에 놓아 줌 · 하루 {p['n']}번"
    if skill == "budget":
        return f"예산 +{int(p['up'] * 100)}%"
    if skill == "sort":
        return f"쓸모없는 블록 {p['n']}개를 미리 치워 줌"
    return f"어긋나는 블록을 집으면 알려 줌 · {int(p['chance'] * 100)}%"


def perks(team: list[dict]) -> dict:
    out = {}
    for m in team:
        for s in m["skills"]:
            cur = out.get(s["type"])
            if cur is None or gacha.GRADE_ORDER.index(s["grade"]) > gacha.GRADE_ORDER.index(cur[0]):
                out[s["type"]] = (s["grade"], SKILLS[s["type"]][s["grade"]], m)
    return out


def kit(app, scene, on_done) -> dict:
    """scenes/gacha.py 의 봉투 연출에 넘겨 줄 '학교용 한 벌'."""
    data = app.data.agency["helpers"]
    from .scene import record

    def mark(member_id):
        rec = record(app)
        rec["helpers"][member_id] = rec["helpers"].get(member_id, 0) + 1
        app.profile.save()
    return {"team": scene.helpers, "roster": data["roster"], "say": data["skills"], "skills": SKILLS, "describe": describe,
            "seen": set(record(app)["helpers"]), "mark": mark, "first_skill": None, "banner": "응원 편지 도착!",
            "card": "새 도우미 합류!", "titles": RARITY_TITLE, "button": "같이 해요 ", "done": on_done}
