"""요청하GO! 우리 학교 — 시작 화면: 새로 시작(난이도 선택) / 이어하기 / 도감."""
import math

import pygame

from .. import ui
from ..config import HEIGHT, WIDTH
from ..factory.iso import GREEN, INK, ORANGE, PAPER, SOFT, TEAL, Btn, card, chip, shade
from ..scenes.base import Scene
from . import scene as A


class AgencyTitleScene(Scene):
    BGM = "agency"
    HOME = "hub"

    def __init__(self, app):
        super().__init__(app)
        self.t = 0.0
        self.picking = False
        self.levels = app.data.agency["levels"]
        self.saved = A.load_save(app)
        from ..scenes.album import _face
        self.faces = [_face(lv["look"], (64, 76), ("happy", "neutral", "sly")[min(i, 2)]) for i, lv in enumerate(self.levels)]
        cx = WIDTH // 2
        self.new_btn = Btn((cx - 290, 400, 280, 62), "새로 시작", A.PURPLE, 22)
        self.cont_btn = Btn((cx + 10, 400, 280, 62), "이어하기", TEAL, 22)
        self.cont_btn.enabled = self.saved is not None
        self.album_btn = Btn((cx - 100, 530, 200, 50), "도감 보기", GREEN, 17)
        self.back_btn = Btn((cx - 100, 600, 200, 50), "처음으로", (150, 160, 166), 17)

    def _level_rect(self, i):
        return pygame.Rect(130 + i * 350, 330, 320, 240)

    def start(self, i: int):
        A.delete_save(self.app)
        self.app.start_agency(self.levels[i])

    def resume(self):
        if self.saved:
            self.app.start_agency(self.saved["level"], self.saved)

    def handle_event(self, event):
        if self.picking:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i in range(len(self.levels)):
                    if self._level_rect(i).collidepoint(event.pos):
                        self.start(i)
                        return
            if self.back_btn.clicked(event):
                self.picking = False
        elif self.new_btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self.picking = True
        elif self.cont_btn.clicked(event):
            self.resume()
        elif self.album_btn.clicked(event):
            self.app.to_album("mates", "agency")
        elif self.back_btn.clicked(event):
            self.app.to_hub()

    def update(self, dt):
        self.t += dt
        for b in (self.new_btn, self.cont_btn, self.back_btn, self.album_btn):
            b.update(dt)

    def draw(self, surf):
        surf.blit(A.classroom_background(), (0, 0))
        for i in range(9):                                           # 색종이 블록이 둥실
            col = A.PAPER_COLORS[i % len(A.PAPER_COLORS)]
            x, y = 70 + i * 142, 600 + math.sin(self.t * 1.6 + i) * 10
            pygame.draw.rect(surf, shade(col, 0.72), (x, y + 5, 78, 78), border_radius=10)
            pygame.draw.rect(surf, col, (x, y, 78, 78), border_radius=10)
        card(surf, (WIDTH // 2 - 380, 60, 760, 230), 28)
        ui.draw_text(surf, "다함께! 조달 한바퀴  ·  쓰는 쪽 이야기", (WIDTH // 2, 92), 15, SOFT, True, center=True)
        f = ui.fonts.get(76, "heavy")
        a, b = f.render("요청하", True, INK), f.render("GO!", True, A.PURPLE)
        x = WIDTH // 2 - (a.get_width() + b.get_width()) // 2
        surf.blit(a, (x, 110))
        bounce = abs(math.sin(self.t * 3.2)) * -8
        surf.blit(f.render("GO!", True, shade(A.PURPLE, 0.72)), (x + a.get_width() + 3, 115 + bounce))
        surf.blit(b, (x + a.get_width(), 110 + bounce))
        chip(surf, (WIDTH // 2 - 80, 204, 160, 36), "우리 학교", ORANGE, size=20)
        ui.draw_text(surf, "필요한 것을, 필요한 만큼, 떳떳한 방법으로", (WIDTH // 2, 262), 17, INK, True, center=True)
        if not self.picking:
            self.new_btn.draw(surf)
            self.cont_btn.draw(surf)
            self.album_btn.draw(surf)
            if self.saved:
                s = self.saved
                text = f"이어하기: {s['level']['name']} · {s['day_i'] + 1}일차 · 모은 별 {sum(s['stars'])}"
                w = ui.fonts.get(13, True).size(text)[0] + 28
                chip(surf, (WIDTH // 2 - w // 2, 478, w, 28), text, PAPER, INK, 13)
        else:
            chip(surf, (WIDTH // 2 - 80, 292, 160, 30), "난이도 선택", INK, size=15)
            mouse = pygame.mouse.get_pos()
            rec = self.app.profile.data.get("agency", {}).get("levels", {})
            for i, lv in enumerate(self.levels):
                r = self._level_rect(i)
                r = r.move(0, -6 if r.collidepoint(mouse) else 0)
                col = tuple(lv["color"])
                card(surf, r, 22)
                pygame.draw.rect(surf, col, (r.x, r.y, r.w, 70), border_top_left_radius=22, border_top_right_radius=22)
                c = (r.x + 46, r.y + 35)
                pygame.draw.circle(surf, PAPER, c, 30)
                clip = surf.get_clip()
                surf.set_clip(pygame.Rect(c[0] - 28, c[1] - 30, 56, 58))
                surf.blit(self.faces[i], self.faces[i].get_rect(midtop=(c[0], c[1] - 26)))
                surf.set_clip(clip)
                pygame.draw.circle(surf, shade(col, 0.7), c, 30, 3)
                ui.draw_text(surf, lv["name"], (r.centerx + 30, r.y + 36), 24, PAPER, "heavy", center=True)
                chip(surf, (r.centerx - 70, r.y + 84, 140, 26), lv["tag"], shade(col, 0.85), size=13)
                ui.draw_wrapped(surf, lv["desc"], (r.x + 22, r.y + 124, r.w - 44, 80), 14, INK, True)
                if lv.get("tutorial"):
                    chip(surf, (r.x + 22, r.bottom - 40, 104, 26), "튜토리얼 포함", ORANGE, size=12)
                if lv["id"] in rec:
                    chip(surf, (r.right - 112, r.bottom - 40, 90, 26), f"클리어 {rec[lv['id']]}", GREEN, size=12)
        self.back_btn.label = "뒤로" if self.picking else "처음으로"
        self.back_btn.draw(surf)
        _ = HEIGHT
