"""요청하GO! 우리 학교 — 시작 화면: 새로 시작(난이도 선택) / 이어하기 / 도감."""
import math

import pygame

from .. import cg as C
from .. import props, ui
from ..character import Character
from ..config import HEIGHT, WIDTH
from ..factory.iso import GREEN, INK, ORANGE, PAPER, SOFT, TEAL, Btn, card, chip, shade
from ..scenes.base import Scene
from . import scene as A


_BG: dict = {}


def school_background():
    """요청하GO! 첫 화면의 교실 — 큰 칠판, 창문, 책장, 시계, 게시판. (사람들과 글씨는 장면이 그 위에 그린다)"""
    if "title" not in _BG:
        s = pygame.Surface((WIDTH, HEIGHT))
        s.blit(A.classroom_background(), (0, 0))
        board = pygame.Rect(240, 44, 800, 262)                       # 칠판
        props.box(s, board, (46, 96, 78), radius=12, offset=(8, 10))
        pygame.draw.rect(s, (170, 120, 70), board, 12, border_radius=12)
        pygame.draw.rect(s, (150, 104, 60), (board.x + 40, board.bottom - 4, board.w - 80, 14), border_radius=5)      # 분필 받침
        for i, col in enumerate(((255, 255, 255), (255, 226, 110), (255, 170, 150))):
            pygame.draw.rect(s, col, (board.x + 70 + i * 34, board.bottom - 10, 26, 8), border_radius=3)
        pygame.draw.rect(s, (90, 70, 60), (board.right - 150, board.bottom - 14, 64, 14), border_radius=4)            # 칠판지우개
        props.draw_window(s, (34, 96, 180, 170), 4.0, 0.0)             # 왼쪽 창문
        shelf = pygame.Rect(1066, 150, 186, 200)                     # 오른쪽 책장
        props.box(s, shelf, (214, 160, 106), radius=6, shade=(186, 132, 82), offset=(5, 6))
        for row in range(3):
            y = shelf.y + 12 + row * 62
            pygame.draw.rect(s, (255, 244, 220), (shelf.x + 10, y, shelf.w - 20, 50))
            x = shelf.x + 14
            for k in range(9):
                col = A.PAPER_COLORS[(k * 3 + row * 2) % len(A.PAPER_COLORS)]
                w, h = 14 + (k * 5 + row) % 7, 34 + (k * 7 + row * 3) % 14
                if x + w > shelf.right - 14:
                    break
                pygame.draw.rect(s, col, (x, y + 50 - h, w, h))
                pygame.draw.rect(s, C.INK, (x, y + 50 - h, w, h), 2)
                x += w + 2
            pygame.draw.line(s, C.INK, (shelf.x + 10, y + 50), (shelf.right - 10, y + 50), 3)
        props.draw_clock(s, (1158, 96), 40, 8 * 60 + 50, 0, 0.0)       # 책장 위 시계 (등교 시간)
        note = pygame.Rect(40, 300, 170, 150)                        # 창문 아래 게시판
        props.box(s, note, (236, 214, 170), radius=6, offset=(4, 5))
        ui.draw_text(s, "우리 학교 게시판", (note.centerx, note.y + 16), 13, C.INK, True, center=True)
        papers = (((255, 253, 247), "급식: 떡볶이", (12, 36, 70, 46)), ((255, 238, 150), "새 책걸상 요청!", (88, 36, 70, 46)),
                  ((214, 238, 250), "시험 D-5", (30, 92, 110, 44)))
        for col, text, (dx, dy, w, h) in papers:
            r = pygame.Rect(note.x + dx, note.y + dy, w, h)
            pygame.draw.rect(s, col, r)
            pygame.draw.rect(s, C.INK, r, 2)
            for k, line in enumerate(ui.wrap(text, 11, r.w - 8, True)[:2]):
                ui.draw_text(s, line, (r.centerx, r.y + 22 + k * 13), 11, C.INK, True, center=True)
            props.pin(s, (r.centerx, r.y + 2))
        _BG["title"] = s.convert()
    return _BG["title"]


class AgencyTitleScene(Scene):
    BGM = "agency"
    HOME = "hub"

    def __init__(self, app):
        super().__init__(app)
        self.t = 0.0
        self.picking = False
        self.levels = app.data.agency["levels"]
        self.saved = A.load_save(app)
        from ..scenes.album import _face
        self.faces = [_face(lv["look"], (64, 76), ("happy", "neutral", "sly")[min(i, 2)]) for i, lv in enumerate(self.levels)]
        cx = WIDTH // 2
        self.new_btn = Btn((cx - 290, 400, 280, 62), "새로 시작", A.PURPLE, 22)
        self.cont_btn = Btn((cx + 10, 400, 280, 62), "이어하기", TEAL, 22)
        self.cont_btn.enabled = self.saved is not None
        self.album_btn = Btn((cx - 100, 530, 200, 50), "도감 보기", GREEN, 17)
        self.back_btn = Btn((cx - 100, 600, 200, 50), "처음으로", (150, 160, 166), 17)
        d = app.data
        helpers = {p["id"]: p["look"] for p in d.agency["helpers"]["roster"]}
        # 학교 사람들: (생김새, 서는 자리 x, 크기, 자세) — 왼쪽은 선생님과 아이들, 오른쪽은 행정실 식구들
        cast = [(self.levels[1]["look"], 262, 0.66, "point"), (helpers["a_ban"], 92, 0.46, "cheer"),
                (self.levels[0]["look"], 176, 0.48, "hi"), (d.case_of(1)["officer"]["look"], 1026, 0.64, "wave"),
                (helpers["a_dalin"], 1126, 0.6, "hip"), (helpers["a_alttle"], 1216, 0.56, "clap")]
        self.cast = []
        for look, x, scale, pose in cast:
            ch = Character(look)
            ch.expression = "happy"
            ch.set_pose(pose)
            self.cast.append((ch, x, scale))

    def _level_rect(self, i):
        return pygame.Rect(130 + i * 350, 330, 320, 240)

    def start(self, i: int):
        A.delete_save(self.app)
        self.app.start_agency(self.levels[i])

    def resume(self):
        if self.saved:
            self.app.start_agency(self.saved["level"], self.saved)

    def handle_event(self, event):
        if self.picking:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i in range(len(self.levels)):
                    if self._level_rect(i).collidepoint(event.pos):
                        self.start(i)
                        return
            if self.back_btn.clicked(event):
                self.picking = False
        elif self.new_btn.clicked(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
            self.picking = True
        elif self.cont_btn.clicked(event):
            self.resume()
        elif self.album_btn.clicked(event):
            self.app.to_album("mates", "agency")
        elif self.back_btn.clicked(event):
            self.app.to_hub()

    def update(self, dt):
        self.t += dt
        for b in (self.new_btn, self.cont_btn, self.back_btn, self.album_btn):
            b.update(dt)
        for ch, _, _ in self.cast:
            ch.update(dt)

    def draw(self, surf):
        surf.blit(school_background(), (0, 0))
        # ---- 칠판에 분필로 쓴 제목
        cx = WIDTH // 2
        ui.draw_text(surf, "다함께! 조달 한바퀴  ·  쓰는 쪽 이야기", (cx, 78), 15, (190, 220, 200), True, center=True)
        f = ui.fonts.get(78, "heavy")
        a, b = f.render("요청하", True, (250, 250, 240)), f.render("GO!", True, (255, 226, 110))
        x = cx - (a.get_width() + b.get_width()) // 2
        surf.blit(a, (x, 96))
        bounce = abs(math.sin(self.t * 3.2)) * -8
        surf.blit(b, (x + a.get_width(), 96 + bounce))
        chip(surf, (cx - 80, 196, 160, 36), "우리 학교", ORANGE, size=20)
        ui.draw_text(surf, "필요한 것을, 필요한 만큼, 떳떳한 방법으로", (cx, 262), 17, (236, 244, 236), True, center=True)
        for i, (bx, by) in enumerate(((286, 84), (952, 76), (300, 216), (968, 220))):       # 칠판에 붙인 색종이
            col = A.PAPER_COLORS[(i * 2 + 1) % len(A.PAPER_COLORS)]
            r = pygame.Rect(bx, by + int(math.sin(self.t * 1.5 + i) * 3), 44, 44)
            pygame.draw.rect(surf, shade(col, 0.72), r.move(0, 3), border_radius=8)
            pygame.draw.rect(surf, col, r, border_radius=8)
            props.tape(surf, (r.centerx, r.y), (-8, 6, 10, -6)[i], 30, 10)
        if not self.picking:                                         # ---- 학교 사람들과 책상
            for ch, x, scale in self.cast:
                sh = pygame.Surface((int(150 * scale), 22), pygame.SRCALPHA)
                pygame.draw.ellipse(sh, (60, 35, 20, 60), sh.get_rect())
                surf.blit(sh, sh.get_rect(center=(x, 668)))
                ch.draw(surf, (x, 664 - C.FOOT * scale), scale=scale, full=True)
            for i, dx in enumerate((336, 860)):                      # 색종이 블록이 놓인 책상 두 개
                top = pygame.Rect(dx, 600, 86, 14)
                pygame.draw.line(surf, C.INK, (top.x + 12, top.bottom), (top.x + 8, 676), 6)
                pygame.draw.line(surf, C.INK, (top.right - 12, top.bottom), (top.right - 8, 676), 6)
                props.box(surf, top, (214, 160, 106), radius=5, shade=(186, 132, 82), offset=(3, 4))
                for k, (ox, oy) in enumerate(((8, -24), (34, -24), (20, -48))):
                    col = A.PAPER_COLORS[(i * 3 + k) % len(A.PAPER_COLORS)]
                    r = pygame.Rect(top.x + ox, top.y + oy, 24, 24)
                    pygame.draw.rect(surf, col, r, border_radius=5)
                    pygame.draw.rect(surf, C.INK, r, 2, border_radius=5)
        if not self.picking:
            self.new_btn.draw(surf)
            self.cont_btn.draw(surf)
            self.album_btn.draw(surf)
            if self.saved:
                s = self.saved
                text = f"이어하기: {s['level']['name']} · {s['day_i'] + 1}일차 · 모은 별 {sum(s['stars'])}"
                w = ui.fonts.get(13, True).size(text)[0] + 28
                chip(surf, (WIDTH // 2 - w // 2, 478, w, 28), text, PAPER, INK, 13)
        else:
            chip(surf, (WIDTH // 2 - 80, 292, 160, 30), "난이도 선택", INK, size=15)
            mouse = pygame.mouse.get_pos()
            rec = self.app.profile.data.get("agency", {}).get("levels", {})
            for i, lv in enumerate(self.levels):
                r = self._level_rect(i)
                r = r.move(0, -6 if r.collidepoint(mouse) else 0)
                col = tuple(lv["color"])
                card(surf, r, 22)
                pygame.draw.rect(surf, col, (r.x, r.y, r.w, 70), border_top_left_radius=22, border_top_right_radius=22)
                c = (r.x + 46, r.y + 35)
                pygame.draw.circle(surf, PAPER, c, 30)
                clip = surf.get_clip()
                surf.set_clip(pygame.Rect(c[0] - 28, c[1] - 30, 56, 58))
                surf.blit(self.faces[i], self.faces[i].get_rect(midtop=(c[0], c[1] - 26)))
                surf.set_clip(clip)
                pygame.draw.circle(surf, shade(col, 0.7), c, 30, 3)
                ui.draw_text(surf, lv["name"], (r.centerx + 30, r.y + 36), 24, PAPER, "heavy", center=True)
                chip(surf, (r.centerx - 70, r.y + 84, 140, 26), lv["tag"], shade(col, 0.85), size=13)
                ui.draw_wrapped(surf, lv["desc"], (r.x + 22, r.y + 124, r.w - 44, 80), 14, INK, True)
                if lv.get("tutorial"):
                    chip(surf, (r.x + 22, r.bottom - 40, 104, 26), "튜토리얼 포함", ORANGE, size=12)
                if lv["id"] in rec:
                    chip(surf, (r.right - 112, r.bottom - 40, 90, 26), f"클리어 {rec[lv['id']]}", GREEN, size=12)
        self.back_btn.label = "뒤로" if self.picking else "처음으로"
        self.back_btn.draw(surf)
        _ = HEIGHT
