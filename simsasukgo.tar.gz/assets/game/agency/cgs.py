"""요청하GO! 우리 학교의 이벤트 CG — 같은 CG 틀(game/cg.py)에 game="agency" 로 등록한다.

배역:  주인공(st.hero) = 그 난이도의 주무관,  팀장 자리(st.boss) = 그날의 현장 담당자,  동료 자리(st.mate) = 도우미.
"""
import pygame

from .. import cg as C
from .. import props, ui
from ..cg import INK, Stage, cg
from ..config import WIDTH

GAME = "agency"
MILESTONES = ("a_open", "a_arrive", "a_helper", "a_finale")
PAPERS = [(255, 170, 150), (255, 210, 120), (170, 220, 150), (150, 205, 240), (200, 175, 240)]


def classroom(s, board_text=None):
    s.fill((255, 244, 214))
    board = pygame.Rect(250, 60, 780, 260)
    props.box(s, board, (46, 96, 78), radius=10, offset=(7, 9))
    pygame.draw.rect(s, (170, 120, 70), board, 10, border_radius=10)
    if board_text:
        ui.draw_text(s, board_text, board.center, 44, (250, 250, 240), "heavy", center=True)
    props.draw_window(s, (40, 80, 170, 150), 4.0, 0.0)
    props.draw_window(s, (1070, 80, 170, 150), 4.0, 0.0)
    pygame.draw.rect(s, (250, 228, 180), (0, 420, WIDTH, 60))
    pygame.draw.line(s, INK, (0, 420), (WIDTH, 420), 3)
    C._ground(s, 480, (226, 186, 134))
    C.bunting(s, 0, WIDTH, 4, 30)
    return board


def paper_blocks(s, x, y, n=5, size=44):
    for i in range(n):
        r = pygame.Rect(x + (i % 3) * (size + 4), y - (i // 3) * (size + 4), size, size)
        pygame.draw.rect(s, PAPERS[i % len(PAPERS)], r, border_radius=8)
        pygame.draw.rect(s, INK, r, 3, border_radius=8)


@cg("a_open", "첫 요청서", "현장의 부탁을 받아 적었다. 이제 이걸 예산 안에서, 떳떳한 방법으로 풀어야 한다.", slots=0, game=GAME)
def _open(st: Stage):
    s = st.s
    classroom(s, "오늘 필요한 것은?")
    C.table(s, (430, 520, 420, 40))
    paper_blocks(s, 470, 470, 5)
    st.hero((380, 640), expr="nervous", pose="shrug", scale=1.1, angle=-4, full=True)
    st.boss((900, 640), expr="happy", pose="point", scale=1.08, angle=5, full=True, flip=True)
    C.speech(s, (640, 340, 420, 80), "꼭 필요한 만큼만, 잘 부탁드려요!", (880, 440), 19)


@cg("a_arrive", "물건이 도착한 날", "요청서 한 장이 조달청과 공장을 돌아 상자가 되어 돌아왔다. 현장이 환해졌다.", slots=1, game=GAME)
def _arrive(st: Stage):
    s = st.s
    classroom(s, "고맙습니다!")
    for i, x in enumerate((240, 360, 300)):
        C.carton(s, x, 620 - (i // 2) * 66, 104, "납품")
    st.boss((560, 640), expr="happy", pose="cheer", scale=1.08, angle=-6, full=True, legs=(-16, 16), ground=652)
    st.hero((800, 640), expr="happy", pose="clap", scale=1.1, angle=4, full=True, flip=True)
    st.actor(st.mate(0), (1040, 640), "happy", "hi", 0.96, 6, full=True, flip=True)
    C.confetti(s, 120, 3)


@cg("a_helper", "응원 편지", "요청서를 반듯하게 써 냈더니 돕겠다는 사람이 나타났다. 혼자 하는 일이 아니었다.", slots=1, game=GAME)
def _helper(st: Stage):
    s = st.s
    classroom(s)
    C.banner(s, (400, 130, 480, 80), "같이 해요!", (140, 110, 200), 44)
    st.hero((460, 640), expr="happy", pose="wave", scale=1.1, angle=-4, full=True)
    st.actor(st.mate(0), (820, 640), "happy", "hi", 1.08, 6, full=True, flip=True)
    paper_blocks(s, 580, 600, 3, 40)


@cg("a_finale", "닷새의 요청서", "다섯 곳의 부탁을 다섯 장의 요청서로 풀어냈다. 필요한 것이 필요한 곳에 닿았다.", slots=3, game=GAME)
def _finale(st: Stage):
    s = st.s
    classroom(s, "닷새 동안 수고했어요")
    st.actor(st.mate(1), (230, 640), "happy", "wave", 0.94, -6, full=True)
    st.actor(st.mate(0), (430, 644), "happy", "cheer", 0.98, -3, full=True)
    st.hero((650, 640), expr="happy", pose="cheer", scale=1.14, angle=0, full=True, legs=(-14, 14), ground=654)
    st.boss((870, 644), expr="happy", pose="clap", scale=1.0, angle=4, full=True, flip=True)
    st.actor(st.mate(2), (1060, 640), "happy", "hi", 0.94, 6, full=True, flip=True)
    C.confetti(s, 160, 6)
