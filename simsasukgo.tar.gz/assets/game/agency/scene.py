"""요청하GO! 우리 학교 — 수요기관 담당자가 되어, 현장에 필요한 물건을 예산 안에서 요청한다 (배치 퍼즐).

심사숙GO·납품하GO와 같은 닷새, 같은 다섯 사건(data/world.json)을 '필요하다고 말하는 쪽'에서 겪는다.
하루의 흐름:  현장 목소리 듣기 → 칠판 퍼즐(색종이 블록을 끌어 빈칸 채우기) → 요청서 보내기 → 물건 도착
  별: 통과 1개 + 한 번에 통과 1개 + 고급형 없이 알뜰하게 1개.  별 셋이면 응원 편지(도우미 뽑기).
날마다 규칙이 하나씩 는다 (data/agency.json rules).  시간 제한은 없다 — 차분히 생각하는 편.
"""
import json
import math
import random

import pygame

from .. import cg as C
from .. import props, sfx, storage, ui
from ..character import Character
from ..config import HEIGHT, WIDTH
from ..factory.iso import GREEN, INK, ORANGE, PAPER, RED, SOFT, TEAL, YELLOW, Btn, card, chip, shade
from ..scenes.base import Scene
from . import helpers as H
from . import puzzle as P

INTRO, PUZZLE, RESULT, END = "intro", "puzzle", "result", "end"
PURPLE = (140, 110, 200)
BOARD = pygame.Rect(30, 148, 652, 456)                          # 칠판
TRAY = pygame.Rect(700, 148, 556, 480)                          # 색종이 블록 쟁반
CELL = 84
SLOT_W, SLOT_H, TRAY_CELL = 111, 96, 20
PAPER_COLORS = [(255, 170, 150), (255, 210, 120), (170, 220, 150), (150, 205, 240), (200, 175, 240), (255, 180, 215),
                (160, 225, 215), (250, 195, 150)]
TAG = {"premium": ("고급", (226, 160, 30)), "fresh": ("기한", (60, 150, 220)), "sme": ("중소", (60, 160, 96)),
       "brand": ("상표", (226, 76, 76)), "mini": ("낱개", (130, 136, 150))}
SAVE_NAME = "agency_save.json"
_BG: dict = {}


def record(app) -> dict:
    """꺼도 남는 요청하GO! 기록 (도감이 읽는다)."""
    rec = app.profile.data.setdefault("agency", {})
    for key in ("levels", "helpers"):
        if not isinstance(rec.get(key), dict):
            rec[key] = {}
    rec.setdefault("best_stars", 0)
    return rec


def load_save(app) -> dict | None:
    try:
        data = json.loads(storage.read(app.profile.dir, SAVE_NAME) or "")
        level = next(lv for lv in app.data.agency["levels"] if lv["id"] == data["level"])
        if not 0 <= data["day_i"] < len(app.data.world["cases"]):
            return None
        return dict(data, level=level)
    except Exception:
        return None


def delete_save(app):
    storage.delete(app.profile.dir, SAVE_NAME)


def classroom_background():
    """교실 — 크림색 벽, 색종이 줄, 나무 바닥. (칠판과 쟁반은 장면이 그 위에 그린다)"""
    if "room" not in _BG:
        s = pygame.Surface((WIDTH, HEIGHT))
        s.fill((255, 244, 214))
        pygame.draw.rect(s, (250, 228, 180), (0, 560, WIDTH, 60))             # 허리 몰딩
        pygame.draw.line(s, C.INK, (0, 560), (WIDTH, 560), 3)
        C._ground(s, 620, (226, 186, 134))
        for y in (654, 690):
            pygame.draw.line(s, (206, 164, 112), (0, y), (WIDTH, y), 3)
        C.bunting(s, 0, WIDTH, 6, 30)
        _BG["room"] = s.convert()
    return _BG["room"]


def draw_piece(surf, piece, x, y, cs, color, ghost=None):
    """색종이 블록. (x, y) = 블록 왼쪽 위, cs = 한 칸 크기. ghost = 놓을 수 있는지 미리 보기 색."""
    for dx, dy in piece["cells"]:
        r = pygame.Rect(x + dx * cs, y + dy * cs, cs, cs).inflate(-max(2, cs // 14), -max(2, cs // 14))
        if ghost:
            pygame.draw.rect(surf, ghost, r, max(2, cs // 16), border_radius=max(3, cs // 9))
            continue
        pygame.draw.rect(surf, shade(color, 0.72), r.move(0, max(1, cs // 20)), border_radius=max(3, cs // 9))
        pygame.draw.rect(surf, color, r, border_radius=max(3, cs // 9))
        if cs >= 40:                                               # 종이 접힌 귀퉁이
            pygame.draw.polygon(surf, shade(color, 1.12), [(r.right - cs // 4, r.y), (r.right, r.y), (r.right, r.y + cs // 4)])
    tag = next((t for t in ("brand", "premium", "fresh", "sme", "mini") if t in piece["tags"]), None)
    if tag and not ghost:
        text, col = TAG[tag]
        dx, dy = piece["cells"][0]
        if cs >= 40:
            chip(surf, (x + dx * cs + 8, y + dy * cs + 8, 44, 22), text, col, size=12)
        else:
            pygame.draw.circle(surf, col, (x + dx * cs + cs // 2, y + dy * cs + cs // 2), 6)


class AgencyScene(Scene):
    BGM = "agency"
    HOME = "agency_title"

    def __init__(self, app, level=None, saved=None, seed=None):
        super().__init__(app)
        self.cfg = app.data.agency
        self.level = level or self.cfg["levels"][1]
        self.rng = random.Random(seed)
        self.days = len(app.data.world["cases"])
        self.day_i = 0
        self.stars = []                  # 날마다 받은 별
        self.helpers = []                # 함께하는 도우미 (응원 편지에서 온다, 최대 3명)
        self.run_cgs = []
        self.cg_wait = []
        self.after_wait = False
        self.seeds = [self.rng.randrange(10 ** 6) for _ in range(self.days)]
        self.tutorial = bool(self.level.get("tutorial")) and saved is None
        if saved:
            self.day_i, self.stars = saved["day_i"], list(saved["stars"])
            self.helpers, self.run_cgs, self.seeds = list(saved["helpers"]), list(saved["cgs"]), list(saved["seeds"])
        self.t = self.phase_t = 0.0
        self.toast = None
        self.guide = Character(app.data.dialogue["mascots"]["narmi"]["look"])
        self.guide.expression = "happy"
        self.guide.set_pose("point")
        self.me = Character(self.level["look"])                       # 나 (그 난이도의 주무관)
        self.speaker = None
        self.next_btn = Btn((WIDTH - 290, HEIGHT - 86, 260, 58), "다음", PURPLE, 20)
        self.send_btn = Btn((TRAY.right - 250, 92, 250, 48), "요청서 보내기", ORANGE, 19)
        self.hint_btn = Btn((TRAY.x, 92, 170, 48), "길잡이", GREEN, 16)
        self.reset_btn = Btn((TRAY.x + 186, 92, 110, 48), "다시", (150, 160, 166), 16)
        self._start_day()

    # ================================================================ 하루 준비
    @property
    def day(self) -> int:
        return self.day_i + 1

    def _go(self, phase):
        self.phase, self.phase_t = phase, 0.0

    def _save(self):
        storage.write(self.app.profile.dir, SAVE_NAME, json.dumps(
            {"level": self.level["id"], "day_i": self.day_i, "stars": self.stars, "helpers": self.helpers,
             "cgs": self.run_cgs, "seeds": self.seeds}, ensure_ascii=False))

    def _start_day(self):
        data, tut = self.app.data, self.tutorial
        self.case = data.case_of(self.day)
        self.daycfg = self.cfg["days"][self.day_i]
        self.perks = {} if tut else H.perks(self.helpers)
        if not tut:
            if self.day_i == 0 and "a_open" not in self.run_cgs:
                self.cg_wait.append(("a_open", None))
            self._save()
        pz = self.pz = P.make(self.level, self.day, self.cfg, self.seeds[self.day_i] + (999 if tut else 0), tutorial=tut)
        self.cell = min(CELL, (BOARD.h - 76) // pz["h"], (BOARD.w - 40) // pz["w"])      # 칠판에 맞는 칸 크기
        if "budget" in self.perks:                                    # 예산 따오기
            pz["budget"] = int(pz["budget"] * (1 + self.perks["budget"][1]["up"]) // 5 * 5)
        if "sort" in self.perks:                                      # 정리 반장: 미끼 블록을 미리 치운다
            junk = [p for p in pz["pieces"] if p["home"] is None][:self.perks["sort"][1]["n"]]
            pz["pieces"] = [p for p in pz["pieces"] if not any(p is j for j in junk)]
        for i, p in enumerate(pz["pieces"]):
            p["color"] = PAPER_COLORS[i % len(PAPER_COLORS)]
        self.hints_left = self.perks["hint"][1]["n"] if "hint" in self.perks else 0
        self.tries = 0
        self.drag = None                 # (블록, 잡은 칸의 어긋남 x, y)
        self.mouse = (0, 0)
        self.shake = 0.0
        self.idle = 0.0
        self.voice_i = 0
        self.star_now = 0
        self.speaker = Character(self.case["officer"]["look"])
        self.speaker.expression = "happy"
        self._go(PUZZLE if tut else INTRO)
        sfx.play("pop", 0.5)

    # ================================================================ 퍼즐 조작 (화면 없이도 불러 쓸 수 있다)
    def grid_origin(self):
        pz = self.pz
        return BOARD.centerx - pz["w"] * self.cell // 2, BOARD.y + 52 + (BOARD.h - 70 - pz["h"] * self.cell) // 2

    def slot_rect(self, i):
        return pygame.Rect(TRAY.x + (i % 5) * SLOT_W, TRAY.y + 8 + (i // 5) * SLOT_H, SLOT_W, SLOT_H)

    def place(self, piece, at) -> bool:
        if self.phase != PUZZLE or not P.can_place(self.pz, piece, at):
            return False
        piece["at"] = tuple(at)
        self.idle = 0.0
        sfx.play("paper", 0.5)
        return True

    def take_back(self, piece):
        piece["at"] = None
        self.idle = 0.0

    def reset_board(self):
        for p in self.pz["pieces"]:
            p["at"] = None
        sfx.play("paper", 0.4)

    def use_hint(self) -> bool:
        """길잡이: 아직 안 놓은 정답 블록 하나를 제자리에 놓는다 (걸리는 블록은 쟁반으로 돌려보낸다)."""
        if self.phase != PUZZLE or self.hints_left <= 0:
            return False
        todo = [p for p in self.pz["pieces"] if p["home"] is not None and p["at"] != p["home"]]
        if not todo:
            return False
        p = todo[0]
        want = set(P.cells_of(p, p["home"]))
        for q in self.pz["pieces"]:
            if q is not p and q["at"] is not None and want & set(P.cells_of(q)):
                q["at"] = None
        p["at"] = p["home"]
        self.hints_left -= 1
        who = self.perks["hint"][2]
        self.toast = (f"{who['nick']}: “{who['say']['hint']}”", 2.4)
        sfx.play("correct", 0.5)
        return True

    def submit(self):
        """요청서 보내기. 조건이 하나라도 안 맞으면 보완 요청으로 돌아온다."""
        if self.phase != PUZZLE:
            return
        res = P.check(self.pz)
        bad = next((r for r, ok, _ in res if not ok), None)
        if bad:
            self.tries += 1
            rule = self.cfg["rules"][bad]
            self.toast = (f"보완 요청: {rule['name']} — {rule['why']}", 5.0)
            self.shake = 0.4
            sfx.play("wrong", 0.6)
            return
        if self.tutorial:
            self.star_now = 3
        else:
            self.star_now = 1 + (self.tries == 0) + (P.spent(self.pz) <= self.pz["best"])
            self.stars.append(self.star_now)
        self.hire = not self.tutorial and self.star_now == 3 and len(self.helpers) < H.MAX_HELPERS
        self.speaker.expression = "happy"
        self.speaker.set_pose("cheer")
        self.next_btn.label = "진짜 첫 요청 시작!" if self.tutorial else "응원 편지 열기!" if self.hire else "다음"
        self._go(RESULT)
        sfx.play("fanfare", 0.5)

    def show_cg(self, cg_id, then=None):
        from ..scenes.cgscene import CGScene
        if cg_id not in self.run_cgs:
            self.run_cgs.append(cg_id)

        def done():
            if then:
                then()
            self.app.change(lambda: self)
        chief = {"look": self.case["officer"]["look"], "name": self.case["officer"]["name"], "difficulty": self.level["name"]}
        looks = [m["look"] for m in self.helpers]
        self.app.change(lambda: CGScene(self.app, cg_id, chief=chief, mates=looks, on_done=done, hero_look=self.level["look"]))

    def hire_helper(self):
        from ..scenes.gacha import GachaScene

        def done():                                              # 이 장면으로 돌아온 뒤에 다음 차례(CG·다음 날)로
            self.after_wait = True
            self.app.change(lambda: self)
        self.app.change(lambda: GachaScene(self.app, 1, H.kit(self.app, self, done)))

    def _after_result(self):
        """결과를 본 뒤: (처음 겪은 일의 CG) → 다음 날 / 엔딩."""
        def next_day():
            self.day_i += 1
            self._start_day()
        last = self.day_i >= self.days - 1
        firsts = (("a_arrive", True), ("a_helper", bool(self.helpers)))
        cg_id = next((c for c, ok in firsts if ok and c not in self.run_cgs), None)
        if last:
            self.show_cg("a_finale", self._finish)
        elif cg_id:
            self.show_cg(cg_id, next_day)
        else:
            next_day()

    def _finish(self):
        total = sum(self.stars)
        g = next(x for x in self.cfg["grades"] if total >= x[0])
        self.grade = (g[1], g[2])
        delete_save(self.app)
        rec = record(self.app)
        rec["clear"] = True
        rec["best_stars"] = max(rec["best_stars"], total)
        old = rec["levels"].get(self.level["id"], "C")
        rec["levels"][self.level["id"]] = max(old, g[1], key="CBAS".index)
        self.app.profile.save()
        self.me.expression = "happy"
        self.me.set_pose("cheer")
        self.next_btn.label = "처음 화면으로"
        self._go(END)
        sfx.play("fanfare", 0.6)

    def advance(self):
        ph = self.phase
        if ph == INTRO:
            if self.voice_i < len(self.daycfg["voices"]) - 1:
                self.voice_i += 1
                self.phase_t = 0.0
                sfx.play("pop", 0.4)
            else:
                self._go(PUZZLE)
                sfx.play("paper", 0.5)
        elif ph == RESULT:
            if self.tutorial:                                        # 연습 끝 → 진짜 1일차
                self.tutorial = False
                self._start_day()
            elif self.hire:
                self.hire = False
                self.hire_helper()
            else:
                self._after_result()
        elif ph == END:
            self.app.to_agency()

    # ================================================================ 입력
    def _cell_at(self, pos):
        ox, oy = self.grid_origin()
        return (pos[0] - ox) // self.cell, (pos[1] - oy) // self.cell

    def _drop_target(self):
        """끌고 있는 블록이 놓일 칸 (왼쪽 위)."""
        piece, gx, gy = self.drag
        ox, oy = self.grid_origin()
        return round((self.mouse[0] - gx - ox) / self.cell), round((self.mouse[1] - gy - oy) / self.cell)

    def handle_event(self, event):
        ph = self.phase
        down = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        go = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE)
        if hasattr(event, "pos"):
            self.mouse = event.pos
        if ph == PUZZLE:
            if down:
                self.idle = 0.0
                if self.send_btn.clicked(event):
                    self.submit()
                    return
                if self.hints_left > 0 and self.hint_btn.clicked(event):
                    self.use_hint()
                    return
                if self.reset_btn.clicked(event):
                    self.reset_board()
                    return
                cell = self._cell_at(event.pos)
                for p in self.pz["pieces"]:                          # 칠판에 놓인 블록을 집는다
                    if p["at"] is not None and cell in P.cells_of(p):
                        ox, oy = self.grid_origin()
                        self.drag = (p, event.pos[0] - (ox + p["at"][0] * self.cell), event.pos[1] - (oy + p["at"][1] * self.cell))
                        p["at"] = None
                        sfx.play("paper", 0.3)
                        self._warn(p)
                        return
                for i, p in enumerate(self.pz["pieces"]):            # 쟁반의 블록을 집는다
                    if p["at"] is None and self.slot_rect(i).collidepoint(event.pos):
                        self.drag = (p, self.cell // 2, self.cell // 2)
                        sfx.play("paper", 0.3)
                        self._warn(p)
                        return
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag:
                piece = self.drag[0]
                at = self._drop_target()
                self.drag = None
                if not self.place(piece, at):
                    sfx.play("pop", 0.2)
            elif go:
                self.submit()
        elif self.phase_t > 0.4 and (down or go):
            if ph == INTRO or self.next_btn.clicked(event) or go:
                self.advance()

    def _warn(self, piece):
        """규칙 지킴이: 어긋나거나 비싼 블록을 집으면 알려 준다."""
        if "warn" not in self.perks or piece.get("warned") is not None:
            return
        risky = piece["tags"] & {"brand", "premium"} or ("sme" in self.pz["rules"] and piece["home"] is None and len(piece["cells"]) > 1
                                                           and not piece["tags"])
        piece["warned"] = bool(risky) and self.rng.random() < self.perks["warn"][1]["chance"]
        if piece["warned"]:
            who = self.perks["warn"][2]
            self.toast = (f"{who['nick']}: “{who['say']['warn']}”", 2.6)
            sfx.play("bell", 0.4)

    # ================================================================ 갱신
    def update(self, dt):
        self.t += dt
        self.phase_t += dt
        self.idle += dt
        self.shake = max(0.0, self.shake - dt)
        for ch in (self.guide, self.me, self.speaker):
            if ch:
                ch.update(dt)
        for b in (self.next_btn, self.send_btn, self.hint_btn, self.reset_btn):
            b.update(dt)
        if self.toast:
            self.toast = (self.toast[0], self.toast[1] - dt) if self.toast[1] > dt else None
        if self.app.fade_next is None and self.app.scene is self:
            if self.after_wait:
                self.after_wait = False
                self._after_result()
            elif self.cg_wait:
                self.show_cg(*self.cg_wait.pop(0))

    # ================================================================ 그리기
    def _hud(self, surf):
        card(surf, (24, 18, 420, 62), 16)
        ui.draw_text(surf, "요청하GO! 우리 학교", (42, 28), 13, PURPLE, True)
        head = "튜토리얼" if self.tutorial else f"{self.day}일차 · {self.case['agency']} {self.case['officer']['name']}"
        ui.draw_text(surf, head, (42, 46), 17, INK, "heavy")
        chip(surf, (320, 26, 110, 22), self.level["name"], tuple(self.level["color"]), size=11)
        card(surf, (460, 18, 200, 62), 16)
        ui.draw_text(surf, "모은 별", (476, 28), 12, SOFT, True)
        ui.draw_text(surf, f"★ {sum(self.stars)}", (476, 44), 20, ORANGE, "heavy")
        if self.helpers:
            w = 26 + len(self.helpers) * 96
            card(surf, (676, 18, w, 62), 16)
            for i, m in enumerate(self.helpers):
                x = 690 + i * 96
                pygame.draw.circle(surf, pygame.Color(m["look"]["body"]), (x + 14, 49), 14)
                pygame.draw.circle(surf, INK, (x + 14, 49), 14, 2)
                ui.draw_text(surf, m["nick"], (x + 34, 32), 13, INK, True)
                ui.draw_text(surf, H.SKILLS[m["skills"][0]["type"]]["name"], (x + 34, 50), 10, SOFT, True)

    def _draw_intro(self, surf):
        d = self.daycfg
        board = pygame.Rect(150, 110, 980, 300)
        props.box(surf, board, (46, 96, 78), radius=10, offset=(7, 9))
        pygame.draw.rect(surf, (170, 120, 70), board, 10, border_radius=10)
        ui.draw_text(surf, f"{self.day}일차 · {self.case['agency']}", (board.centerx, board.y + 54), 34, (250, 250, 240), "heavy", center=True)
        ui.draw_text(surf, f"오늘 필요한 것: {self.case['item']}", (board.centerx, board.y + 110), 24, (255, 236, 150), True, center=True)
        ui.draw_wrapped(surf, f"“{self.case['need']}”", (board.x + 120, board.y + 156, board.w - 240, 80), 20, (236, 244, 236), True)
        new = [r for r, v in self.cfg["rules"].items() if v["day"] == self.day and r not in ("cover", "budget")]
        if new:
            rule = self.cfg["rules"][new[0]]
            chip(surf, (board.centerx - 200, board.bottom - 58, 400, 34), f"오늘의 새 규칙: {rule['name']}", ORANGE, size=16)
        self.speaker.draw(surf, (250, 620 - C.FOOT * 0.8), scale=0.8, full=True)
        who, line = d["voices"][self.voice_i]
        C.speech(surf, (400, 450, 640, 110), line, (360, 500), 20)
        chip(surf, (420, 416, ui.fonts.get(14, True).size(who)[0] + 28, 28), who, PURPLE, size=14)
        ui.draw_text(surf, f"{self.voice_i + 1} / {len(d['voices'])}   눌러서 계속", (1030, 574), 14, SOFT, True, anchor="topright")

    def _draw_board(self, surf):
        pz = self.pz
        sx = int(math.sin(self.t * 60) * 8 * (self.shake / 0.4)) if self.shake > 0 else 0
        b = BOARD.move(sx, 0)
        props.box(surf, b, (46, 96, 78), radius=10, offset=(7, 9))
        pygame.draw.rect(surf, (170, 120, 70), b, 10, border_radius=10)
        ui.draw_text(surf, self.daycfg["board"] if not self.tutorial else "연습 칠판", (b.x + 24, b.y + 18), 16, (220, 236, 224), True)
        ox, oy = self.grid_origin()
        ox += sx
        if pz["zone"]:                                               # '먼저 쓸 곳' (기한 있는 물품)
            z = pygame.Rect(ox - 6, oy - 6, pz["w"] * self.cell + 12, pz["zone"] * self.cell + 6)
            hl = pygame.Surface(z.size, pygame.SRCALPHA)
            hl.fill((120, 200, 255, 46))
            surf.blit(hl, z)
            ui.draw_text(surf, "파란 줄 = 먼저 쓸 곳 (기한 있는 물품은 여기에만)", (b.right - 24, b.y + 20), 13, (170, 220, 255), True,
                         anchor="topright")
        for y in range(pz["h"]):
            for x in range(pz["w"]):
                r = pygame.Rect(ox + x * self.cell, oy + y * self.cell, self.cell, self.cell)
                if (x, y) in pz["blocked"]:                          # 못 쓰는 칸 (기둥·가구)
                    pygame.draw.rect(surf, (36, 74, 60), r.inflate(-8, -8), border_radius=8)
                    pygame.draw.line(surf, (90, 130, 112), (r.x + 22, r.y + 22), (r.right - 22, r.bottom - 22), 4)
                    pygame.draw.line(surf, (90, 130, 112), (r.right - 22, r.y + 22), (r.x + 22, r.bottom - 22), 4)
                else:                                                # 분필로 그린 빈칸
                    pygame.draw.rect(surf, (214, 232, 220), r.inflate(-8, -8), 2, border_radius=8)
        for p in pz["pieces"]:
            if p["at"] is not None:
                draw_piece(surf, p, ox + p["at"][0] * self.cell, oy + p["at"][1] * self.cell, self.cell, p["color"])
        if self.tutorial and self.idle > 9 and not self.drag:        # 오래 머뭇거리면 놓을 자리를 알려 준다
            p = next((p for p in pz["pieces"] if p["home"] is not None and p["at"] != p["home"]), None)
            if p:
                draw_piece(surf, p, ox + p["home"][0] * self.cell, oy + p["home"][1] * self.cell, self.cell, None, ghost=ORANGE)
                i = next(i for i, q in enumerate(pz["pieces"]) if q is p)
                pygame.draw.rect(surf, ORANGE, self.slot_rect(i).inflate(-6, -6), 3 + int(abs(math.sin(self.t * 5)) * 3), border_radius=12)

    def _draw_tray(self, surf):
        pz = self.pz
        card(surf, TRAY.inflate(16, 12), 18)
        for i, p in enumerate(pz["pieces"]):
            r = self.slot_rect(i)
            if p["at"] is not None or (self.drag and self.drag[0] is p):
                pygame.draw.rect(surf, (240, 243, 246), r.inflate(-10, -10), border_radius=10)
                continue
            w = (max(x for x, _ in p["cells"]) + 1) * TRAY_CELL
            h = (max(y for _, y in p["cells"]) + 1) * TRAY_CELL
            draw_piece(surf, p, r.centerx - w // 2, r.y + 6 + (60 - h) // 2 + (10 if h <= 40 else 0), TRAY_CELL, p["color"])
            tag = next((t for t in ("brand", "premium", "fresh", "sme", "mini") if t in p["tags"]), None)
            text = f"{p['cost']}만"
            if tag:
                tw = ui.fonts.get(12, True).size(text)[0]
                x0 = r.centerx - (tw + 40) // 2
                ui.draw_text(surf, text, (x0, r.bottom - 22), 12, INK, True)
                chip(surf, (x0 + tw + 6, r.bottom - 24, 34, 18), TAG[tag][0], TAG[tag][1], size=10)
            else:
                ui.draw_text(surf, text, (r.centerx, r.bottom - 14), 12, INK, True, center=True)

    def _draw_status(self, surf):
        pz = self.pz
        res = P.check(pz)
        spent, budget = P.spent(pz), pz["budget"]
        bar = pygame.Rect(BOARD.x, 96, BOARD.w, 40)                    # 예산 막대
        card(surf, bar, 14)
        over = spent > budget
        ui.draw_text(surf, "예산", (bar.x + 16, bar.centery), 15, INK, "heavy", anchor="midleft")
        track = pygame.Rect(bar.x + 66, bar.y + 13, bar.w - 250, 14)
        pygame.draw.rect(surf, (232, 236, 240), track, border_radius=7)
        k = min(1.0, spent / budget)
        if k > 0.02:
            pygame.draw.rect(surf, RED if over else GREEN if k < 0.9 else YELLOW, (track.x, track.y, int(track.w * k), track.h), border_radius=7)
        ui.draw_text(surf, f"{spent} / {budget}만원", (bar.right - 16, bar.centery), 16, RED if over else INK, "heavy", anchor="midright")
        for i, (rule, ok, state) in enumerate(res):                  # 조건 카드
            r = pygame.Rect(BOARD.x + (i % 3) * 220, 614 + (i // 3) * 46, 212, 40)
            pygame.draw.rect(surf, (232, 246, 236) if ok else (255, 240, 236), r, border_radius=12)
            pygame.draw.rect(surf, GREEN if ok else RED, r, 2, border_radius=12)
            pygame.draw.circle(surf, GREEN if ok else RED, (r.x + 20, r.centery), 10)
            if ok:
                c = (r.x + 20, r.centery)
                pygame.draw.lines(surf, PAPER, False, [(c[0] - 5, c[1]), (c[0] - 1, c[1] + 4), (c[0] + 6, c[1] - 4)], 3)
            else:
                ui.draw_text(surf, "!", (r.x + 20, r.centery - 1), 13, PAPER, "heavy", center=True)
            name = self.cfg["rules"][rule]["name"]
            size = 13
            while size > 9 and ui.fonts.get(size, True).size(name)[0] > r.w - 44:
                size -= 1
            ui.draw_text(surf, name, (r.x + 36, r.y + 4), size, INK, True)
            ui.draw_text(surf, state, (r.x + 36, r.y + 22), 11, SOFT, True)
        self.send_btn.draw(surf)
        self.reset_btn.draw(surf)
        if "hint" in self.perks:
            self.hint_btn.label = f"길잡이 {self.hints_left}번"
            self.hint_btn.enabled = self.hints_left > 0
            self.hint_btn.draw(surf)
        tip = "블록을 끌어 칠판에 놓기 · 놓은 블록을 끌면 도로 뺄 수 있어요"
        ui.draw_text(surf, tip, (TRAY.centerx, TRAY.bottom + 22), 13, (120, 96, 70), True, center=True)
        if self.tries:
            ui.draw_text(surf, f"보완 요청 {self.tries}번", (TRAY.right, TRAY.bottom + 44), 13, RED, True, anchor="topright")

    def _draw_drag(self, surf):
        piece, gx, gy = self.drag
        ox, oy = self.grid_origin()
        at = self._drop_target()
        if 0 <= at[0] < self.pz["w"] and 0 <= at[1] < self.pz["h"]:
            ok = P.can_place(self.pz, piece, at)
            draw_piece(surf, piece, ox + at[0] * self.cell, oy + at[1] * self.cell, self.cell, None, ghost=(160, 255, 190) if ok else (255, 130, 120))
        draw_piece(surf, piece, self.mouse[0] - gx, self.mouse[1] - gy - 6, self.cell, piece["color"])

    def _draw_tutorial(self, surf):
        tut = self.cfg["tutorial"]
        placed = sum(1 for p in self.pz["pieces"] if p["at"] is not None)
        full = P.check(self.pz)[0][1]
        text = tut["submit"] if full else tut["budget"] if placed >= 2 else tut["drag"] if self.phase_t > 4 or placed else tut["intro"]
        r = pygame.Rect(BOARD.x + 150, BOARD.bottom - 104, BOARD.w - 170, 92)
        if self.pz["h"] * self.cell + 120 > BOARD.h:
            r.y = BOARD.bottom - 96
        card(surf, r, 16)
        clip = surf.get_clip()
        surf.set_clip(pygame.Rect(r.x + 4, r.y + 4, 88, r.h - 8))
        self.guide.draw(surf, (r.x + 48, r.y + 8), scale=0.34)
        surf.set_clip(clip)
        chip(surf, (r.x + 98, r.y + 10, 84, 22), "튜토리얼", ORANGE, size=12)
        ui.draw_wrapped(surf, text, (r.x + 98, r.y + 38, r.w - 112, 50), 14, INK, True)

    def _draw_result(self, surf):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((255, 244, 214, 190))
        surf.blit(veil, (0, 0))
        r = pygame.Rect(250, 120, 780, 500)
        card(surf, r, 26)
        ui.draw_text(surf, "연습 끝!" if self.tutorial else "물건이 도착했어요!", (r.centerx, r.y + 50), 34, INK, "heavy", center=True)
        for i in range(3):                                           # 별
            k = max(0.0, min(1.0, (self.phase_t - 0.3 - i * 0.25) / 0.2))
            on = i < self.star_now and k > 0
            cx, cy, rad = r.centerx - 90 + i * 90, r.y + 128, 34 * (0.6 + 0.4 * k if on else 1)
            pts = [(cx + math.cos(-math.pi / 2 + j * math.pi / 5) * (rad if j % 2 == 0 else rad * 0.45),
                    cy + math.sin(-math.pi / 2 + j * math.pi / 5) * (rad if j % 2 == 0 else rad * 0.45)) for j in range(10)]
            pygame.draw.polygon(surf, (255, 206, 70) if on else (226, 230, 234), pts)
            pygame.draw.polygon(surf, INK if on else (190, 196, 202), pts, 3)
        clip = surf.get_clip()
        area = pygame.Rect(r.x + 40, r.y + 190, 180, 190)
        pygame.draw.rect(surf, (240, 232, 250), area, border_radius=16)
        surf.set_clip(area)
        self.speaker.draw(surf, (area.centerx, area.y + 22), scale=0.6)
        surf.set_clip(clip)
        ui.draw_text(surf, f"{self.case['officer']['name']} {self.case['officer']['role']}", (area.x, area.bottom + 8), 12, SOFT, True)
        x = area.right + 30
        line = "이제 진짜 현장의 요청을 받으러 가요!" if self.tutorial else self.case["thanks"]
        y = ui.draw_wrapped(surf, f"“{line}”", (x, r.y + 196, r.right - x - 40, 80), 19, INK, True)
        if not self.tutorial:
            rows = [("요청서 통과", True), ("한 번에 통과 (보완 요청 없이)", self.tries == 0),
                    ("알뜰하게 (고급형 없이 딱 맞게)", P.spent(self.pz) <= self.pz["best"])]
            for i, (name, ok) in enumerate(rows):
                yy = max(y + 20, r.y + 290) + i * 34
                pygame.draw.circle(surf, (255, 206, 70) if ok else (226, 230, 234), (x + 12, yy + 10), 11)
                ui.draw_text(surf, "★", (x + 12, yy + 9), 13, INK if ok else (170, 176, 182), "heavy", center=True)
                ui.draw_text(surf, name, (x + 34, yy), 16, INK if ok else SOFT, True)
            ui.draw_text(surf, f"쓴 돈 {P.spent(self.pz)}만원 / 예산 {self.pz['budget']}만원", (x, r.bottom - 100), 14, SOFT, True)
        self.next_btn.rect = pygame.Rect(r.right - 300, r.bottom - 82, 270, 58)
        if self.phase_t > 0.6:
            self.next_btn.draw(surf)

    def _draw_end(self, surf):
        r = pygame.Rect(240, 80, 800, 570)
        card(surf, r, 26)
        g, name = self.grade
        ui.draw_text(surf, f"요청하GO! 우리 학교 · {self.level['name']}", (r.centerx, r.y + 34), 16, PURPLE, True, center=True)
        ui.draw_text(surf, "닷새의 요청서", (r.centerx, r.y + 78), 38, INK, "heavy", center=True)
        pygame.draw.circle(surf, PURPLE, (r.centerx, r.y + 190), 64)
        ui.draw_text(surf, g, (r.centerx, r.y + 188), 64, PAPER, "heavy", center=True)
        ui.draw_text(surf, name, (r.centerx, r.y + 280), 24, INK, "heavy", center=True)
        self.me.draw(surf, (r.x + 150, r.y + 110), scale=0.5)
        for i, st in enumerate(self.stars):
            x = r.centerx - (len(self.stars) - 1) * 62 + i * 124
            ui.draw_text(surf, f"{i + 1}일차", (x, r.y + 330), 13, SOFT, True, center=True)
            ui.draw_text(surf, "★" * st + "☆" * (3 - st), (x, r.y + 356), 20, ORANGE, "heavy", center=True)
        ui.draw_text(surf, f"모은 별 {sum(self.stars)} / {self.days * 3}", (r.centerx, r.y + 404), 18, INK, True, center=True)
        ui.draw_wrapped(surf, "필요한 것을, 필요한 만큼, 떳떳한 방법으로 — 좋은 요청서가 좋은 조달의 첫걸음입니다.",
                        (r.x + 80, r.y + 436, r.w - 160, 60), 17, INK, True)
        ui.draw_text(surf, "요청서가 조달청과 공장을 거치는 이야기는 ‘심사숙GO!’와 ‘납품하GO!’에서 이어집니다.", (r.centerx, r.bottom - 96), 13,
                     TEAL, True, center=True)
        self.next_btn.rect = pygame.Rect(r.centerx - 130, r.bottom - 74, 260, 56)
        self.next_btn.draw(surf)

    def draw(self, surf):
        surf.blit(classroom_background(), (0, 0))
        ph = self.phase
        if ph == END:
            self._draw_end(surf)
            return
        if ph == INTRO:
            self._draw_intro(surf)
        else:
            self._draw_board(surf)
            self._draw_tray(surf)
            self._draw_status(surf)
            if self.tutorial and ph == PUZZLE:
                self._draw_tutorial(surf)
            if self.drag:
                self._draw_drag(surf)
            if ph == RESULT:
                self._draw_result(surf)
        self._hud(surf)
        if self.toast:
            w = min(WIDTH - 60, ui.fonts.get(15, True).size(self.toast[0])[0] + 44)
            chip(surf, ((WIDTH - w) // 2, HEIGHT - 44, w, 34), self.toast[0], INK, size=15)
