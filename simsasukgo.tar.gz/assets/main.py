"""다함께 GO! 조달 한바퀴 — 진입점.  (묶음 첫 화면 → 심사숙GO! 조달청 / 납품하GO! 우리 공장)

asyncio 루프로 작성되어 있어 그대로 pygbag(웹 html 빌드)에서도 동작한다.

게임 흐름
  타이틀(새로 시작/이어하기/도감/설정) → 팀장 선택 → [CG 첫 출근] → 브리핑 → 심사 → 정산
    → (승진했으면 봉투 열기) → [CG] → 다음 날 브리핑 → … → 5일차 정산 → [CG 마지막 퇴근] → 엔딩
  하루를 시작할 때마다 자동 저장 → '이어하기'는 그 날 아침부터.
"""
import asyncio
import math
import os
import random
import time

import pygame

from game import bgm, cg, device, save, sfx, ui
from game.config import ASSET_DIR, FPS, HEIGHT, TITLE, WIDTH
from game.data_loader import load_all
from game.generator import BidGenerator
from game.profile import Profile
from game.scenes.album import AlbumScene
from game.scenes.briefing import BriefingScene
from game.scenes.cgscene import CGScene
from game.scenes.desk import DeskScene
from game.scenes.ending import EndingScene
from game.agency import cgs as _agency_cgs  # noqa: F401  (요청하GO의 CG 를 등록한다)
from game.agency.menu import AgencyTitleScene
from game.agency.scene import AgencyScene
from game.factory.menu import FactoryTitleScene
from game.factory.scene import FactoryScene
from game.scenes.gacha import GachaScene
from game.scenes.hub import HubScene
from game.scenes.life import LifeScene, health_factor, time_factor
from game.scenes.recap import RecapScene
from game.scenes.select import SelectScene
from game.scenes.settings import SettingsScene
from game.scenes.summary import SummaryScene
from game.scenes.title import TitleScene
from game.state import DayStats, GameState

FADE_SEC = 0.28
FADE_COLOR = (74, 52, 40)


MENU_BTN = pygame.Rect(8, 6, 74, 28)      # 터치 기기에서만 보이는 '메뉴'(타이틀로) 버튼


class App:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 1, 1024)  # 512는 느린 PC에서 음악이 끊겨 지직거린다. 1024 = 지연 23ms
        pygame.init()
        pygame.display.set_caption(TITLE)
        try:                                         # 창·작업표시줄 아이콘 (tools/make_icon.py)
            pygame.display.set_icon(pygame.image.load(os.path.join(ASSET_DIR, "icon.png")))
        except Exception:
            pass
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.data = load_all()
        self.state = GameState()
        self.generator = BidGenerator(self.data)
        self.rng = random.Random()        # 동료 뽑기·CG 고르기용 — 플레이할 때마다 다르게
        self.profile = Profile()          # 꺼도 남는 기록: 만난 동료, 클리어, 본 CG, 설정
        self.device = device.detect()     # PC 실행파일 / 웹 / 모바일 웹
        self.queue: list = []             # 정산 뒤에 차례로 할 일 (봉투 열기 → CG → 다음 날)
        self.running = True
        self.apply_settings()
        if self.profile.settings["fullscreen"]:
            self.set_fullscreen(True)
        bgm.on_heard = self.profile.mark_music
        self.scene = HubScene(self)
        self.play_music()
        self.mute_toast = 0.0
        self.frames = 0              # 그린 화면 수 (속도 점검용)
        self.menu_ask = 0.0          # 터치 기기의 '메뉴' 버튼: 한 번 누르면 확인, 한 번 더 누르면 타이틀로
        self.portrait = False        # 모바일에서 화면을 세로로 들고 있는가
        self.portrait_check = 0.0
        self.fade_next = None        # 페이드아웃 후 교체할 장면을 만드는 함수
        self.under = None            # 설정을 게임 중에 열었을 때, 그 밑에 멈춰 둔 장면
        self.fade_t = 0.0
        self.fade_in = FADE_SEC       # 시작할 때도 부드럽게 밝아짐
        self.overlay = pygame.Surface((WIDTH, HEIGHT))
        self.overlay.fill(FADE_COLOR)

    # ------------------------------------------------------------ 설정
    def apply_settings(self):
        st = self.profile.settings
        sfx.master = st["sfx"] / 100
        bgm.master = st["bgm"] / 100
        bgm.enabled = bool(st.get("bgm_on", True))
        bgm.apply_mute()

    def set_fullscreen(self, on: bool):
        if self.device["web"] or os.environ.get("SDL_VIDEODRIVER") == "dummy":
            return     # 브라우저는 자체 전체 화면을 쓴다
        try:
            flags = (pygame.SCALED | pygame.FULLSCREEN) if on else 0
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
        except pygame.error:
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT))

    # ------------------------------------------------------------ 장면 전환 (페이드)
    def change(self, make_scene):
        """make_scene: 새 장면을 만드는 함수. 화면이 어두워진 뒤에 호출된다."""
        if self.fade_next is None:
            self.fade_next = make_scene
            self.fade_t = 0.0

    @property
    def chief(self) -> dict:
        """함께 일하는 팀장(=난이도). 고르지 않았으면 '숙련된조교'."""
        return self.state.chief or self.data.chiefs[1]

    def day_cfg(self) -> dict:
        """오늘의 설정 = days.json 기본값 + 팀장(난이도) 보정."""
        cfg = dict(self.data.days[self.state.day_index])
        mods = self.chief["mods"]
        life = self.data.life                                   # 삶을 못 챙기면 일에도 지장이 생긴다
        cfg["time_limit"] = (cfg["time_limit"] * mods["time"] * time_factor(self.state.stress, life)
                             * health_factor(self.state.health, life))
        cfg["bids"] = cfg["bids"] + mods["bids"]
        cfg["violation_rate"] = max(0.2, min(0.8, cfg["violation_rate"] + mods["violation"]))
        return cfg

    # ------------------------------------------------------------ 메뉴
    def to_hub(self):
        self.change(lambda: HubScene(self))

    def to_factory(self):
        """납품하GO! 시작 화면 (새로 시작 / 이어하기)."""
        self.change(lambda: FactoryTitleScene(self))

    def start_factory(self, level: dict | None = None, saved: dict | None = None):
        self.change(lambda: FactoryScene(self, level, saved))

    def to_agency(self):
        """요청하GO! 시작 화면 (새로 시작 / 이어하기)."""
        self.change(lambda: AgencyTitleScene(self))

    def start_agency(self, level: dict | None = None, saved: dict | None = None):
        self.change(lambda: AgencyScene(self, level, saved))

    def to_home(self):
        """Esc·메뉴 버튼: 지금 장면이 정한 곳으로 돌아간다 (없으면 종료)."""
        home = self.scene.HOME
        if home == "hub":
            self.to_hub()
        elif home == "factory_title":
            self.to_factory()
        elif home == "agency_title":
            self.to_agency()
        elif home == "title":
            self.to_title()
        else:
            self.quit()

    def to_title(self):
        self.change(lambda: TitleScene(self))

    def to_select(self):
        self.change(lambda: SelectScene(self))

    def to_album(self, tab: str = "mates", back: str = "title"):
        """도감. 묶음의 모든 편이 같이 쓴다 — back: 돌아갈 곳 ('title' / 'hub' / 'factory')."""
        self.change(lambda: AlbumScene(self, tab, back))

    def to_settings(self):
        self.change(lambda: SettingsScene(self))

    def gear_rect(self):
        """게임 중 설정 단추의 자리 (이 장면에 단추가 없으면 None)."""
        pos = getattr(self.scene, "GEAR", None)
        if pos is None or self.under is not None:
            return None
        r = pygame.Rect(pos[0], pos[1], 32, 32)
        if self.device["touch"] and r.colliderect(MENU_BTN.inflate(8, 8)):      # 터치 기기의 '메뉴' 단추 옆으로
            r.x = MENU_BTN.right + 8
            r.y = MENU_BTN.y - 2
        return r

    def open_settings(self):
        """게임을 멈춰 두고 설정을 연다. 닫으면 하던 곳으로 그대로 돌아온다 (시간도 멈춰 있다)."""
        if self.under is None and self.fade_next is None:
            self.under = self.scene
            self.scene = SettingsScene(self, overlay=True)
            sfx.play("paper", 0.5)

    def close_settings(self):
        if self.under is not None:
            self.scene, self.under = self.under, None
            sfx.play("paper", 0.5)

    def quit(self):
        """게임 종료. 웹에서는 창을 닫을 수 없으므로 아무 일도 하지 않는다."""
        if not self.device["web"]:
            self.running = False

    # ------------------------------------------------------------ 저장 / 이어하기
    def save_game(self):
        save.write(self.profile.dir, self.state, self.chief["id"])

    def has_save(self) -> bool:
        return save.exists(self.profile.dir)

    def continue_game(self):
        loaded = save.read(self.profile.dir, self.data.chiefs)
        if loaded is None:
            return

        def make():
            self.state = loaded
            self.queue = []
            return BriefingScene(self)
        self.change(make)

    # ------------------------------------------------------------ 한 판의 흐름
    def new_game(self, chief: dict | None = None):
        def make():
            start = self.data.life["start"]
            self.state = GameState(chief=chief, money=start["money"], stress=start["stress"], health=start["health"],
                                   bond=start["bond"], fixed={f["id"]: f["cost"] for f in self.data.life["fixed"]})
            self.save_game()
            self.queue = [lambda: self.change(lambda: BriefingScene(self))]
            if self.chief["id"] == "easy":                      # 쌩신입: 첫 근무 전에 연습부터
                self.queue.insert(0, self.start_tutorial)
            return CGScene(self, "first_day")
        self.change(make)

    def start_tutorial(self):
        """연습 창구: 정상 업체 1곳 + 사업자번호가 다른 업체 1곳. 시간 제한도 기록도 없다."""
        def make():
            gen = self.generator
            notice = gen.make_notice(self.day_cfg())
            good = gen.make_clean(notice)
            bad = gen.make_clean(notice)
            while bad.form["사업자번호"] == good.form["사업자번호"]:
                bad = gen.make_clean(notice)
            gen._inj_r02(bad, notice)
            bad.injected = "R02"
            return DeskScene(self, notice, [good, bad], tutorial=True)
        self.change(make)

    def start_day(self):
        def make():
            cfg = self.day_cfg()
            cfg["bids"] += self.state.backlog               # 어제 남긴 잔업이 오늘 일에 얹힌다
            notice, bids = self.generator.make_day(cfg, bool(self.profile.data.get("factory", {}).get("clear")))
            return DeskScene(self, notice, bids)
        self.change(make)

    def begin_day_stats(self) -> DayStats:
        stats = DayStats(day=self.data.days[self.state.day_index]["day"])
        self.state.history.append(stats)
        return stats

    def over_limit(self) -> bool:
        """감사 경고가 이 팀장의 한도에 닿았는가 (쌩신입은 한도 없음)."""
        limit = self.chief.get("warn_limit", 0)
        return bool(limit) and self.state.warnings >= limit

    def bad_end(self):
        """감사 경고 누적: 감사실 CG → BAD 엔딩. 이어하기 기록은 지운다."""
        save.delete(self.profile.dir)
        self.queue = [lambda: self.change(lambda: EndingScene(self, bad=True))]
        self.show_cg("bad_end")

    def end_day(self, leftover: int = 0):
        """하루 끝. leftover = 18시까지 못 끝낸 건수 — 기한이 넉넉한 몇 건만 내일 잔업으로 넘어간다."""
        last = self.state.day_index >= len(self.data.days) - 1
        carried = 0 if last else min(leftover, self.data.life["backlog_max"])
        today = self.state.history[-1]
        today.leftover, today.carried = leftover, carried
        self.state.backlog = carried
        self.change(lambda: SummaryScene(self))

    def after_summary(self, pulls: int, promoted: bool):
        """정산이 끝난 뒤: (승진했으면 봉투 열기) → CG 한 장 → 퇴근 후 생활 사건 → 다음 날."""
        last = self.state.day_index >= len(self.data.days) - 1
        self.queue = []
        if pulls:
            self.queue.append(lambda: self.change(lambda: GachaScene(self, pulls)))
        if last:
            if self.chief["id"] == "hell":                       # 지옥 모드의 회수: 독한 팀장의 진짜 모습
                self.queue.append(lambda: self.show_cg("truth"))
            self.queue.append(lambda: self.show_cg("finale"))
            self.queue.append(lambda: self.change(lambda: RecapScene(self)))    # 이번 주에 배운 조달 정책
        else:
            if self.state.history[-1].spilled and "spill" not in self.state.run_cgs:     # 커피를 쏟은 날
                self.queue.append(lambda: self.show_cg("spill"))
            if self.state.history[-1].overtime:                 # 야근한 날은 야근 CG
                self.queue.append(lambda: self.show_cg("overtime"))
                if promoted:                                    # 승진 CG 는 놓치지 않게 이어서
                    self.queue.append(lambda: self._show_picked_cg(True, milestone_only=True))
            else:
                self.queue.append(lambda: self._show_picked_cg(promoted))
            self.queue.append(lambda: self.change(lambda: LifeScene(self)))     # 퇴근 후 생활 사건
        self.proceed()

    def _show_picked_cg(self, promoted: bool, milestone_only: bool = False):
        st = self.state
        cg_id = None
        if promoted:                                   # 승진한 날: 첫 승진 → 새 동료 순으로
            cg_id = next((c for c in ("promotion", "newmate") if c not in st.run_cgs), None)
        if cg_id is None and not milestone_only:
            cg_id = cg.pick_random(self.chief["id"], st.run_cgs, self.profile.data["cgs"], self.rng)
        if cg_id:
            self.show_cg(cg_id)
        else:
            self.proceed()

    def show_cg(self, cg_id: str):
        self.change(lambda: CGScene(self, cg_id))

    def proceed(self):
        """다음 할 일로. 남은 일이 없으면 다음 날로 넘어간다."""
        if self.queue:
            self.queue.pop(0)()
        else:
            self.next_day()

    def next_day(self):
        def make():
            if self.state.day_index >= len(self.data.days) - 1:
                save.delete(self.profile.dir)          # 끝까지 왔으면 이어하기 기록은 지운다
                return EndingScene(self)
            self.state.day_index += 1
            self.save_game()
            return BriefingScene(self)
        self.change(make)

    # ------------------------------------------------------------ 메인 루프
    def play_music(self):
        """지금 장면의 곡을 튼다 (장면이 '그대로 두기'를 원하면 건드리지 않는다)."""
        bgm.clear_mood()
        if self.scene.BGM != bgm.KEEP:
            bgm.play(self.scene.BGM)

    def step(self, dt):
        bgm.update(dt)
        if self.fade_next is not None:                 # 어두워지는 중: 입력·갱신 정지
            self.fade_t += dt
            if self.fade_t >= FADE_SEC:
                self.scene = self.fade_next()
                self.play_music()
                self.fade_next = None
                self.fade_in = FADE_SEC
        else:
            self.scene.update(dt)
            self.fade_in = max(0.0, self.fade_in - dt)
        self.mute_toast = max(0.0, self.mute_toast - dt)
        self.menu_ask = max(0.0, self.menu_ask - dt)
        if self.device["mobile"]:
            self.portrait_check -= dt
            if self.portrait_check <= 0:
                self.portrait_check = 0.5
                self.portrait = device.is_portrait()

    def handle(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:      # Esc: 타이틀로 (타이틀에서는 종료)
            if self.under is not None:                                         # 게임 중에 연 설정은 닫기만 한다
                self.close_settings()
                return
            self.to_home()
            return
        if event.type == pygame.KEYDOWN and event.key == pygame.K_m:
            sfx.muted = not sfx.muted
            bgm.apply_mute()
            self.mute_toast = 1.2
            return
        if self.portrait:
            return                                   # 세로 화면에서는 안내만 보여 준다
        if (self.device["touch"] and not isinstance(self.scene, HubScene)
                and event.type == pygame.MOUSEBUTTONDOWN and MENU_BTN.collidepoint(event.pos)):
            if self.menu_ask > 0:
                self.menu_ask = 0.0
                self.to_home()
            else:
                self.menu_ask = 2.5
            sfx.play("click", 0.4)
            return
        gear = self.gear_rect()
        if gear and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and gear.collidepoint(event.pos):
            self.open_settings()
            return
        if self.fade_next is None:
            self.scene.handle_event(event)

    def _draw_gear(self, r):
        s = self.screen
        hot = r.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(s, (255, 236, 170) if hot else (255, 250, 236), r, border_radius=9)
        pygame.draw.rect(s, (74, 52, 40), r, 3, border_radius=9)
        cx, cy = r.center
        for k in range(8):                                       # 톱니 여덟 개
            a = k * math.tau / 8
            pygame.draw.line(s, (74, 52, 40), (cx + math.cos(a) * 5, cy + math.sin(a) * 5),
                             (cx + math.cos(a) * 11, cy + math.sin(a) * 11), 5)
        pygame.draw.circle(s, (74, 52, 40), (cx, cy), 8)
        pygame.draw.circle(s, (255, 250, 236), (cx, cy), 3)

    def render(self):
        self.scene.draw(self.screen)
        gear = self.gear_rect()
        if gear:
            self._draw_gear(gear)
        alpha = 0
        if self.fade_next is not None:
            alpha = 255 * min(1.0, self.fade_t / FADE_SEC)
        elif self.fade_in > 0:
            alpha = 255 * (self.fade_in / FADE_SEC)
        if alpha:
            self.overlay.set_alpha(int(alpha))
            self.screen.blit(self.overlay, (0, 0))
        if self.device["touch"] and not isinstance(self.scene, HubScene):
            if self.menu_ask > 0:
                ui.pill(self.screen, (MENU_BTN.x, MENU_BTN.y, 230, MENU_BTN.h), "한 번 더 누르면 나가기",
                        (240, 120, 90), (255, 255, 255), 14)
            else:
                ui.pill(self.screen, MENU_BTN, "메뉴", (255, 250, 236), (74, 52, 40), 14)
        if self.portrait:
            self.screen.fill((255, 244, 222))
            ui.draw_text(self.screen, "휴대폰을 가로로 돌려 주세요", (WIDTH // 2, HEIGHT // 2 - 40), 64, (74, 52, 40),
                         "heavy", center=True)
            ui.draw_text(self.screen, "다함께 GO! 조달 한바퀴는 가로 화면 전용입니다", (WIDTH // 2, HEIGHT // 2 + 50), 36,
                         (150, 120, 100), True, center=True)
        if self.mute_toast > 0:
            ui.pill(self.screen, (WIDTH // 2 - 90, 60, 180, 36), "소리 끔" if sfx.muted else "소리 켬",
                    (74, 52, 40), (255, 255, 255), 17)

    async def run(self):
        last = time.perf_counter()
        while self.running:
            # 웹은 브라우저가 화면 주사율에 맞춰 불러 주므로 따로 기다리지 않는다 (기다리면 한 박자씩 놓쳐 30fps 로 떨어짐)
            if self.device["web"]:
                now = time.perf_counter()
                dt = min(now - last, 0.05)
                last = now
            else:
                dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.handle(event)
            self.step(dt)
            self.render()
            pygame.display.flip()
            self.frames += 1
            await asyncio.sleep(0)
        pygame.quit()


def selftest(out_dir: str):
    """빌드된 exe 점검용: `SimsasukGO.exe --selftest <폴더>`
    화면을 자동으로 넘기며 스크린샷과 점검 결과(selftest.txt)를 남기고 종료한다.
    실제 플레이 기록을 건드리지 않도록 기록 폴더를 점검 폴더 안으로 돌린다."""
    import traceback

    from game import fonts
    from game.config import DATA_DIR

    os.makedirs(out_dir, exist_ok=True)
    os.environ["JDC_PROFILE_DIR"] = os.path.join(out_dir, "profile")
    log = []
    try:
        app = App()

        def run(sec):
            for _ in range(int(sec * 60)):
                app.step(1 / 60)

        def shot(name):
            app.render()
            pygame.image.save(app.screen, os.path.join(out_dir, name))

        run(1.0)
        shot("0_hub.png")
        app.to_factory()
        run(1.0)
        shot("0_factory_title.png")
        app.start_factory()
        run(1.0)
        shot("0_factory.png")
        app.to_agency()
        run(1.0)
        shot("0_agency_title.png")
        app.start_agency()
        run(1.0)
        shot("0_agency.png")
        app.to_title()
        run(1.0)
        shot("1_title.png")
        app.new_game()
        run(1.5)
        shot("2_cg.png")
        app.proceed()
        run(2.5)
        shot("3_briefing.png")
        app.start_day()
        run(2.5)
        shot("4_desk.png")
        app.scene.decide(True)
        run(1.5)
        shot("5_stamp.png")
        app.end_day()
        run(2.5)
        shot("6_summary.png")
        app.to_album()
        run(1.0)
        shot("7_album.png")

        sounds = ["click", "pop", "stamp", "correct", "wrong", "bell", "fanfare", "blip_mid_1", "gacha_ssr"]
        for n in sounds:
            sfx.play(n, 0)
        loaded = sum(1 for n in sounds if sfx._cache.get(n))
        log += [
            "RESULT: OK",
            f"data dir: {DATA_DIR} (exists={os.path.isdir(DATA_DIR)})",
            f"companies={len(app.data.companies)} rules={len(app.data.rules)} roster={len(app.data.roster)} cgs={len(cg.CGS)}",
            f"font: {getattr(fonts.get(16), 'name', 'loaded')}",
            f"mixer: {pygame.mixer.get_init()}",
            f"sounds loaded: {loaded}/{len(sounds)}",
            f"music: {sum(bool(bgm.path(t['id'])) for t in app.data.music)}/{len(app.data.music)} ({bgm.path('hub')})",
            f"save exists: {app.has_save()}",
        ]
    except Exception:
        log = ["RESULT: FAIL", traceback.format_exc()]
    with open(os.path.join(out_dir, "selftest.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(log))
    pygame.quit()


if __name__ == "__main__":
    import sys

    if "--selftest" in sys.argv:
        idx = sys.argv.index("--selftest")
        selftest(sys.argv[idx + 1] if len(sys.argv) > idx + 1 else "selftest_out")
    else:
        asyncio.run(App().run())
