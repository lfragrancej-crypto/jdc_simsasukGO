"""심사숙GO! 조달청 — 진입점.

asyncio 루프로 작성되어 있어 그대로 pygbag(웹 html 빌드)에서도 동작한다.

게임 흐름
  타이틀(새로 시작/이어하기/도감/설정) → 팀장 선택 → [CG 첫 출근] → 브리핑 → 심사 → 정산
    → (승진했으면 봉투 열기) → [CG] → 다음 날 브리핑 → … → 5일차 정산 → [CG 마지막 퇴근] → 엔딩
  하루를 시작할 때마다 자동 저장 → '이어하기'는 그 날 아침부터.
"""
import asyncio
import os
import random
import time

import pygame

from game import bgm, cg, device, save, sfx, ui
from game.config import ASSET_DIR, FPS, HEIGHT, TITLE, WIDTH
from game.data_loader import load_all
from game.generator import BidGenerator
from game.profile import Profile
from game.scenes.album import AlbumScene
from game.scenes.briefing import BriefingScene
from game.scenes.cgscene import CGScene
from game.scenes.desk import DeskScene
from game.scenes.ending import EndingScene
from game.scenes.gacha import GachaScene
from game.scenes.life import LifeScene, health_factor, time_factor
from game.scenes.select import SelectScene
from game.scenes.settings import SettingsScene
from game.scenes.summary import SummaryScene
from game.scenes.title import TitleScene
from game.state import DayStats, GameState

FADE_SEC = 0.28
FADE_COLOR = (74, 52, 40)


MENU_BTN = pygame.Rect(8, 6, 74, 28)      # 터치 기기에서만 보이는 '메뉴'(타이틀로) 버튼


class App:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 1, 512)   # 짧은 버퍼 = 효과음 지연 최소화
        pygame.init()
        pygame.display.set_caption(TITLE)
        try:                                         # 창·작업표시줄 아이콘 (tools/make_icon.py)
            pygame.display.set_icon(pygame.image.load(os.path.join(ASSET_DIR, "icon.png")))
        except Exception:
            pass
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.data = load_all()
        self.state = GameState()
        self.generator = BidGenerator(self.data)
        self.rng = random.Random()        # 동료 뽑기·CG 고르기용 — 플레이할 때마다 다르게
        self.profile = Profile()          # 꺼도 남는 기록: 만난 동료, 클리어, 본 CG, 설정
        self.device = device.detect()     # PC 실행파일 / 웹 / 모바일 웹
        self.queue: list = []             # 정산 뒤에 차례로 할 일 (봉투 열기 → CG → 다음 날)
        self.running = True
        self.apply_settings()
        if self.profile.settings["fullscreen"]:
            self.set_fullscreen(True)
        self.scene = TitleScene(self)
        bgm.play(self.scene.BGM)
        self.mute_toast = 0.0
        self.frames = 0              # 그린 화면 수 (속도 점검용)
        self.menu_ask = 0.0          # 터치 기기의 '메뉴' 버튼: 한 번 누르면 확인, 한 번 더 누르면 타이틀로
        self.portrait = False        # 모바일에서 화면을 세로로 들고 있는가
        self.portrait_check = 0.0
        self.fade_next = None        # 페이드아웃 후 교체할 장면을 만드는 함수
        self.fade_t = 0.0
        self.fade_in = FADE_SEC       # 시작할 때도 부드럽게 밝아짐
        self.overlay = pygame.Surface((WIDTH, HEIGHT))
        self.overlay.fill(FADE_COLOR)

    # ------------------------------------------------------------ 설정
    def apply_settings(self):
        st = self.profile.settings
        sfx.master = st["sfx"] / 100
        bgm.master = st["bgm"] / 100
        bgm.apply_mute()

    def set_fullscreen(self, on: bool):
        if self.device["web"] or os.environ.get("SDL_VIDEODRIVER") == "dummy":
            return     # 브라우저는 자체 전체 화면을 쓴다
        try:
            flags = (pygame.SCALED | pygame.FULLSCREEN) if on else 0
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
        except pygame.error:
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT))

    # ------------------------------------------------------------ 장면 전환 (페이드)
    def change(self, make_scene):
        """make_scene: 새 장면을 만드는 함수. 화면이 어두워진 뒤에 호출된다."""
        if self.fade_next is None:
            self.fade_next = make_scene
            self.fade_t = 0.0

    @property
    def chief(self) -> dict:
        """함께 일하는 팀장(=난이도). 고르지 않았으면 '숙련된조교'."""
        return self.state.chief or self.data.chiefs[1]

    def day_cfg(self) -> dict:
        """오늘의 설정 = days.json 기본값 + 팀장(난이도) 보정."""
        cfg = dict(self.data.days[self.state.day_index])
        mods = self.chief["mods"]
        life = self.data.life                                   # 삶을 못 챙기면 일에도 지장이 생긴다
        cfg["time_limit"] = (cfg["time_limit"] * mods["time"] * time_factor(self.state.stress, life)
                             * health_factor(self.state.health, life))
        cfg["bids"] = cfg["bids"] + mods["bids"]
        cfg["violation_rate"] = max(0.2, min(0.8, cfg["violation_rate"] + mods["violation"]))
        return cfg

    # ------------------------------------------------------------ 메뉴
    def to_title(self):
        self.change(lambda: TitleScene(self))

    def to_select(self):
        self.change(lambda: SelectScene(self))

    def to_album(self):
        self.change(lambda: AlbumScene(self))

    def to_settings(self):
        self.change(lambda: SettingsScene(self))

    def quit(self):
        """게임 종료. 웹에서는 창을 닫을 수 없으므로 아무 일도 하지 않는다."""
        if not self.device["web"]:
            self.running = False

    # ------------------------------------------------------------ 저장 / 이어하기
    def save_game(self):
        save.write(self.profile.dir, self.state, self.chief["id"])

    def has_save(self) -> bool:
        return save.exists(self.profile.dir)

    def continue_game(self):
        loaded = save.read(self.profile.dir, self.data.chiefs)
        if loaded is None:
            return

        def make():
            self.state = loaded
            self.queue = []
            return BriefingScene(self)
        self.change(make)

    # ------------------------------------------------------------ 한 판의 흐름
    def new_game(self, chief: dict | None = None):
        def make():
            start = self.data.life["start"]
            self.state = GameState(chief=chief, money=start["money"], stress=start["stress"], health=start["health"],
                                   bond=start["bond"], fixed={f["id"]: f["cost"] for f in self.data.life["fixed"]})
            self.save_game()
            self.queue = [lambda: self.change(lambda: BriefingScene(self))]
            return CGScene(self, "first_day")
        self.change(make)

    def start_day(self):
        def make():
            cfg = self.day_cfg()
            cfg["bids"] += self.state.backlog               # 어제 남긴 잔업이 오늘 일에 얹힌다
            notice, bids = self.generator.make_day(cfg)
            return DeskScene(self, notice, bids)
        self.change(make)

    def begin_day_stats(self) -> DayStats:
        stats = DayStats(day=self.data.days[self.state.day_index]["day"])
        self.state.history.append(stats)
        return stats

    def over_limit(self) -> bool:
        """감사 경고가 이 팀장의 한도에 닿았는가 (쌩신입은 한도 없음)."""
        limit = self.chief.get("warn_limit", 0)
        return bool(limit) and self.state.warnings >= limit

    def bad_end(self):
        """감사 경고 누적: 감사실 CG → BAD 엔딩. 이어하기 기록은 지운다."""
        save.delete(self.profile.dir)
        self.queue = [lambda: self.change(lambda: EndingScene(self, bad=True))]
        self.show_cg("bad_end")

    def end_day(self, leftover: int = 0):
        """하루 끝. leftover = 18시까지 못 끝낸 건수 — 기한이 넉넉한 몇 건만 내일 잔업으로 넘어간다."""
        last = self.state.day_index >= len(self.data.days) - 1
        carried = 0 if last else min(leftover, self.data.life["backlog_max"])
        today = self.state.history[-1]
        today.leftover, today.carried = leftover, carried
        self.state.backlog = carried
        self.change(lambda: SummaryScene(self))

    def after_summary(self, pulls: int, promoted: bool):
        """정산이 끝난 뒤: (승진했으면 봉투 열기) → CG 한 장 → 퇴근 후 생활 사건 → 다음 날."""
        last = self.state.day_index >= len(self.data.days) - 1
        self.queue = []
        if pulls:
            self.queue.append(lambda: self.change(lambda: GachaScene(self, pulls)))
        if last:
            self.queue.append(lambda: self.show_cg("finale"))
        else:
            if self.state.history[-1].overtime:                 # 야근한 날은 야근 CG
                self.queue.append(lambda: self.show_cg("overtime"))
                if promoted:                                    # 승진 CG 는 놓치지 않게 이어서
                    self.queue.append(lambda: self._show_picked_cg(True, milestone_only=True))
            else:
                self.queue.append(lambda: self._show_picked_cg(promoted))
            self.queue.append(lambda: self.change(lambda: LifeScene(self)))     # 퇴근 후 생활 사건
        self.proceed()

    def _show_picked_cg(self, promoted: bool, milestone_only: bool = False):
        st = self.state
        cg_id = None
        if promoted:                                   # 승진한 날: 첫 승진 → 새 동료 순으로
            cg_id = next((c for c in ("promotion", "newmate") if c not in st.run_cgs), None)
        if cg_id is None and not milestone_only:
            cg_id = cg.pick_random(self.chief["id"], st.run_cgs, self.profile.data["cgs"], self.rng)
        if cg_id:
            self.show_cg(cg_id)
        else:
            self.proceed()

    def show_cg(self, cg_id: str):
        self.change(lambda: CGScene(self, cg_id))

    def proceed(self):
        """다음 할 일로. 남은 일이 없으면 다음 날로 넘어간다."""
        if self.queue:
            self.queue.pop(0)()
        else:
            self.next_day()

    def next_day(self):
        def make():
            if self.state.day_index >= len(self.data.days) - 1:
                save.delete(self.profile.dir)          # 끝까지 왔으면 이어하기 기록은 지운다
                return EndingScene(self)
            self.state.day_index += 1
            self.save_game()
            return BriefingScene(self)
        self.change(make)

    # ------------------------------------------------------------ 메인 루프
    def step(self, dt):
        if self.fade_next is not None:                 # 어두워지는 중: 입력·갱신 정지
            self.fade_t += dt
            if self.fade_t >= FADE_SEC:
                self.scene = self.fade_next()
                bgm.play(self.scene.BGM)
                self.fade_next = None
                self.fade_in = FADE_SEC
        else:
            self.scene.update(dt)
            self.fade_in = max(0.0, self.fade_in - dt)
        self.mute_toast = max(0.0, self.mute_toast - dt)
        self.menu_ask = max(0.0, self.menu_ask - dt)
        if self.device["mobile"]:
            self.portrait_check -= dt
            if self.portrait_check <= 0:
                self.portrait_check = 0.5
                self.portrait = device.is_portrait()

    def handle(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:      # Esc: 타이틀로 (타이틀에서는 종료)
            if isinstance(self.scene, TitleScene):
                self.quit()
            else:
                self.to_title()
            return
        if event.type == pygame.KEYDOWN and event.key == pygame.K_m:
            sfx.muted = not sfx.muted
            bgm.apply_mute()
            self.mute_toast = 1.2
            return
        if self.portrait:
            return                                   # 세로 화면에서는 안내만 보여 준다
        if (self.device["touch"] and not isinstance(self.scene, TitleScene)
                and event.type == pygame.MOUSEBUTTONDOWN and MENU_BTN.collidepoint(event.pos)):
            if self.menu_ask > 0:
                self.menu_ask = 0.0
                self.to_title()
            else:
                self.menu_ask = 2.5
            sfx.play("click", 0.4)
            return
        if self.fade_next is None:
            self.scene.handle_event(event)

    def render(self):
        self.scene.draw(self.screen)
        alpha = 0
        if self.fade_next is not None:
            alpha = 255 * min(1.0, self.fade_t / FADE_SEC)
        elif self.fade_in > 0:
            alpha = 255 * (self.fade_in / FADE_SEC)
        if alpha:
            self.overlay.set_alpha(int(alpha))
            self.screen.blit(self.overlay, (0, 0))
        if self.device["touch"] and not isinstance(self.scene, TitleScene):
            if self.menu_ask > 0:
                ui.pill(self.screen, (MENU_BTN.x, MENU_BTN.y, 230, MENU_BTN.h), "한 번 더 누르면 타이틀로",
                        (240, 120, 90), (255, 255, 255), 14)
            else:
                ui.pill(self.screen, MENU_BTN, "메뉴", (255, 250, 236), (74, 52, 40), 14)
        if self.portrait:
            self.screen.fill((255, 244, 222))
            ui.draw_text(self.screen, "휴대폰을 가로로 돌려 주세요", (WIDTH // 2, HEIGHT // 2 - 40), 64, (74, 52, 40),
                         "heavy", center=True)
            ui.draw_text(self.screen, "심사숙GO! 조달청은 가로 화면 전용입니다", (WIDTH // 2, HEIGHT // 2 + 50), 36,
                         (150, 120, 100), True, center=True)
        if self.mute_toast > 0:
            ui.pill(self.screen, (WIDTH // 2 - 90, 60, 180, 36), "소리 끔" if sfx.muted else "소리 켬",
                    (74, 52, 40), (255, 255, 255), 17)

    async def run(self):
        last = time.perf_counter()
        while self.running:
            # 웹은 브라우저가 화면 주사율에 맞춰 불러 주므로 따로 기다리지 않는다 (기다리면 한 박자씩 놓쳐 30fps 로 떨어짐)
            if self.device["web"]:
                now = time.perf_counter()
                dt = min(now - last, 0.05)
                last = now
            else:
                dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.handle(event)
            self.step(dt)
            self.render()
            pygame.display.flip()
            self.frames += 1
            await asyncio.sleep(0)
        pygame.quit()


def selftest(out_dir: str):
    """빌드된 exe 점검용: `SimsasukGO.exe --selftest <폴더>`
    화면을 자동으로 넘기며 스크린샷과 점검 결과(selftest.txt)를 남기고 종료한다.
    실제 플레이 기록을 건드리지 않도록 기록 폴더를 점검 폴더 안으로 돌린다."""
    import traceback

    from game import fonts
    from game.config import DATA_DIR

    os.makedirs(out_dir, exist_ok=True)
    os.environ["JDC_PROFILE_DIR"] = os.path.join(out_dir, "profile")
    log = []
    try:
        app = App()

        def run(sec):
            for _ in range(int(sec * 60)):
                app.step(1 / 60)

        def shot(name):
            app.render()
            pygame.image.save(app.screen, os.path.join(out_dir, name))

        run(1.0)
        shot("1_title.png")
        app.new_game()
        run(1.5)
        shot("2_cg.png")
        app.proceed()
        run(2.5)
        shot("3_briefing.png")
        app.start_day()
        run(2.5)
        shot("4_desk.png")
        app.scene.decide(True)
        run(1.5)
        shot("5_stamp.png")
        app.end_day()
        run(2.5)
        shot("6_summary.png")
        app.to_album()
        run(1.0)
        shot("7_album.png")

        sounds = ["click", "pop", "stamp", "correct", "wrong", "bell", "fanfare", "blip_mid_1", "gacha_ssr"]
        for n in sounds:
            sfx.play(n, 0)
        loaded = sum(1 for n in sounds if sfx._cache.get(n))
        log += [
            "RESULT: OK",
            f"data dir: {DATA_DIR} (exists={os.path.isdir(DATA_DIR)})",
            f"companies={len(app.data.companies)} rules={len(app.data.rules)} roster={len(app.data.roster)} cgs={len(cg.CGS)}",
            f"font: {getattr(fonts.get(16), 'name', 'loaded')}",
            f"mixer: {pygame.mixer.get_init()}",
            f"sounds loaded: {loaded}/{len(sounds)}",
            f"bgm path: {bgm._path('desk')}",
            f"save exists: {app.has_save()}",
        ]
    except Exception:
        log = ["RESULT: FAIL", traceback.format_exc()]
    with open(os.path.join(out_dir, "selftest.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(log))
    pygame.quit()


if __name__ == "__main__":
    import sys

    if "--selftest" in sys.argv:
        idx = sys.argv.index("--selftest")
        selftest(sys.argv[idx + 1] if len(sys.argv) > idx + 1 else "selftest_out")
    else:
        asyncio.run(App().run())
